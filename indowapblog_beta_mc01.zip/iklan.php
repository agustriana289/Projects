<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/


define('_IWB_', 1);

require_once('inc/indowapblog.php');
$live_chat='off';
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
switch ($cup)
{
case 'delete':
if (!$user_id)
relogin();
$id=htmlentities($_GET['id']);
if ($is_admin)
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."'");
}
else
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."' AND `site_id`='".$user_id."'");
}
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
}
else
{
$res=mysql_fetch_array($cek);
if (isset($_POST['yes']))
{
mysql_query("DELETE FROM `sponsor` WHERE `id`='".$res['id']."'");
header("Location: iklan.php?cup=pasang");
exit;
}
if (isset($_POST['no']))
{
header("Location: iklan.php?cup=pasang");
exit;
}
$head_title=$LANG['delete'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div class="content">';
if (empty($hasil))
echo $hasil;
echo '<b>'.$LANG['delete_confirm'].'</b><br /><form method="post" action="iklan.php?cup=delete&amp;id='.$id.'"><input type="submit" name="yes" value="'.$LANG['yes'].'"/><input type="submit" name="no" value="'.$LANG['no'].'"/></form>';
echo '</div>';
require_once('inc/foot.php');
}
break;

case 'edit':
if (!$user_id)
relogin();
$id=htmlentities($_GET['id']);
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."' AND `site_id`='".$user_id."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
}
else
{
$res=mysql_fetch_array($cek);
if (isset($_POST['cancel']))
{
header("Location: iklan.php?cup=pasang");
exit;
}
if (isset($_POST['save']))
{
$judul=$_POST['judul'];
$url=$_POST['url'];
$kontrak=$_POST['kontrak'];
if (empty($judul) || empty($url))
$err .='<li>Ada kesalahan pada pengisian formulir.</li>';
if (mb_strlen($judul) > 100 || mb_strlen($url) > 100)
$err .='<li>'.str_replace('::number::','100',$LANG['text_max']).'</li>';
if (empty($err))
{
mysql_query("UPDATE `sponsor` SET `title`='".mysql_real_escape_string($judul)."', `url`='".mysql_real_escape_string($url)."' WHERE `id`='".$res['id']."'");
header("Location: iklan.php?cup=pasang");
exit;
}
else
{
$hasil='<div class="eror">'.$err.'</div>';
}
}
$head_title=$LANG['edit'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hasil))
echo $hasil;
echo '<form method="post" action="iklan.php?cup=edit&amp;id='.$id.'"><h1>'.$LANG['title'].'</h1><input type="text" name="judul" maxlenght="100" value="'.htmlspecialchars($res['title']).'"/><br /><h1>'.$LANG['link'].'</h1><input type="text" name="url" maxlenght="100" value="'.htmlspecialchars($res['url']).'"/><br /><span>Max 100 karakter</span><br/><input type="submit" name="save" value="'.$LANG['save'].'"/><input type="submit" name="cancel" value="'.$LANG['cancel'].'"/></form>';
echo '</div>';
require_once('inc/foot.php');
}
break;

case 'pasang':
if (!$user_id)
relogin();
$head_title=$LANG['add_new'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div class="content">';
if ($indowapblog['credit'] < '7000')
{
minim_credit();
}
else
{
if (isset($_POST['send']))
{
$judul=$_POST['judul'];
$url=$_POST['url'];
$kontrak=$_POST['kontrak'];
$code=$_POST['code'];
if (empty($judul) || empty($url) || empty($kontrak))
$err .='<div class=eror>'.$LANG['empty_text'].'</div>';
if (mb_strlen($judul) > 100 || mb_strlen($url) > 100)
$err .='<div class=eror>'.str_replace('::number::','100',$LANG['text_max']).'</div>';
if ($kontrak != 7 && $kontrak != 15 && $kontrak != 30)
$err .='<div class=eror>'.$LANG['incorrect_data'].'</div>';
if ($kontrak == 7)
{
$harga='10000';
}
elseif ($kontrak == 15)
{
$harga='15000';
}
else
{
$harga='25000';
}

if ($code != $_SESSION['captcha_code'])
$err .='<div class=eror>'.$LANG['incorrect_security_code'].'</div>';
if ($indowapblog['credit'] < $harga)
$err .='<div class=eror>'.str_replace('::number::','...',str_replace('::more::','',$LANG['minim_credit'])).'</div>';
if (empty($err))
{
$hari='86400';
$expired = time() + ($hari * $kontrak);
mysql_query("INSERT INTO `sponsor` SET `site_id`='".$user_id."', `title`='".mysql_real_escape_string($judul)."', `url`='".mysql_real_escape_string($url)."', `expired`='".$expired."', `time`='".time()."'");
$kredit = $indowapblog['credit'] - $harga;
mysql_query("UPDATE `user` SET `credit`='".$kredit."' WHERE `id`='".$user_id."'");
$hasil='<div class=succes>'.$LANG['successfully_added'].'</div>';
}
else
{
$hasil='<div class=eror>'.$err.'</div>';
}
}
if ($hasil)
echo ' '.$hasil.' ';
echo '<form method="post" action="iklan.php?cup=pasang"><h1>'.$LANG['title'].'</h1><input type="text" name="judul" maxlenght="100" value=""/><br /><h1>'.$LANG['link'].'</h1><input type="text" name="url" maxlenght="100" value="http://"/><br /><h1>'.$LANG['lama_kontrak'].'</h1><select name="kontrak"><option value="7">7 Hari</option><option value="15">15 Hari</option><option value="30">30 Hari</option></select><br />';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h1>'.$LANG['security_code'].'</h1><img src="captcha.php" alt=""/><br /><input type="text" name="code" value=""/><br/><input type="submit" name="send" value="'.$LANG['save'].'"/></form>';
if ($is_admin)
{
$cek=mysql_query("SELECT * FROM `sponsor` ORDER BY `time` desc");
}
else
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `site_id`='".$user_id."' ORDER BY `time` desc");
}
if (mysql_num_rows($cek) == 0)
{
}
else
{
echo '<br /><h1>Iklan Anda</h1>';
while ($res=mysql_fetch_array($cek))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo '<a href="'.htmlspecialchars($res['url']).'">'.htmlspecialchars($res['title']).'</a><br />'.$LANG['show'].': '.$res['show'].'<br />'.$LANG['click'].': '.$res['click'].'<br />'.$LANG['added'].': '.waktu($res['time']).'<br />'.$LANG['expired'].': '.waktu($res['expired']).'<br />';
if ($is_admin)
echo ''.$LANG['by'].': '.iwbid($res['site_id']).'<br />';
echo '<a href="iklan.php?cup=edit&amp;id='.$res['id'].'">'.$LANG['edit'].'</a> | <a class="delete" href="iklan.php?cup=delete&amp;id='.$res['id'].'">'.$LANG['delete'].'</a>';
++$i;
echo '</div>';
}
}
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'info':
$head_title=$LANG['advertisement'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div class="content"><form method="get" action="iklan.php"><input type="hidden" name="cup" value="pasang"/><input type="submit" value="'.$LANG['add_new'].'"/></form><br />';
echo $LANG['advertisement_info'];
echo '<br /><table border="1"><tr><th>'.$LANG['lama_kontrak'].'</th><th>'.$LANG['price'].'</th></tr><tr><td>7 '.$LANG['day'].'</td><td>Rp 10.000</td></tr><tr><td>15 '.$LANG['day'].'</td><td>Rp 15.000</td></tr><tr><td>30 '.$LANG['day'].'</td><td>Rp 25.000</td></tr></table><br />';
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align: center;"><a style="color: green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}
echo '<br /><form method="get" action="iklan.php"><input type="hidden" name="cup" value="pasang"/><input type="submit" value="'.$LANG['add_new'].'"/></form><br /></div></div>';
echo '</div>';
require_once('inc/foot.php');
break;
default:
$head_title=$LANG['advertisement'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div class="content"><form method="get" action="iklan.php"><input type="hidden" name="cup" value="info"/><input type="submit" value="'.$LANG['add_new'].'"/></form><br />';
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY `time` desc;");
if (mysql_num_rows($cekadsponsor) != 0)
{
while ($adsponsor=mysql_fetch_array($cekadsponsor))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align: center;"><a style="color: green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
++$i;
echo '</div>';
}
}
echo '<br /><form method="get" action="iklan.php"><input type="hidden" name="cup" value="info"/><input type="submit" value="'.$LANG['add_new'].'"/></form>';
echo '</div>';
require_once('inc/foot.php');
break;
}
?>