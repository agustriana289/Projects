<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
require_once('inc/indowapblog.php');
if ($user_id)
{
echo '<div class="title">'.$LANG['add_new'].'</div>';
echo '<div class="menu"><a href="post.php">'.$LANG['post'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=category">'.$LANG['category'].'</a></div>';
echo '<div class="menu"><a href="file.php">'.$LANG['file'].'</a></div>';
echo '<div class="title">'.$LANG['edit'].'</div>';
echo '<div class="menu"><a href="post.php?cup=manage">'.$LANG['post'].'</a></div>';
echo '<div class="menu"><a href="file.php">'.$LANG['file'].'</a></div>';
echo '<div class="menu"><a href="manage_comment.php?">'.$LANG['comments'].'</a></div>';
echo '<div class="menu"><a href="manage_guestbook.php?">'.$LANG['guestbook'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=following">'.$LANG['following'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=navigation">'.$LANG['navigation'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=css_editor">'.$LANG['theme'].'</a></div>';
echo '<div class="title">'.$LANG['settings'].'</div>';
echo '<div class="menu"><a href="dashboard.php?cup=settings">'.$LANG['blog'].'</a></div>';
echo '<div class="menu"><a href="iklan.php">'.$LANG['ads'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=domain_parking">'.$LANG['domain_parking'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=google">'.$LANG['google_verification'].'</a></div>';
echo '<div class="title">'.$LANG['community'].'</div>';
echo '<div class="menu"><a href="kb.php">'.$LANG['knowledge_base'].'</a></div>';
echo '<div class="menu"><a href="user.php?cup=list">'.$LANG['users_list'].'</a></div>';
echo '<div class="title">'.$LANG['other'].'</div>';
echo '<div class="menu"><a href="dashboard.php?cup=stats">'.$LANG['statistics'].'</a></div>';
echo '<div class="menu"><a href="kuis.php">'.$LANG['quiz'].'</a></div>';
echo '<div class="menu"><a href="new.php">'.$LANG['latest_post'].'</a></div>';
}
else
{
echo '<div class="title">'.$LANG['bookmark'].'</div>';
echo '<div class="menu"><a href="'.$site['url'].'/home.xhtml">'.$LANG['official_blog'].'</a></div>';
echo '<div class="menu"><a href="'.$site['url'].'/feedback.xhtml">'.$LANG['contact_us'].'</a></div>';
echo '<div class="menu"><a href="http://ngecuplis.com">Official WapMasTer</a></div>';
echo '<div class="menu"><a href="http://indowapblog.com">IndoWapBlog</a></div>';
echo '<div class="menu"><a href="'.$site['url'].'/iklan.php">'.$LANG['advertisement'].'</a></div>';
echo '<div class="title">Pengelola</div>';
$req=mysql_query("SELECT id, name FROM user ORDER BY date_reg DESC LIMIT 5;");
while ($res=mysql_fetch_array($req))
{
echo '<div class="menu"><a href="'.$site['url'].'/user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a></div>';
}
echo '<div class="title">Posting Terbaru</div>';
$req=mysql_query("SELECT site_id, title, link, time FROM blog WHERE link != 'hallo-dunia' AND draft = '0' ORDER BY time DESC LIMIT 5;");
while ($res=mysql_fetch_array($req))
{
$site_post=mysql_fetch_array(mysql_query("SELECT name, url FROM site WHERE id='".$res['site_id']."'"));
echo '<div class="menu"><a href="'.$site_post['url'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br/><font color="#555">'.time_ago($res['time']).'</font></div>';
}
echo '<div class="menu"><a href="new.php"><font color="#555">'.$LANG['next'].' &raquo;</font></a></div>';
}
?>