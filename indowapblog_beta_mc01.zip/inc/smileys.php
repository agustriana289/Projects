<?php

defined('_IWB_') or die('Akses Terlarang');
$sm_code = array(':50rb:' => '<img src="http://indowapblog.com/images/smiley/50rb.gif" alt="50rb"/>',
':aah:' => '<img src="http://indowapblog.com/images/smiley/aah.gif" alt="aah"/>',
':amin1:' => '<img src="http://indowapblog.com/images/smiley/amin1.gif" alt="amin1"/>',
':iwb:' => '<b>IndoWapBlog</b>');
?>