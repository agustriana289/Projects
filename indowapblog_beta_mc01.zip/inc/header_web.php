<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

$root=isset($root) ? $root : '';

$head_title=isset($head_title) ? $head_title : $site['name'];

$head_title=htmlspecialchars($head_title);
$deskripsi=isset($head_description) ? $head_description : $site['description'];

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">';
echo '<html xmlns="http://www.w3.org/1999/xhtml">';
echo '<head>';
echo '<title>'.$head_title.'</title>';
echo '<meta name="description" content="'.htmlspecialchars($deskripsi).'" />';
echo '<meta name="viewport" content="width=320" />';
echo '<meta name="viewport" content="initial-scale=1.0" />';
echo '<meta name="viewport" content="user-scalable=false" />';
echo '<meta http-equiv="Cache-Control" content="max-age=1" />';
echo '<meta name="HandheldFriendly" content="True" />';
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
echo '<meta name="Keywords" content="Mobile Blogging Powered By SC54"/>';
echo '<meta name="Copyright" content="� SC54 2014"/>';
echo '<meta name="Author" content="Silent54"/>';
echo '<meta name="Email" content="silentcrew54 [at] gmail [dot] com"/>';
echo '<meta name="Charset" content="UTF-8"/>';
echo '<meta name="Distribution" content="Global"/>';
echo '<meta name="google-site-verification" content="" />';
echo '<meta name="Rating" content="General"/>';
echo '<meta name="Robots" content="INDEX,FOLLOW"/>';
echo '<meta name="Revisit-after" content="1 Day"/>';
echo '<link rel="stylesheet" href="'.$site['url'].'/style/desktop/style.css" type="text/css" media="all"/>';
echo '<link rel="shortcut icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" />';
echo '</head>';
echo '<body><div class="header"><h2 class="logo">';
if (!empty($site['logo'])){
echo htmlspecialchars($site['name']);
}
else
{
echo htmlspecialchars($site['name']);
}
echo '</h2>';
echo '<h2 class="description">'.htmlspecialchars($deskripsi).'</h2>';
echo '</div>';
echo '<div class="mhoza">';
echo '<ul>';
echo '<li class="cakep"><a href="'.$site['url'].'"><span>Home</span></a></li>';
if ($user_id)
{
echo '<li><a href="'.$site['url'].'/user.php"><span>'.$LANG['profile'].'</span></a></li><li><a href="'.$site['url'].'/message.php"><span>'.$LANG['message'].'</span></a></li>';
if ($is_admin)
echo '<li class="last"><a href="'.$site['url'].'/owner.php"><span>'.$LANG['admin_panel'].'</span></a></li>';
echo '<li><a href="'.$user_site.'/home.xhtml"><span>'.$LANG['visit_blog'].'</span></a></li><li><a href="'.$user_site.'/login.php?cup=logout"><span>'.$LANG['logout'].'</span></a></li>';
}else{
echo '<li><a href="'.$user_site.'/login.php"><span>'.$LANG['login'].'</span></a></li><li><a href="'.$user_site.'/register.php"><span>'.$LANG['registration'].'</span></a>';
}
echo '</ul>';
echo '</div>';
if ($user_id)
{
include(''.$root.'inc/live_chat.php');
}
echo '<div class="left">';
include(''.$root.'inc/menu.php');
echo '</div>';
echo '<div class="anu">';

if ($user_id)
{
if ($indowapblog['ban'] == 1)
{
echo '<div class="content">';
echo '<div class="succses">'.str_replace('::id::',$user_id,str_replace('::username::',$user_username,str_replace('::email::',$user_email,$LANG['user_blocked']))).'</div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");

if (mysql_num_rows($ip_cek) != 0)
{
$ip_blocked=mysql_fetch_array($ip_cek);

echo '<div class="content">';
echo '<div class="succses">'.str_replace('::ip::',$ip_blocked['ip'],$LANG['ip_blocked']).'</div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
}

if ($user_id)
{
$kuis=mysql_query("SELECT id, pertanyaan FROM kuis WHERE status='1' AND time > '".time()."' ORDER BY id DESC LIMIT 3;");
if (mysql_num_rows($kuis) != 0)
{
while ($quis=mysql_fetch_array($kuis))
{
$new .='<div class="succses">&raquo; '.$LANG['quiz'].': '.bbsm(substr($quis['pertanyaan'],0,30)).'...<a href="'.$site['url'].'/kuis.php?cup=read&amp;id='.$quis['id'].'#show_bar">&raquo;</a></div>';
}
}
$total_pms=mysql_result(mysql_query("select count(*) as Num from `pm` where `receiver_id`='".$user_id."' and `read`='1'"), 0);
if ($total_pms > 0)
$new .='<div class="succses">&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/message.php?">'.$total_pms.'</a>',$LANG['pm_notification']).'</div>';
if ($dashboard == 'on')
{
$taim = time() - 172800;
$total_following_post=mysql_result(mysql_query("select count(*) as Num from `following_post` where `read` LIKE '%<".$user_id.">%' and `time`>'".$taim."'"), 0);
if ($total_following_post > 0)
$new .='<div class="succses">&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/dashboard.php?cup=following&amp;action=read">'.$total_following_post.'</a>',$LANG['following_notification']).'</div>';

$total_kom=mysql_result(mysql_query("select count(*) as Num from `comment` where `site_id`='".$user_id."' and `status`='0'"), 0);

$total_gb=mysql_result(mysql_query("select count(*) as Num from `guestbook` where site_id='".$user_id."' and `status`='0'"), 0);

if ($total_kom > 0)
$new .='<div class="succses">&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_comment.php?cup=unapproved">'.$total_kom.'</a>',$LANG['comment_notification']).'</div>';

if ($total_gb > 0)
$new .='<div class="succses">&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_guestbook.php?cup=unapproved">'.$total_gb.'</a>',$LANG['guestbook_notification']).'</div>';

} else { }
$notify=mysql_query("select `id`,`text`,`time` from `pm` where `receiver_id`='".$user_id."' and `read`='2' order by `time` desc limit 1;");
if (mysql_num_rows($notify) != 0)
{
$notice=mysql_fetch_array($notify);
$new .='<div class="succses">&raquo; '.html_entity_decode(bbsm($notice['text'])).'</div>';
mysql_query("DELETE FROM `pm` WHERE `id`='".$notice['id']."' OR `text`='".mysql_real_escape_string($notice['text'])."'");
}
if (!empty($new))
echo '<div class="succses">'.$new.'</div>';
}
?>