<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');
echo '</div>';
echo '<div style="clear:both;"></div>';
echo '<div class="footer">';
include(''.$root.'inc/adsense.php');
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}

echo '<a href="'.$site_url.'/language.php?lang=id&amp;back_uri='.urlencode(''.$site_url . $_SERVER['REQUEST_URI'].'').'"><img src="'.$site_url.'/images/id.png" alt="ID"/></a>&nbsp;<a href="'.$site_url.'/language.php?lang=en&amp;back_uri='.urlencode(''.$site_url . $_SERVER['REQUEST_URI'].'').'"><img src="'.$site_url.'/images/en.png" alt="EN"/></a><br/>';
echo '<p>&copy; '.date('Y',time()).' <a href="http://sc54.a78.org">Official</a><br/>All Right Reserved</p></div>';
echo '</body></html>';
mysql_close($iwb_connect);
?>