<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$id=$_GET['id'];

$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$res=mysql_fetch_array($cek);

if (isset($_GET['yes']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
mysql_query("update user set ban='0' where id='".mysql_real_escape_string($id)."'");
header('location: user.php?cup=list');
}
$head_title='Batalkan Pemblokiran';
require_once('inc/head.php');
echo '<div class="content">';
echo '<p>Anda yakin ingin membatalkan <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> dari pemblokiran?<br/>[<a href="owner.php?cup=unbanned&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="user.php?cup=list">TIDAK</a>]</p>';
echo '</div>';
require_once('inc/foot.php');

?>