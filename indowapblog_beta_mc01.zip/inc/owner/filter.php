<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlang!');
if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$page = $_GET['page'];
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM replace_text WHERE type != 'smiley'"), 0);
if (empty($page) || !ctype_digit($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page = 1;
$page--;
$max_view = $site['num_post_main'];
$limit = $page * $max_view;
$page++;
if (isset($_GET['edit'])) {
$id = $_GET['edit'];
if ($cek = mysql_fetch_array(mysql_query("SELECT * FROM replace_text WHERE id = '".mysql_real_escape_string($id)."'"))) {
$_go = "owner.php?cup=filter&amp;edit=".$cek['id']."&amp;page=".$page;
$_key = $cek['key'];
$_value = $cek['value'];
$_name = 'edit';
}
else {
header("Location: owner.php?cup=filter");
exit;
}
}
else {
$_go = "owner.php?cup=filter&amp;page=".$page;
$_key = '';
$_value = '';
$_name = 'add';
}
$key = $_POST['key'];
$value = $_POST['value'];
if (isset($_POST['edit'])) {
if (empty($key)) {
$hasil = '<div class="eror">'.$LANG['empty_text'].'</div>';
}
else {

mysql_query("UPDATE `replace_text` SET `key`='".mysql_real_escape_string($key)."', `value`='".mysql_real_escape_string($value)."' WHERE `id`='".mysql_real_escape_string($id)."'");
$hasil = '<div class="succes">'.$LANG['change_saved'].'</div>';
}
}
elseif (isset($_POST['add'])) {
if (empty($key)) {
$hasil = '<div class="eror">'.$LANG['empty_text'].'</div>';
}
else {
mysql_query("insert into `replace_text` set `key`='".mysql_real_escape_string($key)."', `value`='".mysql_real_escape_string($value)."', `type`='text'");
$hasil = '<div class"succes">Filter text '.$LANG['successfully_added'].'</div>';
}
}
elseif (isset($_GET['delete'])) {
if (mysql_query("DELETE FROM replace_text WHERE id = '".mysql_real_escape_string($_GET['delete'])."'"))
{
$hasil = '<div id="success">Deleted successfully</div>';
$_go = "owner.php?cup=filter&amp;page=".$page;
$_key = '';
$_value = '';
$_name = 'add';
}
else {
$hasil = '<div id="error">Can\'t deleted!</div>';
$_go = "owner.php?cup=filter&amp;page=".$page;
$_key = '';
$_value = '';
$_name = 'add';
}
}
else {
}
$head_title='Word Filter';
require_once('inc/head.php');
echo '<div class="content">';
if ($hasil)
echo $hasil;
echo '<div class="notif"><a href="owner.php?cup=filter">Filter Text</a></div>';
echo '<form method="post" action="'.$_go.'"><h1>'.$LANG['text'].'</h1><input name="key" value="'.htmlentities($_key).'"/><br /><h1>Replace To</h1><input name="value" value="'.htmlentities($_value).'"/><br /><input type="submit" name="'.htmlentities($_name).'" value="'.$LANG['save'].'"/></form><br />';
if ($total == 0) {
}
else {
$q = mysql_query("SELECT * FROM replace_text WHERE type != 'smiley' ORDER BY id DESC LIMIT $limit, $max_view");
while ($res = mysql_fetch_array($q)) {
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo ''.$LANG['text'].': <b>'.htmlentities($res['key']).'</b><br />'.$LANG['result'].': '.iwb_html($res['value']).'<br /><span>[<a href="owner.php?cup=filter&amp;edit='.$res['id'].'">'.$LANG['edit'].'</a>][<a href="owner.php?cup=filter&amp;delete='.$res['id'].'">'.$LANG['delete'].'</a>]</span>';
++$i;
echo '</div>';
}
$link='owner.php?cup=filter&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');
?>