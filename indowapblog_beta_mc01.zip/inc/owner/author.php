<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/


defined('_IWB_') or die('Akses Terlarang!');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$id=$_GET['id'];
if (isset($_GET['id']))
{
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
$head_title='Hapus Penulis';
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="owner.php?cup=author">List Penulis</a> | <a href="owner.php?cup=author&amp;action=add">Tambah Penulis</a> | Hapus Penulis</div><div class="eror">Tidak ada pengguna yang dipilih</div></div>';
require_once('inc/foot.php');
exit;
}
$res=mysql_fetch_array($cek);
if (isset($_GET['yes']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("update user set author='0' where id='".mysql_real_escape_string($id)."'");
header('location: owner.php?cup=author');
}
}
}
$head_title='Hapus Penulis';
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="owner.php?cup=author">List Penulis</a> | <a href="owner.php?cup=author&amp;action=add">Tambah Penulis</a> | Hapus Penulis</div>';
if (isset($_GET['id']))
{
echo '<p>Anda yakin ingin menghapus <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai penulis?<br/>[<a href="owner.php?cup=author&amp;action=delete&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="owner.php?cup=author">TIDAK</a>]</p>';
}
else
{
echo '<form action="owner.php" method="get"><input type="hidden" name="cup" value="author"/><input type="hidden" name="action" value="delete"/>Pilih Penulis:<br/>
<select name="id">
<option value=""></option>';
$REQ=mysql_query("select * from user where author='1' and admin='0' order by name desc");
while ($RES=mysql_fetch_array($REQ))
{
echo '<option value="'.$RES['id'].'">'.htmlspecialchars($RES['name']).'</option>';
}

echo '</select><br/><input type="submit" value="Hapus Penulis"/></form>';
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'add':
if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$id=$_GET['id'];
if (isset($_GET['id']))
{
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
$head_title='Tambah Penulis';
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="owner.php?cup=author">List Penulis</a> | Tambah Penulis | <a href="owner.php?cup=author&amp;action=delete">Hapus Penulis</a></div><p>Tidak ada pengguna yang dipilih</p></div>';
require_once('inc/foot.php');
exit;
}
$res=mysql_fetch_array($cek);

if (isset($_GET['yes']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("update user set author='1' where id='".mysql_real_escape_string($id)."'");
header('location: owner.php?cup=author');
}
}
}
$head_title='Tambah Penulis';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="owner.php?cup=author">List Penulis</a> | Tambah Penulis | <a href="owner.php?cup=author&amp;action=delete">Hapus Penulis</a></div>';
if (isset($_GET['id']))
{
echo '<p>Anda yakin ingin menjadikan <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai penulis?<br/>[<a href="owner.php?cup=author&amp;action=add&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="owner.php?cup=author">TIDAK</a>]</p>';
}
else
{
echo '<form action="owner.php" method="get"><input type="hidden" name="cup" value="author"/><input type="hidden" name="action" value="add"/>Pilih Member:<br/>
<select name="id">
<option value=""></option>';
$REQ=mysql_query("select * from user where author='0' order by name desc");
while ($RES=mysql_fetch_array($REQ))
{
echo '<option value="'.$RES['id'].'">'.htmlspecialchars($RES['name']).'</option>';
}

echo '</select><br/><input type="submit" value="Jadikan Penulis"/></form>';
}
echo '</div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title='List Penulis';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div class="content">';
echo '<div class="notif">List Penulis | <a href="owner.php?cup=author&amp;action=add">Tambah Penulis</a> | <a href="owner.php?cup=author&amp;action=delete">Hapus Penulis</a></div>';
echo '<ol>';
$total=mysql_result(mysql_query("select count(*) as num from user where author='1' and admin='0'"), 0);
if ($total == 0)
{
echo '<div class="eror">Belum ada penulis lain selain Anda</div>';
}
else
{
$req=mysql_query("select * from user where author='1' and admin='0' order by name desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'" /> <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a><br/>';
echo 'IP: '.$res['ip_browser'].' <span class="action_links">[';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="dashboard.php?cup=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="dashboard.php?cup=unblock_ip&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ']</span><br/>IP Proxy: '.$res['ip_proxy'].' <span class="action_links">[';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="dashboard.php?cup=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="dashboard.php?cup=unblock_ip&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ']</span><br/><span class="action_links"><a class="delete" href="dashboard.php?cup=author&amp;action=delete&amp;id='.$res['id'].'">Hapus Penulis</a></span>';
++$i;
echo '</li>';
}
}
echo '</ol>';
$link='owner.php?cup=author&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
}
?>