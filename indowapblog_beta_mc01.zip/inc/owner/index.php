<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');
if (!$user_id)
relogin();
$head_title='Admin Panel';
require_once('inc/head.php');
echo '<div class="content">';
if (!$is_admin)
{
forbidden();
}
else
{
echo '<div class="title">Admin Panel</div><div class="menu"><a href="owner.php?cup=post">Kelola Post</a></div><div class="menu"><a href="owner.php?cup=author">Kelola Author</a></div><div class="menu"><a href="owner.php?cup=filter">Word Filter</a></div><div class="menu"><a href="owner.php?cup=backup">Backup SQL</a></div><div class="menu"><a href="'.$site['url'].'/dashboard.php?cup=ads">'.$LANG['advertisement'].'</a></div>';
}
echo '</div>';
require_once('inc/foot.php');
?>