<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

switch ($action) {

case 'edit':
break;
case 'delete':
$id = $_GET['id'];
mysql_query("DELETE FROM blog WHERE id='".mysql_real_escape_string($id)."'") or die("Blog Not Found");
mysql_query("DELETE FROM comment WHERE blog_id='".mysql_real_escape_string($id)."'");
header("Location: owner.php?cup=post");
break;

default:
$search = isset($_GET['search']) ? trim(urlencode($_GET['search'])) : '';
if (isset($_GET['search']))
{
$page=$_GET['page'];
$total=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE title LIKE '%".mysql_real_escape_string(urldecode($search))."%'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title=''.$LANG['search_for'].' '.urldecode($q);
}
else
{
$head_title=$LANG['search'];
}
require_once('inc/head.php');

echo '<div class="content">';
echo '<form action="owner.php" method="get"><input type="hidden" name="cup" value="post"><input name="search" type="text" value="'.htmlspecialchars(urldecode($search)).'"/><input type="submit" value="'.$LANG['search_submit'].'"/></form><br />';
if (isset($_GET['search']))
{
echo '<div class="succes">'.str_replace('::number::',$total,str_replace('::query::',htmlspecialchars(urldecode($search)),$LANG['search_result'])).'</div>';
if ($total > 0)
{
$req=mysql_query("SELECT * FROM blog WHERE title LIKE '%".mysql_real_escape_string(urldecode($search))."%' ORDER BY time DESC LIMIT $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
$st_posted = mysql_fetch_array(mysql_query("SELECT site FROM user WHERE id='".$res['site_id']."'"));
echo '<a href="'.$st_posted['site'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br ><a href="owner.php?cup=post&amp;action=delete&amp;id='.$res['id'].'">Delete</a><br />'.$LANG['by'].': '.iwbid($res['site_id']).'<br />'.$LANG['date'].': '.time_ago($res['time']);
++$i;
echo '</div>';
}
}
else
{
echo '<div class="eror">'.$LANG['search_not_found'].'</div>';
}
$link='owner.php?cup=post&amp;search='.htmlentities($search).'&amp;page=';
$x='';
pagination($page,$max_view,$total,$link,$x);
}
else {
}
echo '</div>';
require_once('inc/foot.php');
break;
}
?>