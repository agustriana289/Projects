<?php
/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
list($msec,$sec)=Explode(CHR(32),MicroTime());
$headtime=$sec+$msec;
require_once(''.$root.'inc/mobile_detect.class.php');
$detect = new mobile_detect();
if (!$detect->isMobile())
{
include(''.$root.'inc/header_web.php');
}
else {
include(''.$root.'inc/header_wap.php');
}
?>
