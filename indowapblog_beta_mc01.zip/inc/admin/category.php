<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
$cid=htmlentities($_GET['cid']);
if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$req=mysql_query("select * from category where id='".mysql_real_escape_string($cid)."' and site_id='".$user_id."'");
if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
if (isset($_GET['yes']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("delete from category where id='".mysql_real_escape_string($cid)."' and site_id='".$user_id."'");
header('location: dashboard.php?cup=category');
}
}
$head_title=''.$LANG['delete'].' '.$LANG['category'];
require_once('inc/head.php');
echo '<div class="content"><p>'.$LANG['delete_confirm'].'<br/><a href="dashboard.php?cup=category&amp;action=delete&amp;cid='.$cid.'&amp;yes">'.$LANG['yes'].'</a> <a href="dashboard.php?cup=category">'.$LANG['no'].'</a></p></div>';
require_once('inc/foot.php');
break;

case 'edit':
$cid=htmlentities($_GET['cid']);
if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$cat=mysql_query("select * from category where id='".mysql_real_escape_string($cid)."' and site_id='".$user_id."'");
if (mysql_num_rows($cat) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$kat=mysql_fetch_array($cat);
if (isset($_POST['change']))
{
$newname=$_POST['newname'];
$permalink=permalink($newname);
if (mb_strlen($newname) < 2 || mb_strlen($newname) > 30)
$error=$LANG['lenght_category'];

if (empty($newname))
$error=$LANG['empty_text'];
$check_permalink=mysql_query("select * from category where site_id='".$user_id."' and link='".mysql_real_escape_string($permalink)."'");
if (mysql_num_rows($check_permalink) != 0)
$error=$LANG['category_exists'];
if (empty($error))
{
mysql_query("update category set name='".mysql_real_escape_string($newname)."', link='".mysql_real_escape_string($permalink)."' where id='".mysql_real_escape_string($cid)."' and site_id='".$user_id."'");
header('location: dashboard.php?cup=category');
}
else
{
$hasil='<div class="eror">'.$error.'</div>';
}
}
$head_title=''.$LANG['change'].' '.$LANG['category'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hasil))
echo $hasil;
echo '<form method="post" action="dashboard.php?cup=category&amp;action=edit&amp;cid='.$cid.'"><h1>'.$LANG['name'].'</h1><input name="newname" type="text" value="'.htmlspecialchars($kat['name']).'"/><br/><input name="change" type="submit" value="'.$LANG['save'].'"/></form></div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
if (isset($_POST['add_category']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
$name=$_POST['name'];
if (mb_strlen($name) < 2 || mb_strlen($name) > 30)
$err=$LANG['lenght_category'];
if (empty($name))
$err=$LANG['empty_text'];
$perma=permalink($name);
$chk=mysql_query("select * from category where site_id='".$user_id."' and link='".mysql_real_escape_string($perma)."'");
if (mysql_num_rows($chk) != 0)
$err=$LANG['category_exists'];
if (empty($err))
{
mysql_query("insert into category set site_id='".$user_id."', name='".mysql_real_escape_string($name)."', link='".mysql_real_escape_string($perma)."'");
$hasil='<div class="succes">'.$LANG['category'].' '.$LANG['successfully_added'].'</div>';
}
else
{
$hasil='<div class="eror">'.$err.'</div>';
}
}
}

$head_title=''.$LANG['manage'].' '.$LANG['category'];
require_once('inc/head.php');
echo '<div id="message">';
if ($hasil)
echo $hasil;
echo '<div class="content"><ol>';
$total=mysql_result(mysql_query("select count(*) as Num from category where site_id='".$user_id."'"), 0);
$req=mysql_query("select * from category where site_id='".$user_id."' order by name desc");
while ($cat=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<strong>'.htmlspecialchars($cat['name']).'</strong><br/>';
if (empty($cat['blog_id']))
{
$count='0';
}
else
{
$exp=explode(",",$cat['blog_id']);
$count=count($exp);
}
echo ''.$LANG['post'].' '.$count.'<br/><span class="action_links">[<a class="edit" href="dashboard.php?cup=category&amp;action=edit&amp;cid='.$cat['id'].'">'.$LANG['edit'].'</a>]';
if ($cat['id'] != 1)
echo ' [<a class="delete" href="dashboard.php?cup=category&amp;action=delete&amp;cid='.$cat['id'].'">'.$LANG['delete'].'</a>]';
echo '</span>';
++$i;
echo '</li>';
}
if ($total == 0)
echo '<li>'.$LANG['empty'].'</li>';
echo '</ol><h1><a name="add" class="no-link">'.$LANG['add_new'].'</a></h1>
<form action="dashboard.php?cup=category" method="post"><br/><input name="name" type="text" value=""/>
<br/><input name="add_category" type="submit" value="'.$LANG['save'].'"/>
</form></div>';
require_once('inc/foot.php');
}
?>