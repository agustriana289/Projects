<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$page=htmlentities($_GET['page']);
$all=mysql_fetch_array(mysql_query("select sum(total) as totals from stats where site_id='".$user_id."'"));

if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($all['totals'] / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title=$LANG['visitor_statistic'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif">'.$LANG['total_visitor'].' : '.$all['totals'].'</div>';
echo '<ol>';
$req=mysql_query("select * from stats where site_id='".$user_id."' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<strong>'.$LANG['date'].'</strong> : '.$res['time'].'<br/><strong>'.$LANG['visitor'].'</strong> : '.$res['total'].'';
++$i;
echo '</li>';
}
echo '</ol>';
$total=mysql_result(mysql_query("select count(*) as num from stats where site_id='".$user_id."'"), 0);
$link='dashboard.php?cup=stats&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
?>