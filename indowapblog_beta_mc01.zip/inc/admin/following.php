<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'follow':
if (!$user_id)
relogin();
$id = isset($_GET['id']) ? $_GET['id'] : '';
$cek_site = mysql_fetch_array(mysql_query("SELECT url, name FROM site WHERE id='".mysql_real_escape_string($id)."'"));
if (!$cek_site)
{
header("Location: dashboard.php?cup=following");
}
else {
$cek_following = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' AND url='".mysql_real_escape_string($cek_site['url'])."'"), 0);
if ($cek_following == 0) {
if (isset($_POST['yes'])) {
mysql_query("INSERT INTO following SET site_id='".mysql_real_escape_string($user_id)."', url='".mysql_real_escape_string($cek_site['url'])."', title='".mysql_real_escape_string($cek_site['name'])."', time='".time()."'");
header("Location: ".$cek_site['url']);
exit;
}
if (isset($_POST['no']))
{
header("Location: ".$cek_site['url']);
exit;
}
$live_chat = "off";
$head_title = $LANG['follow'];
include("inc/head.php");
echo '<div class="content"><center>'.str_replace('::site_name::','<a href="'.$cek_site['url'].'">'.htmlspecialchars($cek_site['name']).'</a>',$LANG['follow_confirm']).'</center><br/><br /><form method="POST" action="dashboard.php?cup=following&amp;action=follow&amp;id='.$id.'"><input type="hidden" name="follow" value="true"><br/><input type="submit" name="yes" value="'.$LANG['yes'].'"><input type="submit" name="no" value="'.$LANG['no'].'"></form></div>';
include("inc/foot.php");
}
else {
header("Location: ".$cek_site['url']);
}
}
break;

case 'edit':
if (!$user_id)
relogin();


$id=$_GET['id'];
$req=mysql_query("select url, title, subscribe from `following` where `id`='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$fid=mysql_fetch_array($req);

if (isset($_POST['change']))
{
$judul=$_POST['title'];
$sub_notify=$_POST['sub_notify'];
if (empty($judul))
{
$err='<div class="eror">'.$LANG['empty_text'].'</div>';
}
else
{
mysql_query("update `following` set `title`='".mysql_real_escape_string($judul)."', subscribe='".mysql_real_escape_string($sub_notify)."' where `id`='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
header('location: dashboard.php?cup=following');
}
}
$head_title=$LANG['edit'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($err))
echo $err;
echo '<div class="notif"><a href="dashboard.php?cup=following">'.$LANG['following'].'</a> | '.$LANG['edit'].'</div>';
echo '<form method="post" action="dashboard.php?cup=following&amp;action=edit&amp;id='.$id.'">
<h1>'.$LANG['link'].'</h1><strong>'.$fid['url'].'</strong><br/><h1>'.$LANG['title'].'</h1><input name="title" type="text" value="'.htmlspecialchars($fid['title']).'"/><br/><h1>'.$LANG['subscribe'].'</h1><input type="radio" name="sub_notify" value="1"';
if ($fid['subscribe'] == 1)
echo ' checked';
echo ''.$LANG['yes'].'<br/><input type="radio" name="sub_notify" value="0"';
if ($fid['subscribe'] == 0)
echo ' checked';
echo ''.$LANG['no'].'<br/><input name="change" type="submit" value="'.$LANG['save'].'"/></form>';

echo '</div>';
require_once('inc/foot.php');
break;

case 'read':
if (!$user_id)
relogin();

if (isset($_GET['more']))
{
$more=$_GET['more'];
$req=mysql_query("select * from `following_post` where `id`='".mysql_real_escape_string($more)."'");
if (mysql_num_rows($req) == 0)
{
header('location: dashboard.php?cup=following');
exit;
}
else
{
$res=mysql_fetch_array($req);
$uid='<'.$user_id.'>';
$resi=$res['read'];
$newr=str_replace($uid,'-',$resi);
mysql_query("update `following_post` set `read`='".mysql_real_escape_string($newr)."' where id='".mysql_real_escape_string($more)."'");
echo '<html><head><title>'.$LANG['redirect'].'</title><meta http-equiv="refresh" content="10;url='.htmlspecialchars($res['link']).'"></head><body>';
require_once('inc/ads_following.php');
echo '<br /><a href="'.htmlspecialchars($res['link']).'">'.$LANG['click_here'].'</a> '.$LANG['to_continue'].'</body></html>';
exit;
}
}
else
{
$page=$_GET['page'];
$tm = time() - 172800;
$total=mysql_result(mysql_query("select count(*) as num from `following_post` where `read` LIKE '%<".$user_id.">%' and `time`>'".$tm."'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title=$LANG['post_unread'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="dashboard.php?cup=following">'.$LANG['following'].'</a> | '.$LANG['post_unread'].'</div>';

echo '<ol>';
if ($total == 0)
{
echo '<div class="eror">'.$LANG['empty'].'</div>';
}
else
{
$req=mysql_query("select * from `following_post` where `read` LIKE '%<".$user_id.">%' and `time`>'".$tm."' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="dashboard.php?cup=following&amp;action=read&amp;more='.$res['id'].'">'.htmlspecialchars($res['title']).'</a> <small>('.time_ago($res['time']).')</small>';
++$i;
echo '</li>';

}
}
echo '</ol>';
$link='dashboard.php?cup=following&amp;action=read&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
}
break;

case 'unfollow':
if (!$user_id)
relogin();


$id=$_GET['id'];
$cek=mysql_query("select * from following where id='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
if (mysql_num_rows($cek) == 0) {
header('location: dashboard.php?cup=following');
exit;
}
if (isset($_GET['yes'])) {
if (!$user_id) {
relogin();
}
else {
mysql_query("delete from following where id='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
mysql_query("delete from following_post where site_id='".$user_id."' and following_id='".mysql_real_escape_string($id)."'");
header('location: dashboard.php?cup=following');
exit;
}
}
if (isset($_GET['no'])) {
if (!$user_id) {
relogin();
}
else {
header('location: dashboard.php?cup=following');
}
}
$res=mysql_fetch_array($cek);

$head_title=''.$LANG['unfollow'].' '.$res['title'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="dashboard.php?cup=following">'.$LANG['following'].'</a> | '.$LANG['unfollow'].'</div>';
echo '<p>'.str_replace('::site_name::','<a href="'.$res['url'].'">'.htmlspecialchars($res['title']).'</a>',$LANG['unfollow_confirm']).' </p><br/><form method="get" action="dashboard.php"><input type="hidden" name="cup" value="following"><input type="hidden" name="action" value="unfollow"><input type="hidden" name="id" value="'.$id.'"><br/><input type="submit" name="yes" value="'.$LANG['yes'].'"><input type="submit" name="no" value="'.$LANG['no'].'"></form><br />';
echo '</div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();

$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) as num from following where site_id='".$user_id."'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;


$head_title=$LANG['following'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif">'.$LANG['following'].'</div>';
echo '<ol>';

if ($total == 0)
{
echo '<div class="eror">'.$LANG['empty'].'</div>';
}
else
{
$req=mysql_query("select * from following where site_id='".$user_id."' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo 'Blog: <a href="'.$res['url'].'/">';
if (!empty($res['title']))
echo htmlspecialchars($res['title']);
else
echo htmlentities($res['url']);
echo '</a><br />';
$adm = mysql_fetch_array(mysql_query("select id, name from user where site='".$res['url']."'"));
if ($adm)
{
echo ''.$LANG['admin'].': <a href="'.$site_url.'/user.php?id='.$adm['id'].'">'.htmlspecialchars($adm['name']).'</a><br />';
}
echo ''.$LANG['follow_date'].': '.waktu($res['time']).'<br/>Status: ';
if ($res['subscribe'] == 1)
echo '<b>'.$LANG['subscribe'].'</b>';
else
echo '<b>'.$LANG['not_subscribe'].'</b>';
echo '<br /><span>[<a href="dashboard.php?cup=following&amp;action=edit&amp;id='.$res['id'].'">'.$LANG['edit'].'</a>] [<a class="delete" href="dashboard.php?cup=following&amp;action=unfollow&amp;id='.$res['id'].'">'.$LANG['unfollow'].'</a>]</span>';
++$i;
echo '</div>';
}
}
$link='dashboard.php?cup=following&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
}
?>