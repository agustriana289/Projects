<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'place':
if (!$user_id)
relogin();
$id = isset($_GET['id']) ? $_GET['id'] : '';
$in = isset($_GET['in']) ? $_GET['in'] : '1';
$nav = mysql_fetch_array(mysql_query("SELECT * FROM navigation WHERE id='".mysql_real_escape_string($id)."' AND site_id='".mysql_real_escape_string($user_id)."'"));
if ($nav)
{
if ($in < 1 || $in > 30 || !ctype_digit($in))
$Pnav = 1;
else
$Pnav = $in;
mysql_query("UPDATE navigation SET place='".mysql_real_escape_string($Pnav)."' WHERE id='".$nav['id']."'");
header("Location: dashboard.php?cup=navigation");
}
else {
header("Location: dashboard.php?cup=navigation");
}
break;

case 'delete':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$nav_id=htmlentities($_GET['nav_id']);
$cek=mysql_query("select * from navigation where id='".mysql_real_escape_string($nav_id)."' and site_id='".$user_id."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
else
{
if (isset($_GET['yes']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("delete from navigation where id='".mysql_real_escape_string($nav_id)."' and site_id='".$user_id."'");
header('location: dashboard.php?cup=navigation');
}
}
$head_title=$LANG['delete'];
require_once('inc/head.php');
echo '<div class="content"><b>'.$LANG['delete_confirm'].'</b><br/>[<a href="dashboard.php?cup=navigation&amp;action=delete&amp;nav_id='.$nav_id.'&amp;yes">'.$LANG['yes'].'</a>] [<a href="dashboard.php?cup=navigation">'.$LANG['no'].'</a>]</div>';
require_once('inc/foot.php');
}
break;

case 'edit':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$nav_id=htmlentities($_GET['nav_id']);
$cek=mysql_query("select * from navigation where id='".mysql_real_escape_string($nav_id)."' and site_id='".$user_id."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
if (isset($_POST['cancel']))
{
header('location: dashboard.php?cup=navigation');
}
if (isset($_POST['save']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$item=$_POST['item_text'];
if (preg_match("#<b>#i", $item) && !preg_match("#<\/b>#i", $item) || preg_match("#<a href#i", $item) && !preg_match("#<\/a>#i", $item) || preg_match("#<textarea#i", $item) && !preg_match("#<\/textarea>#i", $item))
$error=$LANG['incorrect_html_tag'];
if (mb_strlen($item) > 5000)
$error=str_replace('::number::','5000',$LANG['text_max']);
if (empty($error))
{
mysql_query("update navigation set code='".mysql_real_escape_string($item)."' where id='".mysql_real_escape_string($nav_id)."' and site_id='".$user_id."'");
header('location: dashboard.php?cup=navigation');
}
else
{
$hsl='<div class="eror">'.$error.'</div>';
}
}
$nv=mysql_fetch_array($cek);
$head_title=$LANG['edit'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<form method="post" action="dashboard.php?cup=navigation&amp;action=edit&amp;nav_id='.$nav_id.'">'.$LANG['html_allowed'].'<br/> <textarea rows="3" cols="20" name="item_text">'.htmlentities($nv['code']).'</textarea>
<br/>
<input name="save" type="submit" value="'.$LANG['save'].'"/>
<input name="cancel" type="submit" value="'.$LANG['cancel'].'"/>
</form></div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
if (isset($_POST['add']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$item=$_POST['item_text'];
if (preg_match("#<b>#i", $item) && !preg_match("#<\/b>#i", $item) || preg_match("#<a href#i", $item) && !preg_match("#<\/a>#i", $item) || preg_match("#<textarea#i", $item) && !preg_match("#<\/textarea>#i", $item))
$error=$LANG['incorrect_html_tag'];
if (empty($item))
$error=$LANG['empty_text'];
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM navigation WHERE site_id='".$user_id."'"),0);
if (mb_strlen($item) > '5000')
$error=str_replace('::number::','5000',$LANG['text_max']);
if ($total > 30)
$error=str_replace('::number::','30',$LANG['max_nav_item']);
if (empty($error))
{
mysql_query("insert into navigation set site_id='".$user_id."', code='".mysql_real_escape_string($item)."'");
$hsl='<div class="succes">'.$LANG['navigation'].' '.$LANG['successfully_added'].'</div>';
}
else
{
$hsl='<div class="eror">'.$error.'</div>';
}
}
$head_title=$LANG['navigation'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="#add">'.$LANG['add_new'].'</a> | <a href="dashboard.php">Dashboard</a></div>';
if (!empty($hsl))
echo $hsl;
if (isset($_GET['display']))
echo '<form method="get" action="dashboard.php"><input type="hidden" name="cup" value="navigation"/><input type="submit" value="'.$LANG['display_default'].'"/></form>';
else
echo '<form method="get" action="dashboard.php"><input type="hidden" name="cup" value="navigation"/><input type="hidden" name="display" value="html"/><input type="submit" value="'.$LANG['display_html'].'"/></form>';
$req=mysql_query("SELECT * FROM navigation WHERE site_id='".$user_id."' ORDER BY place ASC");
while ($nv=mysql_fetch_array($req))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
if (isset($_GET['display']))
echo ''.htmlentities(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$user_site,$nv['code']))).'<br/>';
else
echo ''.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$user_site,$nv['code']))).'<br/>';
echo '<span><a
class="edit" href="dashboard.php?cup=navigation&amp;action=edit&amp;nav_id='.$nv['id'].'">'.$LANG['edit'].'</a> <a class="delete" href="dashboard.php?cup=navigation&amp;action=delete&amp;nav_id='.$nv['id'].'">'.$LANG['delete'].'</a></span><form method="GET" action="dashboard.php">
<input type="hidden" name="cup" value="navigation"><input type="hidden" name="action" value="place"><input type="hidden" name="id" value="'.$nv['id'].'"><br/><select name="in">';
$no = 1;
while ($no<=30)
{
echo '<option value="'.$no.'"';
if ($nv['place'] == $no)
echo ' selected';
echo '>'.$no.'</option>';
$no++;
}
echo '</select><br/><input type="submit" value="'.$LANG['save'].'"></form>';
++$i;
echo '</div>';
}
echo '<b><a class="no-link" name="add">'.$LANG['add_new'].'</a></b><br/>
<form method="post" action="dashboard.php?cup=navigation">'.$LANG['html_allowed'].'<br/>
<textarea name="item_text" rows="3"/></textarea><br/><input name="add" type="submit" value="'.$LANG['add'].'"/></form></div>';
require_once('inc/foot.php');
}

?>