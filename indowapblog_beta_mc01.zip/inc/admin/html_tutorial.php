<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$html=isset($_GET['html']) ? trim($_GET['html']) : '';
switch ($html)
{
case 'big':
$kode='<big>Teks</big>';
break;
case 'b':
$kode='<b>Teks</b>';
break;
case 'small':
$kode='<small>Teks</small>';
break;
case 'i':
$kode='<i>Teks</i>';
break;
case 'u':
$kode='<u>Teks</u>';
break;
case 'strike':
$kode='<strike>Teks</strike>';
break;
case 'marque':
$kode='<marque>Teks</marque>';
break;
case 'blink':
$kode='<blink>Teks</blink>';
break;
case 'a':
$kode='<a href="'.$user_site.'/desktop.iwb">Teks</a>';
break;
case 'img':
$kode='<img src="'.$user_site.'/content/gambar.jpg" alt="Teks"/>';
break;
case 'br':
$kode='<br />';
break;
case 'color_blue':
$kode='<font color="blue">Teks</font>';
break;
case 'color_red':
$kode='<font color="red">Teks</font>';
break;
case 'color_white':
$kode='<font color="white">Teks</font>';
break;
case 'color_black':
$kode='<font color="black">Teks</font>';
break;
case 'color_green':
$kode='<font color="green">Teks</font>';
break;
case 'color_yellow':
$kode='<font color="yellow">Teks</font>';
break;
case 'p_center':
$kode='<p align="center">Teks</p>';
break;
case 'p_left':
$kode='<p align="left">Teks</p>';
break;
case 'p_right':
$kode='<p align="right">Teks</p>';
break;
case 'textarea':
$kode='<textarea>Teks</textarea>';
break;
case 'table_1bar_3kol':
$kode='<table border="1"><tr><td>Baris 1/Kolom 1</td><td>Baris 1/Kolom 2</td><td>Baris 1/Kolom 3</td></tr></table>';
break;
case 'table_1kol_3bar':
$kode='<table border="1"><tr><td>Baris 1/Kolom1</td></tr><tr><td>Baris 2/Kolom 1</td></tr><tr><td>Baris 3/Kolom 1</td></tr></table>';
break;
default:
$kode=$LANG['copy_code_here'];
}
$head_title=$LANG['html_tutorial'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<p>'.str_replace('::w3schools::','<a href="http://www.w3schools.com/html/">http://www.w3schools.com/html</a>',$LANG['html_tutorial_info']).'<p><br /><h1>'.$LANG['html_code'].'</h1><br/><textarea size="30">'.htmlspecialchars($kode).'</textarea><br />';
if (isset($_GET['html']))
echo '<div class="green">'.$LANG['result'].'</div><br />'.$kode.'<br />';
echo '<h1>'.$LANG['select_code'].'</h1><br/><form method="get" action="dashboard.php?"><input type="hidden" name="cup" value="html_tutorial"/>
<select name="html">
<option value="">==Pilih Tutorial==</option>
<option value="big">Teks: Besar</option>
<option value="b">Teks: Tebal</option>
<option value="small">Teks: Kecil</option>
<option value="i">Teks: Miring</option>
<option value="u">Teks: Garis Bawah</option>
<option value="strike">Teks: Garis Tengah</option>
<option value="marque">Teks: Berjalan</option>
<option value="blink">Teks: Berkedip</option>
<option value="a">Link</option>
<option value="img">Gambar</option>
<option value="br">Baris Baru</option>
<option value="color_blue">Warna: Biru</option>
<option value="color_red">Warna: Merah</option>
<option value="color_white">Warna: Putih</option>
<option value="color_black">Warna: Hitam</option>
<option value="color_green">Warna: Hijau</option>
<option value="color_yellow">Warna: Kuning</option>
<option value="p_center">Paragraf: Tengah</option>
<option value="p_left">Paragraf: Kiri</option>
<option value="p_right">Paragraf: Kanan</option>
<option value="textarea">Teks Area</option>
<option value="table_1kol_3bar">Tabel: 1 Kolom 3 Baris</option>
<option value="table_1bar_3kol">Table: 1 Baris 3 Kolom</option>
</select><br /><input type="submit" value="'.$LANG['view_code'].'"/></form>';
echo '</div>';
require_once('inc/foot.php');
?>