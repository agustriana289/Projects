<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();
if (!$is_author) {
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}

$template = isset($_GET['template']) ? trim($_GET['template']) : '';

switch ($template) {

case 'mobile':
$head_title='Mobile (WAP)';
require_once('inc/head.php');
echo '<div class="content"><div class="notif"><a href="dashboard.php?cup=css_editor">Template</a> | Mobile (WAP)</div><br/>';
if (isset($_POST['save'])) {
$css = htmlentities($_POST['css']);
if (file_put_contents('themes/default/css/'.$user_id.'.css',$css))
echo '<div class="succses">'.$LANG['change_saved'].'</div>';
else
echo '<div class="eror">'.$LANG['failed'].'</div>';
}
elseif (isset($_POST['reset'])) {
if (file_exists('themes/default/css/'.$user_id.'.css'))
unlink('themes/default/css/'.$user_id.'.css');
echo '<div class="succses">'.$LANG['change_saved'].'</div>';
}
else {
if (file_exists('themes/default/css/'.$user_id.'.css'))
$file = 'themes/default/css/'.$user_id.'.css';
else
$file = 'themes/default/css/default.css';
echo '<br/><br/><form method="post" action="dashboard.php?cup=css_editor&amp;template=mobile"><textarea name="css" cols="26" rows="15">'.htmlspecialchars(file_get_contents($file)).'</textarea><br /><input type="submit" name="save" value="'.$LANG['save'].'"><input type="submit" name="reset" value="'.$LANG['reset'].'"></form><br />';
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'desktop':
$head_title='Desktop (WEB)';
require_once('inc/head.php');
echo '<div class="content"><div class="notif"><a href="dashboard.php?cup=css_editor">Template</a> | Desktop (WEB) | <a href="'.$user_site.'/dashboard.php?cup=css_editor&amp;template=mobile">Mobile (WAP)</a></div><br/>';
if (isset($_POST['save'])) {
$css = htmlentities($_POST['css']);
if (file_put_contents('themes/desktop/css/'.$user_id.'.css',$css))
echo '<div class="succes">'.$LANG['change_saved'].'</div>';
else
echo '<div class="eror">'.$LANG['failed'].'</div>';
}
elseif (isset($_POST['reset'])) {
if (file_exists('themes/desktop/css/'.$user_id.'.css'))
unlink('themes/desktop/css/'.$user_id.'.css');
echo '<div class="succes">'.$LANG['change_saved'].'</div>';
}
else {
if (file_exists('themes/desktop/css/'.$user_id.'.css'))
$file = 'themes/desktop/css/'.$user_id.'.css';
else
$file = 'themes/desktop/css/default.css';
echo '<br/><br/><form method="post" action="dashboard.php?cup=css_editor&amp;template=desktop"><textarea name="css" cols="26" rows="15">'.htmlspecialchars(file_get_contents($file)).'</textarea><br /><br /><input type="submit" name="save" value="'.$LANG['save'].'"><input type="submit" name="reset" value="'.$LANG['reset'].'"></form><br />';
}
echo '</div>';
require_once('inc/foot.php');
break;

default:
$head_title='Thema Blog';
require_once('inc/head.php');
echo '<div class="content"><div class="notif">Template | <a href="dashboard.php">Dashboard</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=css_editor&amp;template=mobile">Mobile (WAP)</a></div><div class="menu"><a href="dashboard.php?cup=css_editor&amp;template=desktop">Desktop (WEB)</a></div>';
echo '</div>';
require_once('inc/foot.php');
break;
}
?>