<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$cek=mysql_query("select * from ads where site_id='".$user_id."'");

if (isset($_POST['save']))
{
$adcode=$_POST['adcode'];
$adby=$_POST['adby'];
if (mysql_num_rows($cek) == 0)
{
$hasil='<div class="eror">'.$LANG['ads_not_added'].'</div>';
}
else
{
$ad=mysql_fetch_array($cek);
if (empty($adcode))
{
$hasil='<div class="eror">'.$LANG['insert_publisher_code'].'</div>';
}
elseif ($adby != 'mobgold' && $adby != 'buzzcity' && $adby != 'smaato' && $adby != 'mobday')
{
$hasil='<div class="eror">'.$LANG['incorrect_ads'].'</div>';
}
else
{
mysql_query("UPDATE `ads` SET `adcode`='".mysql_real_escape_string($adcode)."', `adby`='".mysql_real_escape_string($adby)."' WHERE `site_id`='".$user_id."'");
$hasil='<div class="succes">'.$LANG['change_saved'].'</div>';
}
}
}
if (isset($_POST['add']))
{
$adcode=$_POST['adcode'];
$adby=$_POST['adby'];
if (mysql_num_rows($cek) != 0)
{
$hasil='<div class="eror">'.$LANG['ads_was_added'].'</div>';
}
else
{
if (empty($adcode))
{
$hasil='<div class="eror">'.$LANG['insert_publisher_code'].'</div>';
}
elseif ($adby != 'mobgold' && $adby != 'buzzcity' && $adby != 'smaato' && $adby != 'mobday')
{
$hasil='<div class="eror">'.$LANG['incorrect_ads'].'</div>';
}
else
{
mysql_query("INSERT INTO `ads` SET `site_id`='".$user_id."', `adcode`='".mysql_real_escape_string($adcode)."', `adby`='".mysql_real_escape_string($adby)."', `status`='1'");
$hasil='<div class="succses">Iklan berhasil ditambahkan.</div>';
}
}
}
$head_title=$LANG['ads'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hasil))
echo $hasil;
$cek1=mysql_query("select * from ads where site_id='".$user_id."'");
if (mysql_num_rows($cek1) == 0)
{
echo 'Anda belum penambahkan kode iklan.<br /><form method="post" action="dashboard.php?cup=ads"><h1>'.$LANG['publisher_code'].'</h1><input type="text" name="adcode" value=""/><br /><h1>'.$LANG['ads_by'].'</h1><input type="radio" name="adby" value="mobgold" checked/><a href="http://mobgold.com/">Mobgold</a><br/><input type="radio" name="adby" value="buzzcity"/><a href="http://buzzcity.net/">Buzzcity</a><br /><input type="radio" name="adby" value="smaato"/><a href="http://smaato.com/">Smaato</a><br /><input type="radio" name="adby" value="mobday"/><a href="http://mobday.com/">Mobday</a><br/><input type="submit" name="add" value="'.$LANG['save'].'"/></form>';
}
else
{
$ads=mysql_fetch_array($cek1);
echo ''.$LANG['publisher_code'].': <b>'.htmlspecialchars($ads['adcode']).'</b><br />'.$LANG['ads_by'].': <b>'.htmlspecialchars($ads['adby']).'</b><br />Status: ';
if ($ads['status'] == 1)
echo '<b>'.$LANG['publish'].'</b>';
else
echo '<b>'.$LANG['unapproved'].'</b>';
echo '<br/><form method="post" action="dashboard.php?cup=ads"><h1>'.$LANG['publisher_code'].'</h1><input type="text" name="adcode" value="'.htmlspecialchars($ads['adcode']).'"/><br /><h1>'.$LANG['ads_by'].'</h1><input type="radio" name="adby" value="mobgold" '; if ($ads['adby'] == 'mobgold') echo 'checked'; echo '/><a href="http://mobgold.com/">Mobgold</a><br/><input type="radio" name="adby" value="buzzcity" '; if ($ads['adby'] == 'buzzcity') echo 'checked'; echo '/><a href="http://buzzcity.net/">Buzzcity</a><br /><input type="radio" name="adby" value="smaato" '; if ($ads['adby'] == 'smaato') echo 'checked'; echo '/><a href="http://smaato.com/">Smaato</a><br /><input type="radio" name="adby" value="mobday" '; if ($ads['adby'] == 'mobday') echo 'checked'; echo '/><a href="http://mobday.com/">Mobday</a><br/><input type="submit" name="save" value="'.$LANG['save'].'"/></form>';
}
echo '<br />*'.$LANG['ads_smaato_info'].'</div>';
require_once('inc/foot.php');
?>