<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}

$st=mysql_fetch_array(mysql_query("select * from site where id='".$user_id."'"));

$nama=$_POST['blog_name'];
$deskripsi=$_POST['blog_description'];
$key=strtolower($_POST['blog_keywords']);
$kategori=$_POST['kategori'];
$google=$_POST['blog_meta_google'];
$language=$_POST['blog_language'];
$tema=$_POST['blog_theme'];
$tema_web=$_POST['blog_theme_web'];
$catloc=$_POST['blog_cat_loc'];
$display_following=$_POST['blog_display_following'];
$discount=$_POST['blog_display_count'];
$logo=$_POST['blog_logo'];
$ico=$_POST['blog_favicon'];
$comment_email=$_POST['blog_comment_email'];
$comment_mod=$_POST['blog_comment_mod'];
$comment_captcha=$_POST['blog_comment_captcha'];
$desc=$_POST['blog_desc_post_main'];
$num_post_main=$_POST['blog_num_post_main'];
if ($is_admin)
{
$url=strtolower($_POST['blog_url']);
$allow_reg=$_POST['blog_allow_reg'];
$reg_email=$_POST['blog_reg_email'];
$author=$_POST['blog_reg_author'];
}
else
{
$url=$st['url'];
$allow_reg=$st['allow_reg'];
$reg_email=$st['reg_email'];
$author=$st['reg_author'];
}
$gmt=$_POST['blog_gmt'];


if (isset($_POST['save']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
if (!ctype_digit($kategori) || !ctype_digit($display_following) || !ctype_digit($num_post_main) || !ctype_digit($comment_captcha) || !ctype_digit($discount) || !ctype_digit($comment_email) || !ctype_digit($comment_mod) || !ctype_digit($desc))
$error=$LANG['field_digit_only'];
if (empty($error))
{
mysql_query("update site set name='".mysql_real_escape_string($nama)."', url='".mysql_real_escape_string($url)."', description='".mysql_real_escape_string($deskripsi)."', keywords='".mysql_real_escape_string($key)."', meta_google='".mysql_real_escape_string($google)."', language='".mysql_real_escape_string($language)."', theme='".mysql_real_escape_string($tema)."', theme_web='".mysql_real_escape_string($tema_web)."', cat_loc='".mysql_real_escape_string($catloc)."', display_following='".mysql_real_escape_string($display_following)."', display_count='".mysql_real_escape_string($discount)."', logo='".mysql_real_escape_string($logo)."', favicon='".mysql_real_escape_string($ico)."', comment_email='".mysql_real_escape_string($comment_email)."', comment_mod='".mysql_real_escape_string($comment_mod)."', comment_captcha='".mysql_real_escape_string($comment_captcha)."', desc_post_main='".mysql_real_escape_string($desc)."', num_post_main='".mysql_real_escape_string($num_post_main)."', allow_reg='".mysql_real_escape_string($allow_reg)."', reg_email='".mysql_real_escape_string($reg_email)."', reg_author='".mysql_real_escape_string($author)."', gmt='".mysql_real_escape_string($gmt)."', category='".mysql_real_escape_string($kategori)."' where id='".$user_id."'") or die(mysql_error());
if ($indowapblog['language'] != $language) {
mysql_query("UPDATE user SET language='".mysql_real_escape_string($language)."' WHERE id='".$user_id."'");
}
else {
}
$hsl='<div class="succes">'.$LANG['change_saved'].'</div>';
}
else
{
$hsl='<div class="eror">'.$error.'</div>';
}
}
$head_title=$LANG['blog_settings'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<form method="post" action="dashboard.php?cup=settings">
<h1>'.$LANG['blog_name'].'</h1><br/>
<input name="blog_name" type="text" value="'.htmlspecialchars($st['name']).'" maxlength="49"/><br/><span>'.$LANG['blog_name_info'].'</span>
<h1>URL</h1><br/>';
if ($is_admin)
echo '<input name="blog_url" type="text" value="'.htmlspecialchars($st['url']).'" maxlength="49"/><br />';
else
echo '<b>'.$st['url'].'</b><br />';
echo '<h1>'.$LANG['description'].'</h1><br/>
<input name="blog_description" type="text" value="'.htmlentities($st['description']).'" maxlength="300"/><br/><h1>'.$LANG['keywords'].'</h1><br/>
<input name="blog_keywords" type="text" value="'.htmlentities($st['keywords']).'" maxlength="300"/><br/><h1>'.$LANG['category'].'</h1><br/><select name="kategori">';
$no=1;
while ($no<=10)
{
$n=isset($no) ? $no : '';
switch ($n)
{
case '1':
$name=$LANG['general'];
break;
case '2':
$name=$LANG['art_and_cultur'];
break;
case '3':
$name=$LANG['education'];
break;
case '4':
$name=$LANG['hobbies_and_lifestyle'];
break;
case '5':
$name=$LANG['sport'];
break;
case '6':
$name=$LANG['science_and_technology'];
break;
case '7':
$name=$LANG['business_and_finance'];
break;
case '8':
$name=$LANG['health'];
break;
case '9':
$name=$LANG['personal'];
break;
case '10':
$name=$LANG['other'];
break;
default:
break;
}
echo '<option value="'.$no.'"' . ($st['category'] == $no ? ' selected="selected">' : '>') . $name . '</option>';
$no++;
}
echo '</select><br /><span>'.$LANG['blog_category_info'].'</span><br /><h1>'.$LANG['meta_google'].'</h1><br/>
<input name="blog_meta_google" type="text" value="'.htmlentities($st['meta_google']).'" maxlength="300"/><br/><span>'.$LANG['google_verification'].'. <a href="https://www.google.com/webmasters/verification/verification?hl=en&siteUrl='.$st['url'].'/&continue=https://www.google.com/webmasters/tools/dashboard?hl%3Den%26siteUrl%3D'.$st['url'].'/">'.$LANG['click_here'].'</a></span><br/>
<h1>'.$LANG['language'].'</h1><br/><select name="blog_language">';
if ($st['language'] == "id")
echo '<option value="id">Bahasa Indonesia</option><option value="en">English</option>';
else
echo '<option value="en">English</option><option value="id">Bahasa Indonesia</option>';
echo '</select><br />';
echo '<h1>'.$LANG['wap_template'].'</h1>

<select name="blog_theme">';
echo '<option value="default"';
if ($st['theme'] == "default")
echo ' selected="true"';
echo '>Mobile</option>';
echo '</select><br/><h1>'.$LANG['web_template'].'</h1><br/>
<select name="blog_theme_web"><option value="default">Default</option></select><br />';
echo '<h1>'.$LANG['show_counter'].'</h1><br/>
<select name="blog_display_count">';
if ($st['display_count'] == '1')
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br/><span>'.$LANG['show_counter_info'].'</span><br/><h1>'.$LANG['show_following'].'</h1><br/>
    <select name="blog_display_following">';
if ($st['display_following'] == '1')
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br/><span>'.$LANG['show_following_info'].'</span><br/><h1>'.$LANG['logo'].' (<a href="file.php">'.$LANG['upload'].'</a>)</h1><br/>
        <select name="blog_logo">';
$fil = glob("data/".$user_id."/*");
foreach ($fil as $fils)
{
$fils = basename($fils);
$ext = substr($fils,-4);
if ($ext == '.gif' || $ext == '.png' || $ext == '.jpg')
{
echo '<option' . ($st['logo'] == $fils ? ' selected="selected">' : '>') . $fils . '</option>';
}
}
echo '<option value="">'.$LANG['no_logo'].'</option></select><br /><h1>'.$LANG['icon'].' (<a href="file.php">'.$LANG['upload'].'</a>)</h1><br/>
        <select name="blog_favicon">';
$ikons = glob("data/".$user_id."/*.ico");
foreach ($ikons as $ikon)
{
$ikon = basename($ikon);
echo '<option' . ($st['favicon'] == $ikon ? ' selected="selected">' : '>') . $ikon . '</option>';
}
echo '</select><br /><span>'.$LANG['icon_info'].'</span><br /><h1>'.$LANG['comment_moderate'].'</h1><br/><select name="blog_comment_mod">';
if ($st['comment_mod'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br />';
echo '<h1>'.$LANG['comment_captcha'].'</h1><br/><select  name="blog_comment_captcha">';
if ($st['comment_captcha'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br/><span>'.$LANG['comment_captcha_info'].'</span><br />';
echo '<h1>'.$LANG['comment_email'].'</h1><br/><select name="blog_comment_email">';
if ($st['comment_email'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br />';
echo '<h1>'.$LANG['desc_main_page'].'</h1><br/><select name="blog_desc_post_main">';
if ($st['desc_post_main'] == 1)
echo '<option value="1">'.$LANG['penuh'].'</option><option value="0">'.$LANG['singkat'].'</option>';
else
echo '<option value="0">'.$LANG['singkat'].'</option><option value="1">'.$LANG['penuh'].'</option>';
echo '</select><br/><span><br/>'.$LANG['desc_main_page_info'].'</span><br /><h1>'.$LANG['num_post_main'].'</h1>
<input name="blog_num_post_main" type="text" value="'.htmlentities($st['num_post_main']).'" maxlength="2" size="10"/><br/><span>'.$LANG['num_post_main_info'].'</span>
<br/>';
if ($is_admin)
{
echo '<h1>'.$LANG['allow_registration'].'</h1><br/><select name="blog_allow_reg">';
if ($st['allow_reg'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br />';
echo '<h1>'.$LANG['coupon_registration'].'</h1><br/><select name="blog_reg_email">';
if ($st['reg_email'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br/><span>'.$LANG['coupon_registration_info'].'</span><br />';
echo '<h1>'.$LANG['allow_registration_author'].'</h1><br/><select name="blog_reg_author">';
if ($st['reg_author'] == 1)
echo '<option value="1">'.$LANG['yes'].'</option><option value="0">'.$LANG['no'].'</option>';
else
echo '<option value="0">'.$LANG['no'].'</option><option value="1">'.$LANG['yes'].'</option>';
echo '</select><br />';
}
echo '<h1>'.$LANG['time_zone'].'</h1><select name="blog_gmt">';
echo '<option value="-12">GMT -12</option><option value="-11">GMT -11</option><option value="-10">GMT -10</option><option value="-9">GMT -9</option><option value="-8">GMT -8</option><option value="-7">GMT -7</option><option value="-6">GMT -6</option><option value="-5">GMT -5</option><option value="-4">GMT -4</option><option value="-3">GMT -3</option><option value="-2">GMT -2</option><option value="-1">GMT -1</option><option value="0">GMT 0</option><option value="+1">GMT +1</option><option value="+2">GMT +2</option><option value="+3">GMT +3</option><option value="+4">GMT +4</option><option value="+5">GMT +5</option><option value="+6">GMT +6</option><option value="+7" selected="selected">GMT +7</option><option value="+8">GMT +8</option><option value="+9">GMT +9</option><option value="+10">GMT +10</option><option value="+11">GMT +11</option><option value="+12">GMT +12</option>';
echo '</select><br/><input name="save" type="submit" value="'.$LANG['save'].'"/>
</form></div>';
require_once('inc/foot.php');
?>