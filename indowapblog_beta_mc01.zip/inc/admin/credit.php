<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang');

if (!$user_id)
relogin();

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'free_credit':
if (!$user_id)
relogin();

$head_title=$LANG['free_credit'];
require_once('inc/head.php');
echo '<div class="content"><div class="notif"><a href="dashboard.php?cup=credit">'.$LANG['credit'].'</a> | <a href="dashboard.php?cup=credit&amp;action=transfer">'.$LANG['transfer_credit'].'</a> | '.$LANG['payout_credit'].'</div>';
if ($indowapblog['credit'] < 200 && (date("D", time()) == 'Sat' || date("D", time()) == 'Sun'))
{
$kr = $indowapblog['credit'] + 500;
mysql_query("UPDATE user SET credit='".$kr."' WHERE id='".$user_id."'");
echo '<div class=succes>'.str_replace('::number::','500'