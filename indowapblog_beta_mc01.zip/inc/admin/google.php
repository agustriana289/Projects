<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang');


$head_title=$LANG['google_verification'];
require_once('inc/head.php');
if (!$is_author)
{
forbidden();
}
else
{
echo '<div class="content">'.str_replace('::link::','<a href="https://www.google.com/webmasters/verification/verification?hl=en&siteUrl='.$user_site.'/&continue=https://www.google.com/webmasters/tools/dashboard?hl%3Den%26siteUrl%3D'.$user_site.'/&pli=1">'.$LANG['click_here'].'</a>',$LANG['google_verification_info']).'</div>
';
}
require_once('inc/foot.php');
?>