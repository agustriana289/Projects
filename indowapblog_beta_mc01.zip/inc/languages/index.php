<?php

defined("_IWB_") or die("Akses Terlarang!");
?>