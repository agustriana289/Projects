<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

if ($defined != 'on')
{
define('_IWB_', 1);
include('inc/indowapblog.php');
}
else
{
defined('_IWB_') or die('ERROR'); // Opsional
}
if (!$user_id)
relogin();
$dashboard='on';
$head_title=$LANG['dashboard'];
require_once('inc/head.php');

echo '<div class="content">';
echo '<div class="title">'.$LANG['add_new'].'</div>';
echo '<div class="menu"><a href="post.php">'.$LANG['post'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=category">'.$LANG['category'].'</a></div>';
echo '<div class="menu"><a href="file.php">'.$LANG['file'].'</a></div>';

echo '<div class="title">'.$LANG['edit'].'</div>';
echo '<div class="menu"><a href="post.php?cup=manage">'.$LANG['post'].'</a></div>';
echo '<div class="menu"><a href="file.php">'.$LANG['file'].'</a></div>';
echo '<div class="menu"><a href="manage_comment.php?">'.$LANG['comments'].'</a></div>';
echo '<div class="menu"><a href="manage_guestbook.php?">'.$LANG['guestbook'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=following">'.$LANG['following'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=navigation">'.$LANG['navigation'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=css_editor">'.$LANG['theme'].'</a></div>';

echo '<div class="title">'.$LANG['settings'].'</div>';
echo '<div class="menu"><a href="dashboard.php?cup=settings">'.$LANG['blog'].'</a></div>';
echo '<div class="menu"><a href="iklan.php">'.$LANG['ads'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=domain_parking">'.$LANG['domain_parking'].'</a></div>';
echo '<div class="menu"><a href="dashboard.php?cup=google">'.$LANG['google_verification'].'</a></div>';

echo '<div class="title">'.$LANG['community'].'</div>';
echo '<div class="menu"><a href="kb.php">'.$LANG['knowledge_base'].'</a></div>';
echo '<div class="menu"><a href="user.php?cup=list">'.$LANG['users_list'].'</a></div>';

echo '<div class="title">'.$LANG['other'].'</div>';
echo '<div class="menu"><a href="dashboard.php?cup=stats">'.$LANG['statistics'].'</a></div>';
echo '<div class="menu"><a href="kuis.php">'.$LANG['quiz'].'</a></div>';
echo '<div class="menu"><a href="new.php">'.$LANG['latest_post'].'</a></div>';
echo '</div>';
require_once('inc/foot.php');
?>