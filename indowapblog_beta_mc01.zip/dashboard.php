<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/
define('_IWB_', 1);
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
$cup=htmlentities($cup);

include('inc/indowapblog.php');
switch ($cup)
{
case 'ads':
include('inc/admin/ads.php');
break;
case 'category':
include('inc/admin/category.php');
break;
case 'credit':
include('inc/admin/credit.php');
break;
case 'css_editor':
include('inc/admin/css_editor.php');
break;
case 'domain_parking':
include('inc/admin/domain_parking.php');
break;
case 'following':
include('inc/admin/following.php');
break;
case 'google':
include('inc/admin/google.php');
break;
case 'html_tutorial':
include('inc/admin/html_tutorial.php');
break;
case 'navigation':
include('inc/admin/navigation.php');
break;
case 'settings':
include('inc/admin/settings.php');
break;
case 'stats':
include('inc/admin/stats.php');
break;
case 'subscribe':
include('inc/admin/subscribe.php');
break;
case 'template':
include('inc/admin/template.php');
break;
default:
$defined='on';
include('member.php');
break;
}
?>