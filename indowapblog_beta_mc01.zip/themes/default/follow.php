<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');

if (!$user_id)
{
relogin();
}
else {
$cek=mysql_result(mysql_query("select count(*) as num from following where site_id='".$user_id."' and url='".$site['url']."'"), 0);
if ($cek == 0) {
header("Location: ".$site_url."/dashboard.php?cup=following&action=follow&id=".$site_id);
}
else {
header('Location: '.$site['url']);
}
}
?>