<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');
$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) from guestbook where site_id='".$site['id']."' and status='1'"), 0);
$gp = ceil($total / $site['num_post_main']);

if (!ctype_digit($page) || empty($page) || $page > $gp)
{
$page=$gp;
}
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

if (isset($_POST['guestbook']))
{

if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$uid=$user_id;
$url=$site_url;
}
else
{
$nama=$_POST['name'];
$email=$_POST['email'];
$uid='0';
$url='';
}
$pesan=$_POST['message'];

if ($site['comment_mod'] == 1)
{
 if ($is_admin)
$sts='1';
else
$sts='0';
}
else
{
$sts='1';
}
$code=intval($_POST['captcha']);

if ($code != $_SESSION['captcha_code'])
$hsl=$LANG['incorrect_security_code'];

if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl=str_replace('::number::','500',$LANG['text_max']);
if (empty($pesan))
$hsl=$LANG['empty_text'];
if (empty($email))
$hsl=$LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)
$hsl=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl=$LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl=$LANG['lenght_name'];
if (empty($nama))
$hsl=$LANG['empty_name'];
if (empty($hsl))
{

mysql_query("insert into `guestbook` set site_id='".$site['id']."', `user_id`='".$uid."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `site`='".mysql_real_escape_string($url)."', `text`='".mysql_real_escape_string($pesan)."', status='".$sts."', `time`='".time()."'") or die(mysql_error());
if ($sts == 1)
$hsl=$LANG['message_added_successfully'];
else
$hsl=$LANG['message_waiting_approved'];
}
$hasil=$hsl;
}
$head_title=$LANG['guestbook'];
require_once('themes/default/header.php');
if ($hasil)
echo '<div class="pesan">'.$hasil.'</div>';
echo '<div class="book">'.$LANG['guestbook'].'</div>';

if ($total != 0)
{
$req=mysql_query("select * from guestbook where site_id='".$site['id']."' and status='1' order by time asc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
if (!empty($res['site']))
$show_user='<a href="'.htmlentities($res['site']).'" rel="dofollow">'.htmlspecialchars($res['name']).'</a>';
else
$show_user = htmlspecialchars($res['name']);
echo '<div class="menu"><img src="'.$site['url'].'/img.php?img='.$res['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/> '.$show_user.'<span>'.waktu($res['time']).'</span>';
echo '<p>'.bbsm($res['text']).'</p></div>';
}
$link=''.$site['url'].'/guestbook/page/';
$q='.xhtml';
show_pagination($page,$max_view,$total,$link,$q);
}
else
{
echo '<div class="menu">
<p class="eror">'.$LANG['guestbook_empty'].'</p></div>';
}
echo '<form id="comment-form" action="'.$site['url'].'/guestbook.xhtml" method="post">';
$rdr = $site['url'] . htmlspecialchars($_SERVER['REQUEST_URI']);
if ($user_id)
{
echo '<div class="menu"><img src="'.$site['url'].'/img.php?img='.$user_id.'.jpg&amp;w=40&amp;h=40" alt=""/> <a href="'.$site['url'].'/user.php?id='.$user_id.'">'.htmlspecialchars($user_name).'</a><span>(<a href="'.$site['url'].'/login.php?cup=logout&amp;redir='.base64_encode($rdr).'" rel="nofollow">'.$LANG['logout'].'</a>)</span>';
}
else
{
echo '<p><a href="'.$site['url'].'/login.php?redir='.base64_encode($rdr).'" rel="nofollow">'.$LANG['login'].'</a><br /><h1>'.$LANG['name'].': </h1><br/><input type="text" name="name" value=""><br/><h1>'.$LANG['email'].'</h1><br/><input type="text" name="email" value=""><br />';
}
echo '<h1>'.$LANG['message'].':</h1><br/><textarea name="message" rows="8" cols="20"></textarea>
<br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo '<h1>'.$LANG['security_code'].':</h1><br/>
<img src="'.$site['url'].'/captcha.php" alt="'.$LANG['refresh'].'...."/><br/>
<input type="text" name="captcha" value="" size="22"><br/>';
echo '<input name="guestbook" type="submit" value="'.$LANG['send'].'"/></form></div>';

require_once('themes/default/footer.php');

?>