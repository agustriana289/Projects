<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$t=strtolower(preg_replace('#([\W_]+)#','-',$_GET['t']));

$cek=mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' AND link='".mysql_real_escape_string($t)."' AND draft='0' ORDER BY id DESC LIMIT 1;");

if (mysql_num_rows($cek) == 0) {
require_once('themes/default/header.php');
echo '<div class="post"><p class="eror">'.$LANG['blog_not_found'].'</p></div>';
require_once('themes/default/footer.php');
}
else {
$blogs=mysql_fetch_array($cek);

$tot = $blogs['count'] + 1;
mysql_query("UPDATE blog SET count='".$tot."' WHERE id='".$blogs['id']."'");

$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' AND url='".mysql_real_escape_string($site_url)."'"), 0);


if ($blogs['private'] == 1) {
if ($user_id)
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2) {
if ($user_id && ($cf != "0" || $site_id == $user_id))
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_follower'];
}
else {
$blog_description = $blogs['description'];
}
if (substr($_SERVER['REQUEST_URI'], -12) == "translate=en")
{
$blog_description = GoogleTranslate($blog_description,"en");
}
elseif (substr($_SERVER['REQUEST_URI'], -12) == "translate=ru")
{
$blog_description = GoogleTranslate($blog_description,"ru");
}
else {
$blog_description = $blog_description;
}
$head_description = substr(htmlentities(strip_tags($blog_description)),0,200);
$head_title=$blogs['title'];
require_once('themes/default/header.php');

echo '<div class="post"><h1>'.htmlspecialchars($blogs['title']).'</h1><span>'.waktu($blogs['time']).'</span>';
$Trans2RU='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=ru">RU</a>]';
$Trans2EN='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=en">EN</a>]';
echo '<p>'.iwb_html(str_replace('[EN]',$Trans2EN,str_replace('[RU]',$Trans2RU,$blog_description))).'</p>';

echo '<br/><br/></div>';
echo '<h1 class="author">Info</h1><div class="menu">'.$LANG['author'].': '.iwbid($site_id);
if (!empty($blogs['category'])) {
echo '</div><div class="menu">Share: <a href="http://m.facebook.com/sharer.php?u='.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="images/fb.png" alt="Share on Facebook"/></a> <a href="http://mobile.twitter.com/home?status='.urlencode($blogs['title']).'+'.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="images/tw.png" alt="Share on Twitter"></a></div><div class="menu">'.$LANG['category'].': ';
$explod = explode(",",$blogs['category']);
$count_exp = count($explod) -1;
$rand = mt_rand(0, $count_exp);

// Rand kategory
$q_related = $explod[$rand];

for ($e =0; $e <= $count_exp; $e++)
{
if ($_kat = mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id='" . mysql_real_escape_string($explod[$e]) . "' AND site_id='" . $site['id'] . "'")))
echo '<a href="' . $site['url'] . '/category/' . $_kat['link'] . '/1.xhtml">' . htmlentities($_kat['name']) . '</a>, ';
}
}
if (!empty($blogs['tag'])) {
echo '</div><div class="menu">' . $LANG['tag'] . ': ';
$explode = explode(",", $blogs['tag']);
if ($explode) {
$count = count($explode) -1;
for ($i = 0; $i <= $count; $i++) {
echo '<a href="' . $site_url . '/tag/' . $explode[$i] . '/1.xhtml">' . str_replace('-', ' ', $explode[$i]) . '</a> ';
}
}
else {
echo '<a href="' . $site_url . '/tag/' . $blogs['tag'] . '/1.xhtml">' . str_replace('-', ' ', $blogs['tag']) . '</a>';
}
}
echo '</div><div class="menu"><a href="' . $site_url . '/follow.xhtml">Follow</a></div><div class="menu"><a href="' . $site_url . '/guestbook.xhtml">Guestbook</a></div>';
echo '<h1 class="recent">'.$LANG['related_post'].'</h1>';
if (!empty($blogs['category']))
{
$_related = mysql_fetch_array(mysql_query("SELECT blog_id FROM category WHERE id='" . mysql_real_escape_string($q_related) . "' AND site_id='" . $site['id'] . "'"));
$exp = explode(",",$_related['blog_id']);
$count = count($exp) - 1;
if ($count > 4)
$cou = 4;
else
$cou = $count;
for ($i=0; $i <= $cou; $i++)
{
if ($exp[$i] == $blogs['id']) {
continue;
}
else {
if ($reads = mysql_fetch_array(mysql_query("SELECT title, link FROM blog WHERE id='" . mysql_real_escape_string($exp[$i]) . "' AND site_id='" . $site['id'] . "' AND draft = '0'")))
echo '<div class="menu"><a href="' . $site['url'] . '/' . $reads['link'] . '.xhtml">' . htmlspecialchars($reads['title']) . '</a></div>';
}
}
}
$AD=mysql_query("SELECT * FROM ads WHERE site_id='".$site['id']."' AND status='1'");
if (mysql_num_rows($AD) != 0) {
$ADS=mysql_fetch_array($AD);
$PB=$ADS['adcode'];
echo '<!-- ads start --><div class="ads">';
if ($ADS['adby'] == 'mobgold') {
ads_mobgold($PB);
}
elseif ($ADS['adby'] == 'buzzcity') {
ads_buzzcity($PB);
}
elseif ($ADS['adby'] == 'smaato') {
ads_smaato($PB);
}
if ($ADS['adby'] == 'mobday') {
ads_mobday($PB);
}
else {
}
echo '</div><!-- ads end -->';
}
else
{
echo '<!-- ads start --><!-- <div class="ads">Ads Here</div> --><!-- ads end -->';
}
$list_comments = mysql_query("SELECT * FROM comment WHERE blog_id='".$blogs['id']."' AND status='1' ORDER BY time asc");
$total_comments = mysql_num_rows($list_comments);

echo '<h1 class="comment">';
if ($site['display_count'] == 1)
{
echo ''.$LANG['comments'].' '.$total_comments.' | '.$LANG['hits'].' '.$blogs['count'].' | '.$LANG['subscribe'].' (<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">'.$LANG['email'].'</a>)';
}
else
{
echo ''.$LANG['comments'].' '.$total_comments.' | '.$LANG['subscribe'].' (<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">'.$LANG['email'].'</a>)';
}
echo '</h1><!-- comment start -->';

// Start function
function show_comments()
{
if ($GLOBALS['total_comments'] < 1)
{
echo '<!-- comment-list start --><div class="menu"><p class="eror">'.$GLOBALS['LANG']['comment_empty'].'</p></div><!-- comment-list end -->';
}
else
{
while ($comments=mysql_fetch_array($GLOBALS['list_comments']))
{
if (empty($comments['site']))
$show_user=$comments['name'];
else
$show_user='<a
href="'.htmlentities($comments['site']).'"
rel="nofollow">'.htmlspecialchars($comments['name']).'</a>';
echo '<div class="menu"><img src="'.$GLOBALS['site']['url'].'/img.php?img='.$comments['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/> '.$show_user.'<span>'.waktu($comments['time']).'</span>';
echo '<p>'.nl2br(bbsm($comments['text'])).'</p></div><!-- comment-list end -->';
}
}
if ($GLOBALS['blogs']['allow_comment'] == 1)
{
$skrg='/'.$GLOBALS['blogs']['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil='<span class="eror">'.$GLOBALS['LANG']['incorrect_security_code'].'</span>';
if ($string == 'err_msg')
$hasil='<span class="eror">'.$GLOBALS['LANG']['empty_text'].'</span>';
if ($string == 'err_mail')
$hasil='<span class="eror">'.$GLOBALS['LANG']['empty_email'].'</span>';
if ($string == 'err_invalid_email')
$hasil='<span class="eror">'.$GLOBALS['LANG']['incorrect_email'].'</span>';

if ($string == 'err_leng_email')
$hasil='<span class="eror">'.$GLOBALS['LANG']['lenght_email'].'</span>';
if ($string == 'err_name')
$hasil='<span class="eror">'.$GLOBALS['LANG']['empty_name'].'</span>';
if ($string == 'ok')
$hasil='<span id="success">'.$GLOBALS['LANG']['comment_waiting_approved'].'</span>';
if ($string == 'success')
$hasil='<span class="pesan">'.$GLOBALS['LANG']['comment_successfully_added'].'</span>';
if (!empty($hasil))
echo '<!-- notice start --><div class="notice">'.$hasil.'</div><!-- notice end -->';
echo '<form action="'.$GLOBALS['site']['url'].'/comment.xhtml" method="POST">';
$redir=''.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'.xhtml#new_comment';
if ($GLOBALS['user_id'])
{
echo '<div class="menu"><img src="'.$GLOBALS['site']['url'].'/img.php?img='.$GLOBALS['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/> <a href="'.$GLOBALS['site']['url'].'/user.php?id='.$GLOBALS['user_id'].'">'.htmlspecialchars($GLOBALS['user_name']).'</a><span>(<a href="'.$GLOBALS['site']['url'].'/login.php?cup=logout&amp;redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['logout'].'</a>)</span>';
}
else
{
echo '<p><a href="'.$GLOBALS['site']['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['login'].'</a><br /><h1>'.$GLOBALS['LANG']['name'].'</h1><br /><input type="text" name="name" value="'.htmlspecialchars(stripslashes($_SESSION['name'])).'">';
if ($GLOBALS['site']['comment_email'] == 1)
echo '<h1>'.$GLOBALS['LANG']['email'].'</h1><br /><input type="text" name="email" value="'.htmlspecialchars(stripslashes($_SESSION['email'])).'">';
echo '<h1>'.$GLOBALS['LANG']['site'].'</h1><br /><input type="text" name="site" value="'.htmlspecialchars(stripslashes($_SESSION['site'])).'">';
}
echo '<h1>'.$GLOBALS['LANG']['comments'].'</h1><br /><textarea name="text" rows="8" cols="20"></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($GLOBALS['site']['comment_captcha'] == 1)
{
echo '<h1>'.$GLOBALS['LANG']['security_code'].'</h1><br /><img src="'.$GLOBALS['site']['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" value="">';
}
else
{
echo '<input type="hidden" name="code" value="'.htmlentities($_SESSION['captcha_code']).'"/>';
}
echo '<input type="hidden" name="t" value="'.htmlspecialchars($GLOBALS['t']).'"/><br /><input name="comment" type="submit" value="Komentar"/></form>';
}
else
{
echo '<!-- notice start --><div class="eror">'.$GLOBALS['LANG']['comment_closed'].'</div><!-- notice end -->';
}
}
// End function

if ($blogs['private'] == 1)
{
if ($user_id)
show_comments();
else
echo '<!-- notice start --><div class="pesan">'.$GLOBALS['LANG']['comment_hidden'].'</div><!-- notice end -->';
}
elseif ($blogs['private'] == 2)
{
if ($user_id && ($cf != 0 || $site_id == $user_id))
show_comments();
else
echo '<!-- notice start --><div class="pesan">'.$LANG['comment_hidden'].'</div><!-- notice end -->';
}
else
{
show_comments();
}
require_once('themes/default/footer.php');
}
?>