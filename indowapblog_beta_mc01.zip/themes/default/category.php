<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');

$name=htmlentities($_GET['name']);
$page=htmlentities($_GET['page']);

$req=mysql_query("select * from category where site_id='".$site['id']."' and link='".mysql_real_escape_string($name)."'");

if (mysql_num_rows($req) == 0)
{
$head_title=$LANG['category'];
require_once('themes/default/header.php');
echo '<div class="post"><p class="eror">'.str_replace('::name::',htmlspecialchars($name),$LANG['category_not_found']).'</p></div>';
}
else
{
$cat=mysql_fetch_array($req);
$head_title=$cat['name'];
require_once('themes/default/header.php');

if (!ctype_digit($page) || $page == 1 || empty($page) || $page > (ceil(count(explode(",",$cat['blog_id'])))))
$page='0';
$max_view=$site['num_post_main'];
$pgs=$page*$max_view;
$lmt=$pgs+$max_view;

echo '<div class="pesan">'.htmlspecialchars($cat['name']).'</div>';
if (!empty($cat['blog_id']))
{
$eks=explode(",",$cat['blog_id']);
$count=count($eks);
if ($count < $lmt)
$lmt=$count;
$i=$pgs;
while ($i<$lmt)
{
if (!empty($eks[$i]) && ctype_digit($eks[$i]))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".mysql_real_escape_string($eks[$i])."' and draft='0'"));

$desc_leng=strlen(htmlentities(strip_tags($blog['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blog['description']),0,150);
if (($desc_mainpage=='1') || ($desc_leng<='149'))
$description=$blog['description'];
else
$description=$desc_put;
$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' and url='".mysql_real_escape_string($site_url)."'"), 0);

if ($blog['private'] == 1)
{
if ($user_id)
$show_description=$description;
else
$show_description=$LANG['post_only_for_member'];
}
elseif ($blog['private'] == 2)
{
if ($user_id && ($cf != "0" || $site_id == $user_id))
$show_description=$description;
else
$show_description=$LANG['post_only_for_follower'];
}
else
{
$show_description=$description;
}

$kat=explode(",",$blog['category']);
$kategori=mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id='".mysql_real_escape_string($kat[0])."' and site_id='".$site['id']."'"));

$total_komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."' and status='1'"),0);

echo '<div class="postt"><h1><a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a></h1><small>'.date("M",$blog['time']).' '.date("d",$blog['time']).' <a href="'.$site['url'].'/category/'.$kategori['link'].'/1.xhtml">'.htmlspecialchars(stripslashes($kategori['name'])).'</a></small><p>'.iwb_html($show_description).'</p></span>Comment: '.$total_komentar.'</span>';
if ($site['display_count'] == 1)
echo '&nbsp;&nbsp;Count: '.$blog['count'].'</span>';
echo '</div>';
echo '<div class="ads">';
iwb_ads();
echo '</div>';

$i++;
}
}

$total=$count;
$link=''.$site['url'].'/category/'.$cat['link'].'/';
$q='.xhtml';
$pagination="on";
}
else
{
echo '<div class="post"><p class="eror">'.str_replace('::name::',htmlspecialchars(stripslashes($cat['name'])),$LANG['category_empty']).'</p></div>';
}
}
require_once('themes/default/footer.php');
?>