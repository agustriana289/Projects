<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');


if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$sender=$user_id;
}
else
{
$nama=$_POST['senders_name'];
$email=$_POST['senders_email'];
$sender='0';
}
$pesan=$_POST['message'];
$code=intval($_POST['captcha']);

$head_title=$LANG['feedback'];
require_once('themes/default/header.php');
if (isset($_POST['send']))
{
if ($code != $_SESSION['captcha_code'])
$hsl=$LANG['incorrect_security_code'];
if (mb_strlen($pesan) > 500)
$hsl=str_replace('::number::','500',$LANG['text_max']);
if (empty($pesan))
$hsl=$LANG['empty_text'];
if (empty($email))
$hsl=$LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)
$hsl=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl=$LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl=$LANG['lenght_name'];
if (empty($nama))
$hsl=$LANG['empty_name'];
if (empty($hsl))
{
mysql_query("insert into `pm` set `receiver_id`='".$site['id']."', `sender_id`='".$sender."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".time()."'") or die(mysql_error());
$hsl=$LANG['message_successfully_sent'];
}
echo '<div class="pesan">'.$hsl.'</div>';
}
echo '<div class="feed">'.$LANG['feedback'].'</div>';

echo '<form action="'.$site['url'].'/feedback.xhtml" method="post">';
if ($user_id)
{
echo '<div class="menu"><img src="'.$site['url'].'/img.php?img='.$user_id.'.jpg&amp;w=40&amp;h=40" alt=""/> <a href="'.$site['url'].'/user.php?id='.$user_id.'">'.htmlspecialchars($user_name).'</a><span>(<a href="'.$site['url'].'/login.php?cup=logout" rel="nofollow">'.$LANG['logout'].'</a>)</span>';
}
else
{
echo '<h1>'.$LANG['name'].'</h1><br/><input type="text" name="senders_name" value=""><br /><h1>'.$LANG['email'].'</h1><br/><input type="text" name="senders_email" value=""><br />';
}
echo '<h1>'.$LANG['message'].'</h1>
<textarea name="message" rows="8" cols="20"></textarea><br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo '<h1>'.$LANG['security_code'].'</h1><br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/><input type="text" name="captcha" value="" size="22"><br/><input type="submit" name="send" value="'.$LANG['send'].'"/></form></div>';
require_once('themes/default/footer.php');
?>