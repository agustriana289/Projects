<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');
if ($site['cat_loc']=="foot")
{
show_category();
}

$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) == 0) {

}
else {
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<!-- ads start --><div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div><!-- ads end -->';
}


echo '<h1 class="navigasi">'.$LANG['navigation'].'</h1>';

if ($homepage != 'off')
echo '<div class="navigasi-list-home"><a href="'.$site['url'].'">'.$LANG['homepage'].'</a></div>';
$nav=mysql_query("select * from navigation where site_id='".$site['id']."' order by place asc");
while ($navs=mysql_fetch_array($nav))
{
echo '<div class="navigasi-list">'.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$site['url'],$navs['code']))).'</div>';
}
echo '<div class="footer">';

$t_day=date('d-m-Y', time());
$qr=mysql_query("select total from stats where site_id='".$site['id']."' and time='$t_day'");
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set site_id='".$site['id']."', total='1', time='$t_day'");
}
else
{
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
mysql_query("update stats set total='$new_count' where site_id='".$site['id']."' and time='$t_day'");
}

if ($site['display_count'] == 1)
{
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats where site_id='".$site['id']."'"));

echo '<p>Visitor: '.$t_all['total'].'</p>';
}
echo '&copy; '.date('Y', time()).' <a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a><br />'.$LANG['powered_by'].' <small><a href="http://indowapblog.com">IndoWapBlog.Com</a></small></div>';
echo '</body></html>';
mysql_close($iwb_connect);
?>