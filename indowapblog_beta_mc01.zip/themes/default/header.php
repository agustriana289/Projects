<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');

if ($user_id)
{
if ($indowapblog['ban'] == '1')
{
header('Location: index.php');
exit;
}
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
if (mysql_num_rows($ip_cek) != 0)
{
header('location: index.php');
exit;
}
}
$head_title=isset($head_title) ? $head_title : $site['name'];

if ($head_title != $site['name'])
$head_title=''.htmlspecialchars($head_title).' | '.htmlspecialchars($site['name']).'';
else
$head_title=htmlspecialchars($head_title);

$head_description=isset($head_description) ? $head_description : $site['description'];
$head_description=strip_tags($head_description);
$head_description=substr($head_description,0,200);

header("Cache-Control: public");
header('Content-type: application/xhtml+xml; charset=UTF-8');

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">';
echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">';
echo '<head><title>'.stripslashes($head_title).'</title>';
echo '<link rel="shortcut icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" />';
echo '<meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=iso-8859-1" />';
echo '<meta name="HandheldFriendly" content="True" />';
echo '<meta name="description" content="'.htmlentities(strip_tags(stripslashes($head_description))).'" />';
echo '<meta name="keywords" content="'.htmlentities($site['keywords']).'" />';
echo '<link rel="alternate" type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml"/>';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

echo '<meta name="viewport" content="width=320" />';
echo '<meta name="viewport" content="initial-scale=1.0" />';
echo '<meta name="viewport" content="user-scalable=false" />';
echo '<meta http-equiv="Cache-Control" content="max-age=1" />';
echo '<link rel="stylesheet" type="text/css" href="'.$site['url'].'/theme/default/style.css" media="all">';
echo '<script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script></head><body>';

if (!empty($site['logo']))
{
$headitem='<img src="'.$site['url'].'/content/'.htmlentities($site['logo']).'" alt="'.htmlentities($site['name']).'"/>';
}
else
{
$headitem=htmlspecialchars($site['name']);
}

echo '<div class="header"><h1><a href="'.$site['url'].'/home.xhtml">'.$headitem.'</a></h1><span>'.htmlspecialchars(stripslashes($site['description'])).'</span></div>';

echo '<div class="search"><form action="'.$site['url'].'/" method="GET"><input type="text" name="search" value=""><input type="submit" value="'.$LANG['search_submit'].'"></form></div>';
?>