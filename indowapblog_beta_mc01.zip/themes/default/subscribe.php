<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Dilarang!');

function show_table($var)
{
}

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'unsubscribe':
$code=htmlentities($_GET['code']);
$cek=mysql_query("select * from subscribe where site_id='".$site['id']."' and code='".mysql_real_escape_string($code)."' limit 1;");
if (mysql_num_rows($cek) == 0)
{
$hasil=$LANG['incorrect_confirm_code'];
}
else
{
mysql_query("delete from subscribe where site_id='".$site['id']."' and code='".mysql_real_escape_string($code)."'");
$hasil=$LANG['unsubscribe_successfully'];
}
$head_title=$LANG['unsubscribe'];
require_once('themes/default/header.php');
show_table($LANG['unsubscribe']);
echo '<div class="post"><h1>'.$LANG['unsubscribe'].'</h1>';
echo '<p>'.$hasil.'</p>';
echo '</div>';
require_once('themes/default/footer.php');
break;

case 'confirm':
$code=htmlentities($_GET['code']);
$cek=mysql_query("select * from subscribe where site_id='".$site['id']."' and code='".mysql_real_escape_string($code)."' limit 1;");
if (mysql_num_rows($cek) == 0)
{
$hasil=$LANG['incorrect_confirm_code'];
}
else
{
$res=mysql_fetch_array($cek);
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("update subscribe set status='1', code='".$cod."', time='".$tim."' where id='".$res['id']."'");
$hasil=$LANG['subscribe_successfully'];
}
$head_title=$LANG['confirm_subscribe'];
require_once('themes/default/header.php');
show_table($LANG['confirm_subscribe']);
echo '<div class="post"><h1>'.$LANG['confirm_subscribe'].'</h1>';
echo '<p>'.$hasil.'</p>';
echo '</div>';
require_once('themes/default/footer.php');

break;
case 'new_posts':

if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error=$LANG['incorrect_email'];
if (empty($my_email))
$error=$LANG['empty_email'];
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='new_posts'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil=$LANG['was_subscribe'];
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='new_posts', status='1', code='".$cod."', time='".$tim."'");
$hasil=$LANG['subscribe_new_post_successfully'];
}
}
else
{
$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='new_posts'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$res['code'],str_replace('::site_url::',$site['url'],$LANG['subscribe_new_post_msg'])));
$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='new_posts', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$cod,str_replace('::site_url::',$site['url'],$LANG['subscribe_new_post_msg'])));

$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/posts/subscribe.xhtml">'.$LANG['back'].'</a>';
}
}

$head_title=$LANG['subscribe_new_post'];
require_once('themes/default/header.php');
show_table($LANG['subscribe']);
echo '<div class="post"><h1>'.$LANG['subscribe'].'</h1>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>'.$LANG['subscribe_new_post'].'</p><p><form method="post" action="'.$site['url'].htmlspecialchars($_SERVER['REQUEST_URI']).'"><b>'.$LANG['email'].'</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<br/><input type="submit" name="subscribe" value="'.$LANG['send'].'"/>
</form></p>';
}
echo '</div>';
require_once('themes/default/footer.php');
break;


case 'new_comments':
if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error=$LANG['incorrect_email'];
if (empty($my_email))
$error=$LANG['empty_email'];
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='new_comments'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil=$LANG['was_subscribe'];
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='new_comments', status='1', code='".$cod."', time='".$tim."'");
$hasil=$LANG['subscribe_new_comment_successfully'];
}
}
else
{

$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='new_comments'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$res['code'],str_replace('::site_url::',$site['url'],$LANG['subscribe_new_comment_msg'])));


$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);

}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='new_comments', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$cod,str_replace('::site_url::',$site['url'],$LANG['subscribe_new_comment_msg'])));
$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/comments/subscribe.xhtml">'.$LANG['back'].'</a>';
}
}



$head_title=$LANG['subscribe_new_comment'];
require_once('themes/default/header.php');
show_table($LANG['subscribe']);
echo '<div class="post"><h1>Berlangganan</h1>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>'.$LANG['subscribe_new_comment'].'</p><p><form method="post" action="'.$site['url'].htmlspecialchars($_SERVER['REQUEST_URI']).'"><b>'.$LANG['email'].'</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<br/><input type="submit" name="subscribe" value="'.$LANG['send'].'"/>
</form></p>';
}
echo '</div>';
require_once('themes/default/footer.php');
break;

default:
$sub=htmlentities($_GET['sub']);
if (empty($sub))
$sub=htmlentities($_POST['sub']);
$Req=mysql_query("select * from blog where site_id='".$site['id']."' and link='".mysql_real_escape_string($sub)."' limit 1;");
if (mysql_num_rows($Req) != 0)
{
$blog=mysql_fetch_array($Req);

}
if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error=$LANG['incorrect_email'];
if (empty($my_email))
$error=$LANG['empty_email'];
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='".mysql_real_escape_string($sub)."'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil=''.$LANG['was_subscribe'].' <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='".mysql_real_escape_string($sub)."', status='1', code='".$cod."', time='".$tim."'");
$hasil=''.$LANG['subscribe_comment_successfully'].' <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';
}
}
else
{

$cek_sub=mysql_query("select * from subscribe where site_id='".$site['id']."' and email='".mysql_real_escape_string($my_email)."' and sub='".mysql_real_escape_string($sub)."'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::blog::',$blog['title'],str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$res['code'],str_replace('::site_url::',$site['url'],$LANG['subscribe_comment_msg']))));
$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set site_id='".$site['id']."', email='".mysql_real_escape_string($my_email)."', sub='".mysql_real_escape_string($sub)."', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where id='".$site['id']."' limit 1;"));

$email = $my_email;
$subject=$LANG['confirm_subscribe'];
$pesan=str_replace('::blog::',$blog['title'],str_replace('::site_name::',htmlspecialchars($site['name']),str_replace('::link::',''.$site['url'].'/subscribe/'.$cod,str_replace('::site_url::',$site['url'],$LANG['subscribe_comment_msg']))));
$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil=str_replace('::via::','email',$LANG['confirm_code_was_sent']);
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/'.htmlentities($sub).'/subscribe.xhtml">'.$LANG['back'].'</a>';
}
}


$head_title=''.$LANG['subscribe_comment'].': '.$blog['title'];
require_once('themes/default/header.php');
show_table($LANG['subscribe']);
echo '<div class="post"><h1>'.$LANG['subscribe'].'</h1>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>';
$rek=mysql_query("select * from blog where site_id='".$site['id']."' and link='".mysql_real_escape_string($sub)."' limit 1;");
if (mysql_num_rows($rek) == 0)
{
echo $LANG['blog_not_found'];
}
else
{
echo ''.$LANG['subscribe_comment'].' <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';

echo '</p><p><form method="post" action="'.$site['url'].htmlspecialchars($_SERVER['REQUEST_URI']).'"><b>'.$LANG['email'].'</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<input type="hidden" name="sub" value="'.htmlentities($sub).'" />';
echo '<br/><input type="submit" name="subscribe" value="'.$LANG['send'].'"/>
</form>';
}
}
echo '</p></div>';
require_once('themes/default/footer.php');
}
?>