<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

$search = urlencode($_GET['search']);
$tag = htmlentities($_GET['tag']);
$page = htmlentities($_GET['page']);

if (isset($_GET['search'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND (title LIKE '%".mysql_real_escape_string(urldecode($search))."%' or description LIKE '%".mysql_real_escape_string(urldecode($search))."%') AND draft = '0'"), 0);

$head_title=''.$LANG['search_for'].': '.urldecode($search);
}
elseif (isset($_GET['tag'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft = '0'"), 0);

$head_title=''.$LANG['tag'].': '.str_replace('-', ' ', $tag);
}
else {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND draft = '0'"), 0);
}

if (empty($page) || $page == 0 || !ctype_digit($page) || $page > (ceil($total / $site['num_post_main'])))
$page = 1;
$page--;
$max_view = $site['num_post_main'];
$limit = $page * $max_view;
$page++;

require_once('themes/desktop/header.php');
if (isset($_GET['search']))
{
echo '<div class="pesan">'.str_replace('::number::','<i>'.$total.'</i>',str_replace('::query::','&quot;<i>'.htmlentities(urldecode($search)).'</i>&quot;',$LANG['result'])).'</div>';

$blog = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND (title LIKE '%".mysql_real_escape_string($search)."%' OR description LIKE '%".mysql_real_escape_string($search)."%') AND draft = '0' ORDER BY time DESC LIMIT $limit, $max_view");
}
elseif (isset($_GET['tag'])) {
echo '<div class="pesan">'.$LANG['tag'].' <li>'.str_replace('-', ' ', $tag).'</li></div>';

$blog = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft = '0' ORDER BY time DESC LIMIT $limit, $max_view");
}
else {
$blog=mysql_query("select * from blog where site_id='".$site['id']."' and draft='0' order by time desc limit $limit,$max_view");
}
if ($total > 0)
{
$is_follower = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '".$user_id."' AND url = '".mysql_real_escape_string($site_url)."'"), 0);
$posted = iwbid($site_id);
while ($blogs = mysql_fetch_array($blog))
{
echo '<div class="post-home">';
echo '<h2><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">'.htmlspecialchars($blogs['title']).'</a></h2><span>'.$LANG['by'].' '.$posted.' '.$LANG['on'].' '.waktu($blogs['time']).'</span>';

$desc_leng = strlen(strip_tags($blogs['description']));
$desc_mainpage = $site['desc_post_main'];
$desc_put = substr(strip_tags($blogs['description']),0,300);

if ($desc_mainpage == 1 || $desc_leng < 249)
$description = $blogs['description'];
else
$description = ''.$desc_put.'...<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">['.$LANG['more'].']</a>';

$komentar = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM comment WHERE blog_id = '".$blogs['id']."' AND status = '1'"), 0);
if ($blogs['private'] == 1) {
if ($user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>'.$LANG['post_only_for_member'].'</p>';
}
elseif ($blogs['private'] == 2) {
if ($site_id == $user_id || $is_follower > 0)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>'.$LANG['post_only_for_follower'].'</p>';
}
else {
echo '<p>'.iwb_html($description).'</p>';
}
echo '<span>Komentar : <a href="'.$site['url'].'/'.$blogs['link'].'.xhtml#comments">'.$komentar.'</a></span>';
echo '</div>';
}
}
else {
if (isset($_GET['search'])) {
echo '<div class="rorr">'.$LANG['search_not_found'].'</div>';
}
elseif (isset($_GET['tag'])) {
echo '<div class="rorr">'.$LANG['tag'].' '.$LANG['empty'].'</div>';
}
else {
echo '<div class="rorr">'.$LANG['blog_empty'].'</div>';
}
}
if (isset($_GET['search'])) {
$link=''.$site['url'].'/?search='.$search.'&amp;page=';
$q='';
$pagination="on";
$homepage="on";
}
elseif (isset($_GET['tag'])) {
$link=''.$site['url'].'/tag/'.$tag.'/';
$q='.xhtml';
$pagination="on";
$homepage="on";
}
else {
$link=''.$site['url'].'/page/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}

if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1) {
echo '<div class="pagination">';
for ($i = 1; $i <= $pages; $i++) {
if ($page==$i) {
$num='<span>'.$i.'</span>';
}
else {
$num='<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>';
}
echo $num;
}
echo '</div>';
}

require_once('themes/desktop/footer.php');
?>