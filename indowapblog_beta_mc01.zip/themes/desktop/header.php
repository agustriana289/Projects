<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/


defined('_IWB_') or die('Akser Terlarang!');

if ($user_id) {
$sol = time() - 300;
if ($user_lastdate < $sol) {
mysql_query("UPDATE user SET lastdate = '".time()."' WHERE id = '".$user_id."'");
}
if ($indowapblog['ban'] == 1) {
header("Location: ".$site_url."/login.php?iwb=logout");
exit;
}
}

$head_title = isset($head_title) ? $head_title : $site['name'];

if ($head_title != $site['name'])
$head_title = "".$head_title." | ".$site['name'];
else
$head_title = $head_title;
$head_title = htmlspecialchars($head_title);

$head_description = isset($head_description) ? $head_description : $site['description'];
$head_description = substr(strip_tags($head_description), 0, 200);
$head_description = htmlentities($head_description);

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="'.$site['url'].'/theme/desktop/style.css" type="text/css" />
<title>'.$head_title.'</title><link rel="alternate" media="handheld" href="'.$site['url'].'/" title="Mobile/PDA" /><meta name="description" content="'.$head_description.'" /><!-- Update your html tag to include the itemscope and itemtype attributes -->
<itemscope itemtype="http://schema.org/Blog">

<!-- Add the following three tags inside head -->
<meta itemprop="name" content="'.$head_title.'">
<meta itemprop="description" content="'.$head_description.'"><meta name="keywords" content="'.htmlentities($site['keywords']).'" />';
echo '<link rel="alternate" type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml" />';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

echo '<link rel="icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" />
    <link rel="shortcut icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" />
<script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script></head>
<body><div id="iwb">';
if (!empty($site['logo'])) {
$headitem = '<img src="'.$site['url'].'/content/'.htmlentities($site['logo']).'" alt="'.htmlentities($site['name']).'"/>';
}
else {
$headitem = htmlspecialchars($site['name']);
}
echo '<div id="header"><h2 class="logo">'.$headitem.'</h2><h2 class="description">'.htmlspecialchars($site['description']).'</h2></div>';
echo '<div id="page-sub"><ul id="menu">';
echo '<li><a href="'.$site['url'].'/home.xhtml">HOME</a></li>';
echo '<li><a href="#">FEEDBACK</a>';
echo '<ul class="sub-menu">';
echo '<li><a href="'.$site['url'].'/feedback.xhtml">Feedback</a></li>';
echo '</ul>';
echo '</li>';
echo '<li><a href="#">INFORMASI</a>';
echo '<ul class="sub-menu">';
echo '<li><a href="'.$site['url'].'/guestbook.xhtml">Goestbook</a></li>';
echo '<li><a href="'.$site['url'].'/follow.xhtml">Follow</a></li>';
echo '</ul>';
echo '</li>';
echo '</ul>';
echo '<form method="get" action="'.$site['url'].'/">';
echo '<input type="text" name="search" class="s-txt" value="" />';
echo '<input type="submit" class="search-sm" value="'.$LANG['search_submit'].'"/>';
echo '</form>';
echo '</div>';
echo '<div id="sidebar">';
echo '<ul>';
echo '<li>';
echo '<h3>'.$LANG['latest_post'].'</h3><ul>';
$recents = mysql_query("SELECT title, link FROM blog WHERE site_id = '".$site['id']."' AND draft = '0' ORDER BY time DESC LIMIT 10;");
while ($recent = mysql_fetch_array($recents))
{
echo '<li><a href="'.$site['url'].'/'.$recent['link'].'.xhtml">'.htmlspecialchars($recent['title']).'</a></li>';
}
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<li><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></li>';
}
echo '</ul></li>';
echo '<li>';
echo '<h3>'.$LANG['category'].'</h3>';
echo '<ul>';
$cats = mysql_query("SELECT * FROM category WHERE site_id = '".$site['id']."' ORDER BY name DESC");
if (mysql_num_rows($cats) > 0) {
while ($cat = mysql_fetch_array($cats))
{
if (empty($cat['blog_id'])) {
$cat_count = 0;
}
else {
$cat_count = count(explode(",",$cat['blog_id']));
}
echo '<li><a href="'.$site['url'].'/category/'.$cat['link'].'/1.xhtml">'.htmlspecialchars($cat['name']).'</a> ('.$cat_count.')</li>';
}
}
else {
echo '<li>'.$LANG['empty'].'</li>';
}
echo '</ul></li>';
$followings = mysql_query("SELECT * FROM following WHERE site_id = '".$site['id']."' ORDER BY id DESC LIMIT 50;");
$total_followings = mysql_num_rows($followings);
if ($total_followings > 0)
{
echo '<li>';
echo '<h3>'.$LANG['following'].'</h2><ul>';
while ($rs = mysql_fetch_array($followings))
{
echo '<li><a href="'.htmlentities($rs['url']).'">'.htmlspecialchars($rs['title']).'</a></li>';
}
echo '</ul></li>';
}
echo '<li>';
echo '<h3>'.$LANG['navigation'].'</h3><ul>';

if ($homepage != 'off')
$navs = mysql_query("SELECT * FROM navigation WHERE site_id = '".$site['id']."' ORDER BY place ASC");
while ($nav = mysql_fetch_array($navs))
{
echo '<li>'.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$site['url'],$nav['code']))).'</li>';
}
echo '</ul></li>';
echo '</ul></div>';
?>