<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

echo '</div><div class="footer">';

$t_day = date('d-m-Y', time());
$qr = mysql_query("SELECT total FROM stats WHERE site_id = '".$site['id']."' AND time = '".$t_day."'");
$Qr = mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("INSERT INTO stats SET site_id = '".$site['id']."', total = '1', time = '".$t_day."'");
}
else
{
mysql_query("UPDATE stats SET total = '".$new_count."' WHERE site_id = '".$site['id']."' AND time = '".$t_day."'");
}
echo '<p><a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a><br/>&copy; '.date('Y', time()).' <a href="http://indowapblog.com">IndoWapBlog.Com</a><br/><a href="'.$site['url'].'/mobile.iwb">Mobile</a> | Desktop</span></p></div></body></html>';
mysql_close($iwb_connect);
?>
