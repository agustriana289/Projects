<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang!');

if (substr($_SERVER['REQUEST_URI'], -12) == "translate=en")
{
$blog_description = GoogleTranslate($blog_description,"en");
}
elseif (substr($_SERVER['REQUEST_URI'], -12) == "translate=ru")
{
$blog_description = GoogleTranslate($blog_description,"ru");
}
else {
$blog_description = $blog_description;
}
$Trans2RU='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=ru">RU</a>]';
$Trans2EN='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=en">EN</a>]';

$t = htmlentities($_GET['t']);

$cek = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND link = '".mysql_real_escape_string($t)."' AND draft = '0'");
if (mysql_num_rows($cek) == 0)
{
require_once('themes/desktop/header.php');
echo '<div class="post-single">
<h2>'.$LANG['blog_not_found'].'</h2>
	<p>'.$LANG['blog_not_found'].'</p></div>';
require_once('themes/desktop/footer.php');
exit;
}
else {
$blogs = mysql_fetch_array($cek);

$tot = $blogs['count'] + 1;
mysql_query("UPDATE blog SET count = '".$tot."' WHERE id = '".$blogs['id']."'");

$is_follower = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '".$user_id."' AND url = '".mysql_real_escape_string($site_url)."'"), 0);
if ($blogs['private'] == 1) {
if ($user_id)
$blog_description = $blogs['description'];
else
$blog_description = $LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2) {
if ($site_id == $user_id || $is_follower > 0)
$blog_description = $blogs['description'];
else
$blog_description = $LANG['post_only_for_follower'];
}
else {
$blog_description = $blogs['description'];
}
$head_description = $blog_description;
$head_title = $blogs['title'];
require_once('themes/desktop/header.php');

echo '<div class="post-single"><h2>'.htmlspecialchars($blogs['title']).'</h2>'.$LANG['on'].' '.waktu($blogs['time']).'<br/><p>'.iwb_html($blogs['description']).'</p></div>';
echo '<div class="share-recent">';
echo '<ul><li>';
echo '<h2>Share Artikel</h2>';
echo '<ul>';
echo '<li><a href="http://www.facebook.com/sharer.php?u='.$site['url'].'/'.$blogs['link'].'.xhtml" rel="nofollow"><img src="images/facebook.png" alt="Share on Facebook" /></a> <a href="https://twitter.com/share?url='.$site['url'].'/'.$blogs['link'].'.xhtml"><img src="images/twitter.png"></a></li>';
echo '<li><b>'.$LANG['by'].':</b> <font color="yellow">'.iwbid($site_id).'</font></li>';
echo '</ul>';
echo '<li>';
echo '<h2>Tag Artikel</h2>';
echo '<ul>';
if (!empty($blogs['category']))
{
$exkt = explode(",",$blogs['category']);
$countexp = count($exkt) -1;
for ($e = 0; $e <= $countexp; $e++)
{
$ktname = mysql_fetch_array(mysql_query("SELECT * FROM category WHERE id = '".mysql_real_escape_string($exkt[$e])."' AND site_id = '".$site['id']."'"));
echo '<li><b>'.$LANG['category'].':</b> <a href="'.$site['url'].'/category/'.$ktname['link'].'/1.xhtml">'.htmlentities($ktname['name']).'</a></li>';
}
if (!empty($blogs['tag'])) {
$exp = explode(",", $blogs['tag']);
if ($exp) {
$count = count($exp) - 1;
for ($i = 0; $i <= $count; $i++) {
echo '<li><b>'.$LANG['tag'].':</b> <a href="'.$site_url.'/tag/'.$exp[$i].'/1.xhtml">'.str_replace('-', ' ', $exp[$i]).'</a></li>';
}
}
else {
echo '<li><a href="'.$site_url.'/tag/'.$blogs['tag'].'/1.xhtml">'.str_replace('-', ' ', $blogs['tag']).'</a></li>';
}
}
echo '</ul>';
}
echo '</li>';
echo '</li>';
echo '</ul>';
echo '</div>';
function show_comments()
{
global $blogs, $site, $user_id, $user_name, $user_site, $user_email, $t, $limit, $max_view;
echo '<div id="koment"><h3>'.$GLOBALS['LANG']['comments'].'</h3><br/><small><a href="'.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'/rss.xml">RSS</a> / <a href="'.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'/subscribe.xhtml">'.$GLOBALS['LANG']['email'].'</a></small>';
$total_comments = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM comment WHERE blog_id = '".$GLOBALS['blogs']['id']."' AND status = '1'"), 0);
if ($total_comments > 0)
{
echo '<div class="pesan">'.$total_comments.' Respon untuk
&quot;'.htmlspecialchars($GLOBALS['blogs']['title']).'&quot;</div>';
}
else
{
echo '<div class="rorr">'.$GLOBALS['LANG']['comment_empty'].'</div>';
}
if ($GLOBALS['site']['display_count'] == 1)
echo '<div class="pesan">Dilihat sebanyak &quot;'.$GLOBALS['blogs']['count'].'&quot; kali</div>';
if ($total_comments > 0)
{
$comment = mysql_query("SELECT * FROM comment WHERE blog_id = '".$GLOBALS['blogs']['id']."' AND status = '1' ORDER BY time ASC");
while ($comments = mysql_fetch_array($comment))
{
echo '<div id="comment-list">';
if (!empty($comments['site']))
echo '<h1><a href="'.htmlentities($comments['site']).'/" rel="nofollow">'.htmlspecialchars($comments['name']).'</a>';
else
echo htmlspecialchars($comments['name']);
echo '<small> ['.waktu($comments['time']).']</small></h1>
<p>'.bbsm($comments['text']).'</p>
</div>';
}
}

if ($GLOBALS['blogs']['allow_comment'] == 1)
{
$skrg='/'.$blogs['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil = $GLOBALS['LANG']['incorrect_security_code'];
if ($string == 'err_msg')
$hasil = $GLOBALS['LANG']['empty_text'];
if ($string == 'err_mail')
$hasil = $GLOBALS['LANG']['empty_email'];
if ($string == 'err_invalid_email')
$hasil = $GLOBALS['LANG']['incorrect_email'];
if ($string == 'err_leng_email')
$hasil = $GLOBALS['LANG']['lenght_email'];
if ($string == 'err_name')
$hasil = $GLOBALS['LANG']['empty_name'];
if ($string == 'ok')
$hasil = $GLOBALS['LANG']['comment_waiting_approved'];
if ($string == 'success')
$hasil = $GLOBALS['LANG']['comment_successfully_added'];
if (!empty($hasil))
echo '<div class="pesan">'.$hasil.'</div>';
if ($GLOBALS['user_id'])
{
$form_title = $GLOBALS['user_name'];
$form_site = $GLOBALS['user_site'];
$form_email = $GLOBALS['user_email'];
}
else
{
$form_title = stripslashes($_SESSION['nama']);
$form_site = stripslashes($_SESSION['url']);
$form_email = stripslashes($_SESSION['email']);
}
echo '<form
id="kolom"
action="'.$GLOBALS['site']['url'].'/comment.xhtml"
method="post">';
$redir=''.$GLOBALS['site']['url'].'/'.$blogs['link'].'.xhtml#new_comment';
if (!$GLOBALS['user_id'])
echo '<div class="aut"><a
href="'.$GLOBALS['site']['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['login'].'</a>
</div>';
else
echo '<div class="aut"><a
href="'.$GLOBALS['site']['url'].'/login.php?iwb=logout&amp;redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['logout'].'</a></div>';
echo '<div class="aut">'.$GLOBALS['LANG']['name'].'</div>
<input type="text"
name="title" value="'.$form_title.'" class="txt"/><br />'.$GLOBALS['LANG']['site'].'<br/>
<input type="text"
name="site" value="'.$form_site.'" class="txt"/>';
if ($GLOBALS['site']['comment_email'] == 1)
echo '<br/>'.$GLOBALS['LANG']['email'].'<br/>
<input type="text"
name="email" value="'.$form_email.'" class="txt"/>';
echo '<br/>'.$GLOBALS['LANG']['comments'].'<br/><textarea
name="body" rows="4" class="area"/></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($GLOBALS['site']['comment_captcha'] == 1)
{
echo '<br />'.$GLOBALS['LANG']['security_code'].'<br /><img src="'.$GLOBALS['site']['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" value="" class="txt"/>';
}
else {
echo '<input type="hidden" name="code" value="'.htmlentities($_SESSION['captcha_code']).'">';
}
echo '<input type="hidden"
name="t" value="'.$GLOBALS[t].'"/><br/><input
name="comment" class="sum"
type="submit" id="comment"
value="'.$GLOBALS['LANG']['send'].'"/></form>';
}
else {
echo '<div class="rorr"><a name="new_comment">'.$GLOBALS['LANG']['comment_closed'].'</a></div>';
}
echo '</div>';
}

if (($blogs['private'] == 1 && $user_id) || $blogs['private'] == 0 || ($blogs['private'] == 2 && ($site_id == $user_id || $is_follower > 0))) {
show_comments();
}
else {
echo '<div class="rorr">'.$LANG['comment_hidden'].'</div>';
}

echo '</div>';
require_once('themes/desktop/footer.php');
}
?>