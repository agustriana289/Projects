<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Kesalahan: pembatasan akses');

$head_title = $LANG['feedback'];
require_once('themes/desktop/header.php');
echo '<div id="feedback"><h2>Umpan Balik</h2>';

if ($user_id) {
$nama = $user_name;
$email = $user_email;
$sender = $user_id;
}
else {
$nama = $_POST['senders_name'];
$email = $_POST['senders_email'];
$sender = 0;
}
$pesan = $_POST['message'];
$code = intval($_POST['captcha']);

if (isset($_POST['send']))
{

if ($code != $_SESSION['captcha_code'])
$hsl = $LANG['incorrect_security_code'];
if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl = $LANG['text_max'];
if (empty($pesan))
$hsl = $LANG['empty_text'];
if (empty($email))
$hsl = $LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)$hsl = $LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl = $LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl = $LANG['lenght_name'];
if (empty($nama))
$hsl = $LANG['empty_name'];
if (empty($hsl))
{
mysql_query("INSERT INTO `pm` SET `receiver_id` = '".$site['id']."', `sender_id` = '".$sender."', `name` = '".mysql_real_escape_string($nama)."', `email` = '".mysql_real_escape_string($email)."', `text` = '".mysql_real_escape_string($pesan)."', `read` = '1', `time` = '".time()."'") or die(mysql_error());
$hsl = $LANG['message_successfully_sent'];
}
echo '<div class="pesan">'.$hsl.'</div>';
}

echo '<form id="iwbfeed" name="feedback" action="'.$site['url'].'/feedback.xhtml" method="post"><p>'.$LANG['name'].'<br/>';
if ($user_id)
echo '<b>'.htmlspecialchars($user_name).'</b>';
else
echo '<input class="txt" type="text" name="senders_name" value=""/>';
echo '<br/>'.$LANG['email'].'<br/>';
if ($user_id)
echo '<b>'.$user_email.'</b>';
else
echo '<input class="txt" type="text" name="senders_email" value=""/>';
echo '<br/>'.$LANG['message'].'<br/>
<textarea class="area" name="message" rows="3"/></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($site['comment_captcha'] == 1) {
echo '<br />'.$LANG['security_code'].'<br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/><input type="text" class="txt" name="captcha" value=""/><br/>';
}
else {
echo '<input type="hidden" name="captcha" value="'.htmlentities($_SESSION['captcha_code']).'">';
}
echo '<input type="submit" class="sum" name="send" value="'.$LANG['send'].'"/></form></div>';
require_once('themes/desktop/footer.php');
?>