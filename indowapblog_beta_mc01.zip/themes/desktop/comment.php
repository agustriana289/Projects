<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

defined('_IWB_') or die('Akses Terlarang');

$t = htmlentities($_POST['t']);
$nama = $_POST['title'];
$situs = $_POST['site'];
$mail = $_POST['email'];
$psn = $_POST['body'];
$code = intval($_POST['code']);
$comment_captcha = $site['comment_captcha'];

if ($user_id) {
$commentator = $user_id;
}
else {
$commentator = 0;
}
$req = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND link = '".mysql_real_escape_string($t)."'");
if (mysql_num_rows($req) != 0) {
$is_follower = mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM following WHERE site_id = '".$user_id."' AND url = '".$site_url."'"), 0);
$blogs = mysql_fetch_array($req);
if ($blogs['allow_comment'] == 1)
{
if ($code != $_SESSION['captcha_code'])
$err='err_code';
if (empty($psn))
$err='err_msg';
if ($site['comment_email'] == 1)
{
if (empty($mail))
$err='err_email';
elseif (mb_strlen($mail) < 2 || mb_strlen($mail) > 250)
$err='err_leng_email';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $mail))
$err='err_invalid_email';
}

if (empty($nama))
$err='err_name';

if ($blogs['private'] == 1 && !$user_id) {
$err='member_only';
}
elseif ($blogs['private'] == "2" && $is_follower == "0" && $site_id != $user_id) {
$err='author_only';
}
else {
}

if (empty($err)) {
if ($site['comment_mod'] == 1) {
if ($is_admin)
$sts = 1;
else
$sts = 0;
}
else {
$sts = 1;
}

if ($commentator != 0 && $commentator != $site['id'])
{
$cr=mysql_fetch_array(mysql_query("SELECT credit FROM user WHERE id='".$site['id']."'"));
$credit = $cr['credit'] + 10;
mysql_query("UPDATE user SET credit='".$credit."' WHERE id='".$site['id']."'");
}

mysql_query("insert into comment set site_id='".$site['id']."', user_id='".$commentator."', blog_id='".$blogs['id']."', name='".mysql_real_escape_string($nama)."', site='".mysql_real_escape_string($situs)."', email='".mysql_real_escape_string($mail)."', text='".mysql_real_escape_string($psn)."', status='".$sts."', time='".time()."'");

//*Kirim email*//
if ($blogs['private'] == 1)
{
$kom='Komentar disembunyikan. Silakan kunjungi '.htmlspecialchars($site['name']).' untuk melihat komentar ini.';
}
elseif ($blogs['private'] == 2)
{
$kom='Komentar disembunyikan. Silakan kunjungi '.htmlspecialchars($site['name']).' untuk melihat komentar ini.';
}
else
{
$kom=$psn;
}

$ceksub = mysql_query("SELECT * FROM subscribe WHERE site_id = '".$site['id']."' AND (sub = '".mysql_real_escape_string($t)."' OR sub = 'new_comments') AND status = '1' ORDER BY time DESC LIMIT 20;");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$adm=mysql_fetch_array(mysql_query("select email from user where id='".$site['id']."' limit 1;"));

$email = $subscribe['email'];
$subject="Komentar Baru: ".htmlspecialchars($blogs['title'])."";
$pesan="Komentar baru dari postingan: ".htmlspecialchars($blogs['title'])."\r\n\r\n---\r\n\r\nOleh: ".htmlspecialchars($nama)."\r\n\r\nPada: ".waktu(time())."\r\n\r\nKomentar: ".htmlspecialchars($kom)."\r\n\r\n...\r\n\r\nUntuk membalas komentar ini silakan klik ".$site['url']."/".$t.".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$site['url']."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= htmlspecialchars($site['name']);
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".htmlspecialchars($site['name'])." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}
if ($user_id) {
}
else {
$_SESSION['nama'] = $nama;
$_SESSION['url'] = $situs;
$_SESSION['email'] = $mail;
}
unset($_SESSION['captcha_code']);
if ($site['comment_mod'] == 1)
{
if ($is_admin)
header('location: '.$site['url'].'/'.$t.'.xhtml?success#new_comment');
else
header('location: '.$site['url'].'/'.$t.'.xhtml?ok#new_comment');
}
else {
header('location: '.$site['url'].'/'.$t.'.xhtml?success#new_comment');
}
}
else {
header('location: '.$site['url'].'/'.$t.'.xhtml?'.$err.'#new_comment');
}
}
else {
header('location: '.$site['url'].'/'.$t.'.xhtml');
}
}
else {
header("Location: ".$site_url);
}
mysql_close($iwb_connect);
?>