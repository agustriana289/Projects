<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/


define('_IWB_', 1);
require_once('inc/indowapblog.php');

$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
if (!$user_id)
relogin();
if (!$is_admin)
{
include('inc/head.php');
forbidden();
include('inc/foot.php');
exit;
}
switch ($cup)
{
case 'post': include('inc/owner/post.php');
break;
case 'filter': include('inc/owner/filter.php');
break;
case 'unbanned':
include('inc/owner/unbanned.php');
break;
case 'forum_setting':
include('inc/owner/forum_setting.php');
break;
case 'delete_user':
include('inc/owner/delete_user.php');
break;
case 'banned':
include('inc/owner/banned.php');
break;
case 'author':
include('inc/owner/author.php');
break;
default:
include('inc/owner/index.php');
break;
}
?>