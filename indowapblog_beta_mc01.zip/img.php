<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

function angka($var)
{
if (ctype_digit($var))
return $var;
else
return '0';
}
header("Content-type: image/jpeg");

$path = 'images/profile';
$image=angka(substr($_GET['img'],0,-4));
$image = "".$image.".jpg";
$w_w=angka($_GET['w']);
$w_h=angka($_GET['h']);

$img  = $path . '/' . $image;
if (file_exists($img)) {
	$percent = 0;
	$constrain = 0;
	$w = $w_w;
	$h = $w_h;
} else {
	$img = $path . '/default.jpg';
	$percent = 0;
	$constrain = 0;
	$w = $w_w;
	$h = $w_h;
}

$x = @getimagesize($img);
$sw = $x[0];
$sh = $x[1];

if ($percent > 0)
{
$percent = $percent * 0.01;
	$w = $sw * $percent;
	$h = $sh * $percent;
} else {
	if (isset ($w) AND !isset ($h)) {
		$h = (100 / ($sw / $w)) * .01;
		$h = @round ($sh * $h);
	} elseif (isset ($h) AND !isset ($w)) {
$w = (100 / ($sh / $h)) * .01;
		$w = @round ($sw * $w);
	} elseif (isset ($h) AND isset ($w) AND isset ($constrain)) {
$hx = (100 / ($sw / $w)) * .01;
		$hx = @round ($sh * $hx);

		$wx = (100 / ($sh / $h)) * .01;
		$wx = @round ($sw * $wx);

		if ($hx < $h) {
			$h = (100 / ($sw / $w)) * .01;
			$h = @round ($sh * $h);
		} else {
			$w = (100 / ($sh / $h)) * .01;
			$w = @round ($sw * $w);
		}
	}
}

$im = @ImageCreateFromJPEG ($img) or // Read JPEG Image
$im = @ImageCreateFromPNG ($img) or // or PNG Image
$im = @ImageCreateFromGIF ($img) or // or GIF Image
$im = false; // If image is not JPEG, PNG, or GIF

if (!$im) {
readfile($img);
} else {
$thumb = @ImageCreateTrueColor ($w, $h);
@ImageCopyResampled ($thumb, $im, 0, 0, 0, 0, $w, $h, $sw, $sh);
@ImageJPEG ($thumb);
}
?>