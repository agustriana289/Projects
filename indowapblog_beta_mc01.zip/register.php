<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
switch ($cup)
{
case 'request_kupon':
if (isset($_POST['send']))
{
$email=strtolower($_POST['email']);
$code=$_POST['code'];

if (mb_strlen($email) < 5 || mb_strlen($email) > 40)
$error .='<div class=eror>'.$LANG['lenght_email'].'</div>';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$error .='<div class=eror>'.$LANG['incorrect_email'].'</div>';
if (empty($email))
$error .='<div class=eror>'.$LANG['empty_email'].'</div>';
$check_email=mysql_query("select id from user where email='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$error .='<div class=eror>'.$LANG['email_was_used'].'</div>';
if ($code != $_SESSION['captcha_code'])
$error .='<div class=eror>'.$LANG['incorrect_security_code'].'</div>';
if (empty($error))
{
$adm=mysql_fetch_array(mysql_query("select email from user where id='1'"));
$kupon = rand("11111","99999");
$waktu_kupon = time() + 3600;
mysql_query("insert into kupon_reg set code='".mysql_real_escape_string($kupon)."', email='".mysql_real_escape_string($email)."', time='".mysql_real_escape_string($waktu_kupon)."'");
$email = $email;
$subject=$LANG['reg_coupon_subject'];
$pesan .= "\r\n\r\n";
$pesan .= str_replace('::number::',$kupon,str_replace('::time::',waktu($waktu_kupon),str_replace('::link::',''.$site['url'].'/register.php',str_replace('::site_name::',$site['name'],str_replace('::site_url::',$site['url'],$LANG['reg_coupon_msg'])))));
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
$hasil=str_replace('::time::',waktu($waktu_kupon),$LANG['coupon_successfully_sent']);
}
else
{
$error='<div class=eror>'.$error.'</div>';
}
}
$head_title=$LANG['request_coupon'];
require_once('inc/head.php');
echo '<div class="content">';
if ($site['reg_email'] == 0)
{
echo $LANG['reg_not_using_coupon'];
}
else
{
if (!empty($hasil))
{
echo $hasil;
}
else
{
echo $error;
echo '<form method="post" action="register.php?cup=request_kupon"><h1>'.$LANG['email'].'</h1><br/>
<input name="email" type="text" value="'.htmlentities($email).'" maxlength="40" size="30"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h1>'.$LANG['security_code'].'</h1><br/><img src="captcha.php" alt=""/><br /><input class="name" type="text" name="code" value=""/><br/><input name="send" type="submit" value="'.$LANG['send'].'"/>
</form>';
}
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'terms':
$head_title=$LANG['tos'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="register.php?">'.$LANG['registration'].'</a> | '.$LANG['tos'].'</div>';
echo '<p>'.$LANG['tos_text'].'</p>';
echo '</div>';
require_once('inc/foot.php');
break;


default:
if ($user_id)
{
header('location: index.php');
exit;
}
if ($site['allow_reg'] == 0)
{
$head_title='Pendaftaran Di Nonaktifkan';
require_once('inc/head.php');
echo '<div class="content">';
echo '<img src="images/maaf.gif"> Maaf pendaftaran sementara di non-aktifkan !!! <img src="images/cipok.gif"><br/> Silahkan hubungi admin atau <a href="http://fb.com/mhozacuplis1">Mhoza CupLas CupLis</a> untuk mengkonfirmasi pendaftaran.</div>';
require_once('inc/foot.php');
}
else
{
$subdomain_forbidden = array("admin","wap","mobi","mobile","www","blog","blogs","help","mail","webmail","cpanel","hexagram","whm","panel","contact","SC54","administrator","support","google","gmail","plus","facebook","yahoo","youtube","twitter","blogger","book","blogspot","developer","market","network","mywapblog","user","users","code","email","username","name","nickname","main","forum","wordpress","chat","download","codex","meta","link","server","host","hosting","donasi","donation","free","atom","feed","subscribe","page","pages","fans","porn","horn","sexx","bugil","live","room","kontol","memek","itil","jembut","bego","horni","group","grup","community","komunitas","bantuan","register","registration","member","members","chatroom","guest","guestbook","follow","feedback","load","localhost","subdomain","domain","video","audio","xxxx","service","services","tool","tools","wapmaster","webmaster","master","show","adsense","webhost","webhosting","freehosting","profile","profil","wall","porno","webdisk","chatroom","adult","bing","bego","hack","hacker","windowslive","inwap","sextgem","xtgem","cname","official");

$username=htmlentities(strtolower($_POST['username']));
$domain=htmlentities(strtolower($_POST['domain']));
$pass=$_POST['pass'];
$re_pass=$_POST['re_pass'];
$name=htmlentities($_POST['name']);
$email=strtolower($_POST['email']);
$code=$_POST['code'];
$kupon=$_POST['kupon'];
if (isset($_POST['register']))
{
if (in_array(strtolower($username), $subdomain_forbidden))
$error .='<div class=eror>'.$LANG['username_forbidden'].'</div>';
$st_check=strtolower('http://'.$username.'.'.$domain);
$check_site=mysql_query("select * from site where url='".mysql_real_escape_string($st_check)."' or url_www='".mysql_real_escape_string($st_check)."'");
if (mysql_num_rows($check_site) != 0)
$error .='<div class=eror>'.$LANG['site_was_registered'].'</div>';
if ($domain != $iwb_main_domain)
if ($domain != $iwb_main_domain2)
if ($domain != $iwb_main_domain3)

$error .='<div class=eror>'.$LANG['incorrect_domain'].'</div>';
if (mb_strlen($username) < 4 || mb_strlen($username) > 32)
$error .='<div class=eror>'.$LANG['lenght_username'].'</div>';

$awal=substr($username, 0, 1);
$akhir=substr($username, -1);
if ($awal == '-' || $awal == '_' || $akhir == '-' || $akhir == '_')
$error .='<div class=eror>'.$LANG['username_first_and_last'].'</div>';
if (preg_match("/[^a-z0-9\-]/", $username))
$error .='<div class=eror>'.$LANG['username_allowed_chars'].'</div>';
if (empty($username))
$error .='<div class=eror>'.$LANG['empty_username'].'</div>';
if ($pass != $re_pass)
$error .='<div class=eror>'.$LANG['incorrect_password'].'</div>';
if (mb_strlen($pass) < 4 || mb_strlen($pass) > 12)
$error .='<div class=eror>'.$LANG['lenght_password'].'</div>';
if (empty($pass) || empty($re_pass))
$error .='<div class=eror>'.$LANG['empty_password'].'</div>';
if ($site['reg_email'] == 1)
{
$k=mysql_query("select * from kupon_reg where code='".mysql_real_escape_string($kupon)."' and time > '".time()."'");
if (mysql_num_rows($k) == 0)
$error .='<div class=eror>'.$LANG['incorrect_coupon'].'</div>';
}
else
{
if (mb_strlen($email) < 5 || mb_strlen($email) > 40)
$error .='<div class=eror>'.$LANG['lenght_email'].'</div>';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$error .='<div class=eror>'.$LANG['incorrect_email'].'</div>';
if (empty($email))
$hasil .='<div class=eror>'.$LANG['empty_email'].'</div>';
$check_email=mysql_query("select id from user where email='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$error .='<div class=eror>'.$LANG['email_was_used'].'</div>';
}
if (mb_strlen($name) < 4 || mb_strlen($name) > 30)
$error .='<div class=eror>'.$LANG['lenght_name'].'</div>';
if (preg_match("/[^a-zA-Z0-9\ \-\.\@\{\}\_]/", $name))
$error .='<div class=eror>'.$LANG['incorrect_name'].'</div>';
if (substr($name,0,1) == ' ' || substr($name,-1) == ' ')
$error .='<div class=eror>'.$LANG['incorrect_name'].'</div>';
if (empty($name))
$error .='<div class=eror>'.$LANG['empty_name'].'</div>';
if ($code != $_SESSION['captcha_code'])
$error .='<div class=eror>'.$LANG['incorrect_security_code'].'</div>';
if (empty($error))
{
$password=md5($pass);
$konf='0';
$st_url='http://'.$username.'.'.$domain.'';
$st_url_www='http://www.'.$username.'.'.$domain.'';
if ($site['reg_email'] == 1)
{
$em=mysql_fetch_array($k);
$email = $em['email'];
mysql_query("delete from kupon_reg where code='".mysql_real_escape_string($kupon)."'");
}
else
{
$email = $email;
}
mysql_query("insert into user set username='".mysql_real_escape_string($username)."', password='".mysql_real_escape_string($password)."', email='".mysql_real_escape_string($email)."', name='".mysql_real_escape_string($name)."', site='".mysql_real_escape_string($st_url)."', author='1', credit='500', confirm='".$konf."', date_reg='".time()."'");
$new_id=mysql_insert_id();
$st_title=''.$name.' Mobile Blog';
mysql_query("INSERT INTO `site` SET name='".mysql_real_escape_string($st_title)."', url='".mysql_real_escape_string($st_url)."', url_www='".mysql_real_escape_string($st_url_www)."', description='My Mobile Blog Powered By SC54', keywords='tips, trick, gratisan, xl, indosat, tsel, SC54, open source, mobile blog', theme='default', theme_web='default.web', logo='', favicon='favicon.ico', cat_loc='index', display_following='1', comment_email='1', comment_mod='0', comment_captcha='1', num_post_main='10', desc_post_main='0', gmt='+7', category='10'") or die(mysql_error());
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='Komentar: <a href=\"_SITE_URL_/comment/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/comments/subscribe.xhtml\">[E-Mail]</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='Posting: <a href=\"_SITE_URL_/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/posts/subscribe.xhtml\">[E-Mail]</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/feedback.xhtml\">Feedback</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/guestbook.xhtml\">Buku Tamu</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/chat.php\">Chat Room</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/follow.xhtml\">Follow</a>'");


//*Kategori pertama*//
mysql_query("insert into category set site_id='".$new_id."', link='tak-berkategori', name='Tak Berkategori'");
$new_cat_id=mysql_insert_id();

//*Posting Pertama Blog*//

$title='Posting Pertama';
$teks='Ini adalah postingan pertama Anda, silakan ubah atau hapus postingan ini by Silent54.';
mysql_query("insert into blog set site_id='".$new_id."', title='".mysql_real_escape_string($title)."', description='".mysql_real_escape_string($teks)."', link='posting-pertama', time='".time()."', category='".$new_cat_id."', allow_comment='1', draft='0'");
$new_blog_id=mysql_insert_id();

//*Update kategori*//
mysql_query("update category set blog_id='".$new_blog_id."' where id='".$new_cat_id."'");

//*Komentar*//
mysql_query("insert into comment set site_id='".$new_id."', user_id='1', blog_id='".$new_blog_id."', name='ngecuplis.com', site='http://ngecuplis.com', email='mhozacuplis@gmail.com', text='Terima kasih telah berkreasi dengan SC54', status='1', time='".time()."'");
}
}
$head_title=$LANG['registration'];
require_once('inc/head.php');
echo '<div id="overlay"><div id="popup"><div class="content">';
if (isset($_POST['register']) && empty($error))
{
echo '<div class="succes">'.$LANG['registration_successfully'].'</div>';
}
else
{
if (!empty($error))
echo '<div class="eror">'.$error.'</div>';
echo '<div class="notif">'.$LANG['registration'].' | <a href="register.php?cup=terms">'.$LANG['tos'].'</a></div>';
if ($site['reg_email'] == 1)
{
echo '<p>'.$LANG['coupon_info'].'</p><br />';
}
echo '<form method="post" action="register.php">
<h1>'.$LANG['username'].'</h1><br/>
<input class="name" name="username" type="text" value="'.htmlentities($username).'" maxlength="32"/><br/>
<h1>'.$LANG['domain'].'</h1><br/><select name="domain"><option value="'.$iwb_main_domain.'">'.$iwb_main_domain.'</option><option value="'.$iwb_main_domain2.'">'.$iwb_main_domain2.'</option><option value="'.$iwb_main_domain3.'">'.$iwb_main_domain3.'</option></select><br/>
<h1>'.$LANG['password'].'</h1><br/>
<input class="pass" name="pass" type="password" maxlength="12"/><br/>
<h1>'.$LANG['re_password'].'</h1><br/>
<input class="pass" name="re_pass" type="password" maxlength="12"/><br/>
<h1>'.$LANG['name'].'</h1><br/>
<input class="name" name="name" type="text" value="'.htmlentities($name).'" maxlength="49"/><br/>';
if ($site['reg_email'] == 1)
echo '<h1>'.$LANG['coupon'].'</h1><br/><input type="text" class="email" name="kupon" value="'.htmlentities($kupon).'" maxlength="5"/><br />';
else
echo '<h1>'.$LANG['email'].'</h1><br/>
<input class="email" name="email" type="text" value="'.htmlentities($email).'" maxlength="40"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h1>'.$LANG['security_code'].'</h1><br/><img src="captcha.php" alt=""/><br /><input class="name" type="text" name="code" value=""/><br/>';
echo ''.str_replace('::register::',$LANG['register'],$LANG['tos_notice']).'<br/>
<input name="register" type="submit" value="'.$LANG['register'].'"/>

</form>';
}
echo '</div></div></div>';
require_once('inc/foot.php');
}
}
?>