<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
require_once('inc/indowapblog.php');
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
switch ($cup)
{
case 'phone_number':
if (!$user_id)
relogin();
$head_title=$LANG['phone_number'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="user.php">'.$LANG['profile'].'</a> | <a href="user.php?cup=edit">'.$LANG['edit'].'</a> | <a href="user.php?cup=upload">'.$LANG['upload_photo'].'</a> | <a href="user.php?cup=password">'.$LANG['change_password'].'</a></div>';
if (isset($_POST['confirm']))
{
$kode = "<".htmlentities($_POST['code']).">";
if (preg_match("#".$kode."#s",$indowapblog['no_hp']))
{
$hp = str_replace($kode,"",$indowapblog['no_hp']);
mysql_query("UPDATE user SET no_hp='".mysql_real_escape_string($hp)."' WHERE id='".$user_id."'");
echo $LANG['confirmation_successfully'];
}
else {
echo $LANG['incorrect_confirm_code'];
}
}
elseif (isset($_POST['save']))
{
$cc = str_replace('+','',$_POST['cc']);
$hp = $_POST['hp'];
if (!ctype_digit($cc) || !ctype_digit($hp))
{
echo $LANG['incorrect_phone_number'];
}
elseif (strlen($cc) < 1 || strlen($cc) > 4 || strlen($hp) < 6 || strlen($hp) > 12)
{
echo $LANG['incorrect_phone_number'];
}
elseif (md5($_POST['pwd']) != $indowapblog['password'])
{
echo $LANG['incorrect_password'];
}
else {
if (substr($hp,0,1) == "0")
$hp = substr($hp,1);
$kode = $user_id . rand(100,999);
$phone = "[+".$cc."]".$hp."<".$kode.">";
$get = implode("",file("http://smester.net/sms2.php?api=133968184436511&kode=".$cc."&nomor=".$hp."&pesan=".urlencode("Kode komfirmasi Anda adalah ".$kode.". IndoWapBlog.  ")));
if (preg_match("#Berhasil#si",$get))
{
mysql_query("UPDATE user SET no_hp='".mysql_real_escape_string($phone)."' WHERE id='".$user_id."'");
echo "".str_replace("::via::","Nomor Handphone",$LANG['confirm_code_was_sent'])."<br /><form method=\"post\" action=\"user.php?cup=phone_number\"><h4>".$LANG['code']."</h4><input type=\"text\" name=\"code\" value=\"\"/><br ><input type=\"submit\" name=\"confirm\" value=\"".$LANG['confirm']."\"/></form><br />";
}
else {
echo $LANG['service_not_available'];
}
}
}
else {
if (preg_match("#<#si",$indowapblog['no_hp']))
$myHP = "";
else
$myHP = str_replace("[","",str_replace("]","",$indowapblog['no_hp']));
echo '<b>'.$LANG['phone_number'].': '.$myHP.'</b><br /><form method="post"
action="user.php?cup=phone_number">';
echo '<table border="0"><tr><td><b>CC</b></td><td><b>HP</b></td><tr><td><input name="cc" type="text" value="" maxlength="4" size="5"/></td><td><input name="hp" type="text" value="" maxlength="12"/></td></tr></table><br/>CC: '.$LANG['country_code'].'<br />HP: '.$LANG['phone_number'].'<br /><h1>'.$LANG['password'].'</h1><br/><input name="pwd" type="password" value="" maxlength="12"/><br/><br/><input name="save" type="submit" value="'.$LANG['send'].'"/></form><br/>';
echo "<form method=\"post\" action=\"user.php?cup=phone_number\"><h1>".$LANG['code']."</h1><input type=\"text\" name=\"code\" value=\"\"/><br ><input type=\"submit\" name=\"confirm\" value=\"".$LANG['confirm']."\"/></form><br />";
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'search':
if (!$user_id)
relogin();
$nama=$_GET['name'];
$total=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE name LIKE '%".mysql_real_escape_string($nama)."%'"), 0);
$head_title=$LANG['search'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<h1>'.$LANG['search'].'</h1><form action="'.$site['url'].'/user.php" method="get"><input type="hidden" name="cup" value="search"/><input name="name" type="text" value="'.htmlspecialchars($nama).'"/><br/><input type="submit"  value="'.$LANG['search_submit'].'"/></form>';

if ($total == 0)
{
echo '<div class="succes">'.str_replace('::number::',$total,str_replace('::query::',htmlspecialchars($nama),$LANG['search_result'])).'</div>';
}
else
{
$page=$_GET['page'];
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$req=mysql_query("SELECT id, name, author, admin, date_reg FROM user WHERE name LIKE '%".mysql_real_escape_string($nama)."%' ORDER BY date_reg DESC LIMIT $limit,$max_view");
echo 'Ditemukan '.$total.' untuk pencarian '.htmlspecialchars($nama).'.<br />';
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'" /> ';
if (($res['author'] == '1') && ($res['admin'] == '0'))
{
$font="green";
}
elseif (($res['author'] == '2') && ($res['admin'] == '0'))
{
$font="red";
}
elseif (($res['author'] == '3') && ($res['admin'] == '0'))
{
$font="blue";
}
elseif (($res['author'] == '4') && ($res['admin'] == '0'))
{
$font="yellow";
}
elseif ($res['admin'] == '1')
{
$font="#731174";
}
else
{
$font="black";
}

echo '<a href="user.php?id='.$res['id'].'"><font color="'.$font.'">'.htmlspecialchars($res['name']).'</font></a>';
++$i;
echo '</div>';
}
$link='user.php?cup=search&amp;name='.htmlentities(urlencode($nama)).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');

break;

case 'list':
if (!$user_id)
relogin();
$view=isset($_GET['view'])? trim($_GET['view']) : '';
$page=$_GET['page'];
if ($view == 'member')
{
$total=mysql_result(mysql_query("select count(*) as num from user where author='0' and ban='0'"), 0);
$head_title='List Member';
}
elseif ($view == 'ban')
{
$total=mysql_result(mysql_query("select count(*) as num from user where ban='1'"), 0);
$head_title='Member Diblokir';
}
elseif ($view == 'author')
{
$total=mysql_result(mysql_query("select count(*) as num from user where author='1' and ban='0'"), 0);
$head_title='List Penulis';
}
elseif ($view == 'admin')
{
$total=mysql_result(mysql_query("select count(*) as num from user where admin='1'"), 0);
$head_title='List Administrator';
}
elseif ($view == 'notlogin')
{
$total=mysql_result(mysql_query("select count(*) as num from user where lastdate=''"), 0);
$head_title='Belum Masuk';
}
else
{
$total=mysql_result(mysql_query("select count(*) as num from user"), 0);
$head_title='List Pengguna';
}
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif">';
if (empty($view))
echo $LANG['all'];
else
echo '<a href="user.php?cup=list">'.$LANG['all'].'</a>';
echo ' | ';
if ($view == 'member')
echo $LANG['member'];
else
echo '<a href="user.php?cup=list&amp;view=member">'.$LANG['member'].'</a>';
echo ' | ';
if ($view == 'ban')
echo $LANG['baned'];
else
echo '<a href="user.php?cup=list&amp;view=ban">'.$LANG['baned'].'</a>';
echo ' | ';
if ($view == 'author')
echo $LANG['author'];
else
echo '<a href="user.php?cup=list&amp;view=author">'.$LANG['author'].'</a>';
echo ' | ';
if ($view == 'admin')
echo $LANG['admin'];
else
echo '<a href="user.php?cup=list&amp;view=admin">'.$LANG['admin'].'</a>';
echo ' | ';
if ($is_admin)
{
if ($view == 'notlogin')
echo $LANG['not_login'];
else
echo '<a href="user.php?cup=list&amp;view=notlogin">'.$LANG['not_login'].'</a>';
}
echo '</div>';
echo '<h1>'.$LANG['search'].'</h1><form action="'.$site['url'].'/user.php" method="get"><input type="hidden" name="cup" value="search"/><input name="name" type="text" value=""/><br/><input type="submit" value="'.$LANG['search_submit'].'"/></form><br />';
if ($view == 'member')
{
$req=mysql_query("select * from user where author='0' and ban='0' order by id desc limit $limit,$max_view");
}
elseif ($view == 'ban')
{
$req=mysql_query("select * from user where ban='1' order by id desc limit $limit,$max_view");
}
elseif ($view == 'author')
{
$req=mysql_query("select * from user where author='1' and ban='0' order by id desc limit $limit,$max_view");
}
elseif ($view == 'admin')
{
$req=mysql_query("select * from user where admin='1' order by id desc limit $limit,$max_view");
}
elseif ($view == 'notlogin')
{
$req=mysql_query("select * from user where lastdate='' order by id asc limit $limit,$max_view");
}
else
{
$req=mysql_query("select * from user order by id desc limit $limit,$max_view");
}
if ($total > 0)
{
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'" /> ';

if (($res['author'] == '1') && ($res['admin'] == '0'))
{
$font="green";
}
elseif (($res['author'] == '2') && ($res['admin'] == '0'))
{
$font="red";
}
elseif (($res['author'] == '3') && ($res['admin'] == '0'))
{
$font="blue";
}
elseif (($res['author'] == '4') && ($res['admin'] == '0'))
{
$font="yellow";
}
elseif ($res['admin'] == '1')
{
$font="#731174";
}
else
{
$font="black";
}

echo '<a href="user.php?id='.$res['id'].'"><font color="'.$font.'">'.htmlspecialchars($res['name']).'</font></a>';
++$i;
echo '</div>';
}
}
else
{
echo '<div class="eror>'.$head_title.' '.$LANG['empty'].'</div>';
}
echo '</div>';
if (empty($view))
$link='user.php?cup=list&amp;page=';
else
$link='user.php?cup=list&amp;view='.htmlentities($view).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
break;

case 'email':
if (!$user_id)
relogin();
if (isset($_POST['change']))
{
$pwd=md5($_POST['pwd']);
$email=strtolower($_POST['email']);
$err='Maaf email tidak bisa dirubah. Untuk merubahnya harap hubungi Administrator.';
if ($indowapblog['password'] != $pwd)
$err=$LANG['incorrect_password'];
if (mb_strlen($email) < 2 || mb_strlen($email) > 250)
$err=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$err=$LANG['incorrect_email'];
if (empty($email))
$err=$LANG['empty_email'];
$check_email=mysql_query("select * from `user` where `email`='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$err=$LANG['email_was_used'];
if (empty($err))
{
mysql_query("update user set email='".mysql_real_escape_string($email)."' where id='".$user_id."'");
$hsl='<div class="succes">'.$LANG['change_saved'].'</div>';
}
else
{
$hsl='<div class="eror">'.$err.'</div>';
}
}
$head_title=$LANG['change_email'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<div class="notif"><a href="user.php">'.$LANG['profile'].'</a> | <a href="user.php?cup=edit">'.$LANG['edit'].'</a> | <a href="user.php?cup=upload">'.$LANG['upload_photo'].'</a> | <a href="user.php?cup=password">'.$LANG['change_password'].'</a></div>';
echo '<form method="post"
action="user.php?cup=email">';

echo '<h1>'.$LANG['email'].'</h1><br/>
    <input 
name="email" type="text" value="'.htmlspecialchars($user_email).'"
maxlength="255"/><br/><h1>'.$LANG['password'].'</h1><br/>
    <input 
name="pwd" type="password" value=""
maxlength="12"/><br/><input name="change" type="submit" value="'.$LANG['save'].'"/></form><br/>';
echo '</div>';
require_once('inc/foot.php');
break;

case 'edit':
if (!$user_id)
relogin();

if (isset($_POST['save']))
{
if (!$user_id)
relogin();

$name=$_POST['name'];
$gender=$_POST['gender'];
$birthday=$_POST['birthday'];
$address=$_POST['location'];
$about=$_POST['about'];
if ($name != $user_name && $indowapblog['credit'] < 300)
$error = 'Perubahan Nama dikenakan kredit Rp 300';

if (mb_strlen($name) < 2 || mb_strlen($name) > 40)
$error=$LANG['lenght_name'];
if (empty($name))
$error=$LANG['empty_name'];
if (preg_match("/[^a-zA-Z0-9\ \-\.\@\{\}\_]/", $name))
$error=$LANG['incorrect_name'];
if (substr($name,0,1) == ' ' || substr($name,-1) == ' ')
$error=$LANG['incorrect_name'];
if (!eregi("^[0-9]{2}-[0-9]{2}-[0-9]{4}\$", $birthday))
$error=$LANG['format_birthday'];

if (empty($error))
{
if ($name == $user_name) {
mysql_query("update user set name='".mysql_real_escape_string($name)."', gender='".mysql_real_escape_string($gender)."', birthday='".mysql_real_escape_string($birthday)."', address='".mysql_real_escape_string($address)."', about='".mysql_real_escape_string($about)."' where id='".$user_id."'");
}
else {
$kr = $indowapblog['credit'] - 300;
mysql_query("update user set name='".mysql_real_escape_string($name)."', gender='".mysql_real_escape_string($gender)."', birthday='".mysql_real_escape_string($birthday)."', address='".mysql_real_escape_string($address)."', about='".mysql_real_escape_string($about)."', credit='".mysql_real_escape_string($kr)."' where id='".$user_id."'");
}
$hsl='<div class="succes">'.$LANG['change_saved'].'</div>';
}
else
{
$hsl='<div class="eror">'.$error.'</div>';
}
}

$head_title=$LANG['edit'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<div class="notif"><a href="user.php">'.$LANG['profile'].'</a> | '.$LANG['edit'].' | <a href="user.php?cup=upload">'.$LANG['upload_photo'].'</a> | <a href="user.php?cup=password">'.$LANG['change_password'].'</a></div>';
echo '<form method="post"
action="user.php?cup=edit">
<h1>'.$LANG['photo'].' <a
href="user.php?cup=upload">'.$LANG['upload'].'</a></h1><br/>
<img src="img.php?img='.$user_id.'.jpg&amp;w=80&amp;h=80" alt="'.htmlspecialchars($indowapblog['name']).'"/><br/><h4>'.$LANG['name'].'</h4><br/>
    <input 
name="name" type="text" value="'.htmlspecialchars($indowapblog['name']).'"
maxlength="49"/><br/>
<h1>'.$LANG['gender'].'</h1><br/><select name="gender">';
if ($indowapblog['gender'] == 'female')
echo '<option value="female">'.$LANG['female'].'</option><option value="male">'.$LANG['male'].'</option>';
else
echo '<option value="male">'.$LANG['male'].'</option><option value="female">'.$LANG['female'].'</option>';
echo '</select><br/>';
echo '<h1>'.$LANG['birthday'].'</h1>
    <input name="birthday" type="text" value="'.htmlentities($indowapblog['birthday']).'" maxlength="49"/><br/><span>HH-BB-TTTT</span><br/><h1>'.$LANG['site'].'</h1><br/><b>'.htmlspecialchars($indowapblog['site']).'</b><br/><h1>'.$LANG['email'].' <a href="user.php?cup=email">'.$LANG['change'].'</a><br/></h1><br/>'.htmlentities($indowapblog['email']).'<br/>';
if (preg_match("#<#si",$indowapblog['no_hp']))
$myHP = "";
else
$myHP = str_replace("[","",str_replace("]","",$indowapblog['no_hp']));
echo '<h1>'.$LANG['phone_number'].' <a href="user.php?cup=phone_number">'.$LANG['change'].'</a></h1>'.htmlentities($myHP).'<br/>';
echo '<h1>'.$LANG['address'].'</h1><br/><input name="location" type="text" value="'.htmlspecialchars($indowapblog['address']).'" maxlength="20"/><br/><h1>'.$LANG['about'].'</h1><br/><textarea name="about" rows="3"/>'.htmlspecialchars($indowapblog['about']).'</textarea>
    <br/>
    <input name="save" type="submit" value="'.$LANG['save'].'"/></form>';

echo '</div>';
require_once('inc/foot.php');

break;
case 'password':
if (!$user_id)
relogin();
if (isset($_POST['change']) && $user_id)
{
$old=$_POST['old_pass'];
$pass=$_POST['new_pass'];
$re_pass=$_POST['re_new_pass'];
if ($indowapblog['password'] != md5($old))
$hasil='<div class="eror">'.$LANG['incorrect_password'].'</div>';
if ($pass != $re_pass)
$hasil='<div class="eror">'.$LANG['incorrect_password'].'</div>';
if (mb_strlen($pass) < 4 || mb_strlen($pass) > 12) $hasil='<ol id="error"><li>'.$LANG['lenght_password'].'</li></ol>';
if (empty($pass) || empty($re_pass)) $hasil='<ol id="error"><li>'.$LANG['empty_password'].'</li></ol>';if (empty($hasil))
{
$new_password=md5($pass);
$cook = md5($user_id) . substr($new_password,0,17);
$cookie = md5($cook);
mysql_query("update `user` set `password`='".mysql_real_escape_string($new_password)."', `cookie`='".mysql_real_escape_string($cookie)."' where `id`='".$user_id."'");
$hasil='<div class="succes">'.$LANG['change_saved'].'</div>';
}
}

$head_title=$LANG['change_password'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hasil))
echo $hasil;
echo '<div class="notif"><a href="user.php">'.$LANG['profile'].'</a> | <a href="user.php?cup=edit">'.$LANG['edit'].'</a> | <a href="user.php?cup=upload">'.$LANG['upload_photo'].'</a> | '.$LANG['change_password'].'</div>';
echo '<form method="post" action="user.php?cup=password"><h1>'.$LANG['old_password'].'</h1><br/>
<input name="old_pass" type="password"/><br/><h1>'.$LANG['new_password'].'</h1><br/>
<input name="new_pass" type="password"/><br/>
<h1>'.$LANG['re_new_password'].'</h1><br/>
<input name="re_new_pass" type="password"/><br/>    <input name="change" type="submit" value="'.$LANG['change'].'"/></form>';
echo '</div>';
require_once('inc/foot.php');

break;

case 'upload':
if (!$user_id)
relogin();
$maxsize='200';
$fail=$_FILES['file']['tmp_name'];
$failname=$_FILES['file']['name'];
if (isset($_POST['upload']) && $user_id)
{
$types = array("image/jpg","image/png","image/gif","image/jpeg");
if (!in_array(mime_content_type($fail), $types))
$hsl='<div class="eror">'.$LANG['incorrect_file_type'].'</div>';
if ($_FILES['file']['size'] > (1024*$maxsize))
$hsl='<div class="eror">'.$LANG['photo_max_200kb'].'</div>';
if (empty($failname))
$hsl='<div class="eror">'.$LANG['failed'].'</div>';
if ($_FILES['file']['size'] == 0)
$hsl='<div class="eror">'.$LANG['failed'].'</div>';
if (empty($hsl))
{
if (move_uploaded_file($fail, "images/profile/$user_id.jpg"))
$hsl='<div class="succes">'.$LANG['photo_successfully_upload'].'</div><div class="menu"><img src="img.php?img='.$user_id.'.jpg&amp;w=64&amp;h=64" alt="'.htmlspecialchars($user_name).'" /></div>';
else
$hsl='<div class="eror">'.$LANG['failed'].'</div>';
}
}
$head_title=$LANG['upload_photo'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<div class="notif"><a href="user.php">'.$LANG['profile'].'</a> | <a href="user.php?cup=edit">'.$LANG['edit'].'</a> | '.$LANG['upload_photo'].' | <a href="user.php?cup=password">'.$LANG['change_password'].'</a></div>';
echo '<form action="user.php?cup=upload" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="200000" type="hidden"/>
    <h1>'.$LANG['upload_photo'].'</h1><br/><input type="file" name="file"/><br/>
    <input name="upload" type="submit" value="'.$LANG['upload'].'"/></form></div>';
require_once('inc/foot.php');


break;


default:
if (!$user_id)
relogin();
$id=abs((int)$_GET['id']);
if (empty($id))
$id=$user_id;
$req=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="eror">Pengguna dengan id '.htmlentities($id).' tidak ada</div>';
echo '</div>';
require_once('inc/foot.php');
exit;
}
$USER=mysql_fetch_array($req);
$head_title=htmlspecialchars($USER['name']);
require_once('inc/head.php');
echo '<div class="content">';
if ($USER['id'] == $user_id)
echo '<div class="notif">'.$LANG['profile'].' | <a href="user.php?cup=edit">'.$LANG['edit'].'</a> | <a href="user.php?cup=upload">'.$LANG['upload_photo'].'</a> | <a href="user.php?cup=password">'.$LANG['change_password'].'</a></div>';
if ($is_admin && $USER['id'] != $user_id && $USER['admin'] < 1)
{
echo '<div class="notif">';
if ($USER['author'] > 0)
echo '<a href="owner.php?cup=author&amp;action=delete&amp;id='.$USER['id'].'">'.$LANG['delete_author'].'</a>';
else
echo '<a href="owner.php?cup=author&amp;action=add&amp;id='.$USER['id'].'">'.$LANG['as_author'].'</a>';
echo ' | ';
if ($USER['ban'] == 0)
echo '<a href="owner.php?cup=banned&amp;id='.$USER['id'].'">'.$LANG['ban'].'</a>';
else
echo '<a href="owner.php?cup=unbanned&amp;id='.$USER['id'].'">'.$LANG['unban'].'</a>';
echo ' | ';
echo '<a href="owner.php?cup=delete_user&amp;id='.$USER['id'].'">'.$LANG['delete_user'].'</a>';
echo '</div>';
}
echo '<table>
    <tr>
<td style="width: 50%;">';
$foto_profile='images/profile/'.$USER['id'].'.jpg';
if (file_exists($foto_profile))
echo '<a href="'.$foto_profile.'"><img src="'.$foto_profile.'" width="80" height="100" alt="" style="width: 100%"/></a>';
else
echo '<img src="images/profile/default.jpg" width="80" height="100" alt="" style="width: 100%"/>';
echo '</td>';

if (($USER['author'] == '1') && ($USER['admin'] == '0'))
{
$font="green";
}

elseif (($USER['author'] == '2') && ($USER['admin'] == '0'))
{
$font="red";
}
elseif (($USER['author'] == '3') && ($USER['admin'] == '0'))
{
$font="blue";
}
elseif (($USER['author'] == '4') && ($USER['admin'] == '0'))
{
$font="yellow";
}
elseif ($USER['admin'] == '1')
{
$font="#731174";
}
else
{
$font="black";
}
echo '<td valign="top"><strong><font color="'.$font.'">'.htmlspecialchars($USER['name']).'</font></strong></td>';
echo '</tr></table>';
if ($USER['id'] != $user_id)
echo '<form method="get" action="message.php"><input type="hidden" name="cup" value="write"/><input type="hidden" name="to" value="'.$USER['id'].'"/>
<input type="submit" value="'.$LANG['send_message'].'"/></form>';
$view=isset($_GET['view']) ? trim($_GET['view']) : '';
switch ($view)
{
case 'info':
echo '<div class="notif"><a href="user.php?id='.$USER['id'].'&amp;view=post">'.$LANG['post'].'</a> | '.$LANG['info'].'</div>';
echo '<h1>'.$LANG['info'].'</h1>
<ol>';
if ($is_admin || $USER['id'] == $user_id)
{
 echo '<li>ID: '.htmlspecialchars($USER['id']).'</li><li>'.$LANG['username'].': '.htmlspecialchars($USER['username']).'</li><li>'.$LANG['credit'].': <a href="dashboard.php?cup=credit">Rp '.strrev(wordwrap(strrev($USER['credit']),3,".",true)).'</a></li><li>'.$LANG['email'].': '.htmlspecialchars($USER['email']).'</li>';
if (preg_match("#<#si",$USER['no_hp']))
$myHP = "";
else
$myHP = str_replace("[","",str_replace("]","",$USER['no_hp']));
echo '<li>'.$LANG['phone_number'].': '.htmlspecialchars($myHP).'</li>';
}
echo '<li>'.$LANG['name'].': '.htmlspecialchars($USER['name']).'</li>
    <li>'.$LANG['gender'].': ';
if ($USER['gender'] == 'female')
echo $LANG['female'];
else
echo $LANG['male'];
echo '</li>
<li>'.$LANG['birthday'].': '.htmlspecialchars($USER['birthday']).'</li>
<li>'.$LANG['address'].': '.htmlspecialchars($USER['address']).'</li>
<li>'.$LANG['site'].': <a href="'.htmlentities($USER['site']).'">'.htmlentities($USER['site']).'</a></li><li>'.$LANG['date_register'].': '.waktu($USER['date_reg']).'</li><li>'.$LANG['last_login'].': '.time_ago($USER['lastdate']).'</li><li>'.$LANG['about'].': '.htmlspecialchars($USER['about']).'</li>';
$following=mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM `following` WHERE `site_id`='".$USER['id']."' AND `url`!='".$USER['site']."'"), 0);
echo '<li>'.$LANG['following'].': '.$following.'</li>';
$follower=mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM `following` WHERE `site_id`!='".$USER['id']."' AND `url`='".$USER['site']."'"), 0);
echo '<li>'.$LANG['follower'].': <a href="follower.php?id='.$USER['id'].'">'.$follower.'</a></li>';
echo '</ol>';
break;
case 'post':
default:
echo '<div class="notif">'.$LANG['post'].' | <a href="user.php?id='.$USER['id'].'&amp;view=info">'.$LANG['info'].'</a></div>';
$totl=mysql_result(mysql_query("select count(*) as num from blog where site_id='".$USER['id']."' and draft='0'"), 0);
$Res=mysql_query("select * from blog where site_id='".$USER['id']."' and draft='0' order by time desc limit 10;");
if ($totl != 0)
{
while ($res=mysql_fetch_array($Res))
{
echo $i % 2 ? '<div class="list">' : '<div class="list1">';
echo '<a href="'.$USER['site'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br/>'.time_ago($res['time']).'<br/>';
$total=mysql_result(mysql_query("select count(*) as num from comment where blog_id='".$res['id']."' AND status='1'"), 0);
echo ''.$LANG['comments'].': <a href="'.$USER['site'].'/'.$res['link'].'.xhtml#comments">'.$total.'</a>';
if ($is_admin)
echo ' <a href="owner.php?cup=post&amp;action=delete&amp;id='.$res['id'].'">'.$LANG['delete'].'</a>';
++$i;
echo '</div>';
}
}
else
{
if ($USER['id'] == $user_id)
echo '<div class=eror>'.$LANG['empty'].'</div>';
else
echo '<div class=eror>'.$LANG['empty'].'</div>';
}
echo '</ol>';
break;
}
echo '</div>';
require_once('inc/foot.php');
break;
}
?>