<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

function head()
{
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>';
echo '<title>Install IndoWapBlog Beta MC01</title>';
echo '<meta name="viewport" content="width=320" />';
echo '<meta name="viewport" content="initial-scale=1.0" />';
echo '<meta name="viewport" content="user-scalable=false" />';
echo '<meta http-equiv="Cache-Control" content="max-age=1" />';
echo '<meta name="HandheldFriendly" content="True" />';
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
echo '<link rel="stylesheet" href="style/mobile/style.css" type="text/css" media="all"/>';
echo'<link rel="icon" type="image/x-icon" href="http://imgnow.net/uploads/714053135id.gif"/>';
echo '<script type="text/javascript">';
echo '<![CDATA[
function init()
{
// Try to clear attcahed onclick events
var hrefs = document.getElementsByTagName("a");
for (i = 0; i < hrefs.length; i++)
{
if(hrefs[i].className != null)
{
hrefs[i].onclick = null;
}
}
}
//]]></script>';
echo '</head><body onload="javascript:init()">';
}

function foot()
{
echo '<div class="footer">Copyright 2011 - '.date('Y',time()).'<br/>Powered By <a href="http://indowapblog.com">IndoWapBlog.com</a><br/>Modif By <a href="http://ngecuplis.com">Official WapMasTer</a></div></body></html>';
}
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'finish':
$db_host=$_POST['db_host'];
$db_user=$_POST['db_user'];
$db_pass=$_POST['db_pass'];
$db_name=$_POST['db_name'];
$st_name=$_POST['st_name'];
$st_url=$_POST['st_url'];
$adm_user=$_POST['adm_user'];
$adm_name=$_POST['adm_name'];
$adm_pass=$_POST['adm_pass'];
$adm_email=$_POST['adm_email'];

if (isset($_POST['finish']))
{
if (!mysql_connect($db_host,$db_user,$db_pass))
{
head();
echo '<div class="header"><h2>Pengaturan Koneksi</h2></div>';
echo '<div class="eror">Tidak dapat terhubung dengan MySQL</div>';
echo '<div class="content">';
echo '<p>Silakan periksa setelan MySQL</p><p><a href="install.php?iwb=install">Kembali</a></p></div>';
foot();
exit;
}
if (!mysql_select_db($db_name))
{
head();
echo '<div class="header"><h2>Pengaturan Koneksi</h2></div>';
echo '<div class="eror">Tidak dapat terhubung dengan Database '.htmlentities($db_name).'</div>';
echo '<div class="content">';
echo '<p>Silakan periksa setelan MySQL DB Name</p><p><a href="install.php?iwb=install">Kembali</a></p></div>';
foot();
exit;
}


if (mb_strlen($adm_email) < 2 || mb_strlen($adm_email) > 250)
$err='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $adm_email))
$err='Alamat email tidak benar';
if (empty($adm_email))
$err='Silakan masukan alamat email';
if (mb_strlen($adm_name) < 2 || mb_strlen($adm_name) > 40)
$err='Nama minimal 2 dan maksimal 40 karakter';
if (empty($adm_name))
$err='Silakan masukan Nama anda';
if (mb_strlen($adm_pass) < 4 || mb_strlen($adm_pass) > 12) $err='Kata sandi minimal 4 dan maksimal 12 karakter';
if (empty($adm_pass)) $err='Silakan masukan kata sandi';
if (mb_strlen($adm_user) < 4 || mb_strlen($adm_user) > 32)
$err='Username minimal 4 dan maksimal 32 karakter';

if (preg_match("/[^a-z0-9\_\-]/", $adm_user))
$err='Karakter Username hanya diperbolehkan a-z, 0-9, -, _';
if (empty($adm_user))
$err='Silakan masukan Username';

if (empty($err))
{
session_name('IndoWapBlog');
session_start();

mysql_connect($db_host,$db_user,$db_pass);

mysql_select_db($db_name);

$domain = str_replace('http://','',$st_url);
$dbfile = "<?php\r\n\r\n" .
"defined('_IWB_') or die ('Kesalahan: pembatasan akses');\r\n\r\n" .
'$dbhost = ' . "'$db_host';\r\n" .
'$dbname = ' . "'$db_name';\r\n" .
'$dbuser = ' . "'$db_user';\r\n" .
'$dbpass = ' . "'$db_pass';\r\n" .
'$iwb_main_domain = ' . "'$domain';\r\n\r\n" .
'?>';
if (!file_put_contents('inc/config.php', $dbfile))
$error='Tidak dapat membuat file inc/config.php, silakan ubah nama inc/config-sample.php ke inc/config.php dan ubah pengaturan didalamnya';
$handle = fopen("install.sql", "r");
$contents = fread($handle, filesize("install.sql"));
fclose($handle);
$sep=';';
$contents=preg_replace("~(--|##)[^\r]*\r~","\r",$contents);
$contents=explode($sep,$contents);
foreach($contents as $coo) {
if(!empty($coo)) {
mysql_query($coo);
}
}

$st_url_www=str_replace('http://','http://'.$adm_user.'.',$st_url);
mysql_query("INSERT INTO `site` SET name='".mysql_real_escape_string($st_name)."', url='".mysql_real_escape_string($st_url)."', url_www='".mysql_real_escape_string($st_url_www)."', description='My Mobile Blog Powered By IndoWapBlog', keywords='tips, trick, gratisan, xl, indosat, tsel, indowapblog, open source, mobile blog', theme='default', theme_web='desktop', logo='', favicon='favicon.ico', cat_loc='index', display_following='1', comment_email='1', comment_mod='0', comment_captcha='1', num_post_main='10', desc_post_main='0', gmt='+7', category='10'") or die(mysql_error());

$password=md5($adm_pass);
mysql_query("insert into user set username='".mysql_real_escape_string($adm_user)."', password='".$password."', email='".mysql_real_escape_string($adm_email)."', name='".mysql_real_escape_string($adm_name)."', gender='male', site='".mysql_real_escape_string($st_url)."', admin='1', author='1', credit='9999999999', date_reg='".time()."'");

$user_id = mysql_insert_id();
setcookie("user_id", $user_id, time() +60 * 60 * 24 * 30);
setcookie("password", $password, time() +60 * 60 * 24 * 30);

//*Posting Pertama Blog*//
$title='Hallo Dunia';
$teks='Ini adalah postingan pertama Anda, silakan ubah atau hapus postingan ini.';
mysql_query("insert into blog set site_id='".$user_id."', user_id='".$user_id."', title='".mysql_real_escape_string($title)."', description='".mysql_real_escape_string($teks)."', link='hallo-dunia', time='".time()."', category='', allow_comment='1', draft='0'");

$bid=mysql_insert_id();
//*Komentar*//
mysql_query("insert into comment set site_id='".$user_id."', user_id='0', blog_id='".$bid."', blog_user_id='".$user_id."', name='IndoWapBlog.com', site='http://indowapblog.com', email='achunk17@gmail.com', text='Terima kasih telah berkreasi dengan IndoWapBlog.', status='1', time='".time()."'");

head();
echo '<div class="header">';
//*Jangan hapus kode img di bawah ini. Fungsi Kode ini untuk berkoneksi dengan pengguna IWB Lainnya agar Anda dapat saling Follow Memfollow*//

//*Mulai Kode IWB Konek*//
//*Selesai Kode IWB Konek*//

echo '<h2>Install IndoWapBlog Beta MC01</h2></div>';
echo '<div class="menu"><ol id="succes"><li>Istallasi berhasil diselesaikan</li></ol>';
if (!empty($error))
echo '<ol id="eror"><li>'.$error.'</li></ol>';
echo '</div>';
echo '<div class="content">';
echo '<p>Selamat... Proses installasi IndoWapBlog Beta MC01 berhasil diselesaikan. Kini Anda bisa mengedit pengaturan blog di <a href="owner.php">Admin Panel</a> atau <a href="/home.xhtml">Lihat Blog</a> Anda.<br/>Demi keamanan silakan hapus file <b>install.php</b><br/><br/>Salam <a href="http://facebook.com/mhozacuplis1">Mhoza CupLas CupLis</a></p>';
echo '</div>';
foot();
mysql_close();
}
else
{
head();
echo '<div class="header"><h2>Install IndoWapBlog Beta MC01</h2></div>';
echo '<div class="eror">'.$err.'</div>';
echo '<div class="content">';
echo '<p>Silakan periksa dan perbaiki kesalahan<br/></p>';
echo '<form method="post" action="install.php?iwb=set"><input name="host" type="hidden" value="'.htmlentities($db_host).'" />';
echo '<input name="user" type="hidden" value="'.htmlentities($db_user).'" />';
echo '<input name="pass" type="hidden" value="'.htmlentities($db_pass).'" />';
echo '<input name="db" type="hidden" value="'.htmlentities($db_name).'" /><br/>';
echo '<input name="set" type="submit" value="Kembali Dan Ulangi"/></form>';
echo '</div>';
foot();
}
}
else
{
header('location: install.php?iwb=install');
}
break;

case 'set':
$host=$_POST['host'];
$user=$_POST['user'];
$pass=$_POST['pass'];
$db=$_POST['db'];
if (isset($_POST['set']))
{
if (!mysql_connect($host,$user,$pass))
{
head();
echo '<div class="header"><h2>Pengaturan Koneksi</h2></div>';
echo '<div class="eror">Tidak dapat terhubung dengan MySQL</div>';
echo '<div class="content">';
echo '<p>Silakan periksa setelan MySQL</p><p><a href="install.php?iwb=install">Kembali</a></p></div>';
foot();
exit;
}
if (!mysql_select_db($db))
{
head();
echo '<div class="header"><h2>Pengaturan Koneksi</h2></div>';
echo '<div class="eror">Tidak dapat terhubung dengan Database '.htmlentities($db).'</div>';
echo '<div class="content">';
echo '<p>Silakan periksa setelan MySQL DB Name</p><p><a href="install.php?iwb=install">Kembali</a></p></div>';
foot();
exit;
}

head();
echo '<div class="header"><h2>Install IndoWapBlog Beta MC011</h2></div>';
echo '<div class="succes">Berhasil Terhubung Dengan MySQL</div>';
echo '<div class="content">';
echo '<div class="notif">Pengaturan Situs</div>';
echo '<p><form method="post" action="install.php?iwb=finish"><input type="hidden" name="db_host" value="'.htmlentities($host).'"><input type="hidden" name="db_user" value="'.htmlentities($user).'"><input type="hidden" name="db_pass" value="'.htmlentities($pass).'"><input type="hidden" name="db_name" value="'.htmlentities($db).'"><h1>Nama Situs</h1>
<br/><input name="st_name" type="text" value="IndoWapBlog Beta MC011" maxlenght="40" size="30"/><br/><h1>URL Situs</h1><br/>
<input name="st_url" type="text" value="http://'.$_SERVER['HTTP_HOST'].str_replace('/install.php?iwb=set','',$_SERVER['REQUEST_URI']).'" size="30"/><br/><span>Tanpa diakhiri garis miring (slash).</span></p>';
echo '<div class="notif">Registrasi Administrator</div>';
echo '<p><h1>Nama Pengurus</h1><br/>
<input name="adm_user" type="text" value="admin" maxlenght="32" size="30"/><br/><h1>Nama Anda</h1><br/>
<input name="adm_name" type="text" value="Administrator" maxlenght="40" size="30"/><br/><h1>Kata Sandi</h1><br/>
<input name="adm_pass" type="text" value="" maxlenght="32" size="30"/><br/><h1>Email</h1><br/>
<input name="adm_email" type="text" value="@" size="30"/></p><input name="finish" type="submit" value="Registrasi"/></form>';
echo '</div>';
foot();
}
else
{
header('location: install.php?iwb=install');
}
break;

case 'install':
head();
echo '<div class="header"><h2>Pengaturan Koneksi</h2></div>';
echo '<div class="content">';
echo '<form method="post" action="install.php?iwb=set"><h1>MySQL Host</h1><br/>
<input name="host" type="text" value="localhost" size="30"/><br/><h1>MySQL User</h1><br/>
<input name="user" type="text" value="root" size="30"/><br/><h1>MySQL Password</h1><br/>
<input name="pass" type="text" value="" size="30"/><br/><h1>MySQL DB Name</h1><br/>
<input name="db" type="text" value="" size="30"/><br/>
<input name="set" type="submit" value="Install"/></form>';
echo '</div>';
foot();
break;

default:
head();
if (!file_exists('inc/courbd.ttf'))
copy('http://indowapblog.googlecode.com/files/courbd.ttf','inc/courbd.ttf');
echo '<div class="header"><h2>Install IndoWapBlog Beta MC011</h2></div>';
echo '<div class="content">';
echo '<div class="notif">Syarat Dan Ketentuan</div>';
echo '<p>Dengan melakukan istallasi IndoWapBlog (IWB) ( IndoWapBlog-MS-Beta-MC011 Full Editing By : Master Chef IWB
Website : http://ngecuplis.com ) Berarti Anda telah setuju dengan syarat dan ketentuan yang ditetapkan oleh pembuat IWB (<a href="http://m.facebook.com/achunks">Achunk JealousMan</a>) dan modif by (<a href="http://m.facebook.com/mhozacuplis1">Mhoza CupLas CupLis</a>), ada pun ketetentuan dan syarat tersebut adalah sebagai berikut:<br/><ul><li>Dilarang menghapus Copyright IndoWapBlog</li><li>Dilarang memperjual belikan Engine atau Modul IndoWapBlog</li><li>Semua isi atau konten pada blog ini adalah tanggung jawab Anda</li></ul><br/>Apabila Anda setuju dengan Syarat dan Ketentuan di atas silakan lanjutkan installasi dengan mengklik &quot;Mulai Installasi&quot; di bawah ini<br/><form method="get" action="install.php"><input type="hidden" name="iwb" value="install"/><input type="submit" value="Mulai Installasi"/></form></p></div>';
foot();
break;
}
?>