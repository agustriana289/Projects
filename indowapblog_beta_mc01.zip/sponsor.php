<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
$id=isset($_GET['id']) ? trim($_GET['id']) : '';
require('inc/indowapblog.php');
if (!ctype_digit($id))
{
$bz="77202";
ads_buzzcity($bz);
ads_buzzcity($bz);
ads_buzzcity($bz);
ads_buzzcity($bz);
}
else
{
$cek=mysql_query("select * from `sponsor` where `id`='".mysql_real_escape_string($id)."' and `expired` > '".time()."'");
if (mysql_num_rows($cek) == 0)
{
$bz="77202";
ads_buzzcity($bz);
ads_buzzcity($bz);
ads_buzzcity($bz);
ads_buzzcity($bz);
}
else
{
$ad=mysql_fetch_array($cek);
$klik = $ad['click'] + 1;
mysql_query("update sponsor set click='".$klik."' where id='".$ad['id']."'");
header("location: ".str_replace('&amp;','&',htmlspecialchars($ad['url'])));
}
}
mysql_close($iwb_connect);
?>