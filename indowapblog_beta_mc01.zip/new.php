<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);


require_once('inc/indowapblog.php');
$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) as num from `blog` where `link`!='posting-pertama' and `draft`='0'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title=$LANG['latest_post'];
require_once('inc/head.php');
echo '<div class="content">';
if ($total > 0)
{
$req=mysql_query("select `site_id`, `title`, `link`, `time` from `blog` where `link`!='posting-pertama' and `draft`= '0' order by `time` desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
$site_post=mysql_fetch_array(mysql_query("SELECT name, url FROM site WHERE id='".$res['site_id']."'"));
echo '<div class="menu">Title: <a href="'.$site_post['url'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br/>Blog: <a href="'.$site_post['url'].'/home.xhtml">'.htmlspecialchars($site_post['name']).'</a> <font color="#555">'.time_ago($res['time']).'</font></div>';
}
}
else
{
echo '<div class="eror">'.$LANG['empty'].'</div>';
}
$link='new.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
?>