<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
$q=isset($_GET['q']) ? trim(urlencode($_GET['q'])) : '';
if (isset($_GET['q']))
{
$page=$_GET['page'];
$total=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE title LIKE '%".mysql_real_escape_string(urldecode($q))."%' or description LIKE '%".mysql_real_escape_string(urldecode($q))."%' and draft='0'"),0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title=''.$LANG['search_for'].' '.urldecode($q);
}
else
{
$head_title=$LANG['search'];
}
require_once('inc/head.php');
echo '<div class"content">';
echo '<form action="'.$site['url'].'/search.php" method="get"><input name="q" type="text" value="'.htmlspecialchars(urldecode($q)).'"/><br/><input type="submit" value="'.$LANG['search_submit'].'"/></form><br />';
if (isset($_GET['q']))
{
echo '<div class="succes">'.str_replace('::number::',$total,str_replace('::query::',htmlspecialchars(urldecode($q)),$LANG['search_result'])).'</div>';
if ($total > 0)
{
$req=mysql_query("SELECT * FROM blog WHERE title LIKE '%".mysql_real_escape_string(urldecode($q))."%' or description LIKE '%".mysql_real_escape_string(urldecode($q))."%' and draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
$site_post=mysql_fetch_array(mysql_query("SELECT name, url FROM site WHERE id='".$res['site_id']."'"));
echo '<div class="menu"><a href="'.$site_post['url'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).' | '.htmlspecialchars($site_post['name']).' <font color="#666666">'.time_ago($res['time']).'</font></a></div>';
}
}
else
{
echo '<div class="eror">'.$LANG['search_not_found'].'</li>';
}
$link='search.php?q='.htmlentities($q).'&amp;page=';
$x='';
pagination($page,$max_view,$total,$link,$x);
}
else {
}
echo '</div>';
require_once('inc/foot.php');
?>