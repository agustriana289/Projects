<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
if (!$user_id)
relogin();

$page=$_GET['page'];
$id=isset($_GET['id']) ? trim($_GET['id']) : $user_id;
$req=mysql_query("select name, site from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$f=mysql_fetch_array($req);

$total=mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM `following` WHERE `site_id`!='".mysql_real_escape_string($id)."' AND `url`='".mysql_real_escape_string($f['site'])."'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title=''.$LANG['follower'].' '.htmlspecialchars($f['name']).'';
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="menu">'.$LANG['follower'].' '.htmlspecialchars($f['name']).'</div>';
if ($total > 0)
{
$req=mysql_query("select `site_id` from `following` where `site_id`!='".mysql_real_escape_string($id)."' and `url`= '".$f['site']."' order by `time` desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
$follower=mysql_fetch_array(mysql_query("select name, url from site where id='".$res['site_id']."'"));
echo '<div class="menu"><a href="'.$follower['url'].'">'.htmlspecialchars($follower['name']).'</a></div>';
}
}
else
{
echo '<div class="eror">'.$LANG['empty'].'</div>';
}
$link='follower.php?id='.htmlspecialchars($id).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
?>