<?php
/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

#author: darkhorn
#deskripsi: auto google verification
$ver=substr(strtolower(preg_replace('#([\W_]+)#','-',$_SERVER['REQUEST_URI'])),1);
echo 'google-site-verification: '.$ver;
?>