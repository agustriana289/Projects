<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
$iwb_redirecting='off';
require('inc/indowapblog.php');
require_once('inc/mobile_detect.class.php');
$detect = new mobile_detect();

$sess_mode=isset($_SESSION['viewmod']) ? stripslashes($_SESSION['viewmod']) : 'default';

// Template situs
if ($site['theme'] == "default") {
$WapDef = "default";
}
else {
$WapDef = "default";
}

// Browser detector
if ($detect->isMobile()) {
if ($sess_mode == 'default' || $sess_mode == 'mobile')
$mode='themes/'.$WapDef;
else
$mode='themes/desktop';
}
else {
if ($sess_mode == 'default' || $sess_mode == 'desktop')
$mode='themes/desktop';
else
$mode='themes/'.$WapDef;
}

$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';

switch ($iwb)
{
case 'desktop_view':
$_SESSION['viewmod']='desktop';
header('location: '.$site_url.'/home.xhtml');
break;

case 'mobile_view':
$_SESSION['viewmod']='mobile';
header('location: '.$site_url.'/home.xhtml');
break;

case 'index':
require_once(''.$mode.'/index.php');
break;

case 'category':
require_once(''.$mode.'/category.php');
break;
case 'read':
require_once(''.$mode.'/read.php');
break;

case 'comment':
include(''.$mode.'/comment.php');
break;

case 'subscribe':
require_once(''.$mode.'/subscribe.php');
break;

case 'guestbook':
require_once(''.$mode.'/guestbook.php');
break;

case 'follow':
include(''.$mode.'/follow.php');
break;

case 'feedback':
require_once(''.$mode.'/feedback.php');
break;

case 'error':
require_once(''.$mode.'/error.php');
break;

default:
if ($_SERVER['HTTP_HOST'] == $iwb_main_domain || $_SERVER['HTTP_HOST'] == 'www.'.$iwb_main_domain.'')
{
$head_title= 'Silent54';
require_once('inc/head.php');
if (!$user_id)
echo ''.$LANG['welcome'].'';
else
echo ''.$LANG['welcome'].'';
echo '<div class="title">'.$LANG['bookmark'].'</div>';
echo '<div class="menu"><a href="'.$site['url'].'/home.xhtml">'.$LANG['official_blog'].'</a></div>';
echo '<div class="menu"><a href="'.$site['url'].'/iklan.php">'.$LANG['advertisement'].'</a></div>';
echo '<div class="menu"><a href="http://sc54.a78.org">Developers</a></div>';
echo '<div class="menu"><a href="http://fb.me/pbalxndr.pbalxndr">Superintendent</a></div>';
echo '<div class="title">'.$LANG['latest_post'].'</div>';
$req=mysql_query("SELECT site_id, title, link, time FROM blog WHERE link != 'hallo-dunia' AND draft = '0' ORDER BY time DESC LIMIT 5;");
while ($res=mysql_fetch_array($req))
{
$site_post=mysql_fetch_array(mysql_query("SELECT name, url FROM site WHERE id='".$res['site_id']."'"));
echo '<div class="menu"><a href="'.$site_post['url'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br/><small><font color="#666666">'.time_ago($res['time']).'</font></small></div>';
}
echo '<div class="menu"><a href="new.php"><font color="#555">'.$LANG['next'].' &raquo;</font></a></div>';
echo '</div>';
require_once('inc/foot.php');
}
else {
require_once(''.$mode.'/index.php');
}
}
?>