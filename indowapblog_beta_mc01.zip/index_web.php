<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
$iwb_redirecting='off';
require('inc/indowapblog.php');
require_once('inc/mobile_detect.class.php');
$detect = new mobile_detect();

$sess_mode=isset($_SESSION['viewmod']) ? stripslashes($_SESSION['viewmod']) : 'default';

// Template situs
if ($site['theme'] == "default") {
$WapDef = "default";
}
else {
$WapDef = "default";
}

// Browser detector
if ($detect->isMobile()) {
if ($sess_mode == 'default' || $sess_mode == 'mobile')
$mode='themes/'.$WapDef;
else
$mode='themes/desktop';
}
else {
if ($sess_mode == 'default' || $sess_mode == 'desktop')
$mode='themes/desktop';
else
$mode='themes/'.$WapDef;
}

$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';

switch ($iwb)
{
case 'desktop_view':
$_SESSION['viewmod']='desktop';
header('location: '.$site_url.'/home.xhtml');
break;

case 'mobile_view':
$_SESSION['viewmod']='mobile';
header('location: '.$site_url.'/home.xhtml');
break;

case 'index':
require_once(''.$mode.'/index.php');
break;

case 'category':
require_once(''.$mode.'/category.php');
break;
case 'read':
require_once(''.$mode.'/read.php');
break;

case 'comment':
include(''.$mode.'/comment.php');
break;

case 'subscribe':
require_once(''.$mode.'/subscribe.php');
break;

case 'guestbook':
require_once(''.$mode.'/guestbook.php');
break;

case 'follow':
include(''.$mode.'/follow.php');
break;

case 'feedback':
require_once(''.$mode.'/feedback.php');
break;

case 'error':
require_once(''.$mode.'/error.php');
break;

default:
if ($_SERVER['HTTP_HOST'] == $iwb_main_domain || $_SERVER['HTTP_HOST'] == 'www.'.$iwb_main_domain.'')
{
$head_title= 'Silent54';
require_once('inc/head.php');
if (!$user_id)
echo ''.$LANG['welcome'].'';
else
echo ''.$LANG['welcome'].'';
require_once('inc/foot.php');
}
else {
require_once(''.$mode.'/index.php');
}
}
?>