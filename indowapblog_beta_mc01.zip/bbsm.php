<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';

switch ($cup)
{
case 'bbcode':
$head_title='BBCode';
require_once('inc/head.php');
echo '<div class="content">';
echo '<div class="notif"><a href="bbsm.php?cup=smiley">Smiley</a> | BBCode</div>';
echo '<div class="menu" style="text-align:center;>';
echo '<b>Kode:</b> [color=blue]Warna Biru[/color]<br/><b>Hasil:</b> <font color="blue">Warna Biru</font>';
echo '<br/><br/>';
echo '<b>Kode:</b> [b]Teks Tebal[/b]<br/><b>Hasil:</b> <b>Teks Tebal</b>';
echo '<br/><br/>';
echo '<b>Kode:</b> [i]Teks Miring[/i]<br/><b>Hasil:</b> <i>Teks Miring</i>';
echo '<br/><br/>';
echo '<b>Kode:</b> [u]Teks Garis Bawah[/u]<br/><b>Hasil:</b> <u>Teks Garis Bawah</u>';
echo '</div></div>';
require_once('inc/foot.php');
break;
case 'delete':
if (!$user_id)
relogin();
if ($is_admin) {
$file = $_GET['file'];
if (file_exists("images/smiley/".$file)) {
unlink("images/smiley/".$file);
header("Location: bbsm.php");
}
else {
include('inc/head.php');
page_not_found();
include('inc/foot.php');
}
}
else {
include('inc/head.php');
forbidden();
include('inc/foot.php');
}
break;
case 'smiley':
default:

$maxsize='5000';
$filename=strtolower($_FILES['file']['name']);

if (isset($_POST['upload']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$types = array("image/jpeg", "image/jpg","image/gif","image/x-png");
if (!in_array(mime_content_type($_FILES['file']['tmp_name']), $types))
$hsl='<div class="eror">Jenis file tidak diijinkan</div>';
if ($_FILES['file']['size'] > (1024*$maxsize))
$hsl='<div class="eror">File maksimal berukuran 5Mb</div>';
$newName=substr($filename,0,-4);
if (empty($filename))
$hsl='<div class="eror">Silakan pilih file</div>';

if (empty($hsl))
{
copy($_FILES['file']['tmp_name'], "images/smiley/$newName.gif");
$hsl='<div class="succes"><b>'.$newName.'</b> berhasil diupload</div>';
}
}
$head_title='Smileys';
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($hsl))
echo $hsl;
echo '<div class="notif">Smiley | <a href="bbsm.php?cup=bbcode">BBCode</a></div>';

if ($is_admin)
{
echo '<form action="bbsm.php?cup=smiley" method="post" enctype="multipart/form-data">';
echo '<input name="MAX_FILE_SIZE" value="5242880" type="hidden"/>';
echo '<h1>Pilih File</h1><br/>';
echo '<input type="file" name="file"/><br/>';
echo '<input name="upload" type="submit" value="Upload"/></form>';
}
if (($is_admin) && ($_GET['action'] == 'update'))
{
$arr=array(".gif",".jpg",".png");
foreach (glob("images/smiley/*") as $file)
{
$files=basename($file);
$fl[] =$files;
$nm=substr($files,-4);
$name=strtolower(substr($files,0,-4));
if (in_array($nm, $arr))
{
$item='\':'.$name.':\' => \'<img src="'.$site_url.'/images/smiley/'.$files.'" alt="'.$name.'"/>\',';
$arrey .= "".$item."\r\n";
$key=':'.$name.':';
$val='<img src="'.$site_url.'/images/smiley/'.$files.'" alt="'.$name.'"/>';
}
}
$arrey .='\':iwb:\' => \'<b>IndoWapBlog</b>\'';
$arreys = "<?php\r\n\r\ndefined('_IWB_') or die('Akses Terlarang');\r\n".'$sm_code'." = array($arrey);\r\n?>";
if (file_put_contents("inc/smileys.php", $arreys)) {
$total=count($fl);
echo '<div class=succes>Telah diperbarui sebanyak '.$total.' smileys.<br/><a href="bbsm.php?cup=smiley">Kembali</a></div>';
}
else {

echo '<div class=eror>Gagal mengupdate Smileys!.<br/><a href="bbsm.php?cup=smiley">Kembali</a></div>';
}
}
else
{
$page = $_GET['page'];
$files = glob("images/smiley/*");
$total = count($files);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / 10)))
$page = 1;
$page--;
$min = ($page * 10) + 1;
$page++;
$max = $min + 9;
$arr = array(".gif",".jpg",".png");
$i = 1;
foreach ($files as $file)
{
$ext = substr(basename($file),-4);
if ($i >= $min && $i <= $max && in_array($ext, $arr)) {
echo $div % 2 ? '<div class="list">' : '<div class="list1">';
echo '<img src="'.$file.'" alt="'.substr(basename($file), 0, -4).'"/><br/><b><input size="10" type="text" value=":'.substr(basename($file),0,-4).':"></b>';
if ($is_admin)
echo ' <a href="bbsm.php?cup=delete&file='.basename($file).'">'.$LANG['delete'].'</a>';
++$div;
echo '</div>';
}
else {
}
$i++;
}

if ($is_admin)
echo '<form method="get" action="bbsm.php"><input type="hidden" name="cup" value="smiley"/><input type="hidden" name="action" value="update"/>';
echo '<input type="submit" value="Perbarui Smiley"/></form>';
$link='bbsm.php?cup=smiley&amp;page=';
$q='';
pagination($page,'10',$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');
}
?>