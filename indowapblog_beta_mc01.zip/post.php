<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
$cup=isset($_GET['cup']) ? trim($_GET['cup']) : '';
switch ($cup)
{
case 'simple_edit':

if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$id = $_GET['id'];
$q = mysql_query("SELECT * FROM blog WHERE id = '" . mysql_real_escape_string($id) . "' AND site_id = '" . $user_id . "'");
if (mysql_num_rows($q) == 0) {
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
else {
$blog = mysql_fetch_array($q);
$title = $blog['title'];
if (isset($_POST['save'])) {
$on = $_POST['on'];
$from = $_POST['from'];
$to = $_POST['to'];
$case = $_POST['case'];
if (empty($from)) {
$hasil = '<div class="eror">Silakan masukan teks yang akan diganti.</div>';
}
else {
if ($on == "body") {
if ($case == "sensitive")
$rep = str_replace($from, $to, $blog['description']);
else
$rep = str_ireplace($from, $to, $blog['description']);
mysql_query("UPDATE blog SET description = '" . mysql_real_escape_string($rep) . "' WHERE id = '" . $blog['id'] . "'");
$hasil = '<div class="succes">Berhasil merubah deskripsi blog dari teks '.htmlspecialchars($from).' menjadi '.htmlspecialchars($from).'</div>';
}
else {
if ($case == "sensitive")
$rep = str_replace($from, $to, $blog['title']);
else
$rep = str_ireplace($from, $to, $blog['title']);
$title = $rep;
mysql_query("UPDATE blog SET title = '" . mysql_real_escape_string($rep) . "' WHERE id = '" . $blog['id'] . "'");
$hasil = '<div class="succes">Berhasil merubah judul title blog dari teks '.htmlspecialchars($from).' menjadi '.htmlspecialchars($from).'</div>';
}
}
}
if (isset($_POST['cancel'])) {
header("Location: post.php?cup=manage");
exit;
}
$head_title = "Edit Cepat";
require_once('inc/head.php');
echo '<div class="content">';
if ($hasil)
echo $hasil;
echo '<div class="notif"><a href="post.php">'.$LANG['write_post'].'</a> | <a href="post.php?cup=manage">'.$LANG['manage_post'].'</a></div><h1><a href="' . $user_site . '/' . $blog['link'] . '.xhtml">' . htmlspecialchars($title) . '</a></h1>';
echo '<form method="POST" action="post.php?cup=simple_edit&amp;id='.$blog['id'].'"><h1 class="title">Bagian</h1><br/><select name="on"><option value="body">Deskripsi Blog</option><option value="title">Title Blog</option></select><br /><h1 class="title">Dari Teks</h1><br/><input type="text" name="from" value=""/><br /><h1 class="title">Ubah Menjadi</h1><br/><input type="text" name="to" value=""/><br /><h1 class="title">Sifat</h1><br/><input type="radio" name="case" value="sensitive">Sensitif<br /><input type="radio" name="case" value="insensitive" checked>Tidak Sensitif<br /><br/><input type="submit" name="save" value="'.$LANG['save'].'"/> <input type="submit" name="cancel" value="'.$LANG['cancel'].'"/></form>';
echo '<br />Atau gunakan metode <a href="post.php?cup=edit&amp;blog_id='.$blog['id'].'">Edit Penuh</a></div>';
require_once('inc/foot.php');
}
break;

case 'edit':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$blog_id = angka($_GET['blog_id']);
$req=mysql_query("select * from blog where id='".mysql_real_escape_string($blog_id)."' and site_id='".$user_id."'");

if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
else
{
$bl=mysql_fetch_array($req);

$tag = isset($_POST['tag']) ? $_POST['tag'] : $bl['tag'];

if (isset($_POST['save']))
$draft = 1;
if (isset($_POST['publish']))
$draft = 0;

if (isset($_POST['publish']) || isset($_POST['save']))
{

$title = $_POST['title'];
$body = $_POST['body'];
$kateg = $_POST['kategori'];
$allow_comment = $_POST['allow_comment'];
$update_time = $_POST['update_time'];
$pp = $_POST['pp'];
$file = $_POST['file'];
if ($update_time == 0)
$time = $bl['time'];
else
$time = time();

if (!empty($kateg))
$kate = implode(",",$kateg);
else
$kate='';
if (empty($title) || empty($body) || empty($kateg))
$error = $LANG['empty_title'];
if (preg_match("#<b>#i", $body) && !preg_match("#<\/b>#i", $body) || preg_match("#<a href#i", $body) && !preg_match("#<\/a>#i", $body) || preg_match("#<textarea#i", $body) && !preg_match("#<\/textarea>#i", $body))
$error=$LANG['incorrect_html_tag'];
if (empty($error))
{
if (empty($bl['count']))
$hit = 0;
else
$hit = $bl['count'];

if ($draft == 0 && $hit < 1 && $time > (time() - 172800))
{
if ($pp == 1)
{
$psn = $LANG['post_only_for_member'];
}
elseif ($pp == 2)
{
$psn=$LANG['post_only_for_follower'];
}
else
{
if (mb_strlen($body) > 200)
$psn=''.strip_tags(substr($body,0,200)).' [...]';
else
$psn=strip_tags($body);
}
$ceksub=mysql_query("select * from subscribe where site_id='".$user_id."' and sub='new_posts' and status='1' ORDER BY id DESC LIMIT 20;");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$email = $subscribe['email'];
$subject="".$LANG['latest_post'].": ".$title."";
$pesan="".$LANG['latest_post'].": ".htmlspecialchars($title)."\r\n\r\n---\r\n\r\nOleh: ".htmlspecialchars($user_name)."\r\n\r\nPada: ".waktu($time)."\r\n\r\n...\r\n\r\n".htmlspecialchars($psn)."\r\n\r\n...\r\n\r\nUntuk mengomentari postingan ini silakan klik ".$user_site."/".$bl['link'].".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$user_site."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= htmlspecialchars($user_name);
$pesan .= "\r\n\r\n";
$pesan .= $user_site;
$dari = "From: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "X-sender: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}else{}
$cekfollower=mysql_query("select * from following where url='".mysql_real_escape_string($user_site)."' and subscribe='1' order by time desc");
if (mysql_num_rows($cekfollower) != 0)
{
$tit=mysql_fetch_array(mysql_query("select name from site where id='".$user_id."'"));
$post_title = "".$title." | ".$tit['name'];
$post_link=''.$user_site.'/'.$bl['link'].'.xhtml';
while ($follower=mysql_fetch_array($cekfollower))
{
$flwr .= "<".$follower['site_id'].">";
}
$flow = $flwr;
mysql_query("INSERT INTO `following_post` SET `title`='".mysql_real_escape_string($post_title)."', `link`='".mysql_real_escape_string($post_link)."', `read`='".mysql_real_escape_string($flow)."', `time`='".time()."'");
}
}else{}

if (empty($tag)) {
$tag = $tag;
}
else {
$tag = iwb_tags($tag);
}
mysql_query("UPDATE `blog` SET `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($body)."', `time`='".mysql_real_escape_string($time)."', `category`='".mysql_real_escape_string($kate)."', `tag`='".mysql_real_escape_string($tag)."', `allow_comment`='".mysql_real_escape_string($allow_comment)."', `draft`='".mysql_real_escape_string($draft)."', `private`='".mysql_real_escape_string($pp)."' WHERE id='".mysql_real_escape_string($blog_id)."' AND site_id='".$user_id."'") or die(mysql_error());
if ($bl['category'] != $kate)
{
$K = mysql_query("SELECT * FROM `category` WHERE site_id='".$user_id."' ORDER BY `id` DESC");
while ($KAT=mysql_fetch_array($K))
{
$item = $blog_id;
$array = $KAT['blog_id'];
$upd = hapus_array($item,$array);
mysql_query("UPDATE `category` SET `blog_id`='".mysql_real_escape_string($upd)."' WHERE `id`='".$KAT['id']."'");
}
$KTG=implode(",",$_POST['kategori']);
$_kt=explode(",",$KTG);

$count=count($_kt);
for ($i=0;$i<$count;$i++)
{
$kf=mysql_fetch_array(mysql_query("select * from category where id='".mysql_real_escape_string($_kt[$i])."' and site_id='".$user_id."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".mysql_real_escape_string($o)."' where id='".mysql_real_escape_string($_kt[$i])."' and site_id='".$user_id."'");
}
}
else
{
}
if ($draft == 0)
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_publish';
else
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_saved';
header("Location: ".$go);
exit;
}
}
if (isset($_POST['go']))
{
$iwbfile=substr($file,-3);

if (($iwbfile=='gif') || ($iwbfile=='jpg') || ($iwbfile=='peg') || ($iwbfile=='png'))
$files='<a href="'.$user_site.'/content/'.$file.'"><img src="'.$user_site.'/content/'.$file.'" alt=""/></a><br/>';
elseif (($iwbfile=='jar') || ($iwbfile=='jad') || ($iwbfile=='zip') || ($iwbfile=='sis') || ($iwbfile=='mp3') || ($iwbfile=='mp4') || ($iwbfile=='3gp') || ($iwbfile=='txt') || ($iwbfile=='nth') || ($iwbfile=='isx') || ($iwbfile=='amr') || ($iwbfile=='tar'))
$files='<a href="'.$user_site.'/content/'.$file.'">'.$file.'</a><br/>';
elseif (empty($file))
$files='';
else
$files=''.$user_site.'/content/'.$file.'';
}

$files=isset($files) ? $files : '';

$head_title=''.$LANG['edit'].' '.$LANG['post'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($error))
echo '<div class="eror">'.$error.'</div>';
echo '<div class="notif"><a href="post.php">'.$LANG['write_post'].'</a> | <a href="post.php?cup=manage">'.$LANG['manage_post'].'</a></div>';
echo '<form
method="post" action="post.php?cup=edit&amp;blog_id='.$blog_id.'">
<h1 class="title">'.$LANG['title'].'</h1><br/>
    <input name="title" type="text"
value="'.htmlentities($bl['title']).'" size="25"/><br />
    <h1 class="title">'.$LANG['text'].'</h1><br/>'.$LANG['html_allowed'].' <a href="dashboard.php?cup=html_tutorial">Tutorial</a>';
$body=isset($body) ? $body : $bl['description'];

    echo '<br/><textarea id="body" name="body" cols="26" rows="15"/>'.htmlentities(''.$files.$body.'').'</textarea><br/>
        <h1 class="title">'.$LANG['add_file'].'</h1>
    <br/>
<select id="file" name="file"><option value=""></option>';
foreach (glob("data/".$user_id."/*") as $file)
{
$files=basename($file);
if ($files == 'index.php' || $files == '.htaccess')
{
continue;
}
else
{
echo '<option value="'.$files.'">'.$files.'</option>';
}
}
echo '</select><br/>
<input type="submit" name="go" value="Go" /><br/>
<h1 class="title">'.$LANG['category'].'</h1><br/>';
$kat=mysql_query("select * from category where site_id='".$user_id."' order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="checkbox" name="kategori[]" value="'.$kategoris['id'].'">'.htmlspecialchars($kategoris['name']).'<br/>';
}
echo '<h1 class="title">'.$LANG['tag'].'</h1><br/>
    <input name="tag" type="text"
value="'.htmlentities($tag).'"/><br /><h1 class="title">'.$LANG['permission'].'</h1><br/><input type="radio"
name="pp"
value="0" ';
if ($bl['private'] == 0)
echo 'checked';
echo '/>'.$LANG['for_all'].'<br/><input type="radio"
name="pp"
value="1" ';
if ($bl['private'] == 1)
echo 'checked';
echo '/>'.$LANG['for_member'].'<br/><input type="radio"
name="pp"
value="2" ';
if ($bl['private'] == 2)
echo 'checked';
echo '/>'.$LANG['for_follower'].'<br/><h1 class="title">'.$LANG['allow_comment'].'</h1><br/><input type="radio"
name="allow_comment"
value="1" checked/>'.$LANG['yes'].'<br/><input type="radio"
name="allow_comment"
value="0"/>'.$LANG['no'].'<br/>
    <h1 class="title">'.$LANG['update_time'].'</h1>    <input type="radio"
name="update_time"
value="1"/>'.$LANG['yes'].'<br/><input type="radio"
name="update_time"
value="0" checked/>'.$LANG['no'].'<br/>
    <input type="submit" name="publish" value="'.$LANG['publish'].'"/>
<input type="submit" name="save" value="'.$LANG['draft'].'"/>
</form><br />Kamu juga bisa menggunakan metode <a href="post.php?cup=simple_edit&amp;id='.$bl['id'].'">Edit Cepat</a></div>';
require_once('inc/foot.php');
}
break;


case 'search':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
$search=htmlspecialchars($_POST['search']);
if (empty($search))
$search=htmlspecialchars($_GET['search']);

$head_title=''.$LANG['search_for'].': '.$search.'';
require_once('inc/head.php');

$total=mysql_result(mysql_query("select count(*) as Num from blog where site_id='".$user_id."' and (title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%')"), 0);

$page=angka($_GET['page']);
if (empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;



$req=mysql_query("select * from blog where site_id='".$user_id."' and (title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%') order by time desc limit $limit,$max_view");

echo '<div class="content">';
if ($total != 0)
echo '<div class="succes">'.str_replace('::query::',htmlentities($search),str_replace('::number::',$total,$LANG['search_result'])).'</div>';
echo '</div>';
echo '<div class="notif"><a href="post.php">'.$LANG['write_post'].'</a> | <a href="post.php?cup=manage">'.$LANG['manage_post'].'</a></div>';
echo '<form method="post" action="post.php?cup=search">
<input name="search" type="text" value=""/><br/>
<input name="save" type="submit" value="'.$LANG['search_submit'].'"/>
</form>
<ol>';
if ($total != 0)
{
while ($blog=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="list">' : '<li class="list1">';
if ($blog['draft'] == 0)
echo '<a href="'.$user_site.'/'.$blog['link'].'.xhtml" accesskey="1">'.htmlspecialchars($blog['title']).'</a> '.$LANG['publish'].'';
else
echo ''.htmlspecialchars($blog['title']).' '.$LANG['draft'].'';
echo '<br/>'.$LANG['date'].': '.waktu($blog['time']).'<br/>';
$kom=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."'"), 0);
if ($blog['draft'] == 0)
echo ''.$LANG['comments'].': <a href="post.php?cup=comment&amp;blog_id='.$blog['id'].'">'.$kom.'</a><br/>';
echo '<span class="action_links">[<a href="post.php?cup=edit&amp;blog_id='.$blog['id'].'">'.$LANG['edit'].'</a>] [<a href="post.php?cup=simple_edit&amp;id='.$blog['id'].'">Edit Cepat</a>] [<a class="delete" href="post.php?cup=delete&amp;blog_id='.$blog['id'].'">'.$LANG['delete'].'</a>]</span>';
++$i;
echo '</li>';
}
$link='post.php?cup=search&amp;search='.htmlentities($search).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
else
{
echo '<div class=eror>'.str_replace('::query::',htmlentities($search),$LANG['search_not_found']).'</div>';
}
echo '</ol>';
echo '</div>';
require_once('inc/foot.php');
}
break;

case 'delete':
$blog_id=angka($_GET['blog_id']);
if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$req=mysql_query("select * from blog where id ='".mysql_real_escape_string($blog_id)."' and site_id='".$user_id."'");

if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
else
{
$bl=mysql_fetch_array($req);

if (isset($_GET['yes']))
{
mysql_query("delete from blog where id='".mysql_real_escape_string($blog_id)."' and site_id='".$user_id."'");
mysql_query("delete from comment where site_id='".$user_id."' and blog_id='".mysql_real_escape_string($blog_id)."'");
$plink=''.$user_site.'/'.$bl['link'].'.xhtml';
mysql_query("delete from `following_post` where `link`='".mysql_real_escape_string($plink)."'");
$cate=mysql_query("select * from category where site_id='".$user_id."' order by id");
while ($cat=mysql_fetch_array($cate))
{
$item=$blog_id;
$array=$cat['blog_id'];
$rep=hapus_array($item,$array);
mysql_query("update category set blog_id='".mysql_real_escape_string($rep)."' where id='".$cat['id']."' and site_id='".$user_id."'");
}
header('location: post.php?cup=manage');
exit;
}

$head_title=$LANG['delete_post'];
require_once('inc/head.php');
echo '<div class="content">';
echo '<p>'.$LANG['delete_confirm'].'<strong>'.htmlspecialchars($req['title']).'</strong><br/><a href="post.php?cup=delete&amp;blog_id='.$blog_id.'&amp;yes">'.$LANG['yes'].'</a> | <a href="post.php?cup=manage">'.$LANG['no'].'</a></p></div>';
require_once('inc/foot.php');
}
break;

case 'manage':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$head_title=$LANG['manage_post'];
require_once('inc/head.php');
$page=angka($_GET['page']);
if (empty($page) || $page == 0 || !ctype_digit($page))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

//*Pencarian Posting*//

$notif=$_GET['notif'];
if ($notif == 'post_successfully_publish')
$ntf=$LANG['post_successfully_publish'];
if ($notif == 'post_successfully_saved')
$ntf=$LANG['post_successfully_saved'];
if ($notif == 'post_successfully_deleted')
$ntf=$LANG['post_successfully_deleted'];
if (!empty($ntf))
echo '<div class="succes">'.$ntf.'</div>';
echo '<div class="content">';
echo '<div class="notif"><a href="post.php">'.$LANG['write_post'].'</a> | '.$LANG['manage_post'].'</div>';
echo '<form method="post" action="post.php?cup=search">
<input name="search" type="text" value=""/><br/>
<input name="save" type="submit" value="'.$LANG['search_submit'].'"/>
</form>
<ol>';
$total=mysql_result(mysql_query("select count(*) as Num from blog where site_id='".$user_id."'"), 0);
$req=mysql_query("select * from blog where site_id='".$user_id."' order by time desc limit $limit,$max_view");
if ($total > 0)
{
while ($blog=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
if ($blog['draft'] == 0)
echo '<a href="'.$user_site.'/'.$blog['link'].'.xhtml" accesskey="1">'.htmlspecialchars($blog['title']).'</a> ('.$LANG['publish'].')';
else
echo ''.htmlspecialchars($blog['title']).' ('.$LANG['draft'].')';
echo '<br/>'.$LANG['date'].': '.waktu($blog['time']).'<br />'.$LANG['category'].': ';
if (!empty($blog['category']))
{
$exp=explode(",",$blog['category']);
$expcount=count($exp);
for ($i=0;$i<$expcount;$i++)
{
$kat=mysql_fetch_array(mysql_query("select * from category where id='".$exp[$i]."'"));
echo htmlspecialchars($kat['name']);
echo ', ';
}
}
echo '<br />'.$LANG['tag'].': '.str_replace('-', ' ', $blog['tag']).'<br />';
$kom=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."'"), 0);
if ($blog['draft'] == 0)
echo ''.$LANG['comments'].': <a href="manage_comment.php?bid='.$blog['id'].'">'.$kom.'</a><br/>';
echo '<span class="action_links"><a href="post.php?cup=edit&amp;blog_id='.$blog['id'].'">'.$LANG['edit'].'</a> <a href="post.php?cup=simple_edit&amp;id='.$blog['id'].'">Edit Cepat</a> <a class="delete" href="post.php?cup=delete&amp;blog_id='.$blog['id'].'">'.$LANG['delete'].'</a></span>';
++$i;
echo '</li>';
}
echo '</ol>';
$link='post.php?cup=manage&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
else
{
echo '<div class="eror">'.$LANG['post_empty'].'</div>';
}
echo '</ol></div>';
require_once('inc/foot.php');
break;

case 'post_upload':
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$selisih = time() - 300;
if (mysql_num_rows(mysql_query("select id from blog where site_id='".$user_id."' and time > $selisih")) != 0)
{
header('location: post.php?cup=manage');
exit;
}

$title = $_POST['title'];
$nama_file = $_FILES['body']['name'];
$body = $_FILES['body']['tmp_name'];
$size = $_FILES['body']['size'];
$kategori = $_POST['kategori'];
$tag = $_POST['tag'];
$allow_comment = $_POST['allow_comment'];
$file = $_POST['file'];
$handle = fopen($body, "r");
$body = fread($handle, $size);
fclose($handle);
if (isset($_POST['save'])) {
$draft = 1;
$count = 0;
}
if (isset($_POST['publish'])) {
$draft = 0;
$count = 1;
}
if ((isset($_POST['publish'])) || (isset($_POST['save'])))
{
if (!$is_author) {
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$pp = $_POST['pp'];
$leng = strlen($title);
if ($leng > 60)
$link = substr($title,0,60);
else
$link = $title;
$permalink = permalink($link);
if (!empty($kategori))
$kate = implode(",",$kategori);
else
$kate = "";
if (empty($title) || empty($body) || empty($kategori))
$error = $LANG['empty_title'];
if (preg_match("#<b>#i", $body) && !preg_match("#<\/b>#i", $body) || preg_match("#<a href#i", $body) && !preg_match("#<\/a>#i", $body) || preg_match("#<textarea#i", $body) && !preg_match("#<\/textarea>#i", $body))
$error=$LANG['incorrect_html_tag'];
if (substr($nama_file,-4) != '.txt')
$error=$LANG['file_must_txt'];
if (function_exists('mime_content_type')) {
if (mime_content_type($_FILES['body']['tmp_name']) != "text/plain")
$error=$LANG['file_must_text_plain'];
}
else {
if ($_FILES['body']['type'] != "text/plain")
$error=$LANG['file_must_text_plain'];
}
if (empty($error))
{
if ($draft == 0)
{
$tit=mysql_fetch_array(mysql_query("select name from site where id='".$user_id."'"));
$post_title = "".$title." | ".$tit['name'];
$post_link=''.$user_site.'/'.$permalink.'.xhtml';

$cekfollower=mysql_query("select * from following where url='".mysql_real_escape_string($user_site)."' and subscribe='1' order by time desc");
if (mysql_num_rows($cekfollower) != 0)
{
while ($follower=mysql_fetch_array($cekfollower))
{
$flwr .= "<".$follower['site_id'].">";
}
$flow = $flwr;
mysql_query("INSERT INTO `following_post` SET `title`='".mysql_real_escape_string($post_title)."', `link`='".mysql_real_escape_string($post_link)."', `read`='".mysql_real_escape_string($flow)."', `time`='".time()."'");
}
if ($pp== 1)
{
$psn=$LANG['post_only_for_member'];
}
elseif ($pp == 2)
{
$psn=$LANG['post_only_for_follower'];
}
else
{
if (mb_strlen($body) > 200)
$psn=''.strip_tags(substr($body,0,200)).' [...]';
else
$psn=strip_tags($body);
}
$ceksub=mysql_query("select * from subscribe where site_id='".$user_id."' and sub='new_posts' and status='1' limit 20;");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$email = $subscribe['email'];
$subject="".$LANG['latest_post'].": ".htmlspecialchars($title)."";
$pesan="".$LANG['latest_post'].": ".htmlspecialchars($title)."\r\n\r\n---\r\n\r\nOleh: ".$user_name."\r\n\r\nPada: ".waktu(time())."\r\n\r\n...\r\n\r\n".htmlspecialchars($psn)."\r\n\r\n...\r\n\r\nUntuk mengomentari postingan ini silakan klik ".$user_site."/".$permalink.".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$user_site."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= htmlspecialchars($user_name);
$pesan .= "\r\n\r\n";
$pesan .= $user_site;
$dari = "From: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "X-sender: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}else{}}else{}
if (empty($tag)) {
$tag = $tag;
}
else {
$tag = iwb_tags($tag);
}
mysql_query("insert into `blog` set `site_id`='".$user_id."', `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($body)."', `link`='".mysql_real_escape_string($permalink)."', `time`='".time()."', `category`='".mysql_real_escape_string($kate)."', `tag`='".mysql_real_escape_string($tag)."', `allow_comment`='".mysql_real_escape_string($allow_comment)."', `draft`='".mysql_real_escape_string($draft)."', `private`='".mysql_real_escape_string($pp)."', `count`='".mysql_real_escape_string($coun)."'") or die(mysql_error());

$blog_id=mysql_insert_id();

if (!empty($kategori))
{
$IMP=implode(",",$kategori);
$KTG=explode(",",$IMP);
$N=count($KTG);
for ($i=0; $i<$N; $i++)
{
$kid=$KTG[$i];
$kf=mysql_fetch_array(mysql_query("select * from category where id='".mysql_real_escape_string($kid)."' and site_id='".$user_id."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set `blog_id`='".mysql_real_escape_string($o)."' where `id`='".mysql_real_escape_string($kid)."' and `site_id`='".$user_id."'");
}
}
else
{
}
if ($draft == 0)
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_publish';
else
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_saved';
header('Location: '.$go);
exit;
}
}
$head_title=$LANG['write_post'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($error))
echo '<div class="erro">'.$error.'</div>';
echo '<div class="notif">'.$LANG['write_post'].' | <a href="post.php?cup=manage">'.$LANG['manage_post'].'</a></div>';
echo '<form
method="post" action="post.php?cup=post_upload" enctype="multipart/form-data">
<input name="MAX_FILE_SIZE" value="5242880" type="hidden"/>
<h1 class="title">'.$LANG['title'].'</h1><br/>
    <input name="title" type="text"
value="'.htmlentities($title).'"/><br />
    <h1 class="title">Upload Text (.txt)</h1><br/>
<input type="file" name="body"/><br/>
<h1 class="title">'.$LANG['category'].'</h1><br/>';
$kat=mysql_query("select * from category where site_id='".$user_id."' order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="checkbox" name="kategori[]" value="'.$kategoris['id'].'" />'.htmlspecialchars($kategoris['name']).'<br/>';
}
echo '<h1 class="title">'.$LANG['tag'].'</h1><br/>
    <input name="tag" type="text"
value="'.htmlentities($tag).'"/><br /><h1 class="title">'.$LANG['permission'].'</h1><br/><input type="radio"
name="pp"
value="0" checked/>'.$LANG['for_all'].'<br/><input type="radio"
name="pp"
value="1"/>'.$LANG['for_member'].'<br/><input type="radio"
name="pp"
value="2"/>'.$LANG['for_follower'].'<br/><h1 class="title">'.$LANG['allow_comment'].'</h1><br/>input type="radio"
name="allow_comment"
value="1" checked/>'.$LANG['yes'].'<br/><input type="radio"
name="allow_comment"
value="0"/>'.$LANG['no'].'<br/>
<input type="submit" name="publish" value="'.$LANG['publish'].'"/> <input type="submit" name="save" value="'.$LANG['draft'].'"/></form></div>';
require_once('inc/foot.php');

break;

default:
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$selisih = time() - 300;
if (mysql_num_rows(mysql_query("select id from blog where site_id='".$user_id."' and time > $selisih")) != 0)
{
header('location: post.php?cup=manage');
exit;
}

$title = $_POST['title'];
$body = $_POST['body'];
$kategori = $_POST['kategori'];
$tag = $_POST['tag'];
$allow_comment = $_POST['allow_comment'];
$file = $_POST['file'];
if (isset($_POST['save'])) {
$draft = 1;
$count = 0;
}
if (isset($_POST['publish'])) {
$draft = 0;
$count =1;
}
if ((isset($_POST['publish'])) || (isset($_POST['save'])))
{
if (!$is_author) {
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$pp = $_POST['pp'];
$leng = strlen($title);
if ($leng > 60)
$link=substr($title,0,60);
else
$link = $title;
$permalink = permalink($link);
if (!empty($kategori))
$kate = implode(",",$_POST['kategori']);
else
$kate = "";

if (empty($title) || empty($body) || empty($kategori))
$error=$LANG['empty_title'];
if (preg_match("#<b>#i", $body) && !preg_match("#<\/b>#i", $body) || preg_match("#<a href#i", $body) && !preg_match("#<\/a>#i", $body) || preg_match("#<textarea#i", $body) && !preg_match("#<\/textarea>#i", $body))
$error=$LANG['incorrect_html_tag'];
if (empty($error))
{
if ($draft == 0)
{
$tit=mysql_fetch_array(mysql_query("select name from site where id='".$user_id."'"));
$post_title = "".$title." | ".$tit['name'];
$post_link=''.$user_site.'/'.$permalink.'.xhtml';

$cekfollower=mysql_query("select * from following where url='".mysql_real_escape_string($user_site)."' and subscribe='1' order by time desc");
if (mysql_num_rows($cekfollower) != 0)
{
while ($follower=mysql_fetch_array($cekfollower))
{
$flwr .= "<".$follower['site_id'].">";
}
$flow = $flwr;
mysql_query("INSERT INTO `following_post` SET `title`='".mysql_real_escape_string($post_title)."', `link`='".mysql_real_escape_string($post_link)."', `read`='".mysql_real_escape_string($flow)."', `time`='".time()."'");
}

if ($pp== 1)
{
$psn=$LANG['post_only_for_member'];
}
elseif ($pp == 2)
{
$psn=$LANG['post_only_for_follower'];
}
else
{
if (mb_strlen($body) > 200)
$psn=''.strip_tags(substr($body,0,200)).' [...]';
else
$psn=strip_tags($body);
}

$ceksub=mysql_query("select * from subscribe where site_id='".$user_id."' and sub='new_posts' and status='1' order by time desc limit 20;");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$email = $subscribe['email'];
$subject="".$LANG['latest_post'].": ".htmlspecialchars($title)."";
$pesan="".$LANG['latest_post'].": ".htmlspecialchars($title)."\r\n\r\n---\r\n\r\nOleh: ".$user_name."\r\n\r\nPada: ".waktu(time())."\r\n\r\n...\r\n\r\n".htmlspecialchars($psn)."\r\n\r\n...\r\n\r\nUntuk mengomentari postingan ini silakan klik ".$user_site."/".$permalink.".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$user_site."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= htmlspecialchars($user_name);
$pesan .= "\r\n\r\n";
$pesan .= $user_site;
$dari = "From: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "X-sender: ".htmlspecialchars($user_name)." <".$user_email.">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}else{}}else{}

if (empty($tag)) {
$tag = $tag;
}
else {
$tag = iwb_tags($tag);
}
mysql_query("INSERT INTO `blog` set `site_id`='".$user_id."', `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($body)."', `link`='".mysql_real_escape_string($permalink)."', `time`='".time()."', `category`='".mysql_real_escape_string($kate)."', `tag`='".mysql_real_escape_string($tag)."', `allow_comment`='".mysql_real_escape_string($allow_comment)."', `draft`='".mysql_real_escape_string($draft)."', `private`='".mysql_real_escape_string($pp)."', `count`='".mysql_real_escape_string($count)."'") or die(mysql_error());

$blog_id=mysql_insert_id();

if (!empty($kategori))
{
$IMP=implode(",",$kategori);
$KTG=explode(",",$IMP);
$N=count($KTG);
for ($i=0; $i<$N; $i++)
{
$kid=$KTG[$i];
$kf=mysql_fetch_array(mysql_query("select * from category where id='".mysql_real_escape_string($kid)."' and site_id='".$user_id."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set `blog_id`='".mysql_real_escape_string($o)."' where `id`='".mysql_real_escape_string($kid)."' and `site_id`='".$user_id."'");
}
}
else
{
}
if ($draft == 0)
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_publish';
else
$go=''.$site_url.'/post.php?cup=manage&notif=post_successfully_saved';
header('Location: '.$go);
exit;
}
}
if (isset($_POST['go']))
{
$iwbfile=substr($file,-3);

if (($iwbfile=='gif') || ($iwbfile=='jpg') || ($iwbfile=='peg') || ($iwbfile=='png'))
$files='<a href="'.$user_site.'/content/'.$file.'"><img src="'.$user_site.'/content/'.$file.'" alt=""/></a><br/>';
elseif (($iwbfile=='jar') || ($iwbfile=='jad') || ($iwbfile=='zip') || ($iwbfile=='sis') || ($iwbfile=='mp3') || ($iwbfile=='mp4') || ($iwbfile=='3gp') || ($iwbfile=='txt') || ($iwbfile=='nth') || ($iwbfile=='isx') || ($iwbfile=='amr') || ($iwbfile=='tar'))
$files='<a href="'.$user_site.'/content/'.$file.'">'.$file.'</a><br/>';
elseif (empty($file))
$files='';
else
$files=''.$user_site.'/content/'.$file.'';
}
$head_title=$LANG['write_post'];
require_once('inc/head.php');
echo '<div class="content">';
if (!empty($error))
echo '<div class="eror">'.$error.'</div>';
echo '<div class="notif">'.$LANG['write_post'].' | <a href="post.php?cup=manage">'.$LANG['manage_post'].'</a></div>';
echo '<form
method="post" action="post.php">
<h1 class="title">'.$LANG['title'].'</h1><br />
    <input name="title" type="text"
value="'.htmlentities($title).'"/><br />
    <h1 class="title">'.$LANG['text'].'</h1><br />'.$LANG['html_allowed'].' <a href="dashboard.php?cup=html_tutorial">Tutorial</a><br />
    <textarea id="body" name="body" cols="26" rows="15"/>'.htmlentities(''.$files.' '.$body.'').'</textarea><br/>
        <h1 class="title">'.$LANG['add_file'].'</h1><br />
<select id="file" name="file"><option value=""></option>';
foreach (glob("data/".$user_id."/*") as $file)
{
$files=basename($file);
if ($files == 'index.php' || $files == '.htaccess')
{
continue;
}
else
{
echo '<option value="'.$files.'">'.$files.'</option>';
}
}
echo '</select>
<input type="submit" name="go" id="go-btn" value="Go" /><br/>
<h1 class="title">'.$LANG['category'].'</h1><br />';
$kat=mysql_query("select * from category where site_id='".$user_id."' order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="checkbox" name="kategori[]" value="'.$kategoris['id'].'" />'.htmlspecialchars($kategoris['name']).'<br/>';
}
echo '<h1 class="title">'.$LANG['tag'].'</h1><br />
    <input name="tag" type="text"
value="'.htmlentities($tag).'"/><br /><h1 class="title">'.$LANG['permission'].'</h1><br /><input type="radio"
name="pp"
value="0" checked/>'.$LANG['for_all'].'<br/><input type="radio"
name="pp"
value="1"/>'.$LANG['for_member'].'<br/><input type="radio"
name="pp"
value="2"/>'.$LANG['for_follower'].'<br/><h1 class="title">'.$LANG['allow_comment'].'</h1><br /><input type="radio"
name="allow_comment"
value="1" checked/>'.$LANG['yes'].'<br/><input type="radio"
name="allow_comment"
value="0"/>'.$LANG['no'].'<br/>
<input type="submit" name="publish" value="'.$LANG['publish'].'"/> <input type="submit" name="save" value="'.$LANG['draft'].'"/></form><br /><a href="post.php?cup=post_upload">'.$LANG['click_here'].'</a> '.$LANG['post_upload_notice'].'</div>';
require_once('inc/foot.php');
}
?>