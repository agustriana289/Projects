<?php

/*
*Nama Script: IndoWapBlog Beta MC01
*Versi: (New Beta MC01 Inversion)
*Pembuat: Achunk JealousMan
*Pengembang: Mhoza CupLas CupLis
*Email: mhozacuplis[at]gmail[dot]com
*Situs: http://indowapblog.com
*Website: http://ngecuplis.com
*Facebook: http://www.facebook.com/mhozacuplis1
*Twitter: http://twitter.com/Mhoza_CupLis
*/

define('_IWB_', 1);
require_once('inc/indowapblog.php');

$page=angka($_GET['page']);
$ol = time() - 300;
$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($user_ol / $site['num_post_main'])))$page='1';$page--;$max_view=$site['num_post_main'];$limit=$page*$max_view;$page++;
$head_title='Member Online';
require_once('inc/head.php');
echo '<div class="content">';

echo '<ol>';
$req=mysql_query("SELECT * FROM user WHERE lastdate>'".$ol."' ORDER BY 'lastdate' DESC LIMIT $limit,$max_view");
if ($user_ol > 0)
{
while ($res=mysql_fetch_array($req)){
echo $i % 2 ? '<li class="list">' : '<li class="list1">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'"/> <a href="user.php?id='.$res['id'].'">';

if (($res['author'] == '1') && ($res['admin'] == '0'))
{
echo '<font color="green">'.htmlspecialchars($res['name']).'</font>';
}

elseif (($res['author'] == '2') && ($res['admin'] == '0'))
{
echo '<font color="red">'.htmlspecialchars($res['name']).'</font>';
}

elseif (($res['author'] == '3') && ($res['admin'] == '0'))
{
echo '<font color="blue">'.htmlspecialchars($res['name']).'</font>';
}

elseif (($res['author'] == '4') && ($res['admin'] == '0'))
{
echo '<font color="orange">'.htmlspecialchars($res['name']).'</font>';
}

elseif ($res['admin'] == '1')
{
echo '<font color="#731174">'.htmlspecialchars($res['name']).'</font>';
}
else
{
echo '<font color="black">'.htmlspecialchars($res['name']).'</font>';
}

echo '</a><br/>Online: '.time_ago($res['lastdate']).'';
++$i;
echo '</li>';
}
}
else
{
echo '<div class="eror">Tidak ada member yang online</div>';
}
echo '</ol></div>';
$total=$user_ol;
$link='online.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
?>