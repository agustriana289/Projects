<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Waptok.Asia | ID Community</title>
  <!-- <title>Waptok.Asia ! Under Construction</title>  -->
</head>

<body>

<?php

echo '<center><img src="theme/default/images/logo.png" alt="Waptok.Asia" /><br />
<span style="color:red"><b>Attention..!!!</b></span><br /><img src="images/red.gif" width="16" height="16" alt="" /><br /><img src="images/closed.png" alt="Under Construction" /><br /><font color="red" size="6"> Site under construction.<br />Please, try again later...!!</font><br /><br /><small>&copy; 2013 <a href="http://www.waptok.asia">Waptok.Asia</a></small></center>';

?>

</body>

</html>
