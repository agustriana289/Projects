<?php
######################
## forged on 4alka.TK#
## repack http://waptok.asia#
######################

require_once'config.php';
require_once'functions.php';
include 'head.php';
$formeruri='http://www.4shared.com/'.$_GET['type'].'/'.$_GET['id'].'/'.$_GET['mod'].'.htm';

# get direct download link
$client = new SoapClient("http://api.4shared.com/servlet/services/DesktopApp?wsdl");

$dlid = $client->getDirectLink(LOGIN,PASSWORD,$formeruri);
$id = $client->decodeLink(LOGIN,PASSWORD,$formeruri);
$info = $client->getFileInfo(LOGIN,PASSWORD,$id);

$regx=array('|\[(.*?)]|i','|\((.*?)\)|i','|www(.*?)$|i');

$nume_fisier=preg_replace($regx,'',utf8_format($info->name));

//echo $dlid;

$status=get_headers($dlid);

if($status[0]=="HTTP/1.1 200 OK") {

echo'<div class="mainblok"><div class="phdr">Download File</div>';
echo'<div class="gmenu">FILE NAME: '.$nume_fisier.'<br>FILE SIZE: '.format_bytes($info->size).'<br>FILE ID: '.$id.'</div>';
echo'<div class="menu"><center>&nbsp;<a href="'.htmlspecialchars($dlid).'"><img src="'.$searchurl.'/download.gif"></a></center></div>';

}

else {
echo '<div class="rmenu">Error !!! File Not Found, Please Try Another Link, Or Use Mobile Browses</div>';

}

echo '<div class="bmenu">&#171; <a href="search.php">Back</a></div>';

echo'</div>';
include 'foot.php';

?>
