<?php
include 'config.php';
if (isset($_GET['type']))
$type = $_GET['type'];

$hal = $_GET['hal'];
if ($hal > 91){
header( 'location:/' );

}

if (!empty($_GET['sort'])){
$sort = $_GET['sort'];
}else{
$sort = 2;
}
if ($sort == 1){
$sorttype = 3;
$sortorder = -1;
}else{
$sorttype = 1;
$sortorder = 1;
}

if (!empty($_GET['search'])){
$search = hapus1($_GET['search']);
$title = 'Search &#187; '.hapus($_GET['search']).'';
$pencarian = 'to &#171;<b>'.hapus($_GET['search']).'.'.$type.'</b>&#187;';

}else{
$a = 'to &#171;<b>'.$type.' latest Updates</b>&#187;';
$title = ''.$searchname.' &#187; Free Mobile Files Search Download';
}


if (!empty($_GET['hal'])){
$noPage = $_GET['hal'];
$isifile = 'Isi file tidak sampai <b>'.$noPage.' halaman</b>';
}else{
$noPage = 1;
}

if($_GET['hal'] > 0) {
$page1 = ($_GET['hal']-1)*10;
}
include 'head.php';
if ($advs == 'on') { 
echo '<div class="mainblok">'; 
include 'ads.php';
echo '</div>';
} else {
echo ' ';
}
echo '<div class="mainblok"><div class="phdr">';
echo '<a href="/multisearch"><b>Search & Load Files</b></a></div>';
echo '<div class="menu"><form method="get" action="">
<input type="text" name="search" value="'.hapus($_GET['search']).'"><br>
<select name="sort"><option value="2">All Size</option><option value="1">-1 MB</option></select>
<select name="type">
<option value="'.$type.'">'.$type.'</option>
<option value="all">all files</option>
<option value="mp3">mp3</option>
<option value="mid">mid</option>
<option value="midi">midi</option>
<option value="amr">amr</option>
<option value="wav">wav</option>
<option value="3gp">3gp</option>
<option value="avi">avi</option>
<option value="mp4">mp4</option>
<option value="mpeg">mpeg</option>
<option value="mpg">mpg</option>
<option value="swf">swf</option>
<option value="flv">flv</option>
<option value="bmp">bmp</option>
<option value="gif">gif</option>
<option value="jpg">jpg</option>
<option value="jpeg">jpeg</option>
<option value="png">png</option>
<option value="rar">rar</option>
<option value="zip">zip</option>
<option value="doc">doc</option>
<option value="pdf">pdf</option>
<option value="txt">txt</option>
<option value="xls">xls</option>
<option value="exe">exe</option>
<option value="jar">jar</option>
<option value="jad">jad</option>
<option value="sis">sis</option>
<option value="sisx">sisx</option>
<option value="nth">nth</option>
<option value="thm">thm</option>
</select><br><input value="Search" type="submit"></form>';
echo '</div>';

      
$grab = "http://search.4shared.com/network/searchXml.jsp?sortType=".$sorttype."&sortOrder=".$sortorder."&sortmode=3&q=".$search."&searchmode=3&searchDescription=&searchExtention=".str_replace("all","",$type)."&sizeCriteria=atleast&sizevalue=10&start=".$page1."";
$file = file_get_contents($grab) or die('<div class="rmenu"><b>Connection failed please repeat again shortly</b></div>');

$result = strstr($file, '<search-result>');
$totalfiles = potong($result,'<total-files>','</total-files>');
$resultfiles = potong($result,'<file>','</file>');
$mulai = explode('<file>',$result);

if (!empty($resultfiles)){
echo '<div class="gmenu">Results <b>'.$totalfiles.' files</b> '.$a.''.$pencarian.'</div>';

require_once 'searchtrack.php';
}else{
echo '<div class="rmenu"><b>Error !!!</b> files are not on <b>find</b> '.$pencarian.' '.$isifile.'</div>';
echo'</div>';
} 
for($i = 1; $i <= 10; $i++){
$url = potong($mulai[$i],'<url>','</url>');
$url1 = explode('/',$url);

$name = potong($mulai[$i],'<name>','</name>');
$size = potong($mulai[$i],'<size>','</size>');
$count = potong($mulai[$i],'<downloads-count>','</downloads-count>');
$date = potong($mulai[$i],'<upload-date>','</upload-date>');
$flash = potong($mulai[$i],'<flash-preview-url>','</flash-preview-url>');
$descript = potong($mulai[$i],'<description>','</description>');
$preview = potong($mulai[$i],'<preview-url>','</preview-url>');
                              
if ($url1[3] == video || $url1[3] == photo){
$image = '<a href="'.$preview.'"><img src="'.$preview.'" width="50" height="50"></a>';
}else{
$image = '<img src="line.gif">';
}
if (!empty($name)){
echo ceil(ceil($a / 2) - ($a / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
echo ''.$image.' <a href="'.$searchurl.'/download.php?type='.$url1[3].'&id='.$url1[4].'&name='.$name.'">'.hapus($name).'</a> (<font color="#ff0000">'.str_replace(",", '.', $size).'</font>)';
echo '</div>';
++$a;
}
}
if(!empty($resultfiles)){
echo '<div class="bmenu">';
$dataPerPage = 10;
$offset = ($noPage - 1) * $dataPerPage;
$jumData = $totalfiles;
$jumPage1 = ceil($jumData/$dataPerPage);
if ($jumPage1 > 91) {
$jumPage =91;}else{
$jumPage = ceil($jumData/$dataPerPage);}
if ($noPage > 1) {
echo  "<a href='".$searchurl."/search.php?type=".$type."&sort=".$sort."&search=".$search."&hal=".($noPage-1)."'>&#171; Back</a>";}
else{
echo '<span style="color: #dddddd;">&#171; Back</span>';}
for($page = 1; $page <= $jumPage; $page++)
{
if ((($page >= $noPage - 2) && ($page <= $noPage + 2)) || ($page == 1) || ($page == $jumPage))
{
if (($showPage == 1) && ($page != 2))  echo "...";
if (($showPage != ($jumPage - 1)) && ($page == $jumPage))  echo "...";
if ($page == $noPage) echo " <b>".$page."</b> ";
else echo " <a href='".$searchurl."/search.php?type=".$type."&sort=".$sort."&search=".$search."&hal=".$page."'>".$page."</a> ";
$showPage = $page;
}
}
if ($noPage < $jumPage) {
echo "<a href='".$searchurl."/search.php?type=".$type."&sort=".$sort."&search=".$search."&hal=".($noPage+1)."'>Next &#187;</a>";}
else {
echo ' <span style="color: #dddddd;">Next &#187;</span>';}
echo '</div></div>';
}
if ($advs == 'on') 
{
echo '<div class="mainblok">';
include 'ads2.php'; 
echo '</div>'; 
} else { 
echo ' '; 
}
include 'foot.php';

                                              
                             
                  
function hapus($txt) {
$txt = preg_replace("/[^a-zA-Z0-9\.-]/", " ", trim($txt));
return $txt;
}


function hapus1($txt) {
$txt = preg_replace("/[^a-zA-Z0-9_\-]/", "_", trim($txt));
return $txt;
}
function potong($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}

?>
