<?php

$div = "|#|";
$dat='lastsearch.txt';

$fp=fopen($dat, 'r');
$count=fgets($fp);
fclose($fp);
$cari = $search;
$cari = str_replace('+', ' ', $cari);
$data = explode($div, $count);
if (in_array($cari, $data)) {
$tulis = implode($div, $data);
$hit=$tulis;
}
else {
$data = explode($div, $count);
$tulis = $data[1].''.$div.''.$data[2].''.$div.''.$data[3].''.$div.''.$data[4].''.$div.''.$data[5].''.$div.''.$data[6].''.$div.''.$data[7].''.$div.''.$data[8].''.$div.''.$data[9].''.$div.''.$data[10].''.$div;
$tulis .= $cari;
$hit=$tulis;
}


$masuk=fopen($dat, 'w');
fwrite($masuk,$tulis);
fclose($masuk);

$fa=fopen($dat, 'r');
$b=fgets($fa);
fclose($fa);
$c = explode($div, $b);
$e = str_replace(' ','+',$c);
echo '';
foreach(array_reverse($e) as $d){
echo ' :: <a href="'.$searchurl.'/search.php?search='.$d.'&sort=2" style="text-decoration:none;">
'.str_replace('+',' ',$d);''.$d.'</a>'; }
echo ' ::';
echo '</a>';
?>
