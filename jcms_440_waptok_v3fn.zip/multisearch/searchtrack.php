<?php


$div = "|#|";
$dat='lastsearch.txt';

$fp=fopen($dat, 'r');
$count=fgets($fp);
fclose($fp);
$cari = $search;
$cari = str_replace('_', ' ', $cari);
$data = explode($div, $count);
if (in_array($cari, $data)) {
$tulis = implode($div, $data);
$hit=$tulis;
}
else {
$data = explode($div, $count);
$tulis = $data[1].''.$div.''.$data[2].''.$div.''.$data[3].''.$div.''.$data[4].''.$div.''.$data[5].''.$div.''.$data[6].''.$div.''.$data[7].''.$div.''.$data[8].''.$div.''.$data[9].''.$div;
$tulis .= $cari;
$hit=$tulis;
}


$masuk=fopen($dat, 'w');
fwrite($masuk,$tulis);
fclose($masuk);

$fa=fopen($dat, 'r');
$b=fgets($fa);
fclose($fa);

$c = explode($div, $b);
?>
