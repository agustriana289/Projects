<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
if (!$user_id) {
echo functions::display_error('Hanya untuk member situs!');
require('../incfiles/end.php');
exit;
}

      $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog_cat`"), 0);
      if($total) {
         if (isset ($_POST['submit'])) {
            $time = time();
            $timer = time();
            $date['day'] = date('d', $time);
            $date['year'] = date('o', $time);
            $date['month'] = date('m', $time);
            $date['i'] = date('i', $time);
            $date['h'] = date('h', $time);
            
            $name = isset ($_POST['name']) ? trim($_POST['name']) : '';
            $text = isset ($_POST['text']) ? trim($_POST['text']) : '';
            $cat = isset($_POST['cat']) ? abs(intval($_POST['cat'])) : 0;
            $day = isset($_POST['day']) && $_POST['day'] >= 1 && $_POST['day'] <= 31 ? abs(intval($_POST['day'])) : 0;
            $month = isset($_POST['month']) && $_POST['month'] >= 1 && $_POST['month'] <= 12 ? abs(intval($_POST['month'])) : 0;
            $year = isset($_POST['year']) && $_POST['year'] >= $date['year'] && $_POST['year'] <= ($date['year'] + 1) ? abs(intval($_POST['year'])) : 0;
            
            $hour = isset($_POST['hour']) && $_POST['hour'] >= 0 && $_POST['hour'] <= 24 ? abs(intval($_POST['hour'])) : 0;
            $minutes = isset($_POST['minutes']) && $_POST['minutes'] >= 0 && $_POST['minutes'] <= 60 ? abs(intval($_POST['minutes'])) : 0;
            
            $error = array();
      
            $error = array();
            
            if(empty($name))
               $error[] = 'Judul blog tidak boleh dikosongkan!';
            else if (mb_strlen($name) < 2 || mb_strlen($name) > 150)
               $error[] = 'Kesalahan dalam panjang Judul blog!';
            if(empty($text))
               $error[] =  'Blog text tidak boleh kosong!';
            else if (mb_strlen($text) < 2 || mb_strlen($text) > 500000000)
               $error[] = 'Kesalahan dalam panjang isi blog!';
            if(!$cat)
               $error[] =  'Tidak memilih kategori!';
               
            if(empty($day) || empty($month) || empty($year))
               $timer = 0;
            else 
               $time = strtotime("$day.$month.$year.$hour.$minutes");
            /*
            if(!empty($timer) && $time < time())
               $error[] = 'Bukan tanggal valid !';
            */
            if(!$error) {
               $data = mysql_query("SELECT * FROM `myblog_cat` WHERE `id`='$cat';");
               if(!mysql_num_rows($data))
                  $error[] =  'Kategori tidak ada!';
            }
            
            if(empty($error)) {
               $q = mysql_query("SELECT * FROM `myblog` WHERE `name`='" . mysql_real_escape_string($name) . "' LIMIT 1");
               if (mysql_num_rows($q)) {
                  $error[] = 'Blog sudah ada!';
               }
            }
            
            if(empty($error)) {
               
               mysql_query("INSERT INTO `myblog` SET
               `refid` = '$cat',
               `name` = '" . mysql_real_escape_string($name) . "',
               `text` = '" . mysql_real_escape_string($text) . "',
               `user_id` = '" . $user_id . "',
               `time` = '" . $time . "'");
               
               $img_id = mysql_insert_id();
               
               require_once ('../incfiles/lib/class.upload.php');
               $handle = new upload($_FILES['imagefile']);
               if ($handle->uploaded) {
                  // SzS+NESzS+SzN,N<S2SzSuSL N"SlN,Sl
                  $handle->file_new_name_body = 'news_' . $img_id;
                  $handle->allowed = array('image/jpeg', 'image/jpg', 'image/gif', 'image/png');
                  $handle->file_max_size = 1024 * $set['flsz'];
                  $handle->file_overwrite = true;
                  $handle->image_resize = true;
                  $handle->image_x = 100;
                  $handle->image_ratio_y = true;
                  $handle->image_convert = 'jpg';
                  $handle->process('../files/blog/');
                  if($handle->processed) {
                     @ chmod('../files/myblog/news_' . $img_id . '.jpg', 0666);
                  }
                  
                  $handle->file_new_name_body = 'small_news_' . $img_id;
                  $handle->image_x = 32;
                  $handle->image_y = 32;
                  $handle->image_convert = 'jpg';
                  $handle->process('../files/myblog/');
                  if($handle->processed) {
                     @ chmod('../files/myblog/small_news_' . $img_id . '.jpg', 0666);
                  }
                  
               }
               $handle->clean();
               
               Header('Location: ../myblog/view.php?id='.$img_id);
               
            } else {
               echo functions::display_error($error, '<a href="nulis.php">Ulang</a>');
            }
            
         } else {
            echo '<form action="nulis.php" method="post" enctype="multipart/form-data">
            <div class="gmenu"><p>
            <b>Judul blog:</b><br />
            <input type="text" name="name" /><br />
            <small>Min. 2, Max. 150 karakter</small><br />
            <b>Blog text:</b><br />
            <textarea name="text" cols="24" rows="4"></textarea><br />
            <small>Min. 2, Max. 5000 Karakter</small><br />
            <b>Pilih Kategori:</b><br />
            <select name="cat">';
            $req = mysql_query("SELECT * FROM `myblog_cat` ORDER BY `realid` ASC");
            while (($row = mysql_fetch_assoc($req)) !== false) {
               echo '<option value="' . $row['id'] . '">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '</option>';
            }
            echo '</select><br /><b>Tanggal (kosong untuk tanggal saat ini):</b><br />
            <table><tr>
            <td><span style="text-decoration: underline;">Tanggal</span><br />
            <input type="text" value="" size="2" maxlength="2" name="day" />.</td>
            <td><span style="text-decoration: underline;">Bulan</span><br />
            <input type="text" value="" size="2" maxlength="2" name="month" />.</td>
            <td><span style="text-decoration: underline;">Tahun</span><br />
            <input type="text" value="" size="4" maxlength="4" name="year" />-</td>
            <td><span style="text-decoration: underline;">Jam</span><br />
            <input type="text" value="" size="2" maxlength="2" name="hour" />:</td>
            <td><span style="text-decoration: underline;">Menit</span><br />
            <input type="text" value="" size="2" maxlength="2" name="minutes" /></td>
            </tr></table>
            <small>Tanggal di sistem ' . date('d.m.o / H:i', time() + $sdvigclock * 3600) . '<br />
            Isi tanggal untuk menampilkan blog selama waktu yang di tentukan</small><br />
            <b>Gambar blog:</b><br />
            <input type="file" name="imagefile"/><br />
            <small>Format yang diperbolehkan: GIF, JPEG, JPG, PNG max.data 1000 kb<br />
            </small>
            <input type="hidden" name="MAX_FILE_SIZE" value="' . (1024 * $set['flsz']) . '" />
            </p><p><input type="submit" value="Tambah" name="submit" />
            </p></div></form>';
            
         }
      } else {
         echo '<div class="rmenu">Kategori masih kosong</div>';
         
      }
      echo '<div class="phdr"><a href="index.php">Kembali ke MyBlog</a></div>';

require_once('../incfiles/end.php');
?>