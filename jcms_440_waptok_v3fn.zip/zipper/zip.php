<?php
/**Script By nekaters
* http://nekaters.com
* Remodif by whiznoe
* http://waptok.asia
*/

require_once ('../zipper/head.php');
echo '<html>
<body class="body">';

if($_GET['url']) {
$down = 'download.php?url';
$url = $_GET[url];
$jar = basename($url);
$jar = explode('?', $jar);
$jar = trim($jar[0]);
$zip = str_replace('jar', 'zip', $jar);
$zip = explode('?', $zip);
$zip = trim($zip[0]);
$download = $down.'='.$url;
echo '<div class=\"phdr\">Download '.$zip.'</div>';
echo '<div class=\"gmenu\">
<b>Url Asal File : </b><a href="'.$url.'">'.$url.'</a><br /><b>Nama file :</b>'.$jar.'<br />
<b>Di Namai Ulang Menjadi :</b>'.$zip.'<br /><br />
<a href="'.$down.'='.$url.'"><center><img src="http://whiznoe.wen.ru/images/loads.png" alt="download"/><br><b>'.$zip.'</b></center></a>
<b>Copy Url</b><br /><input size="25" value="http://waptok.asia/zipper/'.$down.'='.$url.'"/>';
//waptok//
echo '<br /><a href="../zipper/zip.php"><center><b>&laquo; Kembali</b></a></center></div>';
} else {
echo '<div class="mainblok"><div class="phdr">Download Jar as Zip</div><div class="gmenu">';
//waptok//
echo 'Service Download Jar as Zip hanya media download file .Jar yang direname menjadi .Zip, Setelah download selesai silahkan rename kembali menjadi existensi .Jar<br />
<center><b>Masukkan Url File :</b><br/><form action="" method="GET">
<input type="text" name="url" size="18" value="http://" />
<br /><input type="submit" class="submit" value="Submit" /></form></center></div></div>';
}
echo '</body></html>';
require_once ('../zipper/foot.php');
?>
