<?php
/** Moduls grab Jcms Mod by Whiznoe
* http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'status fb via';
$textl = 'Status FB Via';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

?>