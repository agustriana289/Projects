<?php


/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
* Translate by whiznoe - http://www.waptok.asia - http://www.waptok.tk
* Thanks to Teguh - http://user-iwb.tk for this script
*/


$dir = scandir('screen');
if (isset($_GET['clear'])) {

for ($file=0; $file <= count($dir); $file++) {

unlink('screen/'.$dir[$file]);

}
}
define('_IN_JOHNCMS', 1);
$headmod = 'screenshot';
$textl = 'Screenshot Site';
require('../incfiles/core.php');
require('../incfiles/head.php');
if (count($dir) == 2 || isset($_GET['clear'])) {

}
echo '<div class="mainblok"><div class="phdr"><b>Screenshot site</b></div>';
echo '<div class="menu">';
echo '<form action = "?" method = "POST">

Alamat situs (<font color = "dimgray">Tanpa http://</font>):
<br />
<input name = "link" value="waptok.asia">
<br />
<br />
Ukuran (<font color = "dimgray">Lebar x Tinggi</font>):
<br />
<input name = "weight" size = "4">
 x <input name = "height" size = "4">
<br />
<font color = "dimgray">
Kosongkan untuk mendapatkan ukuran asli screenshot!
</font>
<br />
<br />
Lebar screenshot diberikan:
<br />
<input name = "weight_screen" size = "5" value = "400">
<br />
Tentukan format:
<br />
<select name = "ras">
<option value = "png">.png</option>
<option value = "jpg">.jpg</option>
</select>
<br />
<input type = submit value = "Shout">
<br />';

if (isset($_POST['link']) && !empty($_POST['link'])){
$height = intval($_POST['height']);
$weight = intval($_POST['weight']);
$weight_screen = intval($_POST['weight_screen']);
$ras = $_POST['ras'];

    $error = array();
    $link = functions::check(mb_substr($_POST['link'], 0, 40));
if (!preg_match('|^[a-z 0-9-]+(.[a-z 0-9-]+)*(:[0-9]+)?(/.*)?$|i', $link)) { 

        $error[] = 'Link tidak valid';

}
else if (!get_headers('http://'.$link)) {

        $error[] = 'Server tidak tersedia';

}
$rand_up = 0;
if (file_exists('screen/'.$link.'.'.$ras)) {
 
$rand_up = rand(0, 1000000);

}

if (!$error) {

$url = 'http://mini.s-shot.ru/'.$weight.'x'.$height.'/'.$weight_screen.'/'.$ras.'/?http://'.$link;
copy($url, 'screen/'.$rand_up.'_'.$weight.'x'.$height.'_'.$weight_screen.'_'.$ras.'_'.$link.'.'.$ras);
echo  '<br />
<center>
<img src="screen/'.$rand_up.'_'.$weight.'x'.$height.'_'.$weight_screen.'_'.$ras.'_'.$link.'.'.$ras.'">
<br />
<b>
<u>
<a href="screen/'.$rand_up.'_'.$weight.'x'.$height.'_'.$weight_screen.'_'.$ras.'_'.$link.'.'.$ras.'">Unduh</a>
</u>
</b>
</center>';
}
 else 
{

        echo functions::display_error($error);


}
}


echo '<br />';

echo'</div></div>';

if ($rights >= 7) {
    echo '<div class="bmenu"><a href="?clear"><b>Kembali</b></a></div>';

}
require('../incfiles/end.php');
?>
