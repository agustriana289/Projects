<?php
include('social_bookmarking.php');
echo '<b>Social Networks:</b><br />';
echo facebook();
echo twitter();
echo digg();
echo delicious();
?>