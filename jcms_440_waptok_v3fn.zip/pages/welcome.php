<?php

if ($user_id){
} else {
echo '<div class="mainblok"><div class="phdr" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><b>Welcome Friends</b></td>'; 
echo '</tr></table></div>'; 
echo '<div class="menu"><table><tr><td width="40px"><img src="/images/rumah.png" width="40" height="40"/></td>'; 
echo '<td><b><u>Selamat Datang di <font color="blue">Waptok ID Community</b></font></u><br />Silakan lakukan <a href="/registration.php"><b>Registrasi</b></a> atau <a href="/login.php"><b>Login</b></a> agar dapat mengakses seluruh fitur wapsite ini.<br />Terima Kasih Atas Kunjungannya.';
echo '</td></tr></table></div></div>'; 

}

?>