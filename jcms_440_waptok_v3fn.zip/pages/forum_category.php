<?
/** forum category jcms v440
* http://www.waptok.asia
* http://www.waptok.tk
* http://www.indozona.tk
*/

echo '<div class="mainblok"><div class="phdr"><b>' . $lng['forum_category'] . '</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        while (($res = mysql_fetch_array($req)) !== false) {
            echo $i % 2 ? '<div class="list2">' : '<div class="list2">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
            echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_'.$res['id'].'.html">' . $res['text'] . '</a> [<font color="red">' . $count . '</font>]';
            if (!empty($res['soft']))
                echo '<div class="func"><span class="gray">' . $res['soft'] . '</span></div>';
            echo '</div>';
            ++$i;
        }
            if ($count == 0)
{
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo '</div>';
?>