<?php
/* random site Jcms v440 */
/* script ini khusus untuk yang sudah pasang modul friendssite, kalau yang belum dipasang dulu ya */



echo '<div class="mainblok"><div class="menu"><center>';

$req = mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'");
$colmes = mysql_result($req, 0);
$req = mysql_query("SELECT * FROM `friendssite` WHERE `type`='1' ORDER BY RAND() LIMIT 1 ;");
while ($res = mysql_fetch_array($req))
{
$q = mysql_query("SELECT `name`,`id` FROM `users` WHERE `id`='" . $res['iduser'] . "'");
$arr = mysql_fetch_array($q);
echo '<a href="' . $res['site'] . '">' . htmlentities($res['name'], ENT_QUOTES, 'UTF-8') . '</a>';
}
echo '</center></div></div>';

?>
