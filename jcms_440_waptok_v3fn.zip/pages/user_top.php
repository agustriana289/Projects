<?

echo '<div class="mainblok"><div class="phdr"><b><a href="../users/index.php?act=top">User Top</a></b></div>';

function get_top($order = 'postforum') {
global $lng;
$req = mysql_query("SELECT * FROM `users` WHERE `$order` > 0 ORDER BY `$order` DESC LIMIT 3");
if (mysql_num_rows($req)) {
$out = '';
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
$out .= $i % 2 ? '<div class="list2">' : '<div class="list1">';
$out .= functions::display_user
($res, array ('header' =>
('<b>' . $res[$order]) . '<b>')) .
'</div>';
++$i;
}
return $out;
} else {
return '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
}

echo get_top('postforum');

echo'</div>';

?>