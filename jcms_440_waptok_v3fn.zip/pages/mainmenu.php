<? 
 
/** 
* @package     JohnCMS 
* @link        http://johncms.com 
* @copyright   Copyright (C) 2008-2011 JohnCMS Community 
* @license     LICENSE.txt (see attached file) 
* @version     VERSION.txt (see attached file) 
* @author      http://johncms.com/about 
*/ 
 
defined('_IN_JOHNCMS') or die('Error: restricted access'); 
 
$mp = new mainpage(); 
 
/* 
----------------------------------------------------------------- 
S'S"SlSa SlS?N"SlNESLSzN?SlSl 
----------------------------------------------------------------- 
*/ 
//echo $mp->news;
 
include'welcome.php';

echo '<div class="mainblok"><div class="phdr" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><b>' . $lng['dialogue'] . '</b></td>'; 
echo '</tr></table></div>'; 
echo '<div class="menu"><table><tr><td width="40px"><img src="images/waptok_asia.png" width="40" height="40"/></td><td>'; 
echo '<p>&nbsp;&bull;&nbsp;<a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</p>'; 
 
/* 
----------------------------------------------------------------- 
S'S"SlSa SlS+NeSuS?SlNZ 
----------------------------------------------------------------- 
*/// S?N?N<S"SaSz S?Sz S"SlN?N,SuS2N?NZ 

// untuk blog
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog`"), 0);
echo '<p>&nbsp;&bull;&nbsp;<a href="myblog/">' . $lng['myblog'] . '</a> (' . $total . ')</p>';

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
echo '<p>&nbsp;&bull;&nbsp;<a href="../pages/friendssite.php">Friendssite</a> ('.$total.')</p>';
if ($set['mod_guest'] || $rights >= 7) 
echo '<p>&nbsp;&bull;&nbsp;<a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</p>'; 
// S?N?N<S"SaSz S?Sz SRSlNEN?SL 
if ($set['mod_forum'] || $rights >= 7) 
echo '<p>&nbsp;&bull;&nbsp;<a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</p>'; 
echo '</td></tr></table></div></div>'; 

echo '<div class="mainblok"><div class="phdr"><b>' . $lng['useful'] . '</b></div>'; 
if ($set['mod_down'] || $rights >= 7)
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</div>'; 
if ($set['mod_lib'] || $rights >= 7)
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')</div>'; 

if ($set['mod_gal'] || $rights >= 7)
    echo '<div class="menu">';
echo '&bull;&nbsp;<a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</div>';
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</div>';
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="pages/faq.php">' . $lng['information'] . '</a></div>';
echo '</div>';

include'search_forum.php';
include'forum_category.php';
include'recent_post.php';
include'new_topic.php';
include'popular_topic.php';
//include'top_forum.php';
//include'user_top.php';

if ($user_id){
include'shortcuts.php';
}

include'last_myblog.php';
include'recent_upload.php';


if ($user_id){
include'change_theme.php';
}

//include'statistics.php';
include'referer.php';
//include'randomsite.php';

?> 

