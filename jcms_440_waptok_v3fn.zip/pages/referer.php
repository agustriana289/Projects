<?php
/** last visited for jcms remod by Whiznoe
* http://waptok.asia
* http://indozona.tk
*/

function referer(){
$referer = strtolower($_SERVER['HTTP_REFERER']);
$ref = explode("/", $referer);
$pager = "|#|";
$textreferer = "referer.txt";
$fp = fopen($textreferer, 'r');
$count = fgets($fp);
fclose($fp);
$alamat = explode($pager, $count);
if(in_array($ref[2], $alamat)){
$silut = implode($pager, $alamat);}else{   
$alamat = explode($pager, $count);
$silut = $alamat[1].''.$pager.''.$alamat[2].''.$pager.''.$alamat[3].''.$pager.''.$alamat[4].''.$pager.''.$alamat[5].''.$pager.''.$alamat[6].''.$pager.''.$alamat[7].''.$pager.''.$alamat[8].''.$pager.''.$alamat[9].''.$pager.''.$alamat[10].''.$pager.''.$alamat[11].''.$pager.''.$alamat[12].''.$pager.''.$alamat[13].''.$pager.''.$alamat[14].''.$pager.''.$alamat[15].''.$pager;
 $silut .= $ref[2];
}

if(!eregi($_SERVER['HTTP_HOST'], $ref[2])){
$mlebet = fopen($textreferer, 'w');
fwrite($mlebet, $silut);
fclose($mlebet);
}
}

referer();
?>
<?
function ShowReferer(){
$pager = "|#|";
$datazip = "referer.txt";$fa = fopen($datazip, 'r');
$b = fgets($fa);
fclose($fa);
$c = explode($pager, $b);
if (!empty($c))
echo '<div class="mainblok"><div class="phdr"><b>Last Visited</b></div><div class="menu">';
foreach(array_reverse($c) as $d){
if(!empty($d))
echo '<a href="http://'.$d.'">'.$d.'</a>, ';
}
if (!empty($c))
echo '</div>';
}
ShowReferer();
echo '</div>';
?>