<?
/** Search forum Jcms v440
* http://waptok.asia
*/

echo '<div class="mainblok"><div class="phdr"><b>' . $lng['searching'] . '</b></div>
<div class=list1><form action="../forum/search.php" method="post"><input type="text" value="" name="search" size="20"/><input type="submit" value="' . $lng['search'] . '" name="submit"/><br /><input name="t" type="checkbox" value="1" default = "1" ' . ($search_t ? 'checked="checked"' : '') . ' />
' . $lng['forum_topic'] . '
</form></div></div>';

?>