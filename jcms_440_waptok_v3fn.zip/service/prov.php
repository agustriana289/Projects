<?php
/** Prov Maker Jcms v440
* http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'prov';
$textl = 'Prov Maker';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

//*------------- waptok[dot]asia -------------------- *//
echo '<div class="mainblok"><div class="phdr"><b>File Prov Maker</b></div>';
echo '<div class="gmenu"><font color="red"><center>Buat Access Point Setting</font><center></div>';
echo '<div class="list2">
<center><form action="http://myprov.co.cc/generate/access" method="post">
<b>NAMA PROV: </b>
<br>
<input type="text" name="name" class="input">
<br>
<b>NAMA PENGGUNA ( APN ): </b>
<br>
<input type="text" name="apn" class="input">
<br>
<b>IP (Proxy): </b>
<br>
<input type="text" name="prov_ip" class="input">
<br>
<b>PORT: </b>
<br>
<input type="text" name="prov_port" class="input">
<br>
<b>USERNAME: </b>
<br>
<input type="text" name="user_name" class="input">
<br>
<b>PASSWORD: </b>
<br>
<input type="text" name="pass_word" class="input">
<br>
<input type="submit" name="submit" class="submit" value="BUAT"/>
</form>
<center></div></div>';

require_once ("../incfiles/end.php");
?>
