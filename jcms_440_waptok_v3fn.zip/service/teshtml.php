<?php
define('_IN_JOHNCMS', 1);
$textl = 'Tes HTML';
$headmod = 'Tes HTML';
require_once("../incfiles/core.php");
require_once("../incfiles/head.php");

?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.2//EN" 

"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><body><div class="mainblok">
<div class="phdr">
<center><b>HTML TESTER VIEWER</b></center></div><br/><center>Letakkan Kode HTML Kamu Disini:<br/><br/></center><script language="JavaScript">function preview() {var odiv=document.getElementById("outputdiv"); var idiv=document.getElementById("inputcode");


odiv.innerHTML=idiv.value;}</script><form align="center"><textarea id="inputcode"><a href="http://waptok.asia"><font color="red">http://waptok.asia</font></a></textarea><br /><input type="button" onclick="preview()" value="Preview"></form><br /><div id="outputdiv" align="center"></div></center></script><br/></div></body></html>
<?php
require_once("../incfiles/end.php");

?>