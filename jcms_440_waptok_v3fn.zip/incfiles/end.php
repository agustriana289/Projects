<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// �?�u�a�"���L�?N<�a �+�"�l�a N?���aN,��
echo '<div class="mainblok"><div class="menu">';
echo '<div style="text-align:center">';
if (!empty($cms_ads[2]))
echo '' . $cms_ads[2] . ''."\n";
//include_once ('adiquity.php');
echo '</div></div></div>';

echo '<div>';
if ($headmod != "mainpage" || ($headmod == 'mainpage' && $act))
    echo '<img src="'.$home.'/images/home.png" widht="14" height="14"> <a href="' . $set['homeurl'] . '">' . $lng['homepage'] . '</a><br/>';

// A?L>A?AuA?A?L?L? A?A+L?<L?A?L?,L?EA?AlA?L,A?Al A?LLA?AuL?EA?AuL?AaA?AlA?A'A?Az
if ($set_user['quick_go']) {
    echo '<form action="' . $set['homeurl'] . '/go.php" method="post">';
    echo '<div><select name="adres" style="font-size:x-small">
    <option selected="selected">' . $lng['quick_jump'] . '</option>
    <option value="myblog">My Blog</option>
    <option value="guest">' . $lng['guestbook'] . '</option>
    <option value="forum">' . $lng['forum'] . '</option>
    <option value="news">' . $lng['news'] . '</option>
    <option value="gallery">' . $lng['gallery'] . '</option>
    <option value="down">' . $lng['downloads'] . '</option>
    <option value="lib">' . $lng['library'] . '</option>
    <option value="gazen">Gazenwagen :)</option>
    </select><input type="submit" value="Go!" style="font-size:x-small"/>';
    echo '</div></form>';

}
    echo '</div>';
// ��N?�uN,N?���a �z�lN?�uN,��N,�u�"�u�a �l�?�"���a�?
if ($headmod == 'mainpage') {
if ($user_id){
echo '<div class="orangex">' . $lng['member'] . ': <a href="../users/index.php"> ' . counters::users() . ' </a><br/>';
include_once('member.php');
}else{
echo '<div class="orangex">' . counters::online() . '</div>';
}
}
echo '</div>';
echo '</div><div class="footer" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</td><td width="auto" align="right">';
$Contents = ob_get_contents();
$gzib_file = strlen($Contents);
$gzib_file_out = strlen(gzcompress($Contents, 9));
$gzib_pro = round(100 - (100 / ($gzib_file / $gzib_file_out)), 1);
echo 'Gzip: ' . $gzib_pro . '%';
echo '</a></td></tr></table></div>';
////////////////////////////////////////////////////////////// ��N?�uN,N?���a�� �a��N,���"�l���l�2
functions::display_counters();
// �?�u�a�"���L�?N<�a �+�"�l�a N?���aN,��
if (!empty($cms_ads[3]))
echo '<div style="text-align:center">' . $cms_ads[3];

/*
-----------------------------------------------------------------
�'�t�~�s�?�t�~��!!!
ATTENTION!!!
The copyright could not be removed within 60 days of installation scripts
-----------------------------------------------------------------
*/

echo '<div style="text-align:center">';
if($user_id){
echo '<b><a href="/constitution">TOS</a> | <a name="down" id="down"></a><a href="#up"><img src="../theme/' . $set_user['skin'] . '/images/up.png"/></a> | <a href="/faq">FAQ</a></b>';
}
echo '<div><small><a href="http://waptok.tk" target="_blank">&copy;</a> 2012-' . date('Y') . ' ' . $set['copyright'] . '</small></div>';
echo '<div><small>Powered by <a href="http://johncms.com">JohnCMS</a></small></div>';
echo '</div></body></html>';
