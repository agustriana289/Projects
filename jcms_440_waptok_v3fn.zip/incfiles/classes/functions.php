<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Restricted access');

class functions extends core
{
public static function gantiurl($text)
{
$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
$text=str_replace(" ","-", $text);$text=str_replace("--","-", $text);
$text=str_replace("@","-",$text);$text=str_replace("/","-",$text);
$text=str_replace("\\","-",$text);$text=str_replace(":","",$text);
$text=str_replace("\"","",$text);$text=str_replace("'","",$text);
$text=str_replace("<","",$text);$text=str_replace(">","",$text);
$text=str_replace(",","",$text);$text=str_replace("?","",$text);
$text=str_replace(";","",$text);$text=str_replace(".","",$text);
$text=str_replace("[","",$text);$text=str_replace("]","",$text);
$text=str_replace("(","",$text);$text=str_replace(")","",$text);
$text=str_replace("*","",$text);$text=str_replace("!","",$text);
$text=str_replace("$","-",$text);$text=str_replace("&","-and-",$text);
$text=str_replace("%","",$text);$text=str_replace("#","",$text);
$text=str_replace("^","",$text);$text=str_replace("=","",$text);
$text=str_replace("+","",$text);$text=str_replace("~","",$text);
$text=str_replace("`","",$text);$text=str_replace("--","-",$text);
$text = preg_replace("/(Р“ |Р“Ў|Р±єЎ|Р±єЈ|Р“Ј|Р“ў|Р±є§|Р±єҐ|Р±є­|Р±є©|Р±є«|Р”ѓ|Р±є±|Р±єЇ|Р±є·|Р±єі|Р±єµ)/", 'a', $text);$text = preg_replace("/(aРњЂ|aРњЃ|aРњЈ|aРњ‰|aРњѓ|Р“ў|Р“ўРњЂ|Р“ўРњЃ|Р“ўРњЈ|Р“ўРњ‰|Р“ўРњѓ|Р”ѓ|Р”ѓРњЂ|Р”ѓРњЃ|Р”ѓРњЈ|Р”ѓРњ‰|Р”ѓРњѓ)/", 'a', $text);
$text = preg_replace("/(Р“РЃ|Р“©|Р±є№|Р±є»|Р±єЅ|Р“Є|Р±»Ѓ|Р±єї|Р±»‡|Р±»ѓ|Р±»…)/", 'e', $text);$text = preg_replace("/(eРњЂ|eРњЃ|eРњЈ|eРњ‰|eРњѓ|Р“Є|Р“ЄРњЂ|Р“ЄРњЃ|Р“ЄРњЈ|Р“ЄРњ‰|Р“ЄРњѓ)/", 'e', $text);
$text = preg_replace("/(Р“¬|Р“­|Р±»‹|Р±»‰|Р”©)/", 'i', $text);$text = preg_replace("/(iРњЂ|iРњЃ|iРњЈ|iРњ‰|iРњѓ)/", 'i', $text);
$text = preg_replace("/(Р“І|Р“і|Р±»Ќ|Р±»Џ|Р“µ|Р“ґ|Р±»“|Р±»‘|Р±»™|Р±»•|Р±»—|Р–Ў|Р±»ќ|Р±»›|Р±»Ј|Р±»џ|Р±»Ў)/", 'o', $text);$text = preg_replace("/(oРњЂ|oРњЃ|oРњЈ|oРњ‰|oРњѓ|Р“ґ|Р“ґРњЂ|Р“ґРњЃ|Р“ґРњЈ|Р“ґРњ‰|Р“ґРњѓ|Р–Ў|Р–ЎРњЂ|Р–ЎРњЃ|Р–ЎРњЈ|Р–ЎРњ‰|Р–ЎРњѓ)/", 'o', $text);
$text = preg_replace("/(Р“№|Р“є|Р±»Ґ|Р±»§|Р•©|Р–°|Р±»«|Р±»©|Р±»±|Р±»­|Р±»Ї)/", 'u', $text);$text = preg_replace("/(uРњЂ|uРњЃ|uРњЈ|uРњ‰|uРњѓ|Р–°|Р–°РњЂ|Р–°РњЃ|Р–°РњЈ|Р–°Рњ‰|Р–°Рњѓ)/", 'u', $text);
$text = preg_replace("/(Р±»і|Р“Ѕ|Р±»µ|Р±»·|Р±»№)/", 'y', $text);$text = preg_replace("/(Р”‘)/", 'd', $text);
$text = preg_replace("/(yРњЂ|yРњЃ|yРњЈ|yРњ‰|yРњѓ)/", 'y', $text);$text = preg_replace("/(Р”‘)/", 'd', $text);
$text = preg_replace("/(Р“Ђ|Р“Ѓ|Р±є |Р±єў|Р“ѓ|Р“‚|Р±є¦|Р±є¤|Р±є¬|Р±єРЃ|Р±єЄ|Р”‚|Р±є°|Р±є®|Р±є¶|Р±єІ|Р±єґ)/", 'A', $text);$text = preg_replace("/(AРњЂ|AРњЃ|AРњЈ|AРњ‰|AРњѓ|Р“‚|Р“‚РњЂ|Р“‚РњЃ|Р“‚РњЈ|Р“‚Рњ‰|Р“‚Рњѓ|Р”‚|Р”‚РњЂ|Р”‚РњЃ|Р”‚РњЈ|Р”‚Рњ‰|Р”‚Рњѓ)/", 'A', $text);
$text = preg_replace("/(Р“€|Р“‰|Р±єС‘|Р±єє|Р±єј|Р“Љ|Р±»Ђ|Р±єѕ|Р±»†|Р±»‚|Р±»„)/", 'E', $text);$text = preg_replace("/(EРњЂ|EРњЃ|EРњЈ|EРњ‰|EРњѓ|Р“Љ|Р“ЉРњЂ|Р“ЉРњЃ|Р“ЉРњЈ|Р“ЉРњ‰|Р“ЉРњѓ)/", 'E', $text);
$text = preg_replace("/(Р“Њ|Р“Ќ|Р±»Љ|Р±»€|Р”РЃ)/", 'I', $text);$text = preg_replace("/(IРњЂ|IРњЃ|IРњЈ|IРњ‰|IРњѓ)/", 'I', $text);
$text = preg_replace("/(Р“’|Р““|Р±»Њ|Р±»Ћ|Р“•|Р“”|Р±»’|Р±»ђ|Р±»�|Р±»”|Р±»–|Р– |Р±»њ|Р±»љ|Р±»ў|Р±»ћ|Р±» )/", 'O', $text);$text = preg_replace("/(OРњЂ|OРњЃ|OРњЈ|OРњ‰|OРњѓ|Р“”|Р“”РњЂ|Р“”РњЃ|Р“”РњЈ|Р“”Рњ‰|Р“”Рњѓ|Р– |Р– РњЂ|Р– РњЃ|Р– РњЈ|Р– Рњ‰|Р– Рњѓ)/", 'O', $text);
$text = preg_replace("/(Р“™|Р“љ|Р±»¤|Р±»¦|Р•РЃ|Р–Ї|Р±»Є|Р±»РЃ|Р±»°|Р±»¬|Р±»®)/", 'U', $text);$text = preg_replace("/(UРњЂ|UРњЃ|UРњЈ|UРњ‰|UРњѓ|Р–Ї|Р–ЇРњЂ|Р–ЇРњЃ|Р–ЇРњЈ|Р–ЇРњ‰|Р–ЇРњѓ)/", 'U', $text);
$text = preg_replace("/(Р±»І|Р“ќ|Р±»ґ|Р±»¶|Р±»С‘)/", 'Y', $text);$text = preg_replace("/(Р”ђ)/", 'D', $text);
$text = preg_replace("/(YРњЂ|YРњЃ|YРњЈ|YРњ‰|YРњѓ)/", 'Y', $text);$text = preg_replace("/(Р”ђ)/", 'D', $text);
$text=strtolower($text);
return $text;
}
public static function display_pagination2($base_url, $start, $max_value, $num_per_page)
{
$neighbors = 2;
if ($start >= $max_value)
$start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
else
$start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
$base_link = '<a class="pagenav" href="' . strtr($base_url, array('%' => '%%')) . '_p%d.html' . '">%s</a>';
$out[] = $start == 0 ? '' : sprintf($base_link, $start / $num_per_page, 'Prev');
if ($start > $num_per_page * $neighbors)
$out[] = sprintf($base_link, 1, '1');
if ($start > $num_per_page * ($neighbors + 1))
$out[] = '<span style="font-weight: bold;">...</span>';
for ($nCont = $neighbors; $nCont >= 1; $nCont--)
if ($start >= $num_per_page * $nCont) {
$tmpStart = $start - $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
$out[] = '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span>';
$tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;
for ($nCont = 1; $nCont <= $neighbors; $nCont++)
if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
$tmpStart = $start + $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
if ($start + $num_per_page * ($neighbors + 1) < $tmpMaxPages)
$out[] = '<span style="font-weight: bold;">...</span>';
if ($start + $num_per_page * $neighbors < $tmpMaxPages)
$out[] = sprintf($base_link, $tmpMaxPages / $num_per_page + 1, $tmpMaxPages / $num_per_page + 1);
if ($start + $num_per_page < $max_value) {
$display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start / $num_per_page + 2);
$out[] = sprintf($base_link, $display_page, 'Next');
}
return implode(' ', $out);
}
/*
-----------------------------------------------------------------
РђРЅС‚РёС„Р»СѓРґ
-----------------------------------------------------------------
Р РµР¶РёРјС‹ СЂР°Р±РѕС‚С‹:
1 - РђРґР°РїС‚РёРІРЅС‹Р№
2 - Р”РµРЅСЊ / РќРѕС‡СЊ
3 - Р”РµРЅСЊ
4 - РќРѕС‡СЊ
-----------------------------------------------------------------
*/
public static function antiflood()
{
$default = array(
'mode' => 2,
'day' => 10,
'night' => 30,
'dayfrom' => 10,
'dayto' => 22
);
$af = isset(self::$system_set['antiflood']) ? unserialize(self::$system_set['antiflood']) : $default;
switch ($af['mode']) {
case 1:
// РђРґР°РїС‚РёРІРЅС‹Р№ СЂРµР¶РёРј
$adm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` > 0 AND `lastdate` > " . (time() - 300)), 0);
$limit = $adm > 0 ? $af['day'] : $af['night'];
break;
case 3:
// Р”РµРЅСЊ
$limit = $af['day'];
break;
case 4:
// РќРѕС‡СЊ
$limit = $af['night'];
break;
default:
// РџРѕ СѓРјРѕР»С‡Р°РЅРёСЋ РґРµРЅСЊ / РЅРѕС‡СЊ
$c_time = date('G', time());
$limit = $c_time > $af['day'] && $c_time < $af['night'] ? $af['day'] : $af['night'];
}
if (self::$user_rights > 0)
$limit = 4; // Р”Р»СЏ РђРґРјРёРЅРёСЃС‚СЂР°С†РёРё Р·Р°РґР°РµРј Р»РёРјРёС‚ РІ 4 СЃРµРєСѓРЅРґС‹
$flood = self::$user_data['lastpost'] + $limit - time();
if ($flood > 0)
return $flood;
else
return false;
}

/*
-----------------------------------------------------------------
РњР°СЃРєРёСЂРѕРІРєР° СЃСЃС‹Р»РѕРє РІ С‚РµРєСЃС‚Рµ
-----------------------------------------------------------------
*/
public static function antilink($var)
{
$var = preg_replace('~\\[url=(https?://.+?)\\](.+?)\\[/url\\]|(https?://(www.)?[0-9a-z\.-]+\.[0-9a-z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', '<font color="#ff3300"><b>Sensor Bro</b></font>', $var);
$replace = array(
'.tk' => '***',
'.us' => '***',
'.ru' => '***',
'.com' => '***',
'.biz' => '***',
'.cn' => '***',
'.in' => '***',
'.net' => '***',
'.org' => '***',
'.info' => '***',
'.mobi' => '***',
'.wen' => '***',
'.kmx' => '***',
'.h2m' => '***'
);
return strtr($var, $replace);
}

/*
-----------------------------------------------------------------
РџСЂРѕРІРµСЂРєР° РїРµСЂРµРјРµРЅРЅС‹С…
-----------------------------------------------------------------
*/
public static function check($str)
{
$str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
$str = nl2br($str);
$str = strtr($str, array(
chr(0) => '',
chr(1) => '',
chr(2) => '',
chr(3) => '',
chr(4) => '',
chr(5) => '',
chr(6) => '',
chr(7) => '',
chr(8) => '',
chr(9) => '',
chr(10) => '',
chr(11) => '',
chr(12) => '',
chr(13) => '',
chr(14) => '',
chr(15) => '',
chr(16) => '',
chr(17) => '',
chr(18) => '',
chr(19) => '',
chr(20) => '',
chr(21) => '',
chr(22) => '',
chr(23) => '',
chr(24) => '',
chr(25) => '',
chr(26) => '',
chr(27) => '',
chr(28) => '',
chr(29) => '',
chr(30) => '',
chr(31) => ''
));
$str = str_replace("'", "&#39;", $str);
$str = str_replace('\\', "&#92;", $str);
$str = str_replace("|", "I", $str);
$str = str_replace("||", "I", $str);
$str = str_replace("/\\\$/", "&#36;", $str);
$str = mysql_real_escape_string($str);
return $str;
}

/*
-----------------------------------------------------------------
РћР±СЂР°Р±РѕС‚РєР° С‚РµРєСЃС‚РѕРІ РїРµСЂРµРґ РІС‹РІРѕРґРѕРј РЅР° СЌРєСЂР°РЅ
-----------------------------------------------------------------
$br=1           РѕР±СЂР°Р±РѕС‚РєР° РїРµСЂРµРЅРѕСЃРѕРІ СЃС‚СЂРѕРє
$br=2           РїРѕРґСЃС‚Р°РЅРѕРІРєР° РїСЂРѕР±РµР»Р°, РІРјРµСЃС‚Рѕ РїРµСЂРµРЅРѕСЃР°
$tags=1         РѕР±СЂР°Р±РѕС‚РєР° С‚СЌРіРѕРІ
$tags=2         РІС‹СЂРµР·Р°РЅРёРµ С‚СЌРіРѕРІ
-----------------------------------------------------------------
*/
public static function checkout($str, $br = 0, $tags = 0)
{
$str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
if ($br == 1)
$str = nl2br($str);
elseif ($br == 2)
$str = str_replace("\r\n", ' ', $str);
if ($tags == 1)
$str = bbcode::tags($str);
elseif ($tags == 2)
$str = bbcode::notags($str);
$replace = array(
chr(0) => '',
chr(1) => '',
chr(2) => '',
chr(3) => '',
chr(4) => '',
chr(5) => '',
chr(6) => '',
chr(7) => '',
chr(8) => '',
chr(9) => '',
chr(11) => '',
chr(12) => '',
chr(13) => '',
chr(14) => '',
chr(15) => '',
chr(16) => '',
chr(17) => '',
chr(18) => '',
chr(19) => '',
chr(20) => '',
chr(21) => '',
chr(22) => '',
chr(23) => '',
chr(24) => '',
chr(25) => '',
chr(26) => '',
chr(27) => '',
chr(28) => '',
chr(29) => '',
chr(30) => '',
chr(31) => ''
);
return strtr($str, $replace);
}

/*
-----------------------------------------------------------------
РџРѕРєР°Р· СЂР°Р·Р»РёС‡РЅС‹С… СЃС‡РµС‚С‡РёРєРѕРІ РІРЅРёР·Сѓ СЃС‚СЂР°РЅРёС†С‹
-----------------------------------------------------------------
*/
public static function display_counters()
{
global $headmod;
$req = mysql_query("SELECT * FROM `cms_counters` WHERE `switch` = '1' ORDER BY `sort` ASC");
if (mysql_num_rows($req) > 0) {
while (($res = mysql_fetch_array($req)) !== false) {
$link1 = ($res['mode'] == 1 || $res['mode'] == 2) ? $res['link1'] : $res['link2'];
$link2 = $res['mode'] == 2 ? $res['link1'] : $res['link2'];
$count = ($headmod == 'mainpage') ? $link1 : $link2;
if (!empty($count))
echo $count;
}
}
}

/*
-----------------------------------------------------------------
РџРѕРєР°Р·С‹РІР°РµРј РґР°С‚Сѓ СЃ СѓС‡РµС‚РѕРј СЃРґРІРёРіР° РІСЂРµРјРµРЅРё
-----------------------------------------------------------------
*/
public static function display_date($var)
{
$shift = (self::$system_set['timeshift'] + self::$user_set['timeshift']) * 3600;
if (date('Y', $var) == date('Y', time())) {
if (date('z', $var + $shift) == date('z', time() + $shift))
return self::$lng['today'] . ', ' . date("H:i", $var + $shift);
if (date('z', $var + $shift) == date('z', time() + $shift) - 1)
return self::$lng['yesterday'] . ', ' . date("H:i", $var + $shift);
}
return date("d.m.Y / H:i", $var + $shift);
}

/*
-----------------------------------------------------------------
РЎРѕРѕР±С‰РµРЅРёСЏ РѕР± РѕС€РёР±РєР°С…
-----------------------------------------------------------------
*/
public static function display_error($error = NULL, $link = NULL)
{
if (!empty($error)) {
return '<div class="rmenu"><p><b>' . self::$lng['error'] . '!</b><br />' .
(is_array($error) ? implode('<br />', $error) : $error) . '</p>' .
(!empty($link) ? '<p>' . $link . '</p>' : '') . '</div>';
} else {
return false;
}
}

/*
-----------------------------------------------------------------
РћС‚РѕР±СЂР°Р¶РµРЅРёРµ СЂР°Р·Р»РёС‡РЅС‹С… РјРµРЅСЋ
-----------------------------------------------------------------
$delimiter - СЂР°Р·РґРµР»РёС‚РµР»СЊ РјРµР¶РґСѓ РїСѓРЅРєС‚Р°РјРё
$end_space - РІС‹РІРѕРґРёС‚СЃСЏ РІ РєРѕРЅС†Рµ
-----------------------------------------------------------------
*/
public static function display_menu($val = array(), $delimiter = ' | ', $end_space = '')
{
return implode($delimiter, array_diff($val, array(''))) . $end_space;
}

/*
-----------------------------------------------------------------
РџРѕСЃС‚СЂР°РЅРёС‡РЅР°СЏ РЅР°РІРёРіР°С†РёСЏ
Р—Р° РѕСЃРЅРѕРІСѓ РІР·СЏС‚Р° Р°РЅР°Р»РѕРіРёС‡РЅР°СЏ С„СѓРЅРєС†РёСЏ РѕС‚ С„РѕСЂСѓРјР° SMF2.0
-----------------------------------------------------------------
*/
public static function display_pagination($base_url, $start, $max_value, $num_per_page)
{
$neighbors = 2;
if ($start >= $max_value)
$start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
else
$start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
$base_link = '<a class="pagenav" href="' . strtr($base_url, array('%' => '%%')) . 'page=%d' . '">%s</a>';
$out[] = $start == 0 ? '' : sprintf($base_link, $start / $num_per_page, 'Prev');
if ($start > $num_per_page * $neighbors)
$out[] = sprintf($base_link, 1, '1');
if ($start > $num_per_page * ($neighbors + 1))
$out[] = '<span style="font-weight: bold;">...</span>';
for ($nCont = $neighbors; $nCont >= 1; $nCont--)
if ($start >= $num_per_page * $nCont) {
$tmpStart = $start - $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
$out[] = '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span>';
$tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;
for ($nCont = 1; $nCont <= $neighbors; $nCont++)
if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
$tmpStart = $start + $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
if ($start + $num_per_page * ($neighbors + 1) < $tmpMaxPages)
$out[] = '<span style="font-weight: bold;">...</span>';
if ($start + $num_per_page * $neighbors < $tmpMaxPages)
$out[] = sprintf($base_link, $tmpMaxPages / $num_per_page + 1, $tmpMaxPages / $num_per_page + 1);
if ($start + $num_per_page < $max_value) {
$display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start / $num_per_page + 2);
$out[] = sprintf($base_link, $display_page, 'Next');
}
return implode(' ', $out);
}

/*
-----------------------------------------------------------------
РџРѕРєР°Р·С‹РІР°РµРј РјРµСЃС‚РѕРїРѕР»РѕР¶РµРЅРёРµ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
-----------------------------------------------------------------
*/
public static function display_place($user_id = '', $place = '')
{
global $headmod;
$place = explode(",", $place);
$placelist = parent::load_lng('places');
if (array_key_exists($place[0], $placelist)) {
if ($place[0] == 'profile') {
if ($place[1] == $user_id) {
return '<a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $place[1] . '">' . $placelist['profile_personal'] . '</a>';
} else {
$user = self::get_user($place[1]);
return $placelist['profile'] . ': <a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $user['id'] . '">' . $user['name'] . '</a>';
}
}
elseif ($place[0] == 'online' && isset($headmod) && $headmod == 'online') return $placelist['here'];
else return str_replace('#home#', self::$system_set['homeurl'], $placelist[$place[0]]);
}
else return '<a href="' . self::$system_set['homeurl'] . '/index.php">' . $placelist['homepage'] . '</a>';
}

/*
-----------------------------------------------------------------
РћС‚РѕР±СЂР°Р¶РµРЅРёСЏ Р»РёС‡РЅС‹С… РґР°РЅРЅС‹С… РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
-----------------------------------------------------------------
$user          (array)     РјР°СЃСЃРёРІ Р·Р°РїСЂРѕСЃР° РІ С‚Р°Р±Р»РёС†Сѓ `users`
$arg           (array)     РњР°СЃСЃРёРІ РїР°СЂР°РјРµС‚СЂРѕРІ РѕС‚РѕР±СЂР°Р¶РµРЅРёСЏ
[lastvisit] (boolean)   Р”Р°С‚Р° Рё РІСЂРµРјСЏ РїРѕСЃР»РµРґРЅРµРіРѕ РІРёР·РёС‚Р°
[stshide]   (boolean)   РЎРєСЂС‹С‚СЊ СЃС‚Р°С‚СѓСЃ (РµСЃР»Рё РµСЃС‚СЊ)
[iphide]    (boolean)   РЎРєСЂС‹С‚СЊ (РЅРµ РїРѕРєР°Р·С‹РІР°С‚СЊ) IP Рё UserAgent
[iphist]    (boolean)   РџРѕРєР°Р·С‹РІР°С‚СЊ СЃСЃС‹Р»РєСѓ РЅР° РёСЃС‚РѕСЂРёСЋ IP

[header]    (string)    РўРµРєСЃС‚ РІ СЃС‚СЂРѕРєРµ РїРѕСЃР»Рµ РќРёРєР° РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
[body]      (string)    РћСЃРЅРѕРІРЅРѕР№ С‚РµРєСЃС‚, РїРѕРґ РЅРёРєРѕРј РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
[sub]       (string)    РЎС‚СЂРѕРєР° РІС‹РІРѕРґРёС‚СЃСЏ РІРІРµСЂС…Сѓ РѕР±Р»Р°СЃС‚Рё "sub"
[footer]    (string)    РЎС‚СЂРѕРєР° РІС‹РІРѕРґРёС‚СЃСЏ РІРЅРёР·Сѓ РѕР±Р»Р°СЃС‚Рё "sub"
--------------------------------------------------------------
*/
public static function display_user($user = false, $arg = false)
{
global $rootpath, $mod;
$out = false;

if (!$user['id']) {
$out = '<b>' . self::$lng['guest'] . '</b>';
if (!empty($user['name']))
$out .= ': ' . $user['name'];
if (!empty($arg['header']))
$out .= ' ' . $arg['header'];
} else {
if (self::$user_set['avatar']) {
$out .= '<table cellpadding="0" cellspacing="0"><tr><td>';
if (file_exists(($rootpath . 'files/users/avatar/' . $user['id'] . '.png')))
$out .= '<span class="avatar"><img src="' . self::$system_set['homeurl'] . '/files/users/avatar/' . $user['id'] . '.png" width="32" height="32" alt="" /></span>&#160;';
else
$out .= '<span class="avatar"><img src="' . self::$system_set['homeurl'] . '/images/empty.png" width="32" height="32" alt="" /></span>&#160;';
$out .= '</td><td>';
}
if ($user['sex'])
$out .= '<img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/' . ($user['sex'] == 'm' ? 'm' : 'w') . ($user['datereg'] > time() - 86400 ? '_new' : '')
. '.png" width="16" height="16" align="middle" alt="' . ($user['sex'] == 'm' ? 'Рњ' : 'Р–') . '" />&#160;';
else
$out .= '<img src="' . self::$system_set['homeurl'] . '/images/del.png" width="12" height="12" align="middle" />&#160;';
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$user['id']. "' LIMIT 1;"), 0);
$out .= !self::$user_id || self::$user_id == $user['id'] ? '<b>' . $user['name'] . '</b>' : '<a href="' . $set['homeurl'] . '/' .$name_lat.  '"><b>' . $user['name'] . '</b></a>';
$rank = array(
0 => '',
1 => '(GMod)',
2 => '(CMod)',
3 => '(FMod)',
4 => '(DMod)',
5 => '(LMod)',
6 => '(Smd)',
7 => '(Adm)',
9 => '(SV!)'
);
$out .= '' . $rank[$user['rights']];
$out .= (time() > $user['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');

      
if (!empty($arg['header']))
$out .= ' ' . $arg['header'];
if (!isset($arg['stshide']) && !empty($user['status']))
$out .= '<div class="status"><img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/label.png" alt="" align="middle" />&#160;' . $user['status'] . '</div>';
if (self::$user_set['avatar'])
$out .= '</td></tr></table>';
}
if (isset($arg['body']))
$out .= '<div>' . $arg['body'] . '</div>';
$ipinf = !isset($arg['iphide']) && (self::$user_rights || ($user['id'] && $user['id'] == self::$user_id)) ? 1 : 0;
$lastvisit = time() > $user['lastdate'] + 300 && isset($arg['lastvisit']) ? self::display_date($user['lastdate']) : false;
if ($ipinf || $lastvisit || isset($arg['sub']) && !empty($arg['sub']) || isset($arg['footer'])) {
$out .= '<div class="sub">';
if (isset($arg['sub']))
$out .= '<div>' . $arg['sub'] . '</div>';
if ($lastvisit)
$out .= '<div><span class="gray">' . self::$lng['last_visit'] . ':</span> ' . $lastvisit . '</div>';
$iphist = '';
if ($ipinf) {
$out .= '<div><span class="gray">' . self::$lng['browser'] . ':</span> ' . $user['browser'] . '</div>' .
'<div><span class="gray">' . self::$lng['ip_address'] . ':</span> ';
$hist = $mod == 'history' ? '&amp;mod=history' : '';
$ip = long2ip($user['ip']);
if (self::$user_rights && isset($user['ip_via_proxy']) && $user['ip_via_proxy']) {
$out .= '<b class="red"><a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a></b> / ';
$out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($user['ip_via_proxy']) . $hist . '">' . long2ip($user['ip_via_proxy']) . '</a>';
} elseif (self::$user_rights) {
$out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a>';
} else {
$out .= $ip . $iphist;
}
if (isset($arg['iphist'])) {
$iptotal = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_users_iphistory` WHERE `user_id` = '" . $user['id'] . "'"), 0);
$out .= '<div><span class="gray">' . self::$lng['ip_history'] . ':</span> <a href="' . self::$system_set['homeurl'] . '/users/profile.php?act=ip&amp;user=' . $user['id'] . '">[' . $iptotal . ']</a></div>';
}
$out .= '</div>';
}
if (isset($arg['footer']))
$out .= $arg['footer'];
$out .= '</div>';
}
return $out;
}

/*
-----------------------------------------------------------------
Р¤РѕСЂРјР°С‚РёСЂРѕРІР°РЅРёРµ РёРјРµРЅРё С„Р°Р№Р»Р°
-----------------------------------------------------------------
*/
public static function format($name)
{
$f1 = strrpos($name, ".");
$f2 = substr($name, $f1 + 1, 999);
$fname = strtolower($f2);
return $fname;
}

/*
-----------------------------------------------------------------
РџРѕР»СѓС‡Р°РµРј РґР°РЅРЅС‹Рµ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
-----------------------------------------------------------------
*/
public static function get_user($id = false)
{
if ($id && $id != self::$user_id) {
$req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id'");
if (mysql_num_rows($req)) {
return mysql_fetch_assoc($req);
} else {
return false;
}
} else {
return self::$user_data;
}
}

/*
-----------------------------------------------------------------
РўСЂР°РЅСЃР»РёС‚РµСЂР°С†РёСЏ СЃ Р СѓСЃСЃРєРѕРіРѕ РІ Р»Р°С‚РёРЅРёС†Сѓ
-----------------------------------------------------------------
*/
public static function rus_lat($str)
{
$replace = array(
'Р°' => 'a',
'Р±' => 'b',
'РІ' => 'v',
'Рі' => 'g',
'Рґ' => 'd',
'Рµ' => 'e',
'С‘' => 'e',
'Р¶' => 'j',
'Р·' => 'z',
'Рё' => 'i',
'Р№' => 'i',
'Рє' => 'k',
'Р»' => 'l',
'Рј' => 'm',
'РЅ' => 'n',
'Рѕ' => 'o',
'Рї' => 'p',
'СЂ' => 'r',
'СЃ' => 's',
'С‚' => 't',
'Сѓ' => 'u',
'С„' => 'f',
'С…' => 'h',
'С†' => 'c',
'С‡' => 'ch',
'С€' => 'sh',
'С‰' => 'sch',
'СЉ' => "",
'С‹' => 'y',
'СЊ' => "",
'СЌ' => 'ye',
'СЋ' => 'yu',
'СЏ' => 'ya'
);
return strtr($str, $replace);
}

/*
-----------------------------------------------------------------
РћР±СЂР°Р±РѕС‚РєР° СЃРјР°Р№Р»РѕРІ
-----------------------------------------------------------------
*/
public static function smileys($str, $adm = false)
{
global $rootpath;
static $smileys_cache = array();
if (empty($smileys_cache)) {
$file = $rootpath . 'files/cache/smileys.dat';
if (file_exists($file) && ($smileys = file_get_contents($file)) !== false) {
$smileys_cache = unserialize($smileys);
return strtr($str, ($adm ? array_merge($smileys_cache['usr'], $smileys_cache['adm']) : $smileys_cache['usr']));
} else {
return $str;
}
} else {
return strtr($str, ($adm ? array_merge($smileys_cache['usr'], $smileys_cache['adm']) : $smileys_cache['usr']));
}
}

/*
-----------------------------------------------------------------
Р¤СѓРЅРєС†РёСЏ РїРµСЂРµСЃС‡РµС‚Р° РЅР° РґРЅРё, РёР»Рё С‡Р°СЃС‹
-----------------------------------------------------------------
*/
public static function timecount($var)
{
global $lng;
if ($var < 0) $var = 0;
$day = ceil($var / 86400);
if ($var > 345600) return $day . ' ' . $lng['timecount_days'];
if ($var >= 172800) return $day . ' ' . $lng['timecount_days_r'];
if ($var >= 86400) return '1 ' . $lng['timecount_day'];
return date("G:i:s", mktime(0, 0, $var));
}

/*
-----------------------------------------------------------------
РўСЂР°РЅСЃР»РёС‚РµСЂР°С†РёСЏ С‚РµРєСЃС‚Р°
-----------------------------------------------------------------
*/
public static function trans($str)
{
$replace = array(
'a' => 'Р°',
'b' => 'Р±',
'v' => 'РІ',
'g' => 'Рі',
'd' => 'Рґ',
'e' => 'Рµ',
'yo' => 'С‘',
'zh' => 'Р¶',
'z' => 'Р·',
'i' => 'Рё',
'j' => 'Р№',
'k' => 'Рє',
'l' => 'Р»',
'm' => 'Рј',
'n' => 'РЅ',
'o' => 'Рѕ',
'p' => 'Рї',
'r' => 'СЂ',
's' => 'СЃ',
't' => 'С‚',
'u' => 'Сѓ',
'f' => 'С„',
'h' => 'С…',
'c' => 'С†',
'ch' => 'С‡',
'w' => 'С€',
'sh' => 'С‰',
'q' => 'СЉ',
'y' => 'С‹',
'x' => 'СЌ',
'yu' => 'СЋ',
'ya' => 'СЏ',
'A' => 'Рђ',
'B' => 'Р‘',
'V' => 'Р’',
'G' => 'Р“',
'D' => 'Р”',
'E' => 'Р•',
'YO' => 'РЃ',
'ZH' => 'Р–',
'Z' => 'Р—',
'I' => 'Р�',
'J' => 'Р™',
'K' => 'Рљ',
'L' => 'Р›',
'M' => 'Рњ',
'N' => 'Рќ',
'O' => 'Рћ',
'P' => 'Рџ',
'R' => 'Р ',
'S' => 'РЎ',
'T' => 'Рў',
'U' => 'РЈ',
'F' => 'Р¤',
'H' => 'РҐ',
'C' => 'Р¦',
'CH' => 'Р§',
'W' => 'РЁ',
'SH' => 'Р©',
'Q' => 'РЄ',
'Y' => 'Р«',
'X' => 'Р­',
'YU' => 'Р®',
'YA' => 'РЇ'
);
return strtr($str, $replace);
}
}
