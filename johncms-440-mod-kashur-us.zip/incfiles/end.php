<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2]))
echo '<div class="gmenu">' . $cms_ads[2] . '</div>';

/*
* Ads
echo '<div class="mainblok"><div class="menu"><div style="text-align:center">';
if ($headmod == 'mainpage') {
include'adiquity.php';
include'mobgold.php';
} else {
include_once ('mobgold.php');
include_once ('adiquity.php');
}
echo '</div></div></div>';
*/

// Счетчик посетителей онлайн
if ($headmod == 'mainpage') {
if ($user_id){
echo '<div class="orangex">' . $lng['member'] . ': <a href="../users/index.php"> ' . counters::users() . ' </a><br/>';
include_once('member.php');
}else{
echo '<div class="orangex">' . counters::online() . '</div>';
}
}
echo '</div>';
echo '</div><div class="footer" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
echo '' . $set['copyright'] . '';
echo '</td><td width="auto" align="right">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</a></td></tr></table></div>';
////////////////////////////////////////////////////////////// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
if (!empty($cms_ads[3]))
echo '<div style="text-align:center">' . $cms_ads[3];

/*
-----------------------------------------------------------------
ВНИМАНИЕ!!!
ATTENTION!!!
The copyright could not be removed within 60 days of installation scripts
-----------------------------------------------------------------
*/

echo '<div style="text-align:center">';
echo '<div><small> &copy; '.strtoupper($_SERVER['HTTP_HOST']).' 2012<br />Powered By <a href="http://johncms.com">JohnCMS</a></small></div>';

echo '</div></body></html>';
