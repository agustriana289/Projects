<?
if ($user_id && $user_id != $res['user_id'] && (mysql_result($checkthank, 0) < 1)) {
echo'<a href="index.php?id=' . $id . '&amp;thanks=' . $res['id'] . '&amp;user=' . $res['user_id'] . '&amp;start=' . $start . '&amp;thank#thanksyou"><img src="prus_mod/thanks.gif" alt="like"/>';
echo '</a>';
}
?>