<?php

define('_IN_JOHNCMS', 1);
$headmod = 'journal';
require ('../incfiles/core.php');
$lng_forum = core::load_lng('forum');
$textl = 'Forum Notification';
require ('../incfiles/head.php');

if (!$user_id) {
echo '<div class="rmenu"><p>Access only for user, please login first</p></div>';
require ('../incfiles/end.php');
exit;
}
echo '<div class="mainblok"><div class="phdr"><b>Forum Notification</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `id_user`='$user_id'" . ($rights >= 7 ? "" : " AND `close` != '1'")), 0);
if ($total > $kmess)
echo '<div class="topmenu">' . functions::display_pagination('journal.php?', $start, $total, $kmess) . '</div>';
echo '</div>';
if($datauser['journal_forum']) {
echo '<div class="topmenu">Post Quoted: ' . $datauser['journal_forum'] . '</div>';
mysql_query("UPDATE `users` SET `journal_forum`='0' WHERE `id` = '$user_id'");
}

if ($total) {
$req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
WHERE `forum`.`type` = 'm' AND `forum`.`id_user`='$user_id'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . " ORDER BY `forum`.`id` DESC LIMIT $start, $kmess");
while (($res = mysql_fetch_assoc($req)) !== false) {
if ($res['close'])
echo '<div class="rmenu">';
else
echo $i % 2 ? '<div class="mainblok">' : '<div class="mainblok">';
$theme = mysql_fetch_assoc(mysql_query("SELECT `text` FROM `forum` WHERE `id` = '" . $res['refid'] . "' ORDER BY `id` ASC LIMIT 1"));
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$res['user_id']. "' LIMIT 1;"), 0);
echo '<div class="phdr"><table width="100%" cellpadding="0" cellspacing="0"><tr>' .
'<td width="auto"><b><a href="'.$set['homeurl'].'/users/profile.php?user='.$res['user_id'].'">' . $res['from'] . '</a>:</b> <a href="../forum/index.php?id=' . $res['refid'] . '">' . $theme['text'] . '</a></td>' .
'<td width="auto" align="right"><a href="../forum/index.php?act=post&amp;id=' . $res['id'] . '">View</a></td></tr></table></div>';
echo '<div class="textshout">';
$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = nl2br($text);
$text = bbcode::tags($text);
if ($set_user['smileys'])
$text = functions::smileys($text, ($res['rights'] >= 1) ? 1 : 0);
echo $text;
$file_req = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] . "'");
if (mysql_num_rows($file_req) > 0) {
$file_res = mysql_fetch_assoc($file_req);
$file_ile_size = round(@filesize('../files/forum/attach/' . $file_res['filename']) / 1024, 2);
echo '<br /><span class="gray">' . $lng_forum['attached_file'] . ':';
$att_ext = strtolower(functions::format('./files/forum/attach/' . $file_res['filename']));
$pic_ext = array('gif', 'jpg', 'jpeg', 'png');
if (in_array($att_ext, $pic_ext))
echo '<div><a href="../forum/index.php?act=file&amp;id=' . $file_res['id'] . '"><img src="../forum/thumbinal.php?file=' .
(urlencode($file_res['filename'])) . '" alt="' . $lng_forum['click_to_view'] . '" /></a></div>';
else
echo '<br /><a href="../forum/index.php?act=file&amp;id=' . $file_res['id'] . '">' . $file_res['filename'] . '</a>';
echo ' (' . $file_ile_size . ' Kb.)<br/>' . $lng_forum['downloads'] . ': ' . $file_res['dlcount'] . ' ' . $lng_forum['time'] . '</span>';
}
echo '</div><div class="forumb" align="right">' .
'<a href="../forum/index.php?act=say&amp;id=' . $res['id'] . '"><img src="../images/reply.png" alt="reply" /></a>&#160;' .
'<a href="../forum/index.php?act=say&amp;id=' . $res['id'] . '&amp;cyt"><img src="../images/fquote.png" alt="quote" /></a></div>';
echo '</div>';
++$i;
}
} else
echo '<div class="menu"><p>Empty!</p></div>';
echo '<div class="mainblok"><div class="phdr">Total: ' . $total . '</div>';
if ($total > $kmess)
echo '<div class="topmenu">' . functions::display_pagination('journal.php?', $start, $total, $kmess) . '</div>';
echo '</div>';
if ($total > $kmess) {
echo '<p><form action="journal.php?" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
'</form></p>';
}

echo '<p><a href="profile.php?act=office">Back</a></p>';

require_once ('../incfiles/end.php');
?>