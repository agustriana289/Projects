<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/
switch($act) 
{ 
default: 

echo '<div class="mainblok"><div class="phdr"><b>Main Menu</b></div>'; 
echo $mp->news;
echo '<div class="topmenu"><b>' . $lng['useful'] . '</b> | <a href="/index.php?act=comm">' . $lng['community'] . '</a></div>';
// Ссылка на загрузки
if ($set['mod_down'] || $rights >= 7)
    echo '<div class="menu"><table><tr><td class="avatar" width="40px"><img src="' .$homepage . '/images/waptok.png" width="40" height="40"/></td></div><td>&bull; <a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</br>';
// Ссылка на библиотеку
if ($set['mod_gal'] || $rights >= 7)
    echo '&bull; <a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</br>';

/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/
// Ссылка на гостевую
if ($set['mod_guest'] || $rights >= 7)
    echo '&bull; <a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</br>';

// Ссылка на библиотеку
if ($set['mod_lib'] || $rights >= 7)
    echo '&bull; <a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')';
    echo '</td></tr></table></div></div>';

/*
-----------------------------------------------------------------
Блок полезного
-----------------------------------------------------------------
*/    
break;
case 'comm':
echo '<div class="mainblok"><div class="phdr"><b>Main Menu</b></div>';
echo '<div class="topmenu"><a href="/index.php">' . $lng['useful'] . '</a> | <b>' . $lng['community'] . '</b></div>';

echo '<div class="menu"><table><tr><td class="avatar" width="40px"><img src="images/waptok.png" width="40" height="40"/></td></div><td>&bull; <a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</br>' .
    '&bull; <a href="pages/faq.php">' . $lng['information'] . ', FAQ</a></br>';
if ($user_id || $set['active']) {
echo '&bull; <a href="users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')</br>' .
        '&bull; <a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</br>';
}
echo '</td></tr></table></div></div>';
}

include 'forum_category.php';
include 'recent_post.php';
?>
