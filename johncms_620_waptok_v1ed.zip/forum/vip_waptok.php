<?php
/**
 * Simple VIP Forum JohnCMS v440
 * Mod : Nickzers
 * Repack http://www.waptok.asia
 */

if ($rights == 7 || $rights >= 9) {
echo '<div class="mainblok"><div class="phdr">Post Required</div><div class="menu"><form method="post">
<input type="text" value="'.$type1['min_post'].'" name="totalpost"/><br/>
<input type="submit" name="minpost" value="Oke"/>
</div></div>';
}
    $req = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `id` = '".($type1['id'])."' AND `type` = 't'");
if(isset($_POST['minpost'])){
    if (mysql_result($req, 0) > 0) {
        mysql_query("UPDATE `forum` SET  `min_post` = '" . ($_POST['totalpost']) . "' WHERE `id` = '".($type1['id'])."'");
        header('Location: index.php?id='.($type1['id']).'');
    } else {
        require('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require('../incfiles/end.php');
        exit;
    }
}
if(!$user_id){
$post_gue=1;
}else{
$post_gue=$datauser['postforum'];
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $post_gue < $type1['min_post']){
echo '<div class="omenu"><img src="../images/lock.png"> Min '.$type1['min_post'].' Total Post to Unlocked this Topic</div>';
require_once("../incfiles/end.php");
exit;
}
?>