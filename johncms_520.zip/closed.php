<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>JohnCMS.com ! работы на сайте</title>
  <!-- <title>JohnCMS.com ! under construction</title>  -->
</head>
<body>
<?php
echo '<center><img src="images/logo.gif" alt="JohnCMS" /><br />
<span style="color:red"><b>Внимание!</b></span><br />
<img src="images/red.gif" width="16" height="16" alt="" /> На сайте ведутся технические работы.<br />Попробуйте зайти позднее</center><br /></center> ';
?>
<?php
/*
// English version

echo '<center><img src="images/logo.gif" alt="JohnCMS" /><br />
<span style="color:red"><b>Attention!</b></span><br />
<img src="images/red.gif" width="16" height="16" alt="" /> Site under construction.<br />Please, try again later</center><br /></center> ';
*/
?>
</body>
</html>