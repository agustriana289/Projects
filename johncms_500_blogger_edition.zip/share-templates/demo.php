<?php

define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
if ($rights == 7 || $rights == 9) {
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND (`type`='file' OR `type`='xfile')");
} else { $treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");
}
$textl = "Share Templates";
if(mysql_num_rows($treq) == 0) {
header("Location: index.php");
exit;
}
$bprev = mysql_fetch_array(mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '".mysql_real_escape_string($set['blogpreview'])."'"));
if (!$bprev) {
die("Blog untuk preview template tidak ada.");
exit;
}
$blogpreview = "u".$bprev['user_id']."-b".$bprev['id'];
$tres = mysql_fetch_array($treq);
$template = $tres['user_id']."-".$tres['theme']."-".$tres['template'];
if(is_file("../files/templates/".$blogpreview."-".$tres['theme'].".xml"))
unlink("../files/templates/".$blogpreview."-".$tres['theme'].".xml");
if (copy("../files/share-templates/files/".$template.".xml","../files/templates/".$blogpreview."-".$tres['theme'].".xml")) {
header("Location: ".functions::blog_link($bprev['url1'])."/".$tres['theme'].".iwb");
exit;
}
else {
require('../incfiles/head.php');

echo '<div class="phdr">Share Templates</div>';
echo '<div class="rmenu">Kesalahan. Cobalah beberapa saat lagi.</div>';
require("../incfiles/end.php");
}
?>