<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
if ($rights == 7 || $rights == 9) {
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND (`type`='file' OR `type`='xfile')");
} else { $treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");
}
if (mysql_num_rows($treq) == 0) {
$headmod = "sharetemplates";
$textl = "Share Templates | Detil"; 
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Share Templates</b></a> | Detil</div>'.functions::display_error("Template tidak ditemukan");
require('../incfiles/end.php');
exit;
}
$tres = mysql_fetch_array($treq);
$headmod = "BYURL";
$headmodurl = $set['homeurl']."/share-templates/detail.php?id=".$tres['id'];
$textl = "Share Templates | ".htmlspecialchars($tres['name']);
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Share Templates</b></a> | '.htmlspecialchars($tres['name']).'</div>';
$template = $tres['user_id']."-".$tres['theme']."-".$tres['template'];
echo '<div class="list1">';
$size = round($tres['size'] / 1024, 2);
if (file_exists("../files/share-templates/screenshot/".$template.".jpeg"))
echo '<a href="../files/share-templates/screenshot/'.$template.'.jpeg"><img src="../files/share-templates/screenshot/'.$template.'.jpeg" width="120" height="180" alt=""/></a><br />';
else
echo '<img src="../files/share-templates/screenshot/no-preview.jpg" width="120" height="180" alt=""/></a><div class="sub">';
echo '<div><img src="../users/avatar.php?user='.$tres['user_id'].'" alt=""/> <a href="../users/profile.php?user='.$tres['user_id'].'">';
$q = mysql_query("SELECT `name` FROM `users` WHERE `id`='".mysql_real_escape_string($tres['user_id'])."'");
if (mysql_num_rows($q)) { $p = mysql_fetch_assoc($q); echo $p['name'];
} else { echo '?'; }
echo '</a>';
$totemp = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE `user_id`='".mysql_real_escape_string($tres['user_id'])."' AND `type`='file'"),0);
$total_comment = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='comment'"),0);
$total_set = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='set'"),0);
echo ' (<a href="index.php?author='.$tres['user_id'].'">'.$totemp.'</a>)';
echo '</div><div>Nama: '.htmlspecialchars($tres['name']).'<br />Template: '.ucfirst($tres['theme']).'<br />Ukuran: '.$size.' kb<br />Diupload: '.functions::display_date($tres['time']).'<br />Keterangan: '.functions::smileys(functions::checkout($tres['text'],1,1)).'</div>';
echo '<br />';
$_SESSION['auth'] = md5(rand(111111,999999));
$del = false;
if ($user_id) { 
if ($tres['type'] == "xfile" AND $rights >= 7)
echo '<a href="modul.php?act=accept&amp;id='.$tres['id'].'&amp;sess='.$_SESSION['auth'].'">Setujui</a> | ';
if (($tres['user_id'] == $user_id) OR $rights == 7 OR $rights == 9) {
$del = true;
echo '<a href="delete.php?id='.$tres['id'].'&amp;sess='.$_SESSION['auth'].'" onclick="return confirm(\'Kamu yakin akan menghapus ini?\')">Hapus</a> | ';
}
}
echo '<a href="demo.php?id='.$tres['id'].'">Demo</a> | <a>Download</a> (<a href="download.php?id='.$tres['id'].'">XML</a>/<a href="download.php?id='.$tres['id'].'&amp;archive=zip">ZIP</a>)';
if ($user_id) echo ' | <a href="set.php?id='.$tres['id'].'&amp;sess='.$_SESSION['auth'].'">Pasang</a>';
echo '</div>';
echo '</div>';
if($user_id) {
switch($act) {
case 'set':
$total = $total_set;
echo '<div class="phdr"><b><a href="detail.php?act=comment&amp;id='.$tres['id'].'">Komentar ('.$total_comment.')</a></b> | Digunakan ('.$total.')</div>';
echo '<div class="rmenu">Berikut adalah blog yang pernah menggunakan template ini.</div>';
if ($total == 0) {
echo '<div class="rmenu">Belum ada yang menggunakan template ini</div>';
}
else {
$qu = mysql_query("SELECT * FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='set' ORDER BY `time` DESC LIMIT $start,$kmess;");
while ($co = mysql_fetch_array($qu)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($co['name'])."'"));
echo '<img src="../images/blogs.png" alt=""/> ';
if ($blog)
echo '<a href="'.$blog['url1'].'">'.htmlspecialchars($blog['title']).'</a><br />('.functions::display_date($co['time']).')</div>';
else
echo htmlspecialchars($co['text']).'<br />('.functions::display_date($co['time']).')</div>';
$i++;
}
if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination("detail.php?act=set&amp;id=".$tres['id']."&amp;", $start, $total, $kmess) . '</div>';
}
break;
case 'comment':
default:
$total = $total_comment;
echo '<div class="phdr">Komentar ('.$total.') | <b><a href="detail.php?act=set&amp;id='.$tres['id'].'">Digunakan ('.$total_set.')</a></b></div>';
echo '<div class="gmenu"><form name="form" action="modul.php?act= add_comment&amp;id='.$tres['id'].'" method="post"><textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><input type="hidden" name="sess" value="'.$_SESSION['auth'].'"/><br/><input type="submit" name="submit" value="' . $lng['sent'] . '"/></form></p></div>';
if ($total == 0) {
echo '<div class="rmenu">Belum ada komentar</div>';
}
else {
$qu = mysql_query("SELECT * FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='comment' ORDER BY `time` DESC LIMIT $start,$kmess;");
while ($co = mysql_fetch_array($qu)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<img src="../users/avatar.php?user='.$co['user_id'].'" alt=""/> <a href="../users/profile.php?user='.$co['id'].'">'.htmlspecialchars($co['name']).'</a> ('.functions::display_date($co['time']).')<br />'.functions::smileys(functions::checkout($co['text'],1,1));
if ($del == true)
echo '<div class="sub"><a href="modul.php?act=delete_comment&amp;id='.$tres['id'].'&amp;cid='.$co['id'].'&amp;sess='.$_SESSION['auth'].'" onclick="return confirm(\'Kamu yakin akan menghapus ini?\')">Hapus</a></div>';
echo '</div>';
$i++;
}
if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination("detail.php?act=comment&amp;id=".$tres['id']."&amp;", $start, $total, $kmess) . '</div>';
}
break;
}
}
require('../incfiles/end.php');
?>
