<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */


define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");
if (!$user_id) {
header("location: index.php");
exit;
}

if (mysql_num_rows($treq) == 0) {
header("Location: index.php");
exit;
}
$tres = mysql_fetch_array($treq);
$template = $tres['user_id']."-".$tres['theme']."-".$tres['template'];
if (!isset($_SESSION['set']))
$_SESSION['set'] = md5(time());
$submit = $_SESSION['set'];
$textl = "Share Templates | Memasang: ".htmlspecialchars($tres['name']);
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Share Templates</b></a> | <a href="detail.php?id='.$tres['id'].'">'.htmlspecialchars($tres['name']).'</a> | Memasang</div><div class="gmenu">';
$req = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
if (mysql_num_rows($req) == 0) {
echo '<div class="rmenu">Kamu belum memiliki satu pun blog. Untuk membuat blog silakan <a href="../panel-blog?act=create_blog">klik di sini</a>.</div></div>';
require('../incfiles/end.php');
exit;
}
if (isset($_POST[$submit])) {
unset($_SESSION['set']);
$blog_id = abs(intval($_POST['blog_id']));

$b = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($b) == 0)
$error = 'Blog yang dipilih tidak benar.';
if (empty($error)) {
$bl = mysql_fetch_array($b);
if(file_exists("../files/templates/u".$user_id."-b".$bl['id']."-".$tres['theme'].".xml"))
unlink("../files/templates/u".$user_id."-b".$bl['id']."-".$tres['theme'].".xml");
if(copy("../files/share-templates/files/".$template.".xml","../files/templates/u".$user_id."-b".$bl['id']."-".$tres['theme'].".xml")) {
$qb = mysql_query("SELECT * FROM `sharetemplates` WHERE `user_id`='".$user_id."' AND `name`='".$bl['id']."' AND `template`='".$tres['id']."' AND `type`='set'");
if(mysql_num_rows($qb) == 0) {
mysql_query("INSERT INTO `sharetemplates` SET `user_id`='".$user_id."',`name`='".$bl['id']."',`template`='".$tres['id']."',`text`='".functions::blog_link($bl['url1'])."',`type`='set',`time`='".time()."'");
}
echo 'Template <a href="detail.php?id='.$tres['id'].'">'.htmlspecialchars($tres['name']).'</a> berhasil dipasang pada <a href="'.functions::blog_link($bl['url1']).'">'.htmlspecialchars($bl['title']).'</a>';
}
else {
echo functions::display_error('Template gagal dipasang.');
}
} else { echo functions::display_error($error); }
} else {
echo '<form method="post" action="set.php?id='.$tres['id'].'"/><h3>Pilih Blog</h3><select name="blog_id">';
while ($blog = mysql_fetch_array($req)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select><input type="submit" name="'.$submit.'" value="Pasang Template"/></form>';
}
echo '</div>';
require('../incfiles/end.php');
?>