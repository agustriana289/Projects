<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */


define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
if ($rights == 7 || $rights == 9) {
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND (`type`='xfile' OR `type`='file')");
} else { $treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");
 }
if (mysql_num_rows($treq) == 0) {
header("Location: index.php");
exit;
}
$tres = mysql_fetch_array($treq);
if (!$user_id OR !isset($_SESSION['auth'])) {
header("location: detail.php?id=".$tres['id']);
exit;
}
switch ($act) {
case 'accept':
if ($rights == 7 || $rights == 9) {
mysql_query("UPDATE `sharetemplates` SET `type`='file' WHERE `id`='".$tres['id']."'");
}
header("Location: detail.php?id=".$tres['id']);
break;
case 'add_comment':
if(!isset($_POST['submit']) OR $_SESSION['auth'] != $_POST['sess'] OR mb_strlen($_POST['msg']) < 2 OR mb_strlen($_POST['msg']) > 5000) {
header("Location: detail.php?id=".$tres['id']);
exit;
}
mysql_query("INSERT INTO `sharetemplates` SET `user_id`='".$user_id."',`name`='".mysql_real_escape_string($datauser['name'])."',`template`='".$tres['id']."',`text`='".mysql_real_escape_string($_POST['msg'])."',`type`='comment',`time`='".mysql_real_escape_string(time())."'");
header("Location: detail.php?id=".$tres['id']);
break;
case 'delete_comment':
if (($_GET['sess'] == $_SESSION['auth']) AND ($tres['user_id'] == $user_id OR $rights == 7 OR $rights == 9)) {
unset($_SESSION['auth']);
mysql_query("DELETE FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($_GET['cid'])."' AND `template`='".$tres['id']."' AND `type`='comment'");
}
header("Location: detail.php?id=".$tres['id']);
break;
default:
header("Location: detail.php?id=".$tres['id']);
break;
}
?>