<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error');
if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$bl = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if(mysql_num_rows($bl)==0) {
$textl = "Panel Blog | Kelola Navigasi";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>Panel Blog</b></a> | Kelola Navigasi</div>';echo functions::display_error('Blog yang dipilih tidak benar.','<a href="index.php?act=manage_navigations">'.$lng['back'].'</a>');
require('../incfiles/head.php');
exit;
}
$blog = mysql_fetch_array($bl);
if (empty($blog['navigations'])) {
$show_html .= '<div class="menu"><p>'.$lng['list_empty'].'</p></div>';
}
else {
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$key = $_SESSION['key'];

if (strpos($blog['navigations'],"^") === false) {
if (isset($_GET['delete']) AND isset($_GET['key']) AND $_GET['key'] == $key AND $_GET['delete'] == "ALL") {
unset($_SESSION['key']);
mysql_query("UPDATE `blog_sites` SET `navigations` = '' WHERE `id` = '".$blog['id']."'");
header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
elseif (isset($_GET['edit']) AND $_GET['edit'] == "ALL") {
if (isset($_POST[$key])) {
unset($_SESSION['key']);
$code = $_POST['code'];
require("../incfiles/lib/htmlpurifier/navigation.php");
$code = $purifier->purify($code);
if (mb_strlen($code) < 2 OR mb_strlen($code) > 5000){
$show_html .= '<div class="menu"><p>Kode minimal 2 dan maksimal 5000 karakter.<br /><a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'">Kembali</a></p></div>';
}
else {
$newcode = str_replace("^","",rep_text($code));
mysql_query("UPDATE `blog_sites` SET `navigations` = '".mysql_real_escape_string($newcode)."' WHERE `id` = '".$blog['id']."'");
header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
}
else {
$show_html .= '<div class="menu"><form method="post" action="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;edit=ALL"><p><h3>Kode</h3><textarea rows="' . $set_user['field_h'] . '" name="code">'.htmlentities(rep_text($blog['navigations'],true)).'</textarea></p><p><input type="submit" name="'.$key.'" value="Simpan"/> <a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'">Batal</a></p></form></div>';
}
}
else {
$show_html .= '<div class="menu">'.functions::smileys($blog['navigations']).'<div class="sub"><a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;edit=ALL">Edit</a> | <a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;delete=ALL&amp;key='.$key.'">Hapus</a></div></div>';
}
}
else {
$nav = explode("^",$blog['navigations']);
$nav_totals = count($nav);
for ($i = 0; $i < $nav_totals; $i++) {
if (isset($_GET['down']) AND isset($_GET['key']) AND $_GET['key'] == $key AND ctype_digit($_GET['down']) AND $_GET['down'] == $i AND $i >= 0 AND $i < $nav_totals) {
unset($_SESSION['key']);
$u = $i + 1;
$nav2 = explode("^",$blog['navigations']);
for ($n=0;$n<count($nav2);$n++){

if ($n == $u) { $navigs[] = $nav[$i]; }
else { if ($n == $i) {
$navigs[] = $nav[$u];
} else { $navigs[] = $nav2[$n]; } }

}
$newcode = implode("^",$navigs);
mysql_query("UPDATE `blog_sites` SET `navigations` = '".mysql_real_escape_string($newcode)."' WHERE `id` = '".$blog['id']."'");

header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
elseif (isset($_GET['up']) AND isset($_GET['key']) AND $_GET['key'] == $key AND ctype_digit($_GET['up']) AND $_GET['up'] == $i AND $i > 0 AND $i <= $nav_totals) {
unset($_SESSION['key']);
$u = $i - 1;
$nav2 = explode("^",$blog['navigations']);
for ($n=0;$n<count($nav2);$n++){

if ($n == $u) { $navigs[] = $nav[$i]; }
else { if ($n == $i) {
$navigs[] = $nav[$u];
} else { $navigs[] = $nav2[$n]; } }

}
$newcode = implode("^",$navigs);
mysql_query("UPDATE `blog_sites` SET `navigations` = '".mysql_real_escape_string($newcode)."' WHERE `id` = '".$blog['id']."'");
header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
elseif (isset($_GET['delete']) AND isset($_GET['key']) AND $_GET['key'] == $key AND ctype_digit($_GET['delete']) AND $_GET['delete'] == $i) {
$nav2 = explode("^",$blog['navigations']);
for ($n=0;$n<count($nav2);$n++){
if ($n == $i)
continue;
$newcodes[] = $nav2[$n];
}
if (is_array($newcodes))
$newcode = implode("^",$newcodes);
else
$newcode = $newcode;
mysql_query("UPDATE `blog_sites` SET `navigations` = '".mysql_real_escape_string($newcode)."' WHERE `id` = '".$blog['id']."'");

header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
elseif (isset($_GET['edit']) AND ctype_digit($_GET['edit']) AND $_GET['edit'] == $i) {
if (isset($_POST[$key])) {
unset($_SESSION['key']);
$code = $_POST['code'];
require("../incfiles/lib/htmlpurifier/navigation.php");
$code = $purifier->purify($code);
if (mb_strlen($code) < 2 OR mb_strlen($code) > 5000){
$show_html .= '<div class="menu"><p>Kode minimal 2 dan maksimal 5000 karakter.<br /><a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'">Kembali</a></p></div>';
}
else {
$nav2 = explode("^",$blog['navigations']);
for ($n=0;$n<count($nav2);$n++){
if ($n == $i) {
$newcodes[] = str_replace("^","",rep_text($code));
}
else {
$newcodes[] = $nav2[$n];
}
}
$newcode = implode("^",$newcodes);
mysql_query("UPDATE `blog_sites` SET `navigations` = '".mysql_real_escape_string($newcode)."' WHERE `id` = '".$blog['id']."'");

header('location: index.php?act=manage_navigations&blog_id='.$blog['id']);
exit;
}
}
else {
$show_html .= '<div class="menu"><form method="post" action="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;edit='.$i.'"><p><h3>Kode</h3><textarea rows="' . $set_user['field_h'] . '" name="code">'.htmlentities($nav[$i]).'</textarea></p><p><input type="submit" name="'.$key.'" value="Simpan"/> <a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'">Batal</a></p></form></div>';
}
}
else {
$show_html .= '<div class="menu">'.functions::smileys($nav[$i]).'<div class="sub">'.($i > 0 ? '<a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;up='.$i.'&amp;key='.$key.'">Naik</a> | ': '').($i < ($nav_totals - 1) ? '<a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;down='.$i.'&amp;key='.$key.'">Turun</a> | ' : '').'<a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;edit='.$i.'&amp;key='.$key.'">Edit</a> | <a href="index.php?act=manage_navigations&amp;blog_id='.$blog['id'].'&amp;delete='.$i.'&amp;key='.$key.'">Hapus</a></div></div>';
}
}
}
}
$textl = "Panel Blog | Kelola Navigasi";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>Panel Blog</b></a> | Kelola Navigasi</div>';
if (isset($_GET['notice']) AND $_GET['notice'] != "") {
echo '<div class="rmenu">'.htmlentities(urldecode($_GET['notice'])).'</div>';
}
echo'<div class="user"><p><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3></p></div>';
echo $show_html;
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Panel Blog | Kelola Navigasi";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>Panel Blog</a></b> | Kelola Navigasi</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="manage_navigations"><h3>Pilih blog</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="Lanjutkan"/></p></form></div>';
require('../incfiles/end.php');
}