<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error');

$textl = "Panel Blog | Komentar Blog";
require('../incfiles/head.php');echo '<div class="phdr"><b>Komentar Blog</b></div>';
$new = time() - 3600;
switch ($mod) {
case 'accepted':
$l = "accepted";
$sql = " AND `status`='accepted'";
break;
case 'moderated':
$l = "moderated";
$sql = " AND `status`='modeted'";
break;
case 'spam':
$l = "spam";
$sql = " AND `status`='spam'";
break;
case 'new':
$l = "new";
$sql = " AND (`adminread`='0' OR `time` > '".$new."')";
break;
default:
$l = "ALL";
$sql = "";
break;
}
if (isset($_GET['comment_id'])) {
$cid = mysql_real_escape_string(trim($_GET['comment_id']));
$co_que = mysql_query("SELECT * FROM `blog_comments` WHERE `id`='".$cid."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($co_que) != 0) {
$co = mysql_fetch_array($co_que);
if ($co['status'] != "spam" AND $mod == "spam") {
mysql_query("UPDATE `blog_comments` SET `status`='spam' WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0 AND $co['status'] == "accepted") { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dipindahkan.";
}
elseif ($co['status'] != "accepted" AND $mod == "accepted") {
mysql_query("UPDATE `blog_comments` SET `status`='accepted' WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0) { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` + 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dipindahkan.";
}
elseif ($mod == "delete") {
mysql_query("DELETE FROM `blog_comments` WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0 AND $co['status'] == "accepted") { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dihapus.";
}

}
else{
$return = "Komentar yang dipilih tidak benar.";
}
}
if ($return)
echo '<div class="rmenu">'.$return.'</div>';
$query = mysql_query("(SELECT COUNT(*) FROM `blog_comments` WHERE `user_id`='".$user_id."' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `user_id`='".$user_id."' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `user_id`='".$user_id."' AND `status`='spam') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `user_id`='".$user_id."' AND (`adminread`='0' OR `time` > '".$new."'))");
$totals = array();
while ($tot = mysql_fetch_array($query)) {
$totals[] = $tot[0];
}
echo '<div class="menu"><ul><li>'.($mod == "accepted" ? 'Disetujui ('.$totals[0].')' : '<a href="index.php?act=comments&amp;mod=accepted">Disetujui ('.$totals[0].')</a>').'</li><li>'.($mod == "moderated" ? 'Dimoderasi ('.$totals[1].')' : '<a href="index.php?act=comments&amp;mod=moderated">Dimoderasi ('.$totals[1].')</a>').'</li><li>'.($mod == "spam" ? 'Spam ('.$totals[2].')' : '<a href="index.php?act=comments&amp;mod=spam">Spam ('.$totals[2].')</a>').'</li><li>'.($mod == "unread" ? 'Belum dibaca / Baru ('.$totals[3].')' : '<a href="index.php?act=comments&amp;mod=new">Belum dibaca / Baru ('.$totals[3].')</a>').'</li></ul></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `user_id`='".$user_id."'".$sql),0);
if ($total == 0) {
echo '<div class="rmenu"><p>Tidak ada komentar</p></div>';
} else {
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=comments&amp;mod='.$l.'&amp;', $start, $total, $kmess).'</div>';
$q = mysql_query("SELECT * FROM `blog_comments` WHERE `user_id`='".$user_id."'".$sql." ORDER BY `time` DESC LIMIT $start, $kmess;");
while ($comment = mysql_fetch_array($q)) {
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$comment['site_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
if ($comment['author_id'] != 0)
echo '<a href="../users/profile.php?user='.$comment['author_id'].'"><img src="../users/avatar.php?user='.$comment['author_id'].'" alt=""/></a> ';
else
echo '<img src="../users/avatar.php?user='.$comment['author_id'].'" alt=""/>';
echo '<a href="'.htmlentities($comment['author_homepage']).'">'.htmlspecialchars($comment['author_name']).'</a> ';
if ($comment['adminread'] == 0) {
mysql_query("UPDATE `blog_comments` SET `adminread`='1' WHERE `id`='".$comment['id']."'");
echo '(<span class="red">'.functions::display_date($comment['time']).'</span>)';
}
else {
echo '('.functions::display_date($comment['time']).')';
}
if ($comment['quote'] == "") { echo '<br />'.nl2br($comment['text']).'<br />'; } else { $quot = explode("<!-- quote -->",$comment['quote']); echo '<fieldset><legend>'.$quot[0].'</legend><div>'.nl2br($quot[1]).'</div></fieldset><br />'.nl2br($comment['text']).'<br />';}
if ($comment['post_id'] == 0) {
echo 'Pada <a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/guestbook.html').'">Buku Tamu | '.htmlspecialchars($blog['title']).'</a>';
} else {
$post = mysql_fetch_array(mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `id`='".$comment['post_id']."'"));
echo 'Pada postingan <a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html').'">'.htmlspecialchars($post['title']." | ".$blog['title']).'</a> ';
}

echo '<div class="sub">'.($comment['status'] == "accepted" ? '<a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html?quote='.$comment['id']).'">Balas</a> | <a href="index.php?act=comments&amp;mod=spam&amp;comment_id='.$comment['id'].'">Spam</a>' : '<a href="index.php?act=comments&amp;mod=accepted&amp;comment_id='.$comment['id'].'">Menyetujui</a>').' | <a href="index.php?act=comments&amp;mod=delete&amp;comment_id='.$comment['id'].'" onclick="return confirm(\'Anda yakin ingin menghapus komentar ini?\')"><span class="red">Hapus</span></a></div></div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=comments&amp;mod='.$l.'&amp;', $start, $total, $kmess).'</div>';
}
require("../incfiles/end.php");
?>