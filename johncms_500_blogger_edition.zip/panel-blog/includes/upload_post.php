<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error');

function SaveTags($var) {
if ($exp = explode(",",$var)) {
$count = count($exp) -1;
for ($i = 0; $i <= $count; $i++) {
$vars[] = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$exp[$i])));
}
$var = implode(",",$vars);
}
else {
$var = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$var)));
}
return $var;
}
$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;


function permalink($var)
{
global $user_id;
$var = preg_replace('#([\W_]+)#',' ',$var);
$var = str_replace(' ','-',$var);
$var = strtolower($var);
$cek = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE `user_id`='".$user_id."' AND `permalink`='".mysql_real_escape_string($var)."'"),0);
if ($cek == 0) {
$var = $var;
} else {
$num = $cek + 1;
$var = $var."-".$num;
}
return $var;
}

if (isset($_GET['blog_id'])) {
$blogid = trim($_GET['blog_id']);
$ttl = isset($_POST['title']) ? $_POST['title'] : '';

$cat = isset($_POST['category']) ? $_POST['category'] : '';
$tags = isset($_POST['tags']) ? strtolower($_POST['tags']) : '';
$privacy = isset($_POST['privacy']) ? $_POST['privacy'] : '';
$cb = mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blogid)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($cb) == 0) {
header('location: index.php');
exit;
}
$bl = mysql_fetch_assoc($cb);
if (isset($_POST['publish'])) {
$desc = $_FILES['description']['tmp_name'];
$hand = fopen($desc,"r");
$dcs = fread($hand,$_FILES['description']['size']);
fclose($hand);
$nlbr = isset($_POST['nlbr']) ? $_POST['nlbr'] : 0;
if ($nlbr == 1) {
$dcs = str_replace("\n","<br />",str_replace("\r","<br />",str_replace("\r\n","<br />",$dcs)));
}
$tags = SaveTags($tags);
if ($privacy == "publics")
$privacy = "publics";
else
$privacy = "friends";
$hh = $_POST['hh'];
$bb = $_POST['bb'];
$tttt = $_POST['tttt'];
$jj = $_POST['jj'];
$mm = $_POST['mm'];
$ss = $_POST['ss'];
$curtime = $_POST['DefaultTime'];
$key = $_POST['key'];
$waktuku = $hh." ".$bb." ".$tttt." ".$jj.":".$mm.":".$ss;
$waktu = strtotime($waktuku);
if (strtotime($waktuku) < strtotime($curtime)) {
$waktu = time();
$draft = "no";
}
else {
$waktu = $waktu - $shift;
$draft = "yes";
}
$cfg_form = true;
require("../incfiles/lib/htmlpurifier/purify.php");
$dcs = $purifier->purify($dcs);
if ($_FILES['description']['size'] > 501024)
$error = "File maksimal berukuran 50kb";
if ($_FILES['description']['type'] != "text/plain")
$error = "File harus berekstensi TXT";
if (empty($_FILES['description']['name']))
$error = "Silakan pilih file";
if (empty($_SESSION['key']) OR $_SESSION['key'] != $key)
$error = "Session tidak benar.";
$bc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blogid)."' AND `user_id`='".$user_id."' AND `permalink`='".mysql_real_escape_string($cat)."'");
if (mysql_num_rows($bc) == 0)
$error = "Blog atau kategori yang dipilih tidak benar.";
/*
$dflood = time() - 90;
$cflood = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `user_id`='".$user_id."' AND `time` > '".$dflood."'"),0);
if ($cflood != 0)
$error = "Silakan tunggu beberapa saat lagi.";
*/
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 100)
$error = "Judul harus 2 s/d 100 karakter.";
if (mb_strlen($dcs) < 10)
$error = "Deskripsi minimal 10 karakter";
if (empty($error)) {
mysql_query("INSERT INTO `blog_posts` SET `site_id` = '".mysql_real_escape_string($blogid)."', `user_id`='".$user_id."', `title` = '".mysql_real_escape_string(rep_text(strip_tags($ttl)))."', `description` = '".mysql_real_escape_string(rep_text($dcs))."', `category` = '".mysql_real_escape_string($cat)."', `tags` = '".mysql_real_escape_string($tags)."', `permalink` = '".mysql_real_escape_string(permalink($ttl))."', `privacy` = '".mysql_real_escape_string($privacy)."', `draft` = '".mysql_real_escape_string($draft)."', `time` = '".mysql_real_escape_string($waktu)."'");

mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='".mysql_real_escape_string($blogid)."' AND `user_id`='".$user_id."' AND `permalink`='".mysql_real_escape_string($cat)."'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
header("location: index.php?act=manage_posts&blog_id=".$blogid."&notice=".urlencode("Posting berhasil disimpan."));
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = "Panel Blog | Upload Posting";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>Panel Blog</a></b> | Upload Posting</div>';
if ($error)
echo $error;
echo'<div class="menu"><form method="post" action="index.php?act=upload_post&amp;blog_id='.$blogid.'" enctype="multipart/form-data"><p><h3>Blog</h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($bl['url1']).'/">'.htmlspecialchars($bl['title']).'</a><br /><h3>Judul</h3><input type="text" name="title" value="'.htmlspecialchars($ttl).'"/><br /><h3>Deskripsi</h3><input type="file" name="description"/><br /><span>Harus file TXT</span><br /><input type="checkbox" name="nlbr" value="1"> Replace new line to &lt;br /&gt;<br /><h3>Kategori</h3>
<select name="category">';
$bcats = mysql_query("SELECT `name`,`permalink` FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blogid)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($bcats) == 0) {
}
else {
while($bcat=mysql_fetch_array($bcats)) {
echo '<option value="'.$bcat['permalink'].'"' . ($cat == $bcat['permalink'] ? ' selected="selected"' : '').'>'.htmlspecialchars($bcat['name']).'</option>';
}
}
echo '</select><br /><h3>Tags</h3><input type="text" name="tags" value="'.htmlspecialchars($tags).'"/><br /><span>Pisahkan dengan koma (,)</span><br /><h3>Privasi</h3><select name="privacy"><option value="publics"'.($privacy == "publics" ? ' selected="selected"' : '').'>Publik</option><option value="friends"'.($privacy == "friends" ? ' selected="selected"' : '').'>Teman</option></select><br />';
$taim = time();
$tm = explode("-",date("d-F-Y-H-i-s",($taim + $shift)));
echo '<h3>Waktu diterbitkan</h3>';
echo '<select name="hh" size="2">';
for($i=1;$i<=31;$i++) {
if (strlen($i) != 2)
$tgl = "0".$i;
else
$tgl = $i;
echo '<option' . ($tm[0] == $tgl ? ' selected="selected">' : '>') . $tgl . '</option>';
}
echo '</select>';
$bulan = array("January","February","March","April","May","June","July","August","September","October","November","December");
echo '<select name="bb" size="8">';
for($i=0;$i<count($bulan);$i++) {
echo '<option' . ($tm[1] == $bulan[$i] ? ' selected="selected">' : '>') . $bulan[$i] . '</option>';
}
echo '</select>';
echo '<select name="tttt" size="4"><option value="'.$tm[2].'" selected="selected">'.$tm[2].'</option><option value="'.($tm[2] + 1).'">'.($tm[2] + 1).'</option>';
echo '</select>';
echo '<select name="jj" size="2">';
for($i=0;$i<=23;$i++) {
if (strlen($i) != 2)
$jam = "0".$i;
else
$jam = $i;
echo '<option' . ($tm[3] == $jam ? ' selected="selected">' : '>') . $jam . '</option>';
}
echo '</select>';
echo '<select name="mm" size="2">';
for($i=0;$i<=59;$i++) {
if (strlen($i) != 2)
$mnt = "0".$i;
else
$mnt = $i;
echo '<option' . ($tm[4] == $mnt ? ' selected="selected">' : '>') . $mnt . '</option>';
}
echo '</select>';
$_SESSION['key'] = md5(time());
echo '<input type="hidden" name="ss" value="'.$tm[5].'"><input type="hidden" name="DefaultTime" value="'.date("d F Y H:i:s",($taim + $shift)).'"><input type="hidden" name="key" value="'.$_SESSION['key'].'"></p><p><input type="submit" name="publish" value="Terbitkan"/></p></form></div>';require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Panel Blog | Upload Posting";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>Panel Blog</a></b> | Upload Posting</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="upload_post"><h3>Pilih blog</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="Lanjutkan"/></p></form></div>';
require('../incfiles/end.php');
}
