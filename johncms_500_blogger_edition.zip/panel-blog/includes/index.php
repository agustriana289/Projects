<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error');

$textl = "Panel Blog";
require('../incfiles/head.php');echo '<div class="phdr"><b>My Blogs</b></div>';

$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$nums = mysql_num_rows($myb);
if ($nums == 0) {
echo '<div class="menu"><p>Anda belum memiliki blog.</p></div>';
}
else {
while($blog=mysql_fetch_array($myb)) {
echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
$query = "(SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `draft`='no') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `draft`='yes') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='spam') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='spam')";
$sql = mysql_query($query);
$total = array();
while ($res = mysql_fetch_array($sql)) { $total[] = $res[0]; }

echo '<h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3><div class="sub"><div><a href="index.php?act=edit_blog&amp;blog_id='.$blog['id'].'">Edit</a> | <a href="index.php?act=edit_blog&amp;mod=delete&amp;blog_id='.$blog['id'].'">Hapus</a></div><ul><li>Posting: <a href="index.php?act=manage_posts&amp;blog_id='.$blog['id'].'">'.($total[1] + $total[2]).'</a> ('.$total[1].' diterbitkan, '.$total[2].' konsep)</li><li>Kategori: <a href="index.php?act=manage_categories&amp;blog_id='.$blog['id'].'">'.$total[0].'</a></li><li>Komentar: <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'">'.($total[3] + $total[4] + $total[5]).'</a> (<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=accepted">'.$total[3].'</a> disetujui, <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=moderated">'.$total[4].'</a> menunggu moderasi, <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=spam">'.$total[5].'</a> spam)</li><li>'.$lng['guestbook'].': <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook">'.($total[6] + $total[7] + $total[8]).'</a> (<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=accepted">'.$total[6].'</a> disetujui, <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=moderated">'.$total[7].'</a> menunggu moderasi, <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=spam">'.$total[8].'</a> spam)</li><li>Hits hari ini: '.($blog['hits_today_date'] == date('d-m-Y',(time() + $set['timeshift'])) ? $blog['hits_today'] : '0').'</li><li>Total hits: '.$blog['hits_total'].'</li>';
if (($total[1] + $total[2]) > 0) {
$last_post = mysql_fetch_array(mysql_query("SELECT `draft`,`time` FROM `blog_posts` WHERE `site_id`='".$blog['id']."' ORDER BY `time` DESC LIMIT 1"));
echo '<li>Posting terakhir: '.functions::display_date($last_post['time']).($last_post['draft'] == "yes" ? ' (Konsep)' : '').'</li>';
if (($total[3] + $total[4] + $total[5]) > 0) {
$last_comment = mysql_fetch_array(mysql_query("SELECT `time` FROM `blog_comments` WHERE `site_id`='".$blog['id']."' ORDER BY `time` DESC LIMIT 1"));
echo '<li>Komentar terakhir: '.functions::display_date($last_comment['time']).'</li>';
}
}
echo '</ul></div>';
echo '</div>';
++$i;
}
}
echo'<div class="phdr"><b>Menu</b></div><div class="menu"><a href="index.php?act=create_blog"><b><span class="red">Buat blog baru ('.($set['blogmax'] - $nums).')</span></b></a></div>';echo '<div class="menu"><a href="index.php?act=write_post">Menulis Posting</a></div>';
echo '<div class="menu"><a href="index.php?act=upload_post">Upload Posting</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_posts">Kelola Posting</a></div>';
echo '<div class="menu"><a href="index.php?act=create_category">Membuat Kategori</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_categories">Kelola Kategori</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_comments">Kelola Komentar</a></div>';
echo '<div class="menu"><a href="index.php?act=create_navigation">Membuat Navigasi</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_navigations">Kelola Navigasi</a></div>';
echo '<div class="menu"><a href="index.php?act=template">Template</a></div>';
echo '<div class="menu"><a href="files.php">Files</a></div>';
echo '<div class="menu"><a href="moduls.php">Modul</a></div>';
require('../incfiles/end.php');
