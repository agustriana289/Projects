<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');$headmod = "BYURL";
$headmodurl = $set['homeurl']."/panel-blog/files.php";
function FileName($var)
{ $var = preg_replace('#([\W_]+)#',' ',$var);
$var = str_replace(' ','-',$var);
$var = strtolower($var);
return strlen($var) > 30 ? substr($var,0,30) : $var;
}

if (!$user_id) {
    header('Location: ../index.php');
    exit;
}
$textl = "Panel Blog | Files";require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Panel Blog</b></a> | Files</div>';
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
if (mysql_num_rows($myb) == 0) {
echo functions::display_error("Anda belum memiliki blog.");
require('../incfiles/end.php');
exit;
}
if (!is_dir("../files/blogs")) { mkdir("../files/blogs",0777);
file_put_contents("../files/blogs/index.php");
file_put_contents("../files/blogs/.htaccess","deny from all
AddDefaultCharset UTF-8");
}

switch ($act) {
case 'delete':
default:
if ($act == "delete") { $file = htmlentities($_GET['file']);
$fbid = abs(intval($_GET['blog_id']));
$key = htmlentities($_GET['key']);
$token = $_SESSION['key'].md5($file);
if (isset($_SESSION['key']) AND strlen($key) == 64 AND $token == $key) { if (file_exists("../files/blogs/u".$user_id."-b".$fbid."-".$file)) {
unlink("../files/blogs/u".$user_id."-b".$fbid."-".$file);
$return = '<div class="rmenu">File <b>'.$file.'</b> berhasil dihapus.</div>'; } }
}
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$upload = $_SESSION['key'];
if (isset($_POST[$upload])) {
unset($_SESSION['key']);
$upload = false;
$al_ext = array('rar','zip','pdf','tar','gz','ico','jpg','jpeg','gif','png','bmp','3gp','mp3','amr','mp4','avi','mpg','sis','thm','jar','jad','apk','cab','sisx','exe','msi','nth','thm','css','txt','xml');

$ffile = $_FILES['fail']['tmp_name'];
$fname = strtolower($_FILES['fail']['name']);
$fsize = $_FILES['fail']['size'];
if ($fsize >= 1024 * $set['flsz']) 
$error = "Ukuran File tidak boleh lebih dari ".$set['flsz']." Kb.";
$ext = explode(".",$fname);
if (!in_array($ext[1],$al_ext))
$error = "Ekstensi File tidak diijinkan";
if ($fsize == 0) 
$error = "Silakan pilih File.";
$blog_id = $_POST['blog_id'];
$bid = mysql_query("SELECT `url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($bid) == 0) {
$error = "Blog yang dipilih tidak benar.";
} else { $bl = mysql_fetch_assoc($bid); }
if (!$error) {
if(move_uploaded_file($ffile,"../files/blogs/u".$user_id."-b".$blog_id."-".FileName($ext[0]).".".$ext[1]))
echo '<div class="rmenu">File <a href="'.functions::blog_link($bl['url1']).'/content/'.FileName($ext[0]).'.'.$ext[1].'">'.FileName($ext[0]).'.'.$ext[1].'</a> berhasil diupload.</div>';
else
echo '<div class="rmenu">File gagal diupload</div>';
}
else {
echo '<div class="rmenu">'.$error.'</div>';
}
}
if ($return)
echo $return;
echo '<div class="gmenu">';
if ($upload) { echo '<form method="POST" action="files.php" enctype="multipart/form-data"><p><h3>Upload File</h3><input name="fail" type="file"/><br /><h3>Blog</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" name="'.$upload.'" value="Upload"/></p></form>';
} else { echo '<p>Untuk menghapus atau mengupload file lagi silakan <a href="files.php">Reload</a> halaman ini.</p>'; } echo '</div>';
$files = glob("../files/blogs/u".$user_id."-*");
if ($files != false) {
foreach ($files as $rfile) {
$fail[] = array(filemtime($rfile),basename($rfile),filesize($rfile));
}
if ($fail)
rsort($fail);
}

if ($files == false)
$total = 0;
else
$total = (int)count($files);
if ($total) {
if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination('files.php?', $start, $total, $kmess) . '</div>';
$end = $start + $kmess;
        if ($end > $total) $end = $total;
for ($e = $start; $e < $end; $e++) {
$ft = functions::display_date($fail[$e][0]);
$fs = round($fail[$e][2] / 1024, 2);
$ef = explode("-",$fail[$e][1]);
$blid = substr($ef[1],1);
$name = substr($fail[$e][1],strlen($ef[0]."-".$ef[1]."-"));
$blog = mysql_fetch_assoc(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blid)."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.functions::blog_link($blog['url1']).'/content/'.$name.'">'.$name.'</a><div class="sub"><div><a href="files.php?act=delete&amp;file='.$name.'&amp;blog_id='.$blid.'&amp;key='.$upload.md5($name).'" onclick="return confirm(\'Kamu yakin akan menghapus file ini?\')"><span class="red">Hapus</span></a></div><div class="gray">Blog: '.htmlspecialchars($blog['title']).'<br />Uploaded: '.$ft.'<br/>Size: '.$fs.' kb</div></div></div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination('files.php?', $start, $total, $kmess) . '</div>';
 } else { echo '<div class="menu">'.$lng['list_empty'].'</div>'; }
require('../incfiles/end.php');
}