<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if (!$user_id) {
    header('Location: ../index.php');
    exit;
}
$textl = "Panel Blog | Moduls";require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Panel Blog</b></a> | Moduls</div>';
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
if (mysql_num_rows($myb) == 0) {
echo functions::display_error("Anda belum memiliki blog.");
require('../incfiles/end.php');
exit;
}
if(!file_exists("../files/cache/blogmoduls.dat")) {
echo functions::display_error("Modul kosong.");
require("../incfiles/end.php");
exit;
 }
$handle = fopen("../files/cache/blogmoduls.dat","r");
$body = fread($handle,filesize("../files/cache/blogmoduls.dat"));
fclose($handle);
$modul = explode("^",$body."^");
$total = count($modul);
for ($m = 0; $m < $total; $m++) {
$sub = explode("~",$modul[$m]);
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="moduls.php?id='.($m + 1).'"><h3>'.htmlspecialchars($sub[1]).'</h3></a>';
if ($id AND $id == ($m + 1)) { echo '<div class="gray">'.functions::checkout($sub[2], 1, 1).'</div>';
}
echo '</div>';
$i++;
}
require("../incfiles/end.php");
?>