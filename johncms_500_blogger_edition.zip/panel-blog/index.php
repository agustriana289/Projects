<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);
$headmod = "panelblog";

require('../incfiles/core.php');
require('../incfiles/blog.func.php');
if (!$user_id) {
    header('Location: ../index.php');
    exit;
}

$array = array(
'comments',
'create_category',
'create_navigation',
'create_blog',
'edit_blog',
'edit_category',
'edit_navigation',
'edit_post',
'manage_categories',
'manage_comments',
'manage_navigations',
'manage_posts',
'template',
'upload_post',
'write_post'
);
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' . $array[$key] . '.php')) {
    require('includes/' . $array[$key] . '.php');
} else {require('includes/index.php');
}
