<?php

switch($mod) {
case 'mobile':
case 'desktop':
$_SESSION['skin'] = $mod;
break;
default:
break;
}
header("Location: ".functions::blog_link($bsite['url1']));
