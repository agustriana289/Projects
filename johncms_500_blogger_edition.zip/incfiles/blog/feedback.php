<?php

header("Location: ".$set['homeurl']."/mail/index.php?act=write&id=".$bsite['user_id']); exit;