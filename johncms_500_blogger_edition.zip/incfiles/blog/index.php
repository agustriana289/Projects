<?php

defined('_IN_JOHNCMS') or die('Error');
$headmod = "bshome_".$bsite['id'];
$kmess = ctype_digit($bsite_set[8]) && $bsite_set[8] > 0 && $bsite_set[8] < 20 ? $bsite_set[8] : 10;
$start = isset($_REQUEST['page']) ? $page * $kmess - $kmess : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0);

$ptpl = get_tpl($tpl,"if:post");
function searchQuery($var) {
return strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$var)));
}
if (isset($_POST['search']) AND strlen($_POST['search']) >= 2 AND strlen($_POST['search']) <= 10) {
$search = searchQuery($_POST['search']);
header("Location: ".functions::blog_link($bsite['url1'])."/search/".$search."/1.html");
exit;
}
if (isset($_GET['search'])) {
$search = searchQuery(rep_text($_GET['search']));
$headmod = "bssearch_".$bsite['id']."_".$search;
$info = str_replace("{info:message}","Menapilkan postingan pada pencarian ".ucfirst(str_replace("-"," ",$search)),get_tpl($tpl,"info"));
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `title` LIKE '%".mysql_real_escape_string(str_replace("-"," ",$search))."%' AND `draft`='no'"),0);
}
elseif (isset($_GET['category'])) {
$category = strip_tags(rep_text($_GET['category']));
$headmod = "bscat_".$bsite['id']."_".$category;
$info = str_replace("{info:message}","Menapilkan postingan pada kategori ".$category,get_tpl($tpl,"info"));
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `category`='".mysql_real_escape_string($category)."' AND `draft`='no'"),0);
}
elseif (isset($_GET['tag'])) {
$tag = strip_tags(rep_text($_GET['tag']));
$headmod = "bstag_".$bsite['id']."_".$tag;
$info = str_replace("{info:message}","Menapilkan postingan pada tag ".str_replace("-"," ",$tag),get_tpl($tpl,"info"));
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `tags` LIKE '%".mysql_real_escape_string($tag)."%' AND `draft`='no'"),0);
}
else {
$info = false;
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `draft`='no'"),0);
}
if ($total == 0) {
$html .= get_tpl($tpl,"header");
if ($info)
$html .= $info;
$html .= str_replace("{info:message}","Belum ada satu pun posting yang dipublikasikan.",get_tpl($tpl,"info"));
$html .= get_tpl($tpl,"footer");
}
else {
if (isset($_GET['search'])) {
$pagination_link = functions::blog_link($bsite['url1'])."/search/".$search."/";
$html .= str_replace("{header:title}","Pencarian: ".str_replace("-"," ",$search),get_tpl($tpl,"header"));
$preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `title` LIKE '%".mysql_real_escape_string(str_replace("-"," ",$search))."%' AND `draft`='no' ORDER BY `time` DESC LIMIT $start,$kmess");
}
elseif (isset($_GET['category'])) {
$pagination_link = functions::blog_link($bsite['url1'])."/category/".$category."/";
$html .= str_replace("{header:title}","Kategori: ".$category,get_tpl($tpl,"header"));
$preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `category`='".mysql_real_escape_string($category)."' AND `draft`='no' ORDER BY `time` DESC LIMIT $start,$kmess");
}
elseif (isset($_GET['tag'])) {
$pagination_link = functions::blog_link($bsite['url1'])."/tag/".$tag."/";
$html .= str_replace("{header:title}","Tag: ".$tag,get_tpl($tpl,"header"));
$preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `tags` LIKE '%".mysql_real_escape_string($tag)."%' AND `draft`='no' ORDER BY `time` DESC LIMIT $start,$kmess");
}
else {
$pagination_link = functions::blog_link($bsite['url1'])."/page/";
$html .= get_tpl($tpl,"header");
$preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `draft`='no' ORDER BY `time` DESC LIMIT $start,$kmess");
}
if ($info)
$html .= $info;
$pentry = get_tpl($ptpl,"post:entry");
if ($user_id) { if (strpos($datauser['friends'],"<".$bsite['user_id'].">") === false)
$count_contacts = 0;
else
$count_contacts = 1;
 } else { $count_contacts = 0; }
while($post=mysql_fetch_assoc($preq)) {
if (($post['privacy'] == "publics") || ($post['privacy'] != "publics" && ($bsite['user_id'] == $user_id || $count_contacts > 0 || $rights == 9 || $rights == 7))) 
$desc = $post['description'];
else
$desc = "This post only for friends.";

if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7) {
$desc = $desc.' [<a href="'.$set['homeurl'].'/panel-blog/index.php?act=edit_post&amp;post_id='.$post['id'].'">Edit</a> | <a href="'.$set['homeurl'].'/panel-blog/index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post['id'].'">Hapus</a>]';
}

$k_arr = array("#\{post\:entry\:thumb\}#is","#\{post\:entry\:link\}#is","#\{post\:entry\:title\}#is","#\{post\:entry\:date\}#is","#\{post\:entry\:description\}#is","#\{post\:entry\:comments\}#is","#\{post\:entry\:views\}#is");
$thumb_img = get_thumb($desc,70,70);
$v_arr = array(
$thumb_img,
functions::blog_link($bsite['url1'])."/".$post['permalink'].".html"
,
$post['title'],
functions::display_date($post['time']),
$thumb_img.functions::smileys(substr(strip_tags($desc),0,250)),
$post['comments'],
$post['hits_total']
);
$entry .= preg_replace($k_arr,$v_arr,$pentry);
}
if ($total > $kmess) {
$pagination = str_replace("{pagination:link}",preg_replace("#page\=([0-9]+)#is","$1.html",functions::display_pagination($pagination_link, $start, $total, $kmess)),get_tpl($tpl,"pagination"));
}
else {
$pagination = "";
}
if (strpos($ptpl,"{post:pagination}") !== false) {
$html .= str_replace("{post:pagination}",$pagination,get_tpl($ptpl,"post:entry",$entry));
}
else {
$html .= get_tpl($ptpl,"post:entry",$entry).$pagination;
}
$html .= get_tpl($tpl,"footer");
}
echo get_tpl_etc($html);

if ($user_id) {
mysql_query("UPDATE `users` SET `place` = '".mysql_real_escape_string($headmod)."', `lastdate` = '".time()."' WHERE `id` = '".$user_id."'"); } else {
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
    $req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '".$session."' LIMIT 1");
    if (mysql_num_rows($req)) {
mysql_query("UPDATE `cms_sessions` SET `place` = '".mysql_real_escape_string($headmod)."', `lastdate` = '".time()."' WHERE `session_id` = '".$session."'");
    } else {
mysql_query("INSERT INTO `cms_sessions` SET `session_id` = '".$session."', `ip` = '".core::$ip."', `ip_via_proxy` = '".core::$ip_via_proxy."', `browser` = '".mysql_real_escape_string($agn)."', `lastdate` = '".time()."', `sestime` = '".time()."', `place` = '".mysql_real_escape_string($headmod)."'"); }
}