<?php

$ver=str_replace('/','',htmlspecialchars($_SERVER['REQUEST_URI']));
echo 'google-site-verification: '.$ver;
