<?

define('_IN_JOHNCMS', 1);

require_once ('../incfiles/core.php');
require_once ('../incfiles/blog.func.php');
if ($user_id) { if (strpos($datauser['friends'],"<".$bsite['user_id'].">") === false)
$count_contacts = 0;
else
$count_contacts = 1;
 } else { $count_contacts = 0; }
header("Content-Type: application/xml");
echo '<?xml version="1.0" encoding="iso-8859-1"?><rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/"
><channel>' .
     '<title>' . htmlspecialchars($set['copyright']) . ' | Recent Posts</title>' .
     '<link>' . $set['homeurl'] . '</link>' .
     '<description>Recent Posts</description>' .
     '<pubDate>'.date('r', time()).'</pubDate>';

// Blog
$req = mysql_query('SELECT * FROM `blog_posts` WHERE `draft` = "no" ORDER BY `time` DESC LIMIT 15;');
if (mysql_num_rows($req)) {
    while ($res = mysql_fetch_assoc($req)) {
if (($res['privacy'] == "publics") || ($res['privacy'] != "publics" && ($user_id == $res['user_id'] || $count_contacts > 0 || $rights == 9 || $rights == 7))) 
$desc = $res['description'];
else
$desc = "This post only for friends.";
$blog = mysql_fetch_assoc(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$res['site_id']."'"));        echo '<item>' .
             '<title> ' . htmlspecialchars($res['title']." | ".$blog['title'], ENT_QUOTES) . '</title>' .
             '<link>' . $blog['url1'] . '/'.$res['permalink'].'.html</link>' .
             '<description><![CDATA[' . get_thumb($desc,70,70).functions::smileys(substr(strip_tags($desc),0,100)) . ']]></description>' .
             '<pubDate>' . date('r', $res['time']) .
             '</pubDate>' .
             '</item>';
    }
}

echo '</channel></rss>';