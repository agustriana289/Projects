<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if (!isset($_GET['category'])) {
$textl = $textl." | Kategori";
require('../incfiles/head.php');
echo functions::display_error('Tidak ada kategori yang dipilih','<a href="blog.php">'.$lng['back'].'</a>');
}
else {
$category = htmlentities($_GET['category']);
$name = ucfirst(str_replace("-"," ",$category));
$textl = $textl." | Kategori | ".$name;
require('../incfiles/head.php');
echo '<div class="phdr"><a href="blog.php"><b>Opsi Blog</b></a> | Kategori | '.$name.'</div>';
$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_sites` WHERE `category`='".mysql_real_escape_string($category)."'"),0);
if ($total == 0) {
echo '<div class="menu">Tidak ada blog pada kategori '.$name.'.</div>';
} else {
$query = mysql_query("SELECT `id`,`user_id`,`title`,`url1` FROM `blog_sites` WHERE `category`='".mysql_real_escape_string($category)."' ORDER BY `id` DESC LIMIT $start, $kmess");
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('blog.php?act=categories&amp;category='.$category.'&amp;', $start, $total, $kmess).'</div>';
while ($blog=mysql_fetch_array($query)) {
$author = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$blog['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<img src="../images/blogs.png" alt=""/> <a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a><div class="sub">Author: <a href="../users/profile.php?user='.$blog['user_id'].'">'.$author['name'].'</a></div>';
echo '</div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('blog.php?act=categories&amp;category='.$category.'&amp;', $start, $total, $kmess).'</div>';
}
}