<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $textl." | Komentar Terbanyak";
require('../incfiles/head.php');
echo '<div class="phdr"><a href="blog.php"><b>Opsi Blog</b></a> | Komentar Terbanyak</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `draft`='no'"),0);
if ($total == 0) {
echo '<div class="menu">Belum ada posting.</div>';
} else {
$query = mysql_query("SELECT `site_id`,`user_id`,`title`,`permalink`,`comments`,`time` FROM `blog_posts` WHERE `draft`='no' ORDER BY `comments` DESC LIMIT 10");
while($post=mysql_fetch_array($query)) {
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
$author = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$post['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html">'.htmlspecialchars($post['title']." | ".$blog['title']).'</a><div class="sub">Penulis: <a href="../users/profile.php?user='.$post['user_id'].'">'.$author['name'].'</a><br />Waktu: '.functions::display_date($post['time']).'<br />Komentar: '.$post['comments'].'</div>';
echo '</div>';
++$i;
}
}
