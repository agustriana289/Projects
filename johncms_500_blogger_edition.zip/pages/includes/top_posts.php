<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $textl." | Top Posting";
require('../incfiles/head.php');
switch ($mod) {
case 'all_time':
$xmod = "all_time";
$query = "`draft`='no'";
$order = "`hits_total`";
break;
default:
$xmod = "today";
$query = "`hits_today_date`='".date("d-m-Y",(time() + $set['timeshift']))."' AND `draft`='no'";
$order = "`hits_today`";
break;
}
echo '<div class="phdr"><a href="blog.php"><b>Opsi Blog</b></a> | Top Posting | '.($xmod == "all_time" ? 'Semua waktu' : 'Hari ini').'</div>';
echo '<div class="menu"><ul><li>'.($xmod == "all_time" ? '<a href="blog.php?act=top_posts&amp;mod=today">Hari ini</a>' : 'Hari ini').'</li><li>'.($xmod == "today" ? '<a href="blog.php?act=top_posts&amp;mod=all_time">Semua waktu</a>' : 'Semua waktu').'</li></ul></div>';
$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE $query"),0);
if ($total == 0) {
echo '<div class="menu">Belum ada posting.</div>';
} else {
$req = mysql_query("SELECT `id`,`site_id`,`user_id`,`title`,`permalink`,`hits_today`,`hits_total`,`time` FROM `blog_posts` WHERE $query ORDER BY $order DESC LIMIT 10");

while ($post=mysql_fetch_array($req)) {
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
$author = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$post['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html">'.htmlspecialchars($post['title']." | ".$blog['title']).'</a><div class="sub">'.(($rights == 7 || $rights == 9) ? '<div><a href="../panel-blog/index.php?act=edit_post&amp;post_id='.$post['id'].'">Edit</a> | <a href="../panel-blog/index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post['id'].'"><span class="red">Hapus</span></a></div>' : '').'Penulis: <a href="../users/profile.php?user='.$post['user_id'].'">'.$author['name'].'</a><br />Waktu: '.functions::display_date($post['time']).'<br />';
if($mod == "all_time")
echo 'Hits semua waktu: '.$post['hits_total'];
else
echo 'Hits hari ini: '.$post['hits_today'];
echo '</div>';
echo '</div>';
++$i;
}
}
