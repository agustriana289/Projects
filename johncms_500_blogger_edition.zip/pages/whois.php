<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Whois';
$headmod = 'whois';
require('../incfiles/head.php');
echo '<div class="phdr">Whois</div>';
echo '<div class="gmenu"><p><h3>Alamat Blog</h3><form method="get" action="whois.php"><input type="text" name="domain" value=""/><br /><span>Contoh: sub.fastblog.net</span><br /><input type="submit" value="WHOIS"/></form></p></div>';
if (isset($_GET['domain'])) {
$domain = strtolower(addslashes(htmlentities($_GET['domain'])));
if (substr($domain,0,4) == "www.")
$domain = substr($domain,4);
$br = mysql_query("SELECT * FROM `blog_sites` WHERE `url1`='".mysql_real_escape_string("http://".$domain)."' OR `url2`='".mysql_real_escape_string("http://www.".$domain)."'");
if (mysql_num_rows($br) != 0) {
$blog = mysql_fetch_array($br);
$uz = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser`, `rights` FROM `users` WHERE `id` ='".mysql_real_escape_string($blog['user_id'])."'");
$mass1 = mysql_fetch_assoc($uz);echo '<div class="user">URL Blog: <a href="http://'.$domain.'">http://'.$domain.'</a><br />Judul Blog: '.htmlspecialchars($blog['title']).'<br />Mendaftar: '.functions::display_date($blog['time']).'</div>';
echo functions::display_user($mass1);
}
else {
echo '<div class="rmenu">Data tidak ditemukan.</div>';
}
}
require('../incfiles/end.php');
?>