<?
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/
echo $mp->news;
echo '<div class="phdr"><b>Posting Terbaru</b></div>';
$total_posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `draft`='no'"),0);
if ($total_posts) {
$posts = mysql_query("SELECT `site_id`,`title`,`permalink`,`time` FROM `blog_posts` WHERE `draft`='no' ORDER BY `time` DESC LIMIT 5");
while($post=mysql_fetch_array($posts)) {
$blog = mysql_fetch_assoc(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
echo '<div class="menu"><a href="'.($user_id ? $set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html') : functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html').'">'.htmlspecialchars($post['title']." | ".$blog['title']).'</a> <span class="gray">'.functions::display_date($post['time']).'</span></div>';
}
}
else {
echo '<div class="menu">'.$lng['list_empty'].'</div>';
}
echo '<div class="phdr"><b>Opsi Blog</b></div><div class="menu"><a href="pages/blog.php?act=recent_posts">Posting Terbaru</a></div>
<div class="menu"><a href="pages/blog.php?act=top_comments">Komentar Terbanyak</a></div>
<div class="menu"><a href="pages/blog.php?act=top_posts">Top Posting</a></div><div class="menu"><a href="pages/blog.php?act=top_blogs">Top Blog</a></div><div class="menu"><a href="pages/blog.php?">Kategori Blog</a></div>';
echo '<div class="phdr"><b>Penanda</b></div>';
/*
echo '<div class="menu"><a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</div>';
*/
/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/
// Ссылка на гостевую
if ($set['mod_guest'] || $rights >= 7)
    echo '<div class="menu"><a href="guestbook/index.php">'.$lng['guestbook'].'</a> (' . counters::guestbook() . ')</div>';
// Ссылка на Форум
if ($set['mod_forum'] || $rights >= 7)
    echo '<div class="menu"><a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>';

/*
-----------------------------------------------------------------
Блок полезного
-----------------------------------------------------------------
*/    
// Ссылка на загрузки
if ($set['mod_down'] || $rights >= 7)
    echo '<div class="menu"><a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</div>';
// Ссылка на библиотеку
if ($set['mod_lib'] || $rights >= 7)
    echo '<div class="menu"><a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')</div>';
// Ссылка на библиотеку
if ($set['mod_gal'] || $rights >= 7)
    echo '<div class="menu"><a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</div>';
if ($user_id || $set['active']) {
$total_templates = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE `type`='file'"),0);
    echo '<div class="menu"><a href="users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')</div>' .
        '<div class="menu"><a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</div>' .
        '<div class="menu"><a href="share-templates/">Share Templates</a> ('.$total_templates.')</div>';
}
?>
