Indonesian language pack
============================================================
Requires correction of some phrases
============================================================
TRANSLATION AUTHORS:
Panser (http://jogerwap.net), JohnCMS Indonesian Team