<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
echo '<div class="mainblok"><div class="menu">';
echo '<div style="text-align:center">';
if (!empty($cms_ads[2])) {
    echo '' . $cms_ads[2] . '';
}

//include_once ('adiquity.php');
echo '</div></div></div>';
echo '<div>';

if (isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act)) 
    echo '<a href=\'' . $set['homeurl'] . '\'>' . functions::image('menu_home.png') . $lng['homepage'] . '</a><br />';

if ($set_user['quick_go']) {
    echo '<form action="' . $set['homeurl'] . '/go.php" method="post">';
    echo '<div><select name="adres" style="font-size:x-small">
    <option selected="selected">' . $lng['quick_jump'] . '</option>
    <option value="forum">' . $lng['forum'] . '</option>
    <option value="guest">' . $lng['guestbook'] . '</option>
    <option value="news">' . $lng['news'] . '</option>
    <option value="down">' . $lng['downloads'] . '</option>
    </select><input type="submit" value="Go!" style="font-size:x-small"/>';
    echo '</div></form>';
}
    echo '</div>';

if ($headmod == 'mainpage') {
if ($user_id) {
echo '<div class="orangex">' . $lng['member'] . ': <a href="../users/index.php"> ' . counters::users() . ' </a><br/>';
include_once('member.php');
} else {
echo '<div class="orangex">' . counters::online() . '</div>';
}
}
echo '</div>';

echo '</div><div class="footer" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</td><td width="auto" align="right">';
$Contents = ob_get_contents();
$gzib_file = strlen($Contents);
$gzib_file_out = strlen(gzcompress($Contents, 9));
$gzib_pro = round(100 - (100 / ($gzib_file / $gzib_file_out)), 1);
echo 'Gzip: ' . $gzib_pro . '%';
echo '</a></td></tr></table></div>';

// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}

/*
-----------------------------------------------------------------
ВНИМАНИЕ!!!
Данный копирайт нельзя убирать в течение 90 дней с момента установки скриптов
-----------------------------------------------------------------
ATTENTION!!!
The copyright could not be removed within 90 days of installation scripts
-----------------------------------------------------------------
*/
echo '<div style="text-align:center">';
if($user_id) {
echo '<b><a href="/constitution">TOS</a> | <a id="down"></a><a href="#up">' . functions::image('up.png', array('class' => '')) . '</a> | <a href="/faq">FAQ</a></b>';
}
echo '<div><small><a href="http://waptok.asia" target="_blank">&copy;</a> ' . date('Y') . ' ' . $set['copyright'] . '</small></div>';
echo '<div><small><a href="http://johncms.com">JohnCMS</a> 6.2.0</small></div>';

echo '</div></body></html>';