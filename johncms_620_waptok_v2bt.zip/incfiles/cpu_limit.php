<?php
//Cek CPU Load
$load = sys_getloadavg();
$limit =30;
if ($load[0] >= $limit) {
header('HTTP/1.1 503 Too busy, please try again later');
die('<center><h2>Maaf, server kami sedang sibuk. Silahkan kunjungi beberapa saat lagi.</h2><br/>&copy; 2016 <a href="http://www.waptok.asia">WAPTOK.ASIA&trade;</a></center>');
}
?>