<html>
<body style="background:black;color:#00ff00;text-align:center;">
<?php
chmod("download/arctemp",0777);
chmod("download/files",0777);
chmod("download/graftemp",0777);
chmod("download/screen",0777);
chmod("files/cache",0777);
chmod("files/forum/attach",0777);
chmod("files/library",0777);
chmod("files/library/images",0777);
chmod("files/library/images/big",0777);
chmod("files/library/images/orig",0777);
chmod("files/library/images/small",0777);
chmod("files/library/tmp",0777);
chmod("files/lng_edit",0777);
chmod("files/mail",0777);
chmod("files/users/album",0777);
chmod("files/users/avatar",0777);
chmod("files/users/photo",0777);
chmod("forum/file",0777);
chmod("gallery/foto",0777);
chmod("gallery/temp",0777);
chmod("incfiles",0777);
?>
<br /><a style="color:#00ff00;" href="install/index.php">Go To Installation Step</a>
<br /><br /><b><a style="color:#990000;" href="http://www.waptok.asia" target="_blank">WWW.WAPTOK.ASIA</a>&trade;
</b>
</body>
</html>