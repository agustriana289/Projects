<?php
define('_IN_JOHNCMS', 1);
$rootpath = '';
require('incfiles/core.php');

$error = !isset($_SESSION['code']) ? $lng_forum['access_forbidden'] : '';
$code = '/* kode didownload dari ' . $home . ' */';
$code .= $_SESSION['code'];
$code = html_entity_decode(trim($code), ENT_QUOTES, 'UTF-8');
$code = str_replace('<br />', '', $code);

if ($error) {
require('../incfiles/head.php');
echo '<div class="rmenu"><p>' . $error . '</p></div>';
require('../incfiles/end.php');
exit;
}

if (isset($_GET['dnl'])) {
header($_SERVER['SERVER_PROTOCOL'] . ' 200 OK');     
header('Content-Type: application/force-download'); 
header('Content-Description: inline; File Transfer'); 
header('Content-Disposition: attachment; filename="code_waptok.txt";', false); 
}

header('Content-Type: text/plain;charset=UTF-8');
header('Content-Transfer-Encoding: binary'); 
header('Content-Length: ' . mb_strlen($code));

print($code);
exit;

?>