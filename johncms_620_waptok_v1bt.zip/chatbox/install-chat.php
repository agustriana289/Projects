<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Persiapan Install Chatbox!';
require_once('../incfiles/head.php');
$rootpath = '';

echo '<div class="mainblok"><div class="phdr">'.$textl.'</div>';
if (isset($_POST['submit'])) {
     mysql_query("DROP TABLE IF EXISTS `cms_users_chatbox");
     $u_cb = mysql_query("CREATE TABLE `cms_users_chatbox` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  `attributes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");

        mysql_query("DROP TABLE `chat");
        $ch = mysql_query("CREATE TABLE `chat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adm` tinyint(1) NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `browser` tinytext NOT NULL,
  `admin` varchar(25) NOT NULL DEFAULT '',
  `otvet` text NOT NULL,
  `otime` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_who` varchar(20) NOT NULL DEFAULT '',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `ip` (`ip`),
  KEY `adm` (`adm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");

if ($u_cb && $ch) {
echo '<div class="gmenu"><a href="index.php">Home</a> | Chatbox Berhasil diinstall!</div>';
}

if ($u_cb == false)
echo '<div class="rmenu">TABLE `cms_users_chatbox` is not filled !</div>';
if ($ch == false)
echo '<div class="rmenu">TABLE `chat` is not filled !</div>';
} else {
echo '<div class="gmenu">Chatbox for your JohnCMS<form method="POST"><input type="submit" name="submit" value="submit" /></form></div>';

}
echo '<div class="rmenu">&copy; 2016 Mod by <a href="http://www.waptok.asia">Waptok</a></div>';
echo '<div class="phdr">Version 1.0</div>';
echo '</div>';
require_once('../incfiles/end.php');
?>