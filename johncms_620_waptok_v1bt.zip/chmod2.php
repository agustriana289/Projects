<?php
#AUTO CHMOD SETELAH INSTALASI
chmod("incfiles/db.php",0644);
chmod("incfiles",0755);
chmod("install",0600);
unlink("chmod.php");
unlink("install");

?>
<center><a style="color:#800000;" href="panel">Goto Admin Panel</a>
</center>