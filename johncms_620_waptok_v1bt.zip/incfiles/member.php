<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
* @modif       http://waptok.xyz
* @member online for JohnCMS 6.x.x
*/

global $user_id, $home;
$u_on = array();
$ontime = time() - 300;
$guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
$qon = mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate`>='" . $ontime . "';");
$qon2 = mysql_result($qon, 0);
if($qon2>=1) {
   echo '' . $lng['users_on'] . ': ';
} else {
   echo '' . $lng['no_users_on'] . '';
}
$ontime = time() - 300;
$q = @mysql_query("select * from `users` where lastdate>='" . intval($ontime) . "';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)) {
   $where = explode(",", $arr['place']);
   switch ($where[0]) {
      case 'forumfiles' :
      $place = '<a href="../forum/index.php?act=files">Forum files</a>';
      break;
      
      case 'forumwho' :
      $place = '<a href="../forum/index.php?act=who">Who in forum</a>';
      break;
      
      case 'profile' :
      $place = '<a href="../users/profile.php?act=edit">Profile</a>';
      break;
      
      case 'smileys' :
      $place = '<a href="../pages/faq.php?act=smileys">Smileys</a>';
      break;
      
      case 'online' :
      $place = '<a href="../users/index.php">List online</a>';
      break;
      
      case 'blog' :
      $place = '<a href="../pages/blog/index.php">Blogs</a>';
      break;
      
      case 'bbcode' :
      $place = '<a href="../pages/faq.php?act=tags">BBcode</a>';
      break;
      
      case 'read' :
      $place = '<a href="../pages/faq.php?act=forum">Rules</a>';
      break;
      
      case 'load' :
      $place = '<a href="../download/index.php">Download</a>';
      break;
      
      case 'gallery' :
      $place = '<a href="../gallery/index.php">Gallery</a>';
      break;
      
      case 'teman' :
      $place = '<a href="../users/count.php?user=' . $arr['id'] . '">Friend list</a>';
      break;
      
      case 'forum' :
      $place = '<a href="../forum/index.php">Forum</a>';
      break;
      
      case 'chatbook' :
      $place = '<a href="../chatbook/index.php">Chatbook</a>';
      break;
      
      case 'guest' :
      $place = '<a href="../guestbook/index.php">Guestbook</a>';
      break;
            
      case 'lib' :
      $place = '<a href="../library/index.php">Library</a>';
      break;
      
      case 'mainpage' :
      default :
      $place = '<a href="../index.php">Home</a>';
      break;
}

//require_once('incfiles/func_warna.php');
   $u_on[]="<a href='/users/profile.php?user=" . $arr['id'] . "'><b>" . $arr[name] . "</b></a>";
}
if (($qon2>=1) && ($qon2<=5)) {
   echo implode(', ',$u_on).'.';
}
elseif ($qon2>=6) {
   $ton = $qon2-5;
   echo implode(', ',$u_on).'.';
   echo '<a href="' . $home . '/users/index.php?act=online"><b>' . $ton . '</b></a> More..';
}
echo '<br/>' . $lng['guest'] . ': ';
if ($guests>=1) {
   echo '<a href="' . $home . '/users/index.php?act=online&amp;mod=guest">' . $guests . '</a><br/>';
} else
   echo '' . $lng['no_guest'] . '<br/>';
/*
-----------------------------------------------------------------
New member
-----------------------------------------------------------------
*/
echo '' . $lng['new_member'] . ':&nbsp;';
$req = mysql_query("SELECT `id`, `name`, `datereg` FROM `users` WHERE (preg='1') ORDER BY `datereg` DESC LIMIT 1; ");
$arr = mysql_fetch_array($req);
echo '<a href="../users/profile.php?user=' . $arr['id'] . '"><b><font color="green">'.$arr['name'] .'</font></b></a>';
?>
