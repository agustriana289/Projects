<?php

define('_IN_JOHNCMS', 1);

$headmod = 'forum';
$textl = 'attach';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$realtime=time();
if ($rights == 5 || $rights >= 6)
{
if (empty($id))
    {
        echo '<div class="rmenu">Hanya diperbolehkan 1 kali upload extra_attachment<br/></div>';
    }
   
}
if (!empty($id) && $user_id)
{
    switch ($act)
    {
        case "precfile":
            if ($rights == 5 || $rights >= 6)
            {
                $err = '';
                if (empty($_POST['submit']))
                {
                    echo '<form method="post" action="att_file.php?act=precfile&amp;id=' . $id . '" enctype="multipart/form-data">';
                    echo '<div class="gmenu">Name to display:<br/><input name="name"/><br/>';
                    echo 'Select the file( only image file .png .jpg . jpeg .gif .png):<br/><input type="file" name="file"/><br/>';
                    echo '<input value="add" type="submit" name="submit"/></form></div>';
                }
                else
                {
                    $data = $_FILES['file'];
                    $originalname = $data['name'];
                    $filesize = $data['size'];
                    $filetype = $data['type'];
                    $file_tmp = $data['tmp_name'];
                    $file_err = $data['error'];
                    $file_ext = pathinfo($originalname);
                    $file_ext = $file_ext['extension'];
                    $blacklist_ext = array('php', 'pl');
                    $mime = array('text/plain', 'application/x-zip-compressed', 'application/zip', 'image/gif', 'image/png', 'image/jpeg',
                        'application/x-rar-compressed');
                    if (!empty($_POST['name']) && mb_strlen($_POST['name']) < 50)
                    {
                        $name = trim($_POST['name']);
                    }
                    else
                    {
                        @unlink($file_tmp);
                        $err = 'You forgot to enter the name of the article or title of the article privyschaet 50 characters';
                    }
                    foreach ($blacklist_ext as $val)
                    {
                        if (preg_match("/$val\$/i", $originalname))
                        {
                            @unlink($file_tmp);
                            $err = 'Trying to upload a file format is not supported';
                        }
                    }
                    if ($filesize == "0")
                    {
                        @unlink($file_tmp);
                        $err = 'Too little weight File: 0 Bytes!';
                    }
                    if ($file_err)
                    {
                        switch ($file_err)
                        {
                            case "1":
                                @unlink($file_tmp);
                                $err = 'The size of the file received exceeded the maximum allowable size!';
                                break;
                            case "2":
                                @unlink($file_tmp);
                                $err = 'The size of the file received exceeded the maximum allowable size!';
                                break;
                            case "3":
                                @unlink($file_tmp);
                                $err = 'The download file was only partially. ';
                                break;
                            case "4":
                                @unlink($file_tmp);
                                $err = 'No file was uploaded. ';
                                break;
                        }
                    }
                    if (mb_substr_count($originalname, ".") > 1)
                    {
                        @unlink($file_tmp);
                        $err = 'The file must have a single extension. ';
                    }
                    if (!$file_ext)
                    {
                        @unlink($file_tmp);
                        $err = 'The file must have. ';
                    }
                    if (!in_array($filetype, $mime))
                    {
                        @unlink($file_tmp);
                        $err = 'Error, this file is not a valid file ';
                    }
                    if ($err <> "")
                    {
                        echo '<div class="rmenu"><p>' . $err . '</p></div>';
                    }
                    else
                    {
                        if (is_uploaded_file($file_tmp))
                        {
                            $path_file = $user_id . '_' . $realtime . '.' . $file_ext;
                            if (file_exists('file/' . $path_file))
                            {
                                @unlink('file/' . $path_file);
                            }
                            if (move_uploaded_file($file_tmp, 'file/' . $path_file))
                            {
                                if (mysql_query("insert into `att_file` set
                        `id` = '',
                        `fid` = '" . $id . "',
                        `name` = '" . $name . "',
                        `file` = '" . $path_file . "',
                        `time` = '" . $realtime . "';"))
                                {
                                    
          
            echo '<div class="menu"><a href="index.php?act=post&amp;id=' . $id . '">' . $lng['continue'] . '</a><br/>';
                                    echo 'File successfully Uploaded</div>';
                                }
                                else
                                {
                                    header("location: file.php?act=precfile&id=$id");
                                }
                            }
                        }
                    }
                }
            }
            break;
        case "look":
            $cou = mysql_result(mysql_query("select COUNT(*) from `att_file` where `id` = '" . $id. "'"), 0);
            if ($cou > 0)
            {
                $res = mysql_fetch_array(mysql_query("select * from `att_file` where `id` = '" . $id . "'"));
                $file = './file/' . $res['file'];
                if (file_exists($file))
                {
                    header("Location: $file");
                }

            }
            break;
        case "editprec":
            if ($rights == 5 || $rights >= 6)
            {
                $cou = mysql_result(mysql_query("select COUNT(*) from `lib_file` where `fid` = '" . $id . "'"), 0);
                if ($cou > 0)
                {
                    $sql = mysql_query("select * from `lib_file` where `fid` = '" . $id . "'");
                    while ($res = mysql_fetch_array($sql))
                    {
                        $i = 11;
                        echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';
                        echo '<a href="file.php?act=look&amp;id=' . $res['id'] . '">' . $res['name'] . '</a><br/>';
                        echo '<a href="file.php?act=editprec&amp;fid=' . $res['id'] . '&amp;ed&amp;id=' . $id .
                            '"><span class="red">Remove</span></a>';
                        echo '</div>';
                    }
                    if (isset($_GET['ed']))
                    {
                        if (file_exists('./file/' . $ed['file']))
                        {
                            @unlink('./file/' . $ed['file']);
                        }
                        $sql = mysql_query("select * from `lib_file` where `id` = '" . intval($_GET['fid']) . "'");
                        $ed = mysql_fetch_array($sql);
                        $dd = mysql_fetch_array(mysql_query("select `fid` from `library` where `id` = '" . $ed['fid'] . "'"));
                        mysql_query("delete from `lib_file` where `id` = '" . intval($_GET['fid']) . "'");

                        header("Location: fileman.php?id=" . $dd['fid']);
                    }

                }
            }
            $sql1 = mysql_fetch_array(mysql_query("select `fid` from `library` where `id` = '" . $id . "'"));
            echo '<a href="fileman.php?id=' . $sql1['fid'] . '">Back</a>';
            break;
        case "rat":
            if ($_SESSION['rat'] !== $id)
            {
                $_SESSION['rat'] = $id;
                $rat = check($_GET['de']);
                if ($rat != 'plus' and $rat != 'minus')
                {
                    display_error('You have not chosen the way of voting! ');
                    require_once ("../incfiles/end.php");
                    exit;
                }
                $re = mysql_fetch_array(mysql_query("SELECT * FROM `library` WHERE `id` = '" . $id . "' LIMIT 1"));
                if ($rat == 'plus')
                {
                    $plus = $re['plus'] + 1;
                }
                else
                {
                    $plus = $re['plus'];
                }

                if ($rat == 'minus')
                {
                    $minus = $re['minus'] + 1;
                }
                else
                {
                    $minus = $re['minus'];
                }
                $upd = mysql_query("UPDATE `library` SET `minus` = '" . $minus . "', `plus`='" . $plus . "' WHERE `id`='" . $id . "'");
                if (!$upd)
                {
                    display_error('Not added!');
                    require_once ("../incfiles/end.php");
                    exit;
                }
                else
                {
                    echo '<div class="menu">You have successfully voted for the article!</div><a href="read.php?id=' . $id . '">back</a>';
                }
            }
            else
            {
                echo 'You have already voted for this story<br/>';
            }
            echo '<br/><a href="read.php?id=' . $id . '">Back</a>';
            break;
    }
}

require_once ("../incfiles/end.php");
?>