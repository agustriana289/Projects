<?
define('_IN_JOHNCMS', 1);
/*
 by Str@nnik
 http://johncms.com/users/profile.php?user=21326
 ICQ: 609745227
*/

if ($user_id) {
	echo '<div class="gmenu"><form action="mchat/index.php?act=add" name="add" method="post">' .
        'Сообщение (max 500):<br />';
    echo bbcode::auto_bb('add', 'message');
    echo '<textarea rows="' . $set_user['field_h'] . '" name="message"></textarea><br />' .
        '<input type="submit" name="submit" value="Сказать" /></form></div>';
}
$total = mysql_result(mysql_query('select count(*) from `m_chat`'), 0);
if ($total) {
	$req = mysql_query('select * from `m_chat` order by `time` desc limit 3;');
	$i = 0;
	while ($res = mysql_fetch_assoc($req)) {
		echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
		$User = mysql_fetch_assoc(mysql_query('select * from `users` where `id` = ' . $res['user_id'] . ';'));
		if (file_exists((ROOTPATH . 'files/users/avatar/' . $User['id'] . '.png')))
            echo '<img src="' . $home . '/files/users/avatar/' . $User['id'] . '.png" width="32" height="32" alt="" />&#160;';
        else
            echo '<img src="' . $home . '/images/empty.png" width="32" height="32" alt="" />&#160;';
		if ($User['sex'])
            echo functions::image(($User['sex'] == 'm' ? 'm' : 'w') . ($User['datereg'] > time() - 86400 ? '_new' : '') . '.png', array('class' => 'icon-inline'));
        else
            echo functions::image('del.png');
		echo !$User_id || $User_id == $User['id'] ? '<b>' . $User['name'] . '</b>&#160;' : '<a href="' . $home . '/users/profile.php?user=' . $User['id'] . '"><b>' . $User['name'] . '</b></a>&#160;';
            $rank = array(
                0 => '',
                1 => '(GMod)',
                2 => '(CMod)',
                3 => '(FMod)',
                4 => '(DMod)',
                5 => '(LMod)',
                6 => '(Smd)',
                7 => '(Adm)',
                9 => '(SV!)'
                );
        $Rights = isset($User['rights']) ? $User['rights'] : 0;
		echo $rank[$Rights];
		echo (time() > $User['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');
		echo '&#160;<span class="gray">(' . functions::display_date($res['time']) . ')</span>&#160;<a href="mchat/view_mess.php?id='.$res['id'].'">[#'.$res['id'].']</a><br />';
		if ($res['cid']) {
			$view = mysql_fetch_assoc(mysql_query('select * from `m_chat` join `users` on `m_chat`.`user_id` = `users`.`id` and `m_chat`.`id` = '.$res['cid'].';'));
			$view_post = functions::checkout($view['message'], 1, 1);
			if ($set_user['smileys'])
				$view_post = functions::smileys($view_post, $User['rights'] >= 1 ? 1 : 0);
			echo '<div class="quote"><b>' . $view['name'] . '</b>&nbsp;(' . functions::display_date($view['time']) . ')<br />' . $view_post . '</div>';
		}
		$post = functions::checkout($res['message'], 1, 1);
         if ($set_user['smileys'])
            $post = functions::smileys($post, $User['rights'] >= 1 ? 1 : 0);
		echo $post;
		if ($user_id && $user_id != $res['user_id']) {
			echo '<br /><hr />[<a href="mchat/index.php?act=otv&amp;id='.$res['user_id'].'">Отв</a>]&#160;[<a href="mchat/index.php?act=cyt&amp;id='.$res['id'].'">Цит</a>]';
		}
		echo '</div>';
		$i++;
	}
} else {
	echo '<div class="menu">Пусто</div>';
}