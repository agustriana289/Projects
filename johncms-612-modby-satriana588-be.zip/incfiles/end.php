<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2])) {
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
}

// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}

/*
-----------------------------------------------------------------
ВНИМАНИЕ!!!
Данный копирайт нельзя убирать в течение 90 дней с момента установки скриптов
-----------------------------------------------------------------
ATTENTION!!!
The copyright could not be removed within 90 days of installation scripts
-----------------------------------------------------------------
*/
if ($headmod == 'mainpage') {
if ($user_id){
echo '<div class="orangex">Total member: <a href="../users/index.php"> ' . counters::users() . ' </a><br/>';
include_once('member.php');
}else{
echo '<div class="orangex">' . counters::online() . '</div>';
}
}

echo '</div>';
echo '</div><div class="footer" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</td><td width="auto" align="right">';
$Contents = ob_get_contents();
$gzib_file = strlen($Contents);
$gzib_file_out = strlen(gzcompress($Contents, 9));
$gzib_pro = round(100 - (100 / ($gzib_file / $gzib_file_out)), 1);
echo 'Gzip: ' . $gzib_pro . '%';
echo '</a></td></tr></table></div>';
////////////////////////////////////////////////////////////// ��N?�uN,N?���a�� �a��N,���"�l���l�2
functions::display_counters();
// �?�u�a�"���L�?N<�a �+�"�l�a N?���aN,��
if (!empty($cms_ads[3]))
echo '<div style="text-align:center">' . $cms_ads[3];

/*
-----------------------------------------------------------------
�'�t�~�s�?�t�~��!!!
ATTENTION!!!
The copyright could not be removed within 60 days of installation scripts
-----------------------------------------------------------------
*/

echo '<div style="text-align:center">';
echo '<div><small><a href="http://johncms.com" target="_blank">&copy;</a> 2012-' . date('Y') . ' ' . $set['copyright'] . '</small></div>';
echo '<div><small>Powered by <a href="http://johncms.com">JohnCMS 6.1.2</a></small></div>';
echo '</div></body></html>';
