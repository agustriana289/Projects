Ukrainian language pack
============================================================
TRANSLATION AUTHORS:
Reason (http://uamobi.net, ro-mi-ch@mail.ru) Версія перекладу від 13.08.2011