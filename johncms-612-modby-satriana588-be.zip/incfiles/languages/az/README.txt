Azerbaijani language pack
============================================================
TRANSLATION AUTHORS:
Camal (http://freemobi.us, wapbiz@mail.ru)
BEYDI (http://BEYAZ.RU, beyditurk@gmail.com), Azerbaijan web masters BEYDI