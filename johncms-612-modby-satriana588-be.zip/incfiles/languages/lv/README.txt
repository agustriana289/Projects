Latvian language pack
============================================================
DRAFT! Required to edi
============================================================
TRANSLATION AUTHORS:
AgS (http://ags.h2m.ru, agss@inbox.lv)