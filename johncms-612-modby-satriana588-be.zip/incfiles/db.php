<?php

defined('_IN_JOHNCMS') or die ('Error: restricted access');

$db_host = 'mysql.idhostinger.com';
$db_name = 'u263182437_kshdr';
$db_user = 'u263182437_kshur';
$db_pass = 'laillahailallah58';