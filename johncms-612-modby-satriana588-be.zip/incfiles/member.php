<?
$online = array();
$usere = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
$tamune = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
if ($usere >= 1)
echo 'User online: ';
else
echo 'No User online';
$hadir = @mysql_query("SELECT * FROM `users` WHERE `lastdate` >= '" . intval(time() - 300) . "' ORDER BY RAND() LIMIT 5 ;");
$hitung = mysql_num_rows($hadir);
while ($notal = mysql_fetch_array($hadir)){
$online[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?user=' . $notal['id'] . '"><b>' . $notal['name'] . '</b></a>';
}
if (($usere >= 1) && ($usere <= 5)){
echo implode(', ',$online).'.';
} elseif ($usere >= 6){
$minus = $usere - 5;
echo implode(', ',$online).'.';
echo ' <a href="' . core::$system_set['homeurl'] . '/users/index.php?act=online">' . $minus . ' More</a>';
}
//guest//
echo '<br/>Guest: ';
if ($tamune >= 1)
echo '<a href="' . core::$system_set['homeurl'] . '/users/index.php?act=online&amp;mod=guest">' . $tamune . '</a><br/>';
else
echo 'No guest<br/>';
//new member//
echo 'New Member:&nbsp;';
$req = mysql_query("SELECT `id`, `name`, `datereg` FROM `users` WHERE (preg='1') ORDER BY `datereg` DESC LIMIT 1; ");
$arr = mysql_fetch_array($req);
echo '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?user='.$arr['id'] .'"><b>'.$arr['name'] .'</b></a>';
?>
