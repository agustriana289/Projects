<?

/*NGUPRUS.COM FREE THEME V6.5.1 ORIGINAL FILE*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();
/*
-----------------------------------------------------------------
Notif [web] -----------------------------------------------------------------
*/
if ($user_id) {
echo '<div class="phdr"><b>Quickchat</b></div>';
	echo '<div class="gmenu"><form action="mchat/index.php?act=add" name="add" method="post">' .
        'Сообщение (max 500):<br />';
    echo bbcode::auto_bb('add', 'message');
    echo '<textarea rows="' . $set_user['field_h'] . '" name="message"></textarea><br />' .
        '<input type="submit" name="submit" value="Сказать" /></form></div>';
}
$total = mysql_result(mysql_query('select count(*) from `m_chat`'), 0);
if ($total) {
	$req = mysql_query('select * from `m_chat` order by `time` desc limit 3;');
	$i = 0;
	while ($res = mysql_fetch_assoc($req)) {
		echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
		$User = mysql_fetch_assoc(mysql_query('select * from `users` where `id` = ' . $res['user_id'] . ';'));
		echo (time() > $User['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>&#160;');
		echo !$User_id || $User_id == $User['id'] ? '<b>' . $User['name'] . '</b>&#160;' : '<a href="' . $home . '/users/profile.php?user=' . $User['id'] . '"><b>' . $User['name'] . '</b></a>&#160;';
		if ($res['cid']) {
			$view = mysql_fetch_assoc(mysql_query('select * from `m_chat` join `users` on `m_chat`.`user_id` = `users`.`id` and `m_chat`.`id` = '.$res['cid'].';'));
			$view_post = functions::checkout($view['message'], 1, 1);
			if ($set_user['smileys'])
				$view_post = functions::smileys($view_post, $User['rights'] >= 1 ? 1 : 0);
			echo '<div class="quote"><b>' . $view['name'] . '</b>&nbsp;(' . functions::display_date($view['time']) . ')<br />' . $view_post . '</div>';
		}
		$post = functions::checkout($res['message'], 1, 1);
         if ($set_user['smileys'])
            $post = functions::smileys($post, $User['rights'] >= 1 ? 1 : 0);
		echo $post;
		echo '</div>';
		$i++;
	}
} else {
	echo '<div class="menu">Пусто</div>';
}
echo '<div class="phdr"><b>' . $lng['information'] . '</b></div>';

/*
-----------------------------------------------------------------
??????? ????????? ? ????
-----------------------------------------------------------------
*/
if (!empty($ban)) echo '<div class="alarm">' . $lng['ban'] . '&#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=ban">' . $lng['in_detail'] . '</a></div>';

/*
-----------------------------------------------------------------
?????? ?? ?????????????
-----------------------------------------------------------------
*/

//
echo $mp->news;
echo '<div class="menu"><a href="/news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</div>';
echo '<div class="menu"><a href="/pages/faq.php">' . $lng['information'] . ', FAQ</a></div>';

/*
-----------------------------------------------------------------
???? ???????
-----------------------------------------------------------------
*/
echo '<div class="phdr"><b>' . $lng['dialogue'] . '</b></div>';
// ?????? ?? ????????
if ($set['mod_guest'] || $rights >= 7)
    echo '<div class="menu"><a href="/guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</div>';
// ?????? ?? ?????
if ($set['mod_forum'] || $rights >= 7)
    echo '<div class="menu"><a href="/forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>';

/*
-----------------------------------------------------------------
???? ?????????
-----------------------------------------------------------------
*/    
echo '<div class="phdr"><b>' . $lng['useful'] . '</b></div>';
// ?????? ?? ????????
if ($set['mod_down'] || $rights >= 7)
    echo '<div class="menu"><a href="/download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</div>';
// ?????? ?? ??????????
if ($set['mod_lib'] || $rights >= 7)
    echo '<div class="menu"><a href="/library/">' . $lng['library'] . '</a> (' . counters::library() . ')</div>';
// ?????? ?? ??????????
if ($set['mod_gal'] || $rights >= 7)
    echo '<div class="menu"><a href="/gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</div>';
if ($user_id || $set['active']) {
    echo '<div class="phdr"><b>' . $lng['community'] . '</b></div>' .
        '<div class="menu"><a href="/users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')</div>' .
        '<div class="menu"><a href="/users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</div>';
}
?>