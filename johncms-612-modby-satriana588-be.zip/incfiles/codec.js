var msg=document.getElementsByName("maintxt");
for(var i=0;i<msg.length;i++){
var oldtext=document.getElementsByName("maintxt")[i].innerHTML;
var newtext=oldtext.replace(/(^|[\n ])([\w]+?:\/\/[^ ,\"\n\r\t<]*)/ig,'$1<a href="$2" target="_blank">$2</a>');
newtext=newtext.replace(/\[img\](.+?)\[\/img\]/ig,'<img src="$1" alt="'+document.title+'" title="'+document.title+'" style="max-width:100%" />'); document.getElementsByName("dpro")[i].innerHTML=newtext;}
var msga=document.getElementsByName("maintxt");
for(var i=0;i<msga.length;i++){
var txt=document.getElementsByName("maintxt")[i].innerHTML;
txt=txt.replace(/\[youtube=(.+?)\]/ig,'<div name="video"><embed type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="100%" height="400px" src="$1&vq=large"/></div>');
txt=txt.replace(/\[PHP\]/ig,'<pre class="quote1"><code name="codes" class="code">');
txt=txt.replace(/\[\/PHP\]/ig, "</code></pre>");
txt=txt.replace(/\[left\]/ig,'<div align="left">');
txt=txt.replace(/\[\/left\]/ig, "</div>");
txt=txt.replace(/\[center\]/ig,'<center>');
txt=txt.replace(/\[\/center\]/ig, "</center>");
txt=txt.replace(/\[right\]/ig,'<div align="right">');
txt=txt.replace(/\[\/right\]/ig, "</div>");
txt=txt.replace(/\[justify\]/ig,'<div align="justify">');
txt=txt.replace(/\[\/justify\]/ig, "</div>");
txt=txt.replace(/\[p=(.+?)\]/ig,'<p align="$1">');
txt=txt.replace(/\[p\]/ig,'<p>');
txt=txt.replace(/\[\/p\]/ig, "</p>");
txt=txt.replace(/\[input=(.+?)\]/ig,'<span name="codes"><input type="$1" value="');
txt=txt.replace(/\[\/input\]/ig,'"></input></span>');
txt=txt.replace(/\[div=(.+?)\]/ig,'<div class="$1">');
txt=txt.replace(/\[\/div\]/ig,'</div>');
txt=txt.replace(/\[span=(.+?)\]/ig,'<span class="$1">');
txt=txt.replace(/\[\/span\]/ig,'</span>');
txt=txt.replace(/\[text\]/ig,'<div class="hide">KONTEN INI HANYA BISA DILIHAT OLEH MEMBER!!!</div><textarea class="show" rows="3">');
txt=txt.replace(/\[youtube\](.+?)\[\/youtube\]/ig,'<embed type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="100%" height="400px" src="http://youtube.com/v/$1&vq=large"/>');
txt=txt.replace(/\[\/text\]/ig, "</textarea>");
txt=txt.replace(/\[form\]/ig,'<form method="get" action="site_0.xhtml">');
txt=txt.replace(/\[\/form\]/ig, "</form>");
txt=txt.replace(/\[option\]/ig, "<option>");
txt=txt.replace(/\[\/option\]/ig, "</option>");
txt=txt.replace(/\[select\]/ig, "<select>");
txt=txt.replace(/\[\/select\]/ig, "</select>");
txt=txt.replace(/\[indent\]/ig,'<div style="margin-left:12px">');
txt=txt.replace(/\[you\]/ig, ':user:');
txt=txt.replace(/\[\/indent\]/ig, "</div>");
txt=txt.replace(/\[OL\]/ig,'<div id="mf_content" style="padding:0px 10px 0px"><ol>');
txt=txt.replace(/\[\/OL\]/ig, "</ol></div>");
txt=txt.replace(/\[UL\]/ig,'<div id="mf_content" style="padding:0px 10px 0px"><ul>');
txt=txt.replace(/\[\/UL\]/ig, "</ul></div>");
txt=txt.replace(/\[LI\]/ig, "<li>");
txt=txt.replace(/\[\/LI\]/ig, "</li>");
txt=txt.replace(/\[TD\]/ig, '<td class="td" style="padding:2px">');
txt=txt.replace(/\[\/TD\]/ig, '</td>');
txt=txt.replace(/\[TH\]/ig, '<td class="th" style="padding:2px">');
txt=txt.replace(/\[\/TH\]/ig, '</th>');
txt=txt.replace(/\[CAPTION\]/ig, '<caption>');
txt=txt.replace(/\[\/CAPTION\]/ig, '</caption>');
txt=txt.replace(/\[table\]/ig, '<table width="100%">');
txt=txt.replace(/\[\/table\]/ig, '</table>');
txt=txt.replace(/\[TR\]/ig, '<tr>');
txt=txt.replace(/\[\/TR\]/ig, '</tr>');
txt=txt.replace(/\[TD=(.+?)\]/ig,'<td width="$1" class="td" style="padding:2px">');
txt=txt.replace(/\[FLASH\](.+?)\[\/FLASH\]/ig, '<object width="100%" height="400"><param name="movie" value="$1" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><embed width="100%" height="400" src="$1" quality="high" wmode="transparent" type="application/x-shockwave-flash"></embed></object>');
txt=txt.replace(/\[hidden\]/ig,'<div class="hidden">KONTEN INI TELAH DISEMBUNYIKAN KLIK BALAS UNTUK MENYALIN KODE.</div><div style="display:none">');
txt=txt.replace(/\[\/hidden\]/ig,'</div>');
txt=txt.replace(/\[penting\]/ig,'<div class="important"><div class="head">Penting:</div><div class="body">');
txt=txt.replace(/\[\/penting\]/ig,'</div></div>');
txt=txt.replace(/\[khusus\]/ig,'<div class="hide">KONTEN INI HANYA BISA DILIHAT OLEH MEMBER!!!</div><div class="show">');
txt=txt.replace(/\[\/khusus\]/ig,'</div>');
txt=txt.replace(/\[quote\]/ig,'<div class="quote"><div class="text">');
txt=txt.replace(/\[\/quote\]/ig,'</div></div>');
txt=txt.replace(/\[quote=(.+?)\]/ig,'<div class="quote"><div class="head">Dikutip dari <a href="/profile_0.xhtml?u=$1" title="Profil $1">$1</a></div><div class="text">');
txt=txt.replace(/\[fb.(.+?)\]/ig, '<img src="http://pagu.jw.lt/emo/$1.png" alt="emoticon facebook" title="emoticon facebook" width="16px" height="16px" />');
txt=txt.replace(/\[\[f9.(.+?)\]\]/ig, '<img src="https://graph.facebook.com/f9.$1/picture" width="30px" height="30px" alt="emoticon facebook" title="emoticon facebook" />');
txt=txt.replace(/\[\[(.+?)\]\]/ig, '<img src="https://graph.facebook.com/$1/picture" alt="emoticon facebook" title="emoticon facebook" />'); txt=txt.replace(/\[rainbow\](.+?)\[\/rainbow\]/ig,'<span name="rainbow">$1</span>');
document.getElementsByName("maintxt")[i].innerHTML=txt;}
var msgc=document.getElementsByName('video');
for(var i=0;i<msgc.length;i++){
var tx=document.getElementsByName('video')[i].innerHTML;
tx=tx.replace(/watch/ig,'');
tx=tx.replace(/v=/ig,'v/');
tx=tx.replace('?','');
document.getElementsByName('video')[i].innerHTML=tx;}
var msgb=document.getElementsByName("rainbow");
for(var i=0;i<msgb.length;i++){
ray2=document.getElementsByName('rainbow')[i].innerHTML;
ray3=ray2.split("");
ray4=["#FF0000","#FF3500","#FF6A00","#FF9F00","#FFD400","#FFff00","#CAff00","#95ff00","#60ff00","#2Bff00","#00ff00","#00ff35","#00ff6A","#00ff9F","#00ffD4","#00ffff","#00D4ff","#009Fff","#006Aff","#0035ff","#0000ff","#2B00ff","#6000ff","#9500ff","#CA00ff","#FF00ff","#FF00D4","#FF009F","#FF006A","#FF0000","#FF3500","#FF6A00","#FF9F00","#FFD400","#FFff00","#CAff00","#95ff00","#60ff00","#2Bff00","#00ff00","#00ff35","#00ff6A","#00ff9F","#00ffD4","#00ffff","#00D4ff","#009Fff","#006Aff","#0035ff","#0000ff","#2B00ff","#6000ff","#9500ff","#CA00ff","#FF00ff","#FF00D4","#FF009F","#FF006A"];
text="";
for (var j=0;j<ray3.length;j++){
text += '<font color="'+ray4[j%58]+'">' + ray3[j] + '</font>';
document.getElementsByName('rainbow')[i].innerHTML=text;}}