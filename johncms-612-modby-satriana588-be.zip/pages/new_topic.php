<?php
/** New Topic Forum Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * Mod by Whiznoe http://www.waptok.asia
 */

$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 
echo '<div class="mainblok"><div class="phdr"><b>' . $lng['new_topic'] . '</b></div>'; 
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `id` DESC LIMIT $startreq, $kmessreq"); 
while ($arr = mysql_fetch_assoc($req)) { 
$nikuser = mysql_query("SELECT `from`,`id`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "' ORDER BY time DESC"); 
$colmes1 = mysql_num_rows($nikuser); 
$cpg = ceil($colmes1 / $kmess); 
$nam = mysql_fetch_assoc($nikuser);
echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
if ($arr['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
echo '<b>';
switch ($arr['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;

default:
break;
}
echo '</b>';
echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '.html">' . $arr['text'] . '</a> [' . $colmes1 . ']';
if ($cpg > 1)
echo '<small> <a href="/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&gt;&gt;</a></small>';
echo '<div class="sub">'.$arr['from'].' &raquo;&nbsp;';
if ($colmes1 > 1){
echo ''.$nam['from'].'';
}else
echo ''.$arr['from'].'';
echo '&nbsp;<span class="gray">' . counters::update_time($arr['time']) . '</span>';
echo '</div></div>';
$i++;
}

    if ($total > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php' . $id . '?', $startreq, $total, $kmessreq) . '</div>';

}

if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}


echo '</div>';
?>