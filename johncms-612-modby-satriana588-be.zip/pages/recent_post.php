<?php
echo '<div class="mainblok"><div class="phdr"><b>Recent Post</b></div>';
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `close` != '1' ORDER BY `time` DESC LIMIT 10");
$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="menu">' : '<div class="list1">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
if ($res['edit'])
echo '';
elseif ($res['close'])
echo '';
else
echo '';
if ($res['realid'] == 1)
echo '';
echo ' ' . functions::image('op.gif') . '<a href="'.$home.'/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a> (' . $colmes1 . ')';
echo '<br /><div class="sub">';
echo ''.$res['from'].'&nbsp;&raquo;&nbsp;';
if ($colmes1 > 1) {
echo '' . $nick['from'] . '';
}else
echo ''.$res['from'].'';
echo '</div></div>';
++$i;
}
echo '</div>';
?>
