<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/

if ($user_id) {
echo '<div class="mainblok">'; 
	echo '<div class="gmenu"><form action="mchat/index.php?act=add" name="add" method="post">' .
        'Text (max 500):<br />';
    echo bbcode::auto_bb('add', 'message');
    echo '<textarea rows="' . $set_user['field_h'] . '" name="message"></textarea><br />' .
        '<input type="submit" name="submit" value="Send" /></form></div>';
$total = mysql_result(mysql_query('select count(*) from `m_chat`'), 0);
if ($total) {
	$req = mysql_query('select * from `m_chat` order by `time` desc limit 3;');
	$i = 0;
	while ($res = mysql_fetch_assoc($req)) {
		echo $i % 2 ? '<div class="maintxt">' : '<div class="maintxt">';
		$User = mysql_fetch_assoc(mysql_query('select * from `users` where `id` = ' . $res['user_id'] . ';'));
		echo (time() > $User['lastdate'] + 300 ? '<span>' . functions::image('ofl.gif') . ' </span>&#160;' : '<span>' . functions::image('onl.gif') . ' </span>&#160;');
		echo !$User_id || $User_id == $User['id'] ? '<b>' . $User['name'] . '</b>&#160;' : '<a href="' . $home . '/users/profile.php?user=' . $User['id'] . '"><b>' . $User['name'] . '</b></a>&#160;';
			if ($res['cid']) {
			$view = mysql_fetch_assoc(mysql_query('select * from `m_chat` join `users` on `m_chat`.`user_id` = `users`.`id` and `m_chat`.`id` = '.$res['cid'].';'));
			$view_post = functions::checkout($view['message'], 1, 1);
			if ($set_user['smileys'])
				$view_post = functions::smileys($view_post, $User['rights'] >= 1 ? 1 : 0);
			echo '<div class="quote"><b>' . $view['name'] . '</b>&nbsp;(' . functions::display_date($view['time']) . ')' . $view_post . '</div>';
		}
		$post = functions::checkout($res['message'], 1, 1);
         if ($set_user['smileys'])
            $post = functions::smileys($post, $User['rights'] >= 1 ? 1 : 0);
		echo $post;
		echo '</div>';
		$i++;
	}
} else {
	echo '<div class="menu">Пусто</div>';
}
echo '<div class="none" align="center"><a href="' . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'] . '">Refresh</a> | <a href="/pages/faq.php?act=smileys">Smileys</a> | <a href="/pages/img.php">BBimg</a></div>';     

echo '</div>'; 
}
/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/ 
include'recent_post.php';
include'popular_topic.php';
include'forum_category.php';

echo '<div class="mainblok">';
echo '<div class="phdr"><b>' . $lng['useful'] . '</b></div>'; 

if ($set['mod_guest'] || $rights >= 7) 
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</div>'; 
if ($set['mod_forum'] || $rights >= 7) 
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>'; 

if ($set['mod_down'] || $rights >= 7)
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</div>'; 
if ($set['mod_lib'] || $rights >= 7)
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')</div>'; 

if ($set['mod_gal'] || $rights >= 7)
    echo '<div class="menu">';
echo '&bull;&nbsp;<a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</div>';
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</div>';
echo '<div class="menu">';
echo '&bull;&nbsp;<a href="pages/faq.php">' . $lng['information'] . '</a></div>';
echo '</div>';

if ($user_id) {
echo '<div class="mainblok"><div
class="phdr"><b>Statistics</b></div>';
echo'<div class="list1">&#x2022; Total Files: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . '</b></div>';
echo'<div class="list1">&#x2022; Total Topic: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `close` != '1'"), 0) . '</b></div>';
echo'<div class="list1">&#x2022; Total Post: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `close` != '1'"), 0) . '</b></div>';
$thanhvienmoi=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` ORDER BY `datereg` DESC LIMIT 1"));
$all_users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`;"), 0);

$users_boys = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'm';"), 0);

$users_girls = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'zh';"), 0);
 echo '<div class="menu">&#x2022; Member: <b>' . $users_boys . ' Male </b>and <b>' . $users_girls . ' Female</b></div>'; 
echo'</div>';
}
?>
