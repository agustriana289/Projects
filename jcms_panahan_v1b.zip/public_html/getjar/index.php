<?php
define('_IN_JOHNCMS', 1);
$headmod = 'Getjar';
$textl = 'Maling+Getjar';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if(isset($_GET['type']))
$type = $_GET['type'];
if(!empty($_GET['type'])){
$type=$_GET['type'];}else{
$type='mobile-all-software';}

$all='mobile-all-software';
$education='mobile-education-applications';
$sosialmessaging='mobile-social-and-messaging';
$intertainment='mobile-entertainment-applications';
$finance='mobile-finance-applications';
$food='mobile-food-applications';
$games='mobile-all-games';
$healt='mobile-health-applications';
$search='mobile-search-applications';
$lifestyle='mobile-lifestyle-applications';
$maps='mobile-maps-applications';
$music='mobile-music-applications';
$newsweather='mobile-news-and-weather';
$photos='mobile-photos-applications';
$productivity='mobile-productivity-applications';
$religi='mobile-religion-applications';
$shopping='mobile-shopping-applications';
$sport='mobile-sports-applications';
$travel='mobile-travel-applications';
$adult='mobile-adult-applications';

$v=$_GET['type'];
$va=explode('-',$v);
$val=$va[1];
$form='<form method=get action="">Category :<br><select name=type><option value='.$type.'>'.$val.'</otion><option value='.$all.'>All</otion><option value='.$education.'>Education</otion><option value='.$sosialmessaging.'>Sosil Messaging</otion><option value='.$intertainment.'>Intertainment</otion><option value='.$finance.'>Finance</otion><option value='.$food.'>Food</otion><option value='.$games.'>Games</otion><option value='.$healt.'>Healt</otion><option value='.$search.'>Search</otion><option value='.$lifestyle.'>Life Style</otion><option value='.$maps.'>Maps</otion><option value='.$music.'>Music</otion><option value='.$newsweather.'>News & Weather</otion><option value='.$photos.'>Photos</otion><option value='.$productivity.'>Productivity</otion><option value='.$religi.'>Religi</otion><option value='.$shopping.'>Shopping</otion><option value='.$sport.'>Sport</otion><option value='.$travel.'>Travel</otion><option value='.$adult.'>Adult</otion><input type=submit value=Go size=5>';

$rai=$_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
$br = $_SERVER['HTTP_USER_AGENT'];
if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])){
$ua = $rai;
} else {
$ua = $br;
}

ini_set('user_agent',$ua);
function raim($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}

$f='http://m.getjar.com/';
$ff=file_get_contents($f);
$devi=raim($ff,'download-code','Quick Download'); 
$sid=raim($devi,'&sid=','&lang');
$lvt=raim($devi,'&lvt=','&sid');
$devic=explode('/?ref=',$devi);
$device=$devic[0];


define('_IN_JOHNCMS', 1);
$headmod = 'Getjar';
$textl = 'Maling+Getjar';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
echo'<div class=judul>Getjar Software</div>';
echo'<div class=tengah>'.$form.'</div>';


if(isset($_GET['rai']))
{
$ur='http://m.getjar.com/mobile/'.$_GET['rai'];
$f=file_get_contents($ur);
$kabe=raim($f,'<form id="form_product_page"','value="Download"');
$linkrai=raim($kabe,'action="','" method');
header('content-type:text/plain');
header('location:'.$linkrai);
exit;
}


if(!empty($device)){$_SERVER['PHP_SELF'];}else{echo'<font color=red>Your browser is not supported</font>';}

$t='http://m.getjar.com/'.$type.''.$device.'/?ref=0&lvt='.$_GET['lvt'].'&sid='.$_GET['sid'].'&lang=en&o=top&p='.$_GET['p'].'&i='.$_GET['i'];
$tt=file_get_contents($t);

$mua=raim($tt,'<div id="apps">','<div id="footer">');
$al=explode('<div id="appnav" class="more_bar height20">',$mua);
$all=$al[0];
$all=preg_replace('#<div class="(.+?)">#siu','<div class="kiri">',$all);
$all=str_replace('/mobile/','?rai=',$all);
$mor=explode('<div id="appnav" class="more_bar height20">',$tt);
$more=$mor[1];
$more=preg_replace('#<div class="subcat_header">(.+?)</html>#siu','',$more);
$more=preg_replace('#<div id="footer">(.+?)</html>#siu','',$more);
$more=preg_replace('#<div id="(.+?)">#siu','<span class="judul">',$more);
$more=str_replace('</div>','</span>',$more);
$more=str_replace('<div>','',$more);
$more=preg_replace('#/?mobile-(.+?)ref=#siu','?type='.$type.'&ref=',$more);

if(!empty($all)){
echo'<div class="judul">'.str_replace('-',' ',$type).'</div>';
echo $all;}
if(!empty($more)){
echo '<div class="tengah">'.$more.'</div>';}

require_once ("../incfiles/end.php");
?>