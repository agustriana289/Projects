<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Comments on the constitution of the site';
if (!$user_id) {
require_once('../incfiles/head.php');
echo '<div class="rmenu">Comments are allowed to view only authorized!<br/>
<a href="../login.php">login here</a> | <a href="../registration.php">registration here</a><br/></div>';
require_once('../incfiles/end.php');
exit;
}
$id = intval($_GET['id']);
if (!isset($id) OR empty($id)) {
require_once('../incfiles/head.php');
echo '<div class="rmenu">Not listed article, which shows the comments!<br/>
<a href="index.php">contitution</a></div>';
require_once('../incfiles/end.php');
exit;
}
$var = mysql_fetch_array(mysql_query("SELECT * FROM `cons` WHERE `id` = $id"));
$komm = intval($_GET['komm']);
$komment = mysql_fetch_array(mysql_query("SELECT * FROM `cons_komm` WHERE `id`=$komm"));
$komms =  mysql_query("SELECT * FROM `cons_komm` WHERE `folder` = $id ORDER BY `date` DESC LIMIT $start, $kmess; ");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cons_komm` WHERE `folder` = $id"), 0);
require_once('../incfiles/head.php');
echo '<div class="phdr"><a href="'.$home.'/constitution/index.php">Sites Contitution</a> &raquo; Comments to section"<a href="'.$home.'/constitution/index.php?id='.$id.'"><b>'.$var['name'].'</b></a>"</div>'; 
switch ($act) {
/*
==========================
    УДАЛЕНИЕ КОММЕНТОВ
==========================
*/
case 'del':
if ($rights >= 7) {
echo '<div class="rmenu">You are about to delete the comment <b>'. mb_substr($komment['text'], 0, 50) .'</b>?</div>';
echo '<div class="menu"><a href="komm.php?act=yes&amp;id='.$id.'&amp;komm='.$komm.'">yes</a> | <a href="komm.php?id='.$komment['folder'].'">no</a></div>';
} else {
header('location: komm.php?id='.$id.' ');
}
break;
case 'yes':
$komm = intval($_GET['komm']);
$komment = mysql_fetch_array(mysql_query("SELECT * FROM `cons_komm` WHERE `id`=$komm"));
if (($rights >= 7) AND (!empty($komm))) {
mysql_query("DELETE FROM `cons_komm` WHERE `id`=$komm ");
mysql_query("UPDATE `users` SET `komm`=komm-1 WHERE `id`=". $komment['author'] ."");
echo '<div class="menu">Comment deleted successfully!</div>';
} else {
header('location: komm.php?id='.$id.' ');
}
break;
/*
==========================
  ДОБАВЛЕНИЕ КОММЕНТОВ
==========================
*/
case 'addkomm':
$text = functions::check(mb_substr($_POST['text'], 0, 1000));
if (empty($text)) {
echo '<div class="rmenu">Error! No text of your comment!<br/></div>';
} else {
mysql_query("INSERT INTO `cons_komm` SET
`folder` = '$id',
`date` = '".time()."',
`author` = '$user_id',
`text` = '$text'");
mysql_query("UPDATE `users` SET `komm`=komm+1 WHERE `id`=$user_id");
header('location: komm.php?id='.$id.'');
}
break;
/*
==========================
РЕДАКТИРОВАНИЕ КОММЕНТОВ
==========================
*/
case 'edit':
if (($rights >= 7) AND (!empty($komm))) {
echo '<form name="edit" action="komm.php?act=editkomm&amp;id='.$id.'&amp;komm='.$komm.'" method="post"><div class="rmenu">
Edit comments: (max. 1000):
<br/> '.bbcode::auto_bb('edit', 'text').'
<textarea rows="' . $set_user['field_h'] . '" name="text"> ' . str_replace('<br />', "\r\n", $komment['text']) . '</textarea>
<br/><input type="submit" value="submit"/>
</div></form>';
} else {
header('location: komm.php?id='.$id.' ');
}
break;
case 'editkomm':
if (($rights == 1 || $rights >= 5) AND (!empty($komm))) {
$text = functions::check(mb_substr($_POST['text'], 0, 1000));
mysql_query("UPDATE `cons_komm` SET `text` = '$text' WHERE `id`=$komm ");
header('location: komm.php?id='.$id.'');
} else {
header('location: komm.php?id='.$id.' ');
}
break;
/*
==========================
    СПИСОК КОММЕНТОВ
==========================
*/
default:
echo '<form name="add" action="komm.php?act=addkomm&amp;id='.$id.'" method="post"><div class="list2">
Add new comment: (max. 1000):
<br/> '.bbcode::auto_bb('add', 'text').'
<textarea rows="' . $set_user['field_h'] . '" name="text"></textarea>
<br/><input type="submit" value="add comments"/>
</div></form>';
$i = 0;
while ($result = mysql_fetch_array($komms)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$author = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`=".$result['author'].""));
echo "<a href='".$home."/users?profile.php?user=".$author['id']."'>".$author['name']."</a>";
switch ($author['rights']) {
case 9:
echo ' <small>(SV!)</small>';
break;
case 7:
echo ' <small>(Adm)</small>';
break;
case 6:
echo ' <small>(Smd)</small>';
break;
case 5:
echo ' <small>(Lmod)</small>';
break;
case 4:
echo ' <small>(Dmod)</small>';
break;
case 3:
echo ' <small>(Fmod)</small>';
}
$offline = $author['lastdate'];
$online = $offline + 300;
if (time() > $online) {
echo '<small><font color="#FF0000"> (Off)</font></small>';
} else {
echo '<small><font color="#00AA00"> (On)</font></small>';
}
echo '<br/><small>(' . functions::display_date($result['date']) . ')</small><br/>';
echo ''. functions::smileys(bbcode::tags($result['text'])).'';
if ($rights >= 7) {
echo "<br/>[<a href='komm.php?act=edit&amp;id=".$id."&amp;komm=".$result['id']."'><b>edit</b></a> | <a href='komm.php?act=del&amp;id=".$id."&amp;komm=".$result['id']."'><b>del</b></a>]";
}
echo '</div>';
++$i;
}
echo '<div class="menu"><a href="index.php?id='.$id.'">contitutions</a></div>';
echo '<div class="bmenu">total comments: '.$total.'</div>';
if ($total > $kmess) {
echo functions::display_pagination('komm.php?id='.$id.'&amp;', $start, $total, $kmess);
}
break;
}
if ($act) {
echo '<div class="phdr"><a href="komm.php?id='.$id.'">to comments</a></div>';
}
require_once('../incfiles/end.php');
?>
