<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = ' Admin constitution';
require_once('../incfiles/head.php');
if ($rights <=7) {
require_once('../incfiles/head.php');
echo '<div class="rmenu">Nelostatochno rights!</div>';
require_once('../incfiles/end.php');
exit;
}
switch ($act) {
//  adding an article
case 'add':
echo '<div class="bmenu">Add an article in the constitution</div>';
echo '<form name="add" action="admin.php?act=addend" method="post"><div class="list2">
Title: (max. 255):<br/>
<input type="text" name="name" value=""/><br/>
Text (max. 15 000):<br/> 
'.bbcode::auto_bb('add', 'text').'
<textarea rows="' . $set_user['field_h'] . '" name="text"></textarea><br/>
 Number of articles: (number, "2" - will print the second in the list, assign a second number):<br/>
<input type="text" name="number" value=""/><br/>
<input type="submit" value="submit"/>
</div></form>';
break;
case 'addend':
$name = htmlspecialchars($_POST['name']);
$text = functions::check(mb_substr($_POST['text'], 0, 15000));
$number = intval($_POST['number']);
if (empty($text) OR empty($name) OR empty($number)) {
echo '<div class="rmenu">Error! All fields are required <br/><a href="admin.php?act=add">Fill in the re-</a></div>';
} else {
mysql_query("INSERT INTO `cons` SET
`name` = '$name',
`text` = '$text',
`date` = '".time()."',
`number` = '$number'");
header('location: index.php');
}
break;
// удаление статьи
case 'del':
$id = intval($_GET['id']);
if (!isset($id) OR empty($id)) {
echo '<div class="rmenu">Not listed article, which remove<br/>
<a href="index.php">By the constitution</a></div>';
require_once('../incfiles/end.php');
exit;
} else {
echo '<div class="menu">Really delete?<br/><a href="admin.php?act=delend&amp;id='.$id.'">yes</a> | <a href="index.php?id='.$id.'">no</a></div>';
}
break;
case 'delend':
$id = intval($_GET['id']);
if (!isset($id) OR empty($id)) {
echo '<div class="rmenu">Not listed article, which remove<br/>
<a href="index.php">contitution</a></div>';
require_once('../incfiles/end.php');
exit;
} else {
mysql_query("DELETE FROM `cons` WHERE `id`=$id ");
mysql_query("DELETE FROM `cons_komm` WHERE `folder`=$id ");
header('location: index.php');
}
break;
// редактирование статьи
case 'edit':
$id = intval($_GET['id']);
if (!isset($id) OR empty($id)) {
echo '<div class="rmenu">Not listed article that edit<br/>
<a href="index.php">contitution</a></div>';
require_once('../incfiles/end.php');
exit;
} else {
$prg = mysql_fetch_array(mysql_query("SELECT * FROM `cons` WHERE `id`=$id"));
echo '<div class="bmenu">Edit the article</div>';
echo '<form name="edit" action="admin.php?act=editend&amp;id='.$id.'" method="post"><div class="rmenu">
Title: (max. 255):<br/>
<input type="text" name="name" value="'.$prg['name'].'"/><br/>
Text (max. 15 000):<br/> 
'.bbcode::auto_bb('edit', 'text').'
<textarea rows="' . $set_user['field_h'] . '" name="text">' . str_replace('<br />', "\r\n", $prg['text']) . '</textarea><br/>
Number: (For example, "2" - will print the second in the list, assign a second number):<br/>
<input type="text" name="number" value="'.$prg['number'].'"/><br/>
<input type="checkbox" value="" name="up"/>&#160;Report updating the article<br/>
<input type="submit" value="submite"/>
</div></form>';
}
break;
case 'editend':
case 'edit':
$id = intval($_GET['id']);
if (!isset($id) OR empty($id)) {
echo '<div class="rmenu">Not listed article that edit<br/>
<a href="index.php">constitution</a></div>';
require_once('../incfiles/end.php');
exit;
} else {
$name = htmlspecialchars($_POST['name']);
$text = functions::check(mb_substr($_POST['text'], 0, 15000));
$number = intval($_POST['number']);
if (empty($text) OR empty($name) OR empty($number)) {
echo '<div class="rmenu">Error! All fields are required<br/><a href="admin.php?act=edit&amp;id='.$id.'">Fill in the re-</a></div>';
} else if (isset($_POST['up'])) {
mysql_query("UPDATE `cons` SET
`name` = '$name',
`text` = '$text',
`up` = '".time()."',
`number` = '$number'
WHERE `id`=$id ");
header('location: index.php');
} else {
mysql_query("UPDATE `cons` SET
`name` = '$name',
`text` = '$text',
`number` = '$number'
WHERE `id`=$id ");
header('location: index.php');
}
}
break;
}
require_once('../incfiles/end.php');
?>
