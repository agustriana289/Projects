<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Terms and Privasi';
require_once('../incfiles/head.php');
$id = intval($_GET['id']);
if (empty($id) OR $id == 0) {
// сРисРР РараграфРв (статеР)
$prg = mysql_query("SELECT * FROM `cons` ORDER BY `number`");
echo '<div class="mainblok">';
echo '<div class="phdr">'.$textl.'</div>';
if (mysql_num_rows($prg) != 0)
{
echo '<div class="menu"><b>Constitution List</b></div>';
while ($data = mysql_fetch_array($prg))
{
echo '<div class="menu">
<b>'.$data['number'].'.</b> <a href="index.php?id='.$data['id'].'">'.$data['name'].'</a></div></div>';
}
} else echo 'There are no items in the list!';
if ($rights >= 7) echo '<div class="phdr"><a href="admin.php?act=add">Write an article of the constitution </a></div>';
} else {
// вывР�д Р�араграфа (статьи)
$prg = mysql_fetch_array(mysql_query("SELECT * FROM `cons` WHERE `id`=$id "));
$komms = mysql_result(mysql_query("SELECT COUNT(*) FROM `cons_komm` WHERE `folder` = $id"), 0);
echo '<div class="mainblok">';
echo '<div class="phdr"><a href="index.php">'.$textl.'</a> | '.$prg['name'].'</div>';
echo '<div class="menu">';
echo 'Article came into force: '.functions::display_date($prg['date']).'<br/>';
if (!empty($prg['up'])) {
echo 'The article changed: '.functions::display_date($prg['up']).'<br/>';
}
echo '<b>Article:</b><br/>'. functions::smileys(bbcode::tags($prg['text'])).'';
echo '</div>';
echo '<div class="bmenu"><a href="komm.php?id='.$prg['id'].'">comments ('.$komms.')</a></div>';
if ($rights >= 7) {
echo '<div class="rmenu"><a href="admin.php?act=edit&amp;id='.$prg['id'].'">Edit Article</a> | <a href="admin.php?act=del&amp;id='.$prg['id'].'">Remove article</a></div></div>';
}
}
require_once('../incfiles/end.php');
?>
