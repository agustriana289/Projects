<?
/*
Originally by: FIKTIFisme
Modded by kayukalek.org
*/

$user_u = $res['user_id'];
$req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_u' LIMIT 1");
$res_u = mysql_fetch_array($req_u);
$exp = $res_u['postforum'] + $res_u['postguest'] + $res_u['komm'];
if ($res_u['rights']<3){

if ($exp>=0 && $exp<=50)
echo 'Newbie';
if ($exp>=50 && $exp<=100)
echo 'Wapmodz Users';
if ($exp>=100 && $exp<=200)
echo 'Aktivis Wapmodz';
if ($exp>=200 && $exp<=500)
echo 'Wapmodz Holic';
if ($exp>=500 && $exp<=750)
echo 'Wapmodz Addict';
if ($exp>=750 && $exp<=1000)
echo 'Wapmodz Maniac';
if ($exp>=1000 && $exp<=1200)
echo 'Wapmodz Geek';
if ($exp>=1200 && $exp<=1500)
echo 'Wapmodz Freak';
if ($exp>=1500 && $exp<=2000)
echo 'Made in Wapmodz';
}else{
$user_rights = array(
3 => '<span class="red">Moderator</span>',
6 => '<span class="red">CoAdmin</span>',
7 => '<span class="red">Admin</span>',
9 => '<span class="red"><b>Owner</b></span>'
);
echo @$user_rights[$res['rights']];
}
?>