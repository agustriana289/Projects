<?php
define('_IN_JOHNCMS', 1);
$headmod = 'anime';
require('../incfiles/core.php');
if(empty($_SESSION['error']))
	$_SESSION['error'] = '';
//Функция отображения рейтинга
function rating($id, $type = 0) {
	if(!$id)
		return '<img class="ico" src="../goblogs/stars/stars_5.gif" alt="0" />';
	$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_rating` WHERE `news`='$id'"), 0); 
	if($total) {
		$query = mysql_query("SELECT `golos`, COUNT(*) as `count` FROM `goblogs_rating` WHERE `news`='$id' GROUP BY `golos`");
		$array['plus'] = 0;
		$array['minus'] = 0;
		while (($row = mysql_fetch_assoc($query)) !== false) {
			if(isset($row['golos']) && $row['golos'] == 1) $array['plus'] = $row['count'];
			else if(isset($row['golos']) && $row['golos'] == 2) $array['minus'] = $row['count'];
			else {
				$array['plus'] = 0;
				$array['minus'] = 0;
			}
		}
		if($array['plus'] > $array['minus']) {
			if($array['minus'] == 0) {
				if($array['plus'] == 1) $count = 60;
				else if($array['plus'] == 2) $count = 60;
				else if($array['plus'] == 3) $count = 60;
				else if($array['plus'] == 4) $count = 70;
				else if($array['plus'] == 5) $count = 70;
				else if($array['plus'] == 6) $count = 80;
				else if($array['plus'] == 7) $count = 80;
				else if($array['plus'] == 8) $count = 90;
				else if($array['plus'] == 9) $count = 90;
				else if($array['plus'] >= 10) $count = 100;
			} else {
				$count = round($array['minus'] / $array['plus'], 1) * 100;
				if($count == 0)	$count = 100;
				else $count = (100 - $count);
			}
		} else if($array['plus'] < $array['minus']) {
			if($array['plus'] == 0) {
				if($array['minus'] == 1) $count = 40;
				else if($array['minus'] == 2) $count = 40;
				else if($array['minus'] == 3) $count = 40;
				else if($array['minus'] == 4) $count = 30;
				else if($array['minus'] == 5) $count = 30;
				else if($array['minus'] == 6) $count = 20;
				else if($array['minus'] == 7) $count = 20;
				else if($array['minus'] == 8) $count = 10;
				else if($array['minus'] == 9) $count = 10;
				else if($array['minus'] >= 10) $count = 0;
			} else {
				$pr = (round($array['plus'] / $array['minus'], 1) * 100);
				$count = $pr;
			}
		} else
			$count = 50;
		$percent = $count;
		if($percent == 100)	$stars = 10;
		else if($percent < 100 && $percent >= 90) $stars = 9;
		else if($percent < 100 && $percent >= 90) $stars = 9;
		else if($percent < 90 && $percent >= 80) $stars = 8;
		else if($percent < 80 && $percent >= 70) $stars = 7;
		else if($percent < 70 && $percent >= 60) $stars = 6;
		else if($percent < 60 && $percent >= 50) $stars = 5;
		else if($percent < 50 && $percent >= 40) $stars = 4;
		else if($percent < 40 && $percent >= 30) $stars = 3;
		else if($percent < 30 && $percent >= 20) $stars = 2;
		else if($percent < 20 && $percent >= 10) $stars = 2;
		else if($percent < 10 && $percent > 0) $stars = 1;
		else if($percent == 0) $stars = 0;
		if($type == 0) return '<img class="ico" src="../goblogs/stars/stars_'.$stars.'.gif" alt="&bull;" />';
		else return $percent;
	} else return '<img class="ico" src="../goblogs/stars/stars_5.gif" alt="&bull;" />';
}
if($id) {
	$query = mysql_query("SELECT `goblogs`.*, `goblogs_cat`.`name` as `catname`, `goblogs_cat`.`id` as `catid` FROM `goblogs` LEFT JOIN `goblogs_cat` ON `goblogs`.`refid`=`goblogs_cat`.`id` WHERE `goblogs`.`id`='$id'".($rights < 7 ? " AND `goblogs`.`time`<='" . time() . "'":"")." LIMIT 1;");
	if (mysql_num_rows($query)) {
		//Показываем новость
		$res1 = mysql_fetch_assoc($query);
		$textl =  'Blogs | ' . htmlentities($res1['name'], ENT_QUOTES, 'UTF-8');
		require_once('../incfiles/head.php');
		include($rootpath . 'goblogs/social_bookmarking.php');
		echo '<div class="phdr">'.facebook().' '.twitter().'<h3><center>' . htmlentities($res1['name'], ENT_QUOTES, 'UTF-8') . '</center></h3></div>';
		echo '<div class="list1">';
		//Выводим картинку
		if(file_exists('../files/goblogs/news_' . $id . '.jpg') !== false)
			echo '<img style="float: left; margin: 5px 6px 2px 2px; border: 0px;" src="../files/goblogs/news_' . $id . '.jpg" alt=""/>';
		$text = functions::checkout($res1['text'], 1, 1);
		if ($set_user['smileys'])
			$text = functions::smileys($text);
		echo $text;
		echo '<div style="clear:both;"></div></div>';
		//Обрабатываем голосование
		if(isset($_POST['plus_x']) || isset($_POST['plus_y'])) {
			if($res1['user_id'] == $user_id) {
				$_SESSION['error'] = '<div class="list1 red">Anda tidak boleh menilai blog sendiri!</div>';
			} else {
				$plus = mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_rating` WHERE `news`='$id' AND `user_id`='$user_id' LIMIT 1;"), 0);
				if($plus) {
					$_SESSION['error'] = '<div class="list1 red">Penilaian sudah diterima!</div>';
				} else {
					mysql_query("INSERT INTO `goblogs_rating` SET
					`news`='$id',
					`user_id`='$user_id', `golos`='1';");
					$_SESSION['error'] = '<div class="list1 green">Penilaian diterima!</div>';
				}
			}
			Header('Location: view.php?id=' . $id);
			exit;
		} else if(isset($_POST['minus_x']) || isset($_POST['minus_y'])) {
			if($res1['user_id'] == $user_id) {
				$_SESSION['error'] = '<div class="list1 red">nda tidak boleh menilai blog sendiri!</div>';
			} else {
				$plus = mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_rating` WHERE `news`='$id' AND `user_id`='$user_id' LIMIT 1;"), 0);
				if($plus) {
					$_SESSION['error'] = '<div class="list1 red">Penilaian sudah diterima!</div>';
				} else {
					mysql_query("INSERT INTO `goblogs_rating` SET
					`news`='$id',
					`user_id`='$user_id', `golos`='2';");
					$_SESSION['error'] = '<div class="list1 green">Penilaian diterima!</div>';
				}
			}
			Header('Location: view.php?id=' . $id);
			exit;
		}
		//Сообщение об оставленном голосе
		echo $_SESSION['error'];
		//Выводим автора новости
		$us = mysql_query("SELECT `id`, `name` FROM `users` WHERE `id` = '{$res1['user_id']}'");
		if (mysql_num_rows($us)) {
			$rowuse = mysql_fetch_assoc($us);
			$name_use = $user_id ? '<a href="../users/profile.php?id=' . $rowuse['id'] . '">' . $rowuse['name'] . '</a>' : $rowuse['name'];
		} else {
			$name_use = $lng['guest'];
		}
		//
		mysql_query("UPDATE `goblogs` SET  `count` = (`count`+1) WHERE `id` = '$id'");
	
		echo '<div class="list2"><span class="underline">' . $lng['rating'] . ':</span> ' . rating($id) . '<br />
		'.($user_id ? '<form action="view.php?id=' . $id . '" method="post"><div>
		<input style="cursor:none; border: 0px; padding: 0;padding-top: 2px; margin: 0;" type="image" name="plus" value="15" src="../goblogs/like_yes1.gif" alt="like"/><input class="rate" style="cursor:none; border: 0px; margin: 0; padding: 0;padding-top: 2px;" type="image" src="../goblogs/like_no1.gif" name="minus" alt="-"/>
		</div></form>':'<img class="ico" src="../goblogs/like_yes1.gif" alt="+" /><img class="ico" src="../goblogs/like_no1.gif" alt="-" /><br />').'
		</div><div class="gmenu">
		Ditulis oleh: ' . $name_use . '<br />
		Dilihat: '.$res1['count'].' kali <br />
		Pada: ' . date('d.m.o / H:i', $res1['time'] + $sdvigclock * 3600) . '<br />
		'.($res1['time'] > time()?'<div class="func">Waktu tersisa untuk diperlihatkan: ' . timer($res1['time'] - time()) . '</div>':'').'
		<a href="comments.php?id=' . $id . '">' . $lng['comments'] . '</a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_comments` WHERE `refid`='$id'"), 0) . ')
		</div>
		' . ($rights >= 7 ? '<div class="menu"><div class="func">
		<a href="manage.php?act=newsedit&id='.$id.'">' . $lng['edit'] . '</a><br />
		<a href="manage.php?act=delnews&id=' . $id . '">' . $lng['delete'] . '</a><br />
		</div></div>':'') . '
		<div class="bmenu">Kategori: <a href="index.php?id=' . $res1['catid'] . '">' . htmlentities($res1['catname'], ENT_QUOTES, 'UTF-8') . '</a></div>';
	    echo $_SESSION['error'] . '<div class="gmenu">
				<form action="comments.php?id=' . $id . '" method="post"  enctype="multipart/form-data"><div>
				<b>Pesan komentar:</b><br/>
				<textarea rows="3" name="text">' . (!empty($_POST['text']) ? htmlentities($_POST['text'], ENT_QUOTES, 'UTF-8') : '') . '</textarea>
				<br /><span style="font-size: x-small;">Min 2. Max 5000 karakter</span><br />
				<input type="submit" name="submit" value="Kirim"/>
				</div></form>
				</div>';
	} else {
		$textl = 'Blogs';
		require_once('../incfiles/head.php');
		echo functions::display_error('Blogs tidak ada');
	}
} else {
	$textl = 'Blogs';
	require_once('../incfiles/head.php');
	echo functions::display_error('Blogs tidak dipilih');
}
echo '<div class="phdr"><a href="comments.php?id=' . $id . '">Komentar</a></div>';
			$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_comments` WHERE `refid`='$id';"), 0);
			if($total) {
				if ($total > $kmess)
					echo '<div class="topmenu">' . functions::display_pagination('comments.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
				$i = 1;
				$req = mysql_query("SELECT `goblogs_comments`.*, `goblogs_comments`.`time` as `mtime`, `goblogs_comments`.`id` as `mid`, `users`.* FROM `goblogs_comments` LEFT JOIN `users` ON `goblogs_comments`.`user_id`=`users`.`id` WHERE `goblogs_comments`.`refid`='$id' ORDER BY `goblogs_comments`.`time` DESC LIMIT "
						. $start . "," . $kmess);
				while (($row = mysql_fetch_assoc($req)) !== false) {
					echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
					$post = $row['text'];
					$post = functions::checkout($post, 1, 1);
					if ($set_user['smileys'])
						$post = functions::smileys($post, $row['rights'] >= 1 ? 1 : 0);
					if($row['reply'])
						$post .= '<div class="reply">' . functions::checkout($row['reply'], 1, 1) . '</div>';
					if($rights >= 7) $subtext = '<a href="comments.php?act=replay&amp;id=' . $id . '&amp;com=' . $row['mid'] . '">Jawab</a> | <a href="comments.php&amp;mod=delete&amp;id=' . $id . '&amp;com=' . $row['mid'] . '">Hapus</a>';
					else $subtext = '';
					$text = ' <span class="gray">(' . functions::display_date($row['mtime']) . ')</span>';
					$arg = array(
						'header' => $text,
						'body' => $post,
						'sub' => $subtext
					);
					echo functions::display_user($row, $arg);
					echo '</div>';
					++$i;
				}
				echo '<div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
				if ($total > $kmess) {
					echo '<div class="topmenu">' . functions::display_pagination('comments.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
					echo '<p><form action="index.php" method="get">
					<input type="hidden" name="act" value="comments"/>
					<input type="hidden" name="id" value="' . $id . '"/>
					<input type="text" name="page" size="2"/>
					<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
				}
				}
				else {
				echo '<div class="rmenu">Belum ada komentar,jadilah yg pertamax !</div>';
			}
				echo '<div class="bmenu"><a href="index.php">Back to Blogs</a></div>';
unset($_SESSION['error']);
require('../incfiles/end.php');