<?php

define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Persiapan install modul goblogs gobelz_blogs!';
require_once('../incfiles/head.php');
echo '<div class="phdr">'.$textl.'</div>';
if (isset($_POST['submit'])) {
mysql_query("DROP TABLE `goblogs");
$gbl = mysql_query("CREATE TABLE IF NOT EXISTS `goblogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `refid` (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;");

mysql_query("DROP TABLE `goblogs_cat");
$gbl_cat = mysql_query("CREATE TABLE IF NOT EXISTS `goblogs_cat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `realid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `realid` (`realid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;");



mysql_query("DROP TABLE `goblogs_comments");
$gbl_komm = mysql_query("CREATE TABLE IF NOT EXISTS `goblogs_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(10) unsigned NOT NULL,
  `time` int(11) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refid` (`refid`),
  KEY `time` (`time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;");

mysql_query("DROP TABLE `goblogs_rating");
$gbl_rat = mysql_query("CREATE TABLE IF NOT EXISTS `goblogs_rating` (
  `id_rate` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `news` int(11) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `golos` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id_rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;");


if ($gbl && $gbl_cat && $gbl_komm && $gbl_rat) {
echo '<div class="gmenu"><a href="index.php">Go_blogs</a> Berhasil di Install,Blogs siap digunakan!</div>';
mysql_query("INSERT INTO `goblogs_cat` (`id`, `realid`, `name`) VALUES ('1', '1', 'tes gobelz blogs');");
mysql_query("INSERT INTO `goblogs` (`refid`, `name`, `text`, `user_id`, `time`) VALUES ('1', 'Hidup Persib Bandung !', 'Go persib go!\r\nMaju terus, kamu layak jadi juara sedunia hahaha.', '1', '1324717200');");

}

if ($gbl == false)
echo '<div class="rmenu">TABLE `goblogs` is not filled !</div>';
if ($gbl_cat == false)
echo '<div class="rmenu">TABLE `goblogs_cat` is not filled !</div>';
if ($gbl_rat == false)
echo '<div class="rmenu">TABLE `goblogs_rating` is not filled !</div>';
if ($gbl_komm == false)
echo '<div class="rmenu">TABLE `goblogs_comments` is not filled !</div>';
} else {
echo '<div class="gmenu">Greets you install wizard blogs for johncms 4.4.0 <form method="POST"><input type="submit" name="submit" value="submit" /></form></div>';
}
echo '<div class="rmenu">&copy; author Gobelz@sakahayang <a href="http://sakahayang.se.gp">My site here!</a></div>';
echo '<div class="phdr">Version v2.0 of blogs</div>';
require_once('../incfiles/end.php');
?>