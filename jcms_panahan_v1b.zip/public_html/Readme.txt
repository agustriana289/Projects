Jcms 440 Panahan V1

Engine jcms ini adalah engine jcms mod kashur by Yanz yang saya modif lagi sesuai selera saya.
Fitur awalnya bisa dilihat disini

http://fadilahonespot.mywapblog.com/scrip-jcms-440-full-mod-forum-kashur-php.xhtml

NEW FEATUR
- Mod Prefix Forum
- Rotate Avatar
- Tags Forum
- Complete Share Button
- Notif bot guestbook create tofix forum and new registered
- Upload import file
- Mod color nick
- Rating Forum
- Jumlah Thanks
- New tofik forum rewrite, Last upload file forum, search forum and statistik in mainmenu
- Search forum history
- Style login menu
- Blog by gobelz
- Terms menu
- FAQ Question menu
- Servise menu
- Top forum
- Receint post forum whit pagination
- BOT Shotbox Chat
- Mod new library
- And More

INSTALASI
http://your-domain.com/install and cek next instruction.


Thank for yanz and kashur.

PanahanWAP Community
http://panahan.tk  