<?php
// SimpleWAP Personal CMS
// Versions: 1.1
// Languange: PHP MySQL
// Relase: 11 May 2012
// (c) simplewap.net all rights reserved
// Please do not remove this

// moduls grab Scms by chodot
// http://chapink.com

$q=$_GET['q'];
include 'head.php';

if ($user_id){
echo '<div class="title"> <img src="/images/search.png" alt="*"/> Pencarian MP3</div>';
echo '<form method="get" action="search.php"><input type="text" name="q" value="'.$q.'"><input type="submit" name="search" value="Search"></form><b>';

echo '<div class="phdr"><img src="/images/default.png" alt="*"/> Kategory </div>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Campursari&search=Search"> Campursari </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Lengger&search=Search"> Lengger Banyumasan </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Langgam&search=Search"> Langgam </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Langgam+campursari&search=Search"> Langgam Campursari </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Sopsan&search=Search"> Sopsan Lagu Dablongan </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Dangdut&search=Search"> Dangdut </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Lagu+daerah&search=Search"> Lagu Daerah </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Lagu+80an&search=Search"> Lagu Lagu 80an </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Wayang+kulit&search=Search"> Wayang Kulit </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Dangdut+koplo&search=Search"> Dangdut Koplo </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Remix&search=Search"> Remix </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=Dangdut&search=Search"> Dangdut </div></a>';

echo '<div class="menu"><img src="/images/mp3.png" alt="*"/><a href="/mp3/search.php?q=House+musik&search=Search"> House Musik </div></a>';
} else {
echo '<div class="omenu"> Acces for member online please <a href="/login.php">LOGIN</a> or <a href="/registration.php">REGISTRATION</a> for access full site</div>';
}
include 'foot.php';
?>
