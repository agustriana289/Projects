<?
$path=$_SERVER['QUERY_STRING'];
header("Location: http://loadfree.mobi/mp3/loader.php?$path");

?>
