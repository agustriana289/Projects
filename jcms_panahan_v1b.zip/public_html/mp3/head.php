<?
define('_IN_JOHNCMS', 1);

$headmod = 'Mp3 Search';
$textl = 'Mp3 Search';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
?>
