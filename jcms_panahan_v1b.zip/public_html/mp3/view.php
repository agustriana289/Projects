<?php
// SimpleWAP Personal CMS
// Versions: 1.1
// Languange: PHP MySQL
// Relase: 11 May 2012
// (c) simplewap.net all rights reserved
// Please do not remove this

// moduls grab Scms by chodot
// http://chapink.com

include 'head.php';

$f=file_get_contents('http://loadfree.mobi/mp3/view.php?'.$_SERVER['QUERY_STRING']);
$f=preg_replace('#<?xml(.*?)<div class="head2">#siu','',$f);
$f=preg_replace('#<a href="http://(.*?)</a>#siu','',$f);
$f=preg_replace('#to list(.*?)</body>#siu','',$f);
$f=str_replace('Back','</a><div class="foot">&laquo;<a href="index.php">Kembali</a></div><a href=""></a>',$f);
$f=str_replace('<br/><br/>','',$f);
$f=str_replace('<form','<div class="phdr"><img src="/images/search.png" alt="*"/>  Pencarian MP3</div><div class="menu"><form',$f);
$f=str_replace('Download','<br/>Download',$f);
$f=str_replace('height="100"','height="130"',$f);
$f=str_replace('</form>','</form></div><div class="menu">Download mp3:<br/>',$f);

echo $f;

echo'</div>';

include 'foot.php';
?>
