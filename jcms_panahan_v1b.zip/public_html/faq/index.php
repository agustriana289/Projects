<?php
/* _________________________________________
|Часто задаваемые вопросы (FAQ) для JohnCMS
|Автор: Янулов
|Связь: ICQ - 8065911, e-mail - ianulov93@mail.ru
|________________________________________
*/

/* переписал по 4.4.0 Koenig */

/* установка
распаковать в корень
перейти по ссылке сайт.ру/faq/?act=install
 счетчик и ссылка на главной

 function faq() {
    ////////////////////////////////////////////////////////////
    // Часто задаваемые вопросы (by Янулов)                                    //
    ////////////////////////////////////////////////////////////
     $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `usr_questions`  WHERE `show` = '1'"), 0);
    $old = time() - (3 * 24 * 3600);
    $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `usr_questions` WHERE `time` > '" . $old . "' AND `show` = '1'"), 0);
    if ($new > 0)
        $total .= '&nbsp;<span class="red">+' . $new . '</span>';
    return $total;
}
 
 echo '<div class="menu"><a href="' . $home . '/faq/">Вопросы юзеров</a> (' . faq() . ')</div>'; 
 */

define('_IN_JOHNCMS', 1);
$headmod = 'faq';
$rootpath = '../';
$textl = 'FAQ (Pertanyaan/Jawaban)';
$pg = 'index.php';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if (!empty($_GET['act'])) {
    $act = functions::checkout($_GET['act'], 1, 1);
} 
switch ($act) {
    
    case 'install':
if (!file_exists('install_stop')) {   
    mysql_query("CREATE TABLE `usr_questions`(
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `avtor` varchar(25) NOT NULL,
  `vopros` text NOT NULL,
  `otvet` text NOT NULL,
  `plus` int(11) NOT NULL default '0',
  `minus` int(11) NOT NULL default '0',
  `show` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
        file_put_contents('install_stop', date('d-m-Y') . ' дата установки');
 echo '<span class="green">OK</span> Tabel usr_questions ditambahkan ke database mu<br />';         
} else {
echo '<div class="phdr">Для переустановки удалите файл install_stop</div>';    
echo '<div><a href="../">Жми скорей</a></div>';
}
break;    
    
    
    case "new": 
        ////////////////////////////////////////////////////
        // Задать вопрос                                 //
        ////////////////////////////////////////////////////
        if (!$user_id) {
            require_once ('../incfiles/head.php');
            echo functions::display_error($lng['access_guest_forbidden'], '<a href="../index.php">Please Register Before!!</a>');
            require_once ('../incfiles/end.php');
            exit;
        } 
        $vopros = mb_substr(trim($_POST['vopros']), 0, 500);
            if (($_POST['submit']) && empty($_POST['vopros']))
                $error[] = 'tidak ada pertanyaan';
            if (!$error) {
                if (isset($_POST['submit'])) {
                    if (isset($_POST['msgtrans']))
            $vopros = functions::trans($vopros);
                    
                    mysql_query("INSERT INTO `usr_questions` SET
            `time` = '" . time() . "',
            `avtor` = '" . $login . "',
            `vopros` = '" . mysql_real_escape_string($vopros) . "';");
                    echo '<div class="gmenu"><p>Pertanyaan telah terkirim!<br />tunggu sampai admin menjawab pertanyaan tersebut, untuk melihatnya silahkan cek <br /><a href="' . $pg . '">[disini]</a></p></div>';
                } else {
                    echo '<div class="phdr"><b>Buat Pertanyaan</b></div>';
                    echo '<form action="' . $pg . '?act=new" method="post">';
                    echo '<div class="gmenu">Pertanyaan(max. 500 Karakter):<br/><textarea rows="4" name="vopros"></textarea><br/>';
                    if ($set_user['translit'])
                        echo '<input type="checkbox" name="msgtrans" value="1" /> Translit<br/>';
                    echo '<input type="submit" title="Pertanyaan" name="submit" value="Submit" /></div></form>';
                    echo '<div class="phdr"><a href="../pages/faq.php?act=trans">' . $lng['translit'] . '</a> | <a href="../pages/faq.php?act=smileys">' . $lng['smileys'] . '</a></div>';
                    echo '<p><a href="' . $pg . '">Kembali</a></p>';
                } 
            } else {
                // Выводим сообщение об ошибке
                require_once('../incfiles/head.php');
                echo functions::display_error($error, '<a href="faq.php?act=new">Ulangi Pertanyaan</a>');
                require_once('../incfiles/end.php');
                exit;
            } 
         
        break;

    case 'otvet': 
        ////////////////////////////////////////////////////
        // Ответ Администратора                                //
        ////////////////////////////////////////////////////
        if ($rights >= 7) {
            if (empty($_GET['id'])) {
                require_once ("../incfiles/head.php");
                echo '<p>Error!<br/><a href="' . $pg . '">ke FAQ</a></p>';
                require_once ("../incfiles/end.php");
                exit;
            } 
            $id = intval($_GET['id']);
            $req = mysql_query("SELECT * FROM `usr_questions` WHERE `id`='" . $id . "';");
            $res = mysql_fetch_array($req);
            $otvet = trim($_POST['otvet']);
            if (($_POST['submit']) && empty($_POST['otvet']))
                $error[] = 'Anda belum memberi jawaban';
            if (!$error) {
                if (isset($_POST['submit'])) {
                      if (isset($_POST['msgtrans']))
            $otvet = functions::trans($otvet);
            
                    mysql_query("UPDATE `usr_questions` SET
        `otvet` = '" . mysql_real_escape_string($otvet) . "'
        where `id` = '" . $id . "';");
                    if ($res['show'] == 1)
                        header('location: ' . $pg);
                    else
                        header('location: ' . $pg . '?act=moder');
                } else {
                    $otv = htmlentities($res['otvet'], ENT_QUOTES, 'UTF-8');
                    echo '<div class="phdr"><b>Jawaban Pertanyaan</b></div>';
                    echo '<div class="menu">Pertanyaan: <b>' . $res['vopros'] . '</b></div>';
                    echo '<form action="' . $pg . '?act=otvet&amp;id=' . $id . '" method="post">';
                    echo '<div class="gmenu">Jawab:<br/><textarea rows="4" name="otvet">' . $otv . '</textarea><br/>';
                    if ($set_user['translit'])
                        echo '<input type="checkbox" name="msgtrans" value="1" /> Translit<br/>';
                    echo '<input type="submit" title="Нажмите для отправки" name="submit" value="submit" /></div></form>';
                    echo '<div class="phdr"><a href="../pages/faq.php?act=trans">' . $lng['translit'] . '</a> | <a href="../pages/faq.php?act=smileys">' . $lng['smileys'] . '</a></div>';
                    echo '<p>' . ($res['show'] ? '<a href="' . $pg . '">ke index</a>' : '<a href="' . $pg . '?act=moder">Ke Perbaharui Pertanyaan</a>') . '</p>';
                } 
            } else {
                // Выводим сообщение об ошибке
                require_once('../incfiles/head.php');
                echo functions::display_error($error, '<a href="' . $pg . '?act=otvet&amp;id=' . $id . '">[Jawab]</a>');
                require_once('../incfiles/end.php');
                exit;
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;

    case "edit": 
        ////////////////////////////////////////////////////
        // Редактирование вопроса                      //
        ////////////////////////////////////////////////////
        if ($rights >= 7) {
            if (empty($_GET['id'])) {
                require_once ("../incfiles/head.php");
                echo '<p>Ошибка!<br/><a href="' . $pg . '">В FAQ</a></p>';
                require_once ("../incfiles/end.php");
                exit;
            } 
            $id = intval($_GET['id']);
            $req = mysql_query("SELECT * FROM `usr_questions` WHERE `id`='" . $id . "';");
            $res = mysql_fetch_array($req);
            $vopros = mb_substr(trim($_POST['vopros']), 0, 500);
            if (($_POST['submit']) && empty($_POST['vopros']))
                $error[] = 'Text kosong';
            if (!$error) {
                if (isset($_POST['submit'])) {
                if (isset($_POST['msgtrans']))
            $vopros = functions::trans($vopros);
                    mysql_query("UPDATE `usr_questions` SET
        `vopros` = '" . mysql_real_escape_string($vopros) . "'
        where `id` = '" . $id . "';");
                    if ($res['show'] == 1)
                        header('location: ' . $pg);
                    else
                        header('location: ' . $pg . '?act=moder');
                } else {
                    $vpr = htmlentities($res['vopros'], ENT_QUOTES, 'UTF-8');
                    echo '<div class="phdr"><b>Edit Pertanyaan</b></div>';
                    echo '<form action="' . $pg . '?act=edit&amp;id=' . $id . '" method="post">';
                    echo '<div class="gmenu">Edit(max. 500):<br/><textarea rows="4" name="vopros">' . $vpr . '</textarea><br/>';
                    if ($set_user['translit'])
                        echo '<input type="checkbox" name="msgtrans" value="1" /> Транслит<br/>';
                    echo '<input type="submit" title="Нажмите для отправки" name="submit" value="submit" /></div></form>';
                    echo '<div class="phdr"><a href="../pages/faq.php?act=trans">' . $lng['translit'] . '</a> | <a href="../pages/faq.php?act=smileys">' . $lng['smileys'] . '</a></div>';
                    echo '<p>' . ($res['show'] ? '<a href="' . $pg . '">Ke Index</a>' : '<a href="' . $pg . '?act=moder">Ke perbaharui pertanyaan</a>') . '</p>';
                } 
            } else {
                // Выводим сообщение об ошибке
                require_once('../incfiles/head.php');
                echo functions::display_error($error, '<a href="' . $pg . '?act=edit&amp;id=' . $id . '">[edit]</a>');
                require_once('../incfiles/end.php');
                exit;
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;

    case "del": 
        ////////////////////////////////////////////////////
        // Удаление вопроса                               //
        ////////////////////////////////////////////////////
        if ($rights >= 7) {
            if (empty($_GET['id'])) {
                require_once ("../incfiles/head.php");
                echo '<p>Error!<br/><a href="' . $pg . '">to FAQ</a></p>';
                require_once ("../incfiles/end.php");
                exit;
            } 
            $id = intval($_GET['id']);
            $req = mysql_query("SELECT * FROM `usr_questions` WHERE `id`='" . $id . "';");
            $res = mysql_fetch_array($req);
            if (isset ($_GET['yes'])) {
                mysql_query("DELETE FROM `usr_questions` WHERE `id`='" . $id . "' LIMIT 1;");
                if ($res['show'] == 1)
            header('location: ' . $pg);  
                else
                    header('location: ' . $pg . '?act=moder');
            } else {
                $link = '';
                if ($res['show'] == 1) {
                    $link = ' | <a href="' . $pg . '">Tidak</a>';
                } else {
                    $link = ' | <a href="' . $pg . '?act=moder">Back</a>';
                } 
                echo '<p>yakin menghapus pertanyaan ini?<br/><a href="' . $pg . '?act=del&amp;id=' . $id . '&amp;yes">Hapus</a>' . $link . '</p>';
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;

    case "rate": 
        ////////////////////////////////////////////////////
        // Рейтинг вопросов                               //
        ////////////////////////////////////////////////////
        if (empty($_GET['id'])) {
            require_once ("../incfiles/head.php");
            echo '<p>Error!<br/><a href="' . $pg . '">В FAQ</a></p>';
            require_once ("../incfiles/end.php");
            exit;
        } 
        // Закрываем доступ для гостей
        if (!$user_id) {
           echo functions::display_error($lng['access_guest_forbidden'], '<a href="../index.php">На главную</a>');       
            require_once ('../incfiles/end.php');
            exit;
        } 
        if ($rights < 7) {
            $req = mysql_query("SELECT * FROM `usr_questions` WHERE `id`='" . $id . "';");
            $res = mysql_fetch_array($req);
            $usr_rate = @mysql_query("SELECT * FROM `usr_questions` WHERE `user_id` = '" . $user_id . "' AND `id` = '" . $id . "';");
            $sum = mysql_num_rows($usr_rate);
            if ($sum != 0)
                $error[] = 'Отдавать голос разрешено только один раз';
            if (!$error) {
                if (isset($_GET['thanks'])) {
                    $plus = $res['plus'] + 1;
                    mysql_query("UPDATE `usr_questions` SET `plus` = '" . $plus . "', `user_id` = '" . $user_id . "' where `id` = '" . $id . "';");
                    header('location: ' . $pg);
                } 

                if (isset($_GET['bug'])) {
                    $minus = $res['minus'] + 1;
                    mysql_query("UPDATE `usr_questions` SET `minus` = '" . $minus . "', `user_id` = '" . $user_id . "' where `id` = '" . $id . "';");
                    echo '<div class="gmenu"><p>Нам искренне жаль, что наш ответ вам не помог!<br /><a href="' . $pg . '">Список вопросов</a></p></div>';
                } 
            } else {
                // Выводим сообщение об ошибке
                require_once('../incfiles/head.php');
                echo functions::display_error($lng['access_guest_forbidden'], '<a href="' . $pg . '">В FAQ</a>');
                require_once('../incfiles/end.php');
                exit;
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;

    case "add": 
        ////////////////////////////////////////////////////////////
        // Добавление в список                     //
        ////////////////////////////////////////////////////////////
        require_once ("../incfiles/head.php");
            if (isset($_GET['yes'])) {
                $dc = $_SESSION['dc'];
                $prd = $_SESSION['prd'];
                foreach ($dc as $add_id) {
                    mysql_query("UPDATE `usr_questions` SET  `show` = '1' WHERE `id`='" . intval($add_id) . "';");
                } 
                echo "Pertanyaan berhasil diterbitkan<br/><a href='" . $prd . "'>kembali</a><br/>";
            } else {
                if (empty($_POST['addch'])) {
                    echo '<p>Checklist pertanyaan yang akan di terbitkan<br/><a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">kembali</a></p>';
                    require_once ("../incfiles/end.php");
                    exit;
                } 
                foreach ($_POST['addch'] as $v) {
                    $dc[] = intval($v);
                } 
                $_SESSION['dc'] = $dc;
                $_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
                echo '<p>Anda yakin menmbahkan pertanyaan ini ke index FAQ?<br/><a href="' . $pg . '?act=add&amp;yes">Ya</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Tidak</a></p>';
            } 
         
        break;

    case 'clean': 
        ////////////////////////////////////////////////////
        // Чистка новых вопросов                                  //
        ////////////////////////////////////////////////////
        if ($rights >= 7) {
            $total_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `usr_questions`  WHERE `show` != '1'"), 0);
            if ($total_new > 0) {
                if (isset($_GET['yes'])) {
                    mysql_query("DELETE FROM `usr_questions`  WHERE `show` != '1';");
                    require_once("../incfiles/head.php");
                    echo '<p>Seluruh pertanyaan berhasil dibersihkan!<br/><a href="' . $pg . '?act=moder">kembali</a></p>';
                    require_once("../incfiles/end.php");
                    exit;
                } else {
                    echo '<form action="' . $pg . '?act=clean&amp;yes" method="post">';
                    echo '<div class="phdr"><b>Bersihkan pertanyaan</b></div>';
                    echo '<div class="rmenu"><p>Anda yakin menghapus pertanyaan di mode pembaruan?</p><p><input type="submit" value=" hapus "/></p></div>';
                    echo '<div class="phdr"><a href="' . $pg . '?act=moder">kembali ke perbaharui pertanyaan</a></div>';
                    echo '<p><a href="' . $pg . '?act=moder">kembali</a></p>';
                    echo '</form>';
                } 
            } else {
                require_once("../incfiles/head.php");
                echo '<p>Tidak ada pertanyaan!<br/><a href="' . $pg . '?act=moder">kembali</a></p>';
                require_once("../incfiles/end.php");
                exit;
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;

    case "moder": 
        ////////////////////////////////////////////////////
        // Вывод списка новых вопросов                                  //
        ////////////////////////////////////////////////////
        if ($rights >= 7) {
            echo '<p><a href="' . $pg . '">Ke index FAQ</a></p>';
            echo '<div class="phdr"><b>List pertanyaan</b></div>';
            $req = mysql_query("SELECT COUNT(*) FROM `usr_questions` WHERE `show` != '1'");
            $total = mysql_result($req, 0);
            if ($total) {
                $req = mysql_query("SELECT * FROM `usr_questions`  WHERE `show` != '1' ORDER BY `time`  DESC LIMIT " . $start . "," . $kmess . ";");
                echo '<form action="' . $pg . '?act=add" method="post">';
                while ($res = mysql_fetch_array($req)) {
                    echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
                    
                     $shift = (core::$system_set['timeshift'] + core::$user_set['timeshift']) * 3600;
                     $vr = date("d.m.Y / H:i", $res['time'] + $shift);
                     echo $div;
                    $vopros = $res['vopros'];
                    
                    $vopros = functions::checkout($vopros, 1, 1);
                    $vopros = functions::smileys($vopros, $res['rights'] ? 1 : 0);   
                    echo 'Pertanyaan: <b>' . $vopros . '</b><br />';
                    $otvet = $res['otvet'];
                    $otvet = functions::checkout($otvet, 1, 1);
                    $otvet = functions::smileys($otvet, $res['rights'] ? 1 : 0);   
                    
                    if ($res['otvet'])
                        echo 'Jawaban: ' . $otvet;
                    echo '<div class="sub">Pertanyaan dari: ' . $res['avtor'] . ' ' . $vr . '<br />';
                    echo '<input type="checkbox" name="addch[]" value="' . $res['id'] . '"/>&nbsp;';
                    echo '<a href="' . $pg . '?act=otvet&amp;id=' . $res['id'] . '">Jawab</a> | <a href="' . $pg . '?act=edit&amp;id=' . $res['id'] . '">Edit</a> | <a href="' . $pg . '?act=del&amp;id=' . $res['id'] . '">Delete</a>';
                    echo '</div></div>';
                    ++$i;
                } 
                echo '<div class="gmenu"><input type="submit" value=" Terbitkan ke Index "/></div>';
                echo '</form>';
            } else {
                echo '<div class="menu"><p>Belum ada pertanyaan</p></div>';
            } 
            echo '<div class="phdr">Total:&nbsp;' . $total . '</div>';
            if ($total)
                echo '<div class="func"><p><a href="' . $pg . '?act=clean">Bersihkan</a></p></div>';
            if ($total > $kmess) {
                echo '<p>' . functions::display_pagination('faq.php?act=moder&amp;', $start, $total, $kmess) . '</p>';
                echo '<p><form action="' . $pg . '" method="get"><input type="hidden" name="act" value="moder"/><input type="text" name="page" size="2"/><input type="submit" value="ke halaman &gt;&gt;"/></form></p>';
            } 
        } else {
            header('location: ' . $pg);
        } 
        break;
    default: 
        ////////////////////////////////////////////////////
        // Вывод списка вопросов                                  //
        ////////////////////////////////////////////////////
        // Ссылка на новые вопросы

    // для счетчика
function faq_new($mod = 0) {
    ////////////////////////////////////////////////////////////
    // Счетчик новых вопросов (FAQ)                    //
    ////////////////////////////////////////////////////////////
    global $user_id, $rights, $pg;
    if ($rights >= 7) {
        $req = mysql_query("SELECT COUNT(*) FROM `usr_questions`  WHERE `show` != '1'");
        $total = mysql_result($req, 0);
        if ($mod)
            echo '<p><a href="' . $pg . '?act=moder">Pertanyaan Baru [Perbaharui]</a>&nbsp;' . ($total ? '<span class="red">[<b>' . $total . '</b>]</span>' : '') . '</p>';
        else
            return $total;
    }
}
        
        faq_new(1);
        

        
        echo '<div class="phdr"><b>Frequently Ask Question</b></div>';
        $req = mysql_query("SELECT COUNT(*) FROM `usr_questions` WHERE `show` = '1'");
        $total = mysql_result($req, 0);
        if ($total) {
            $req = mysql_query("SELECT * FROM `usr_questions` WHERE `show` = '1' ORDER BY `time`  DESC LIMIT " . $start . "," . $kmess . ";");
            while ($res = mysql_fetch_array($req)) {
                echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
               
               $shift = (core::$system_set['timeshift'] + core::$user_set['timeshift']) * 3600;
               $vr = date("d.m.Y / H:i", $res['time'] + $shift);
               echo $div;
                 $vopros = $res['vopros'];
                    
                    $vopros = functions::checkout($vopros, 1, 1);
                    $vopros = functions::smileys($vopros, $res['rights'] ? 1 : 0);   
                    echo 'Pertanyaan: <b>' . $vopros . '</b><br />';
                    $otvet = $res['otvet'];
                    $otvet = functions::checkout($otvet, 1, 1);
                    $otvet = functions::smileys($otvet, $res['rights'] ? 1 : 0);
                if ($res['otvet'])
                    echo 'Jawaban: ' . $otvet;
                echo '<div class="sub">Pertanyaan dari: ' . $res['avtor'] . ' ' . $vr . '<br />';
                $usr_rate = @mysql_query("SELECT * FROM `usr_questions` WHERE `user_id` = '" . $user_id . "' AND `id` = '" . $res['id'] . "';");
                $sum = mysql_num_rows($usr_rate);
                if (!empty($user_id) && !$sum) {
                    echo '<span class="green"><a href="' . $pg . '?act=rate&amp;id=' . $res['id'] . '&amp;thanks">like (' . $res['plus'] . ')</a></span> | <span class="red"><a href="' . $pg . '?act=rate&amp;id=' . $res['id'] . '&amp;bug">unlike (' . $res['minus'] . ')</a></span>';
                } else {
                    echo '<span class="green">Like (' . $res['plus'] . ')</span> | <span class="red">Unlike (' . $res['minus'] . ')</span>';
                } 
                if ($rights >= 7)
                    echo '<br /><a href="' . $pg . '?act=otvet&amp;id=' . $res['id'] . '">Jawab</a> | <a href="' . $pg . '?act=edit&amp;id=' . $res['id'] . '">Edit</a> | <a href="' . $pg . '?act=del&amp;id=' . $res['id'] . '">Delete</a>';
                echo '</div></div>';
                ++$i;
            } 
        } else {
            echo '<div class="menu"><p>Pertanyaan Masih Kosong</p></div>';
        } 
        if ($user_id) {
            echo '<div class="gmenu"><a href="' . $pg . '?act=new">-Buat Pertanyaan-</a></div>';
        } 
        echo '<div class="phdr">Total:&nbsp;' . $total . '</div>';
        if ($total > $kmess) {
            echo '<p>' . functions::display_pagination($pg . '?', $start, $total, $kmess) . '</p>';
            echo '<p><form action="' . $pg . '?" method="get"><input type="text" name="page" size="2"/><input type="submit" value="ke halaman &gt;&gt;"/></form></p>';
        } 
        break;
} 
require_once ("../incfiles/end.php");

?>