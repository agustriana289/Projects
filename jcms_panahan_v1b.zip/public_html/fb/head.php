<?
define('_IN_JOHNCMS', 1);

$headmod = 'fb status via';
$textl = 'fb status via';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
?>