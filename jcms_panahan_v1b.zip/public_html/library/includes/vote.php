<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
/*
======================================
    необходимые проверки
======================================
*/
if (!$user_id) {
echo '<div class="rmenu">Voting is only available for users!<br/><a href="index.php">Back</a></div>';
require ('../incfiles/end.php');
exit;
}
echo '<div class="phdr"><a href="index.php"><b>' . $lng['library'] . '</b></a> | Rate</div>';
$rtng = floatval($_GET['rtng']);            
if ($rtng < 0 OR $rtng > 5) {
echo '<div class="rmenu">Invalid value rating!<br/><a href="index.php?id='.$id.'">Back</a></div>';
require ('../incfiles/end.php');
exit;
}
$dir = mysql_fetch_array(mysql_query("SELECT `id` FROM `lib` WHERE `type`='cat' AND `id`=$id"));
if ($dir) {
echo '<div class="rmenu">You can not vote for the category!<br/><a href="index.php">Back</a></div>';
require ('../incfiles/end.php');
exit;
}
if ($id == 0) {
echo '<div class="rmenu">Not selected article!<br/><a href="index.php">Back</a></div>';
require ('../incfiles/end.php');
exit;
}
$was = mysql_fetch_array(mysql_query("SELECT `user` FROM `lib_rate` WHERE `art`='$id' AND `user`='$user_id'"));
if ($was) {
echo '<div class="rmenu">You have already rate this article!<br/><a href="index.php?id='.$id.'">Back</a></div>';
require ('../incfiles/end.php');
exit;
}
/*
======================================
если всё ок, обновляем базу
======================================
*/
if ($rtng >= 0 AND $rtng <= 6) {
mysql_query("UPDATE `lib` SET `rate`=rate + $rtng WHERE `id` = '$id'");          
mysql_query("UPDATE `lib` SET `kol_rate`=kol_rate + 1 WHERE `id` = '$id'");  
$rates = mysql_fetch_array(mysql_query("SELECT `rate`, `kol_rate`  FROM `lib` WHERE `id` = '$id'"));
$rate = $rates['rate'];
$kol_rate = $rates['kol_rate'];
$vote = round($rate/$kol_rate, 2);
mysql_query("UPDATE `lib` SET `rating`=$vote WHERE `id` = '$id'"); 
mysql_query("INSERT INTO `lib_rate` (art,user) VALUES ('$id','$user_id')");
echo '<div class="rmenu">Your vote has successfully taken into account!<br/><a href="index.php?id='.$id.'">Back</a></div>';
} 

?>