<?php

if ($user_id){
} else {
echo '<div class="mainblok">';
echo '<a href="goblogs/"><div class="phdr"><b>Update Blogs</b></div></a><div class="menu">';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs`"), 0);
		if($total) {
			$req = mysql_query("SELECT `id`,`user_id`, `name`, `count`, `text`, `time` FROM `goblogs` ORDER BY `id` DESC LIMIT 1");
			$i = 1;
			while (($row = mysql_fetch_assoc($req)) !== false) {
				echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
				if(file_exists('files/goblogs/small_news_' . $row['id'] . '.jpg') !== false) {
					echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="32">';
					echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../files/goblogs/small_news_' . $row['id'] . '.jpg" alt="" width="32" height="32"/>&#160;';
					echo '</td><td>';
					echo '<a href="../goblogs/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html"><div class="menu">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '<br/>(' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/></div></a>';
					echo '</td></tr></table>';
				} else {
					echo '<a href="../goblogs/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html"><div class="menu">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '<br/> (' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/></div></a>';
				}
				echo '<div class="sub"></div>';
				$text = $row['text'];
				if(mb_strlen($text) > 100) {
					$str = mb_substr($text, 0, 100);
					$text = mb_substr($str, 0, mb_strrpos($str, ' ')) . '...';
				}
				echo functions::checkout($text, 2, 1);
				
				$us = mysql_query("SELECT `id`, `name` FROM `users` WHERE `id` = '".$row['user_id']."'");			
		        if (mysql_num_rows($us)) {
			$rowuse = mysql_fetch_assoc($us);
			$name_use = $user_id ? '<a href="../users/profile.php?id=' . $rowuse['id'] . '">' . $rowuse['name'] . '</a>' : $rowuse['name'];
		} else {
			$name_use = $lng['guest'];
		}
			    
				
		       
		        echo '<br/><a href="../goblogs/comments.php?id=' . $row['id'] . '">Comment :</a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `goblogs_comments` WHERE `refid`= '".$row['id']."' "), 0) . ')';
		        echo '<br/>Posted by:<a href="../users/profile.php?user=' . $rowuse['id'] . '"> ' . $rowuse['name'] . '</a>';
				echo '<br/>Posted On: ' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . '';
		        echo '<br/>Dilihat: '.$row['count'].' kali ';
				echo '</div>';
				
				++$i;
			}
			}
echo '</div></div>';
}

?>