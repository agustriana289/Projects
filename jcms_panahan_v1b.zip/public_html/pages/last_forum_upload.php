<?php
if($user_id){
echo '<div class="mainblok">';
echo '<div class="phdr"><b>Last Forum Upload</b></div>';
$req = mysql_query("SELECT * FROM `cms_forum_files` ORDER BY `id` DESC LIMIT 5");
$i = 0;
while($file = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$path = $file['filename'];
$fls = round(@filesize('files/forum/attach/' . $path) / 1024, 2);
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 5){
echo '<img class="middle" src="images/locked.png" alt="5 post for download"/> File Locked';
}
else {
echo '<img class="middle" src="images/file.gif" alt="'.$file['id'].'"/>';
echo '<a href="forum/index.php?act=file&id='.$file['id'].'"> '.$file['filename'].'</a> ('.$fls.'KB)';
}
echo '</div>';
++$i;
}
echo '</div>';
}
?>
