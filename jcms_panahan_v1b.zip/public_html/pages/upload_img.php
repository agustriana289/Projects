<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */


define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Upload images';
$headmod = 'upload_img';
require('../incfiles/head.php');
$upload_file_size = 1024;

if ($user_id) {
    if (isset($_POST['submit'])) {
        require_once ('../incfiles/lib/class.upload.php');
        $handle = new upload($_FILES['imagefile']);
        if ($handle->uploaded) {
            $name_file = time() . '_' . mt_rand(100, 999);
            $handle->file_new_name_body = $name_file;
            $handle->allowed = array('image/jpeg', 'image/gif', 'image/png');
            $handle->file_max_size = 1024 * $upload_file_size;
            $handle->file_overwrite = true;
            $handle->image_convert = 'jpg';
            $handle->process('../files/images/');
            if ($handle->processed) {
            	$handle->file_new_name_body =$name_file . '_preview';
            	$GetImageSize = GetImageSize('../files/images/' . $name_file . '.jpg');
                $handle->file_overwrite = true;
                $handle->image_resize = true;
               	$handle->image_ratio_crop = true;
               	$x_ratio = 80 / $GetImageSize[0];
            	$y_ratio = 80 / $GetImageSize[1];
				if (($GetImageSize[0] <= 80) && ($GetImageSize[1] <= 80)) {
                	$handle->image_x = $GetImageSize[0];
                	$handle->image_y = $GetImageSize[1];
            	} else if (($x_ratio * $GetImageSize[1]) < 80) {
                	$handle->image_y = ceil($x_ratio * $GetImageSize[1]);
                	$handle->image_x = 80;
            	} else {
                	$handle->image_x = ceil($y_ratio * $GetImageSize[0]);
                	$handle->image_y = 80;
            	}
				$handle->image_convert = 'jpg';
				$handle->process('../files/images/');
				if ($handle->processed) {
        			echo '<div class="phdr"><a href="upload_img.php">Back</a> | <b>Uploading images</b></div>' .
        			'<div class="gmenu">Image uploaded! You can now paste it into any post on this site</div>' .
        			'<div class="menu">BBcode: <input type="text" value="[img=' . $name_file . ']" /></div>' .
        			'<div class="phdr"><a href="upload_img.php">Back</a></div>';
				}else
					echo functions::display_error($handle->error, '<a href="upload_img.php">Back</a>');
			} else
                echo functions::display_error($handle->error, '<a href="upload_img.php">Back</a>');
			$handle->clean();
		} else {
            echo functions::display_error('No file selected', '<a href="upload_img.php">Back</a>');
        }
    } else {
        echo '<div class="phdr"> <a href="faq.php?act=tags">ВВcode</a> | <b>Uploading images</b></div>' .
        '<form enctype="multipart/form-data" method="post" action="upload_img.php?img"><div class="list1">' .
        'Select a picture:<br /><input type="file" name="imagefile" value="" />' .
        '<input type="hidden" name="MAX_FILE_SIZE" value="' . (1024 * $upload_file_size) . '" />' . '<br />' .
        '<p><input type="submit" name="submit" value="Upload" /></p></div></form>' .
        '<div class="list2"><small>Allowed to upload files JPG, JPEG, PNG, GIF<br />' .
        'File size should not exceed ' . $upload_file_size . 'Kb.</small></div>' .
        '<div class="phdr"><b>Images</b></div>';
		$array = glob($rootpath . 'files/images/*preview.jpg');
        $total = count($array);
        $end = $start + $kmess;
        if ($end > $total)
            $end = $total;
        if ($start >= $total) {
            $start = 0;
            $end = $total > $kmess ? $kmess : $total;
        }
        if ($total > 0) {
            for ($i = $start; $i < $end; $i++) {
            	$code = preg_replace('#../files/images/(.+?)_preview.jpg#is', '\1', $array[$i]);
            	echo ($i  % 2) ? '<div class="list2">' : '<div class="list1">';
				echo'' .
				'<a href="' . str_replace('_preview', '', $array[$i]) . '"><img src="' . $array[$i] . '" alt="+"  /></a>' .
    			'<br/>Code: <input type="text" value="[img=' . $code . ']" /></div>';
			}
        } else
            echo '<div class="menu">List is empty!</div>';
        echo '<div class="phdr">Total ' . $total .  '</div>';
        if ($total > $kmess) {
            echo '<div class="topmenu">' . functions::display_pagination('upload_img.php?', $start, $total, $kmess) . '</div>';
            echo '<p><form action="upload_img.php" method="post"><input type="submit" value="Jump &gt;&gt;"/></form></p>';
        }

		echo '<p><a href="faq.php?act=tags">ВВcode</a></p>';
    }
} else {
    header('location: /login.php');
}
require('../incfiles/end.php');

?>