<?php
// New Topik by mbetixz fixed me
if ($user_id){
$total_new = mysql_result (mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `close`!='1' "),0);
$xfriends = mysql_query("SELECT * FROM `forum` WHERE `type`='t' ORDER BY `id` DESC LIMIT 3");
$i = 0;
echo '<div class="mainblok">';
echo '<div class="phdr"><b>New Topic</b></div>';
while($topik_baru = mysql_fetch_array($xfriends)){
echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
$uname= mysql_result(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$topik_baru['user_id']."' LIMIT 1"),0);
$tai= mysql_fetch_array(mysql_query("SELECT `time`,`text` FROM `forum` WHERE `refid`='".$topik_baru['id']."' AND `type`= 'm' ORDER BY `id` ASC LIMIT 1"));
if ($topik_baru['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
if ($topik_baru['tiento'] ==1) {
echo'<b><font color="red">[SHARE]</font></b>';
} elseif ($topik_baru['tiento'] ==2) {
echo'<b><font color="blue">[HELP]</font></b>';
} elseif ($topik_baru['tiento'] ==3) {
echo'<b><font color="red">[HOT]</font></b>';
} elseif ($topik_baru['tiento'] ==4) {
echo'<b><font color="red">[NOTIFICATION]</font></b>';
} elseif ($topik_baru['tiento'] ==5) {
echo'<b><font color="green">[DISCUSSION]</font></b>';
} elseif ($topik_baru['tiento'] ==6) {
echo'<b><font color="blue">[INSTRUCTION]</font></b>';
}
echo '<a href="'.$home.'/forum/' . functions::gantiurl($topik_baru['text']) . '_'.$topik_baru['id'].'.html">'.$topik_baru['text'].'</a>';
echo '<div class="sub">By: '.nick($topik_baru['user_id']).' - '.functions::display_date($topik_baru['time']).'</div></div>';
++$i;
}
echo '</div>';
}
?>
