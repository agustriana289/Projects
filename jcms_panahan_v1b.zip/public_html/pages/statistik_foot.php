<?php
if($user_id){
echo '<div
class="mainblok"><div
class="phdr"><b>Statistics</b></div>';
echo'<div class="list1">&#x2022;Total Files: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . '</b></div>';
echo'<div class="list2">&#x2022;Total Topic: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `close` != '1'"), 0) . '</b></div>';
echo'<div class="list1">&#x2022;Total Post: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `close` != '1'"), 0) . '</b></div>';
$thanhvienmoi=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` ORDER BY `datereg` DESC LIMIT 1"));
$all_users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`;"), 0);

$users_boys = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'm';"), 0);

$users_girls = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'zh';"), 0);
echo '<div class="list1">&#x2022;Member: <b>' . $users_boys . ' Boys </b>and <b>' . $users_girls . ' Girls</b></div>';
echo '</div>';
}
?>
