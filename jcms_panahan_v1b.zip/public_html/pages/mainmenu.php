<?

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
БР�Р�Р� иР�фР�рР�ации
-----------------------------------------------------------------
*/
//echo $mp->news;
include 'pembukaan.php';
echo '<div class="mainblok"><div class="phdr" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><b>' . $lng['dialogue'] . '</b></td>';
echo '</tr></table></div>';
echo '<div class="menu"><table><tr><td width="30px"><img src="images/communication.png" width="30" height="30"/></td><td>';
echo '<p>&nbsp;&bull;&nbsp;<a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</p>';
echo '<p>&nbsp;&bull;&nbsp;<a href="../download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</p>';
echo '<p>&nbsp;&bull;&nbsp;<a href="../library/">' . $lng['library'] . '</a> (' . counters::library() . ')</p>';
/*
-----------------------------------------------------------------
БР�Р�Р� Р�бщеР�ия
-----------------------------------------------------------------
*/// СсыР�Р�а Р�а гР�стевую
if ($set['mod_guest'] || $rights >= 7)
echo '<p>&nbsp;&bull;&nbsp;<a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</p>';
// СсыР�Р�а Р�а ФР�руР�
if ($set['mod_forum'] || $rights >= 7)
echo '<p>&nbsp;&bull;&nbsp;<a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</p>';
echo '</td></tr></table></div></div>';
include'last_blog.php';
include'search_forum.php';
include'recent_post.php';
include'new_forum.php';
include'last_forum_upload.php';
include'top_catagory.php';
include'mymenus.php';
include'statistik_foot.php';
?>
