<?php
include('social_bookmarking.php');
// example of use
echo digg();
echo facebook();
echo twitter();
echo delicious();
?>
