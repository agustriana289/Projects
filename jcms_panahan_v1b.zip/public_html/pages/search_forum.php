<?php
if($user_id){
if ($is_mobile)
echo '<div class="mainblok"><div class="phdr"><b>Forum Search</b></div><div class="forumb"><input name="t" type="checkbox" value="1"  />Forum Topic<br/><form action="' . $set['homeurl'] . '/forum/search.php" method="post"><div> <div style="text-align:left"><input type="text" value="' . ($search ? functions::checkout($search) : '') . '" name="search" /><input class="btn" type="submit" value="' . $lng['search'] . '" name="submit"></small></form>
</div></div></div></div>';
}
?>
