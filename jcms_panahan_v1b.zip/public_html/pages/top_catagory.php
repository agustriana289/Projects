<?php
echo '<div class="mainblok"><div class="phdr"><b>Top Forum</b></div>';
echo '<div class="list2"><img border="0" src="./images/forum.png" width="14" height="14"><font color="gray">&nbsp;<a href="./forum/triks-tersembunyi-internet_85.html">Tips-Tips Internet</a><div class="sub">
<span class="gray">Share tips dan triks internet yang unik atau terbaru seputar internet</span></div>
</font>
</div>';
echo '<div class="list1">
<img border="0" src="./images/forum.png" width="14" height="14"><font color="gray">&nbsp;<a href="./forum/wap-scrip_16.html">Wapsite Scrip</a><div class="sub">
<span class="gray">Share scrip-scrip php untuk membangun wap secara keseluruhan. Serta mendiskusikannya.
</div></font>
</div>';
echo '<div class="list2">
<img border="0" src="./images/forum.png" width="14" height="14"><font color="gray">&nbsp;<a href="./forum/jcms_2.html">JohnCMS</a><div class="sub">
<span class="gray">Share here all kind of johncms scripts, theme, module.</span></div>
</font>
</div>';
echo '<div class="list1">
<img border="0" src="./images/forum.png" width="14" height="14"><font color="gray">&nbsp;<a href="./forum/bisnis-online_88.html">Bisnis Online</a><div class="sub">
<span class="gray">Diskusi mengenai bisnis online yang ada diinternet.</span></div>
</font>
</div>';
echo '<div class="list2">
<img border="0" src="./images/forum.png" width="14" height="14"><font color="gray">&nbsp;<a href="./forum/upreak-area_92.html">Upreak Area</a><div class="sub">
<span class="gray">Tutorial pheaking, hacking apps, website and more in internet.</span></div>
</font>
</div></div>';
?>
