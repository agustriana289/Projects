<?php
echo '<div
class="mainblok"><div
class="phdr"><b>Service & More</b></div><div
class="menu"><img src="/images/partner.png" width="14"
height="14"/> <a
href="pages/friendssite.php">Friends site..</a></div><div
class="menu"><img src="/images/lock.gif" width="14"
height="14"/> <a
href="http://ftpku.tk">WapFTP Service</a></div><div
class="menu"><img src="/images/java.png" width="14"
height="14"/> <a href="/getjar">Java apps</a></div><div
class="menu"><img src="/images/teks.png" width="14"
height="14"/> <a href="/teks_generator">Teks Generator</a></div><div
class="menu"><img src="/images/new.png" width="14"
height="14"/> <a href="/grab_maker">Grab Maker</a></div><div
class="menu"><img src="/images/key.png" width="14"
height="14"/> <a href="http://ftpweb.16mb.com">Simple Wap Ftp</a></div>
<div class="menu"><img src="/images/fb.png" width="14"
height="14"/> <a href="/fb">Status Facebook via</a></div><div class="menu"><img src="/images/mp3.png" width="14"
height="14"/> <a href="/mp3">Mp3 Search</a></div>
<div class="menu"><img src="/images/modules.png" width="14"
height="14"/> <a href="/zip">Converter jar to zip</a></div><div class="menu"><img src="/images/cutter.png" width="14"
height="14"/> <a href="/mp3_cutter">Mp3 Cutter</a></div>
<div class="menu"><img src="/images/blog.png" width="14"
height="14"/> <a href="http://fadilahonespot.mywapblog.com">Blog Tips and Triks</a></div></div>';

?>