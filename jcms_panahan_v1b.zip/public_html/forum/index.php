<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
$lng_forum = core::load_lng('forum');
if (isset($_SESSION['ref']))
unset($_SESSION['ref']);

/*
-----------------------------------------------------------------
Hac?o???py?
-----------------------------------------------------------------
*/
$set_forum = $user_id && !empty($datauser['set_forum']) ? unserialize($datauser['set_forum']) : array(
'farea' => 1,
'upfp' => 0,
'preview' => 1,
'postclip' => 0,
'postcut' => 0
);

/*
-----------------------------------------------------------------
C?co?pac?pe????o? pa?e??? ??Ay?e
-----------------------------------------------------------------
*/
// ???apx?o?
$ext_arch = array(
'zip',
'rar',
'7z',
'tar',
'gz'
);
// ?y??e ???
$ext_audio = array(
'mp3',
'amr'
);
// ???A???o?????
$ext_doc = array(
'txt',
'pdf',
'doc',
'rtf',
'djvu',
'xls'
);
// ???Java
$ext_java = array(
'jar',
'jad'
);
// ????p???
$ext_pic = array(
'jpg',
'jpeg',
'gif',
'png',
'bmp'
);
// ???SIS
$ext_sis = array(
'sis',
'sisx'
);
// ????Ao
$ext_video = array(
'3gp',
'avi',
'flv',
'mpeg',
'mp4'
);
// ???Windows
$ext_win = array(
'exe',
'msi'
);
// AyAe ?? ??o?(?o ? ?pe?c?? ??)
$ext_other = array('wmf');

/*
-----------------------------------------------------------------
OAa???e?Ac????py?
-----------------------------------------------------------------
*/
$error = '';
if (!$set['mod_forum'] && $rights < 7)
$error = $lng_forum['forum_closed'];
elseif ($set['mod_forum'] == 1 && !$user_id)
$error = $lng['access_guest_forbidden'];
if ($error) {
require('../incfiles/head.php');
echo '<div class="rmenu"><p>' . $error . '</p></div>';
require('../incfiles/end.php');
exit;
}

$headmod = $id ? 'forum,' . $id : 'forum';

/*
-----------------------------------------------------------------
?A???c?a???py?
-----------------------------------------------------------------
*/
if (empty($id)) {
$textl = '' . $lng['forum'] . '';
} else {
$trangvip = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");  // TAG MOD
$trangvip1 = mysql_fetch_assoc($trangvip);  // fadilahonespot tag
$req = mysql_query("SELECT `text` FROM `forum` WHERE `id`= '" . $id . "'");
$res = mysql_fetch_assoc($req);
$hdr = strtr($res['text'], array(
'&quot;' => '',
'&amp;' => '',
'&lt;' => '',
'&gt;' => '',
'&#039;' => ''
));
$hdr = mb_substr($hdr, 0, 30);
$hdr = functions::checkout($hdr);
$hdr = html_entity_decode($hdr,ENT_QUOTES,'UTF-8');
$textl = ''.bbcode::notags($res['text']).'...'.$trangvip1['tags'].'';
}
/*
-----------------------------------------------------------------
?pe??ae?pe?? pa@?
-----------------------------------------------------------------
*/
$mods = array(
'addfile',
'import',
'addvote',
'close',
'xoafile',
'minim1',
'minim2',
'minim3',
'minim4',
'minim5',
'deltema',
'delvote',
'editpost',
'editvote',
'file',
'files',
'filter',
'loadtem',
'massdel',
'moders',
'new',
'nt',
'per',
'post',
'ren',
'restore',
'say',
'tema',
'users',
'vip',
'vote',
'who',
'curators'
);
if ($act && ($key = array_search($act, $mods)) !== false && file_exists('includes/' . $mods[$key] . '.php')) {
require('includes/' . $mods[$key] . '.php');
} else {
require('../incfiles/head.php');

/*
-----------------------------------------------------------------
Ec? ?py????, ? A?AA?o???A??????e
-----------------------------------------------------------------
*/
if (!$set['mod_forum']) echo '<div class="alarm">' . $lng_forum['forum_closed'] . '</div>';
elseif ($set['mod_forum'] == 3) echo '<div class="rmenu">' . $lng['read_only'] . '</div>';
if (!$user_id) {
if (isset($_GET['newup']))
$_SESSION['uppost'] = 1;
if (isset($_GET['newdown']))
$_SESSION['uppost'] = 0;
}
if ($id) {
/*
-----------------------------------------------------------------
O?eA?e?????oca (???A ????)
-----------------------------------------------------------------
*/
$type = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");
if (!mysql_num_rows($type)) {
// Ec? ?? ? cy?c?ye? ????e?o?@y
echo functions::display_error($lng_forum['error_topic_deleted'], '<a href="index.php">' . $lng['to_forum'] . '</a>');
require('../incfiles/end.php');
exit;
}
$type1 = mysql_fetch_assoc($type);

/*
-----------------------------------------------------------------
??a????a ?o?e??To??
-----------------------------------------------------------------
*/
if ($user_id && $type1['type'] == 't') {
$req_r = mysql_query("SELECT * FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
if (mysql_num_rows($req_r)) {
$res_r = mysql_fetch_assoc($req_r);
if ($type1['time'] > $res_r['time'])
mysql_query("UPDATE `cms_forum_rdm` SET `time` = '" . time() . "' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
} else {
mysql_query("INSERT INTO `cms_forum_rdm` SET `topic_id` = '$id', `user_id` = '$user_id', `time` = '" . time() . "'");
}
}

/*
-----------------------------------------------------------------
???e?c?y?ypy ?py?
-----------------------------------------------------------------
*/
$res = true;
$parent = $type1['refid'];
while ($parent != '0' && $res != false) {
$req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$parent' LIMIT 1");
$res = mysql_fetch_assoc($req);
if ($res['type'] == 'f' || $res['type'] == 'r')
$tree[] = '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $parent . '.html">' . $res['text'] . '</a>';
$parent = $res['refid'];
}
$tree[] = '<a href="index.php">' . $lng['forum'] . '</a>';
krsort($tree);
if ($type1['type'] != 't' && $type1['type'] != 'm')
$tree[] = '<b>' . $type1['text'] . '</b>';
$sql = ($rights == 9) ? "" : " AND `del` != '1'";
if ($type1['type'] == 'f') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `cat` = '$id'" . $sql), 0);
if ($count > 0)
$filelink = '<a href="index.php?act=files&amp;c=' . $id . '">' . $lng_forum['files_category'] . '</a>';
} elseif ($type1['type'] == 'r') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `subcat` = '$id'" . $sql), 0);
if ($count > 0)
$filelink = '<a href="index.php?act=files&amp;s=' . $id . '">' . $lng_forum['files_section'] . '</a>';
} elseif ($type1['type'] == 't') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `topic` = '$id'" . $sql), 0);
if ($count > 0)
$filelink = '<a href="index.php?act=files&amp;t=' . $id . '">' . $lng_forum['files_topic'] . '</a>';
}
$filelink = isset($filelink) ? $filelink . '&#160;<span class="red">(' . $count . ')</span>' : false;
$wholink = false;
if ($user_id && $type1['type'] == 't') {
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
$wholink = '<a href="index.php?act=who&amp;id=' . $id . '">' . $lng_forum['who_here'] . '?</a>&#160;<span class="red">(' . $online_u . '&#160;/&#160;' . $online_g . ')</span><br/>';
}

/*
-----------------------------------------------------------------
B?oA??px????? ??A??
-----------------------------------------------------------------
*/
echo '<p>' . counters::forum_new(1) . '</p>' .
'<div class="mainblok"><div class="phdr">' . functions::display_menu($tree) . '</div>' .
'<div class="topmenu"><a href="search.php?id=' . $id . '">' . $lng['search'] . '</a>' . ($filelink ? ' | ' . $filelink : '') . ($wholink ? ' | ' . $wholink : '') . '</div></div>';
/*
-----------------------------------------------------------------
O?@a?e?coAp??e ?py?
-----------------------------------------------------------------
*/
switch ($type1['type']) {
case 'f':
/*
-----------------------------------------------------------------
C?co?pa?e???py?
-----------------------------------------------------------------
*/
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='r' AND `refid`='$id' ORDER BY `realid`");
$total = mysql_num_rows($req);
if ($total) {
$i = 0;
while (($res = mysql_fetch_assoc($req)) !== false) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$coltem = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '" . $res['id'] . "'"), 0);
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_'.$res['id'].'.html">' . $res['text'] . '</a>';
if ($coltem)
echo " [$coltem]";
if (!empty($res['soft']))
echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
echo '</div>';
++$i;
}
unset($_SESSION['fsort_id']);
unset($_SESSION['fsort_users']);
} else {
echo '<div class="menu"><p>' . $lng_forum['section_list_empty'] . '</p></div>';
}
echo '<div class="mainblok"><div class="phdr">' . $lng['total'] . ': ' . $total . '</div></div>';
break;

case 'r':
/*
-----------------------------------------------------------------
C?co?????
-----------------------------------------------------------------
*/
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close`!='1'")), 0);
if (($user_id && !isset($ban['1']) && !isset($ban['11']) && $set['mod_forum'] != 3) || core::$user_rights) {
// K??a co?a???????
echo '<div class="gmenu"><form action="index.php?act=nt&amp;id=' . $id . '" method="post"><input type="submit" value="' . $lng_forum['new_topic'] . '" /></form></div>';
}
if ($total) {
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t'" . ($rights >= 7 ? '' : " AND `close`!='1'") . " AND `refid`='$id' ORDER BY `vip` DESC, `time` DESC LIMIT $start, $kmess");
$i = 0;
while (($res = mysql_fetch_assoc($req)) !== false) {
if ($res['close'])
echo '<div class="rmenu">';
else
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$nikuser = mysql_query("SELECT `from`,`user_id` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $res['id'] . "' ORDER BY `time` DESC LIMIT 1");
$nam = mysql_fetch_assoc($nikuser);
$colmes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m' AND `refid`='" . $res['id'] . "'" . ($rights >= 7 ? '' : " AND `close` != '1'"));
$colmes1 = mysql_result($colmes, 0);
$cpg = ceil($colmes1 / $kmess);
$np = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `time` >= '" . $res['time'] . "' AND `topic_id` = '" . $res['id'] . "' AND `user_id`='$user_id'"), 0);
// ?a??
$icons = array(
($np ? (!$res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/op.gif" alt=""/>' : '') : '<img src="../theme/' . $set_user['skin'] . '/images/np.gif" alt=""/>'),
($res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/pt.gif" alt=""/>' : ''),
($res['realid'] ? '<img src="../theme/' . $set_user['skin'] . '/images/rate.gif" alt=""/>' : ''),
($res['edit'] ? '<img src="../theme/' . $set_user['skin'] . '/images/tz.gif" alt=""/>' : '')
);
echo functions::display_menu($icons, '&#160;', '&#160;');
if ($res['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
if ($res['tiento'] ==1) {
echo'<b><font color="red">[SHARE]</font></b>';
} elseif ($res['tiento'] ==2) {
echo'<b><font color="blue">[HELP]</font></b>';
} elseif ($res['tiento'] ==3) {
echo'<b><font color="red">[HOT]</font></b>';
} elseif ($res['tiento'] ==4) {
echo'<b><font color="red">[NOTIFICATION]</font></b>';
} elseif ($res['tiento'] ==5) {
echo'<b><font color="green">[DISCUSSION]</font></b>';
} elseif ($res['tiento'] ==6) {
echo'<b><font color="blue">[INSTRUCTION]</font></b>';
}
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a> [' . $colmes1 . ']';
if ($cpg > 1) {
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html">&#160;&gt;&gt;</a>';
}
echo '<div class="sub">';
echo $res['from'];
if (!empty($nam['from'])) {
echo '&#160;/&#160;'.nick($nam['user_id']);
}
echo ' <span class="gray">(' . functions::display_date($res['time']) . ')</span></div></div>';
++$i;
}
unset($_SESSION['fsort_id']);
unset($_SESSION['fsort_users']);
} else {
echo '<div class="menu"><p>' . $lng_forum['topic_list_empty'] . '</p></div>';
}
echo '<div class="mainblok"><div class="phdr">' . $lng['total'] . ': ' . $total . '</div></div>';
if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div>' .
'<p><form action="index.php?id=' . $id . '" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
'</form></p>';
}
break;

case 't':
/*
-----------------------------------------------------------------
??e????
-----------------------------------------------------------------
*/
$filter = isset($_SESSION['fsort_id']) && $_SESSION['fsort_id'] == $id ? 1 : 0;
$sql = '';
if ($filter && !empty($_SESSION['fsort_users'])) {
// ?Ao???ae???oc ? ???a???epo?
$sw = 0;
$sql = ' AND (';
$fsort_users = unserialize($_SESSION['fsort_users']);
foreach ($fsort_users as $val) {
if ($sw)
$sql .= ' OR ';
$sortid = intval($val);
$sql .= "`forum`.`user_id` = '$sortid'";
$sw = 1;
}
$sql .= ')';
}
if ($user_id && !$filter) {
// ??a????a ?o?e?????
}
#Private topic switch
if ($rights == 7 || $rights >=9) {
echo '<div class="mainblok"><div class="phdr"><b>VIP Forum</b></div>';
echo '<div class="menu">';
if ($type1['minim1'] == 1)
echo '<a href="index.php?act=minim1&amp;id=' . $id . '">&#160;normal post</a><br/>';
else
echo '<a href="index.php?act=minim1&amp;id=' . $id . '&amp;minimed">&#160;20 post</a><br/>';
if ($type1['minim2'] == 1)
echo '<a href="index.php?act=minim2&amp;id=' . $id . '">&#160;normal post</a><br/>';
else
echo '<a href="index.php?act=minim2&amp;id=' . $id . '&amp;minimed">&#160;30 post</a><br/>';
if ($type1['minim3'] == 1)
echo '<a href="index.php?act=minim3&amp;id=' . $id . '">&#160;normal post</a><br/>';
else
echo '<a href="index.php?act=minim3&amp;id=' . $id . '&amp;minimed">&#160;40 post</a><br/>';
if ($type1['minim4'] == 1)
echo '<a href="index.php?act=minim4&amp;id=' . $id . '">&#160;normal post</a><br/>';
else
echo '<a href="index.php?act=minim4&amp;id=' . $id . '&amp;minimed">&#160;50 post</a><br/>';
if ($type1['minim5'] == 1)
echo '<a href="index.php?act=minim5&amp;id=' . $id . '">&#160;normal post</a><br/>';
else
echo '<a href="index.php?act=minim5&amp;id=' . $id . '&amp;minimed">&#160;60 post</a>';
echo '</div></div>';
}
#Private topic block
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 20 && $type1['minim1'] == 1) {
echo '<div class="rmenu"><span class="red"><b>Thread ini terkunci</b></span></div>';
echo '<div class="rmenu">Jumlah posting anda belum mencukupi untuk mengakses thread ini!<br />Minimum Post Untuk Mengakses Thread ini adalah: <b><span class="green">20x Posting</span></b></div>';
echo '<div class="mainblok"><div class="phdr"><a href="../forum/index.php?id=1">Newbie Thread</a> | <a href="../forum/index.php?id=7">kembali</a></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 30 && $type1['minim2'] == 1) {
echo '<div class="rmenu"><span class="red"><b>Thread ini terkunci</b></span></div>';
echo '<div class="rmenu">Jumlah posting anda belum mencukupi untuk mengakses thread ini!<br />Minimum Post Untuk Mengakses Thread ini adalah: <b><span class="green">30x Posting</span></b></div>';
echo '<div class="mainblok"><div class="phdr"><a href="../forum/index.php?id=1">Newbie Thread</a> | <a href="../forum/index.php?id=7">kembali</a></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 40 && $type1['minim3'] == 1) {
echo '<div class="rmenu"><span class="red"><b>Thread ini terkunci</b></span></div>';
echo '<div class="rmenu">Jumlah posting anda belum mencukupi untuk mengakses thread ini!<br />Minimum Post Untuk Mengakses Thread ini adalah: <b><span class="green">40x Posting</span></b></div>';
echo '<div class="mainblok"><div class="phdr"><a href="../forum/index.php?id=1">Newbie Thread</a> | <a href="../forum/index.php?id=7">kembali</a></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 50 && $type1['minim4'] == 1) {
echo '<div class="rmenu"><span class="red"><b>Thread ini terkunci</b></span></div>';
echo '<div class="rmenu">Jumlah posting anda belum mencukupi untuk mengakses thread ini!<br />Minimum Post Untuk Mengakses Thread ini adalah: <b><span class="green">50x Posting</span></b></div>';
echo '<div class="mainblok"><div class="phdr"><a href="../forum/index.php?id=1">Newbie Thread</a> | <a href="../forum/index.php?id=7">kembali</a></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser ['postforum'] < 60 && $type1 ['minim5'] == 1) {
echo '<div class="rmenu"><span class="red"><b>Thread ini terkunci</b></span></div>';
echo '<div class="rmenu">Jumlah posting anda belum mencukupi untuk mengakses thread ini!<br />Minimum Post Untuk Mengakses Thread ini adalah: <b><span class="green">60x Posting</span></b></div>';
echo '<div class="mainblok"><div class="phdr"><a href="../forum/index.php?id=1">Newbie Thread</a> | <a href="../forum/index.php?id=7">kembali</a></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($rights < 7 && $type1['close'] == 1) {
echo '<div class="gmenu"><p>' . $lng_forum['topic_deleted'] . '<br/><a href="?id=' . $type1['refid'] . '">' . $lng_forum['to_section'] . '</a></p></div>';
require('../incfiles/end.php');
exit;
}

// C??? ?c????
$colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'$sql AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
if ($start > $colmes) $start = $colmes - $kmess;
// B?oA???a?e ???
echo '<div class="mainblok"><div class="phdr"><a name="up" id="up"></a><a href="#down"><img src="../theme/' . $set_user['skin'] . '/images/down.png" alt="" width="20px" height="10px" border="0"/></a>&#160;&#160;<b>';
if ($type1['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
if ($type1['tiento'] ==1) {
echo'<b><font color="red">[SHARE]</font></b>';
} elseif ($type1['tiento'] ==2) {
echo'<b><font color="blue">[HELP]</font></b>';
} elseif ($type1['tiento'] ==3) {
echo'<b><font color="red">[HOT]</font></b>';
} elseif ($type1['tiento'] ==4) {
echo'<b><font color="red">[NOTIFICATION]</font></b>';
} elseif ($type1['tiento'] ==5) {
echo'<b><font color="green">[DISCUSSION]</font></b>';
} elseif ($type1['tiento'] ==6) {
echo'<b><font color="blue">[INSTRUCTION]</font></b>';
}

echo'' . $type1['text'] . '</b></div>';
echo '<div class="forumb"><b> Tags:</b> '.$type1['tags'].'</div>';
if ($colmes > $kmess)
echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div>';
echo '</div>';
// Me??yA?????
if ($type1['close'])
echo '<div class="rmenu">' . $lng_forum['topic_delete_who'] . ': <b>' . $type1['close_who'] . '</b></div>';
elseif (!empty($type1['close_who']) && $rights >= 7)
echo '<div class="gmenu"><small>' . $lng_forum['topic_delete_whocancel'] . ': <b>' . $type1['close_who'] . '</b></small></div>';
// Me?????? ??
if ($type1['edit'])
echo '<div class="rmenu>' . $lng_forum['topic_closed'] . '</div>';
#Mod like_dislike
include 'prus_mod/like_dislike.php';

/*
-----------------------------------------------------------------
@o?A?co???
-----------------------------------------------------------------
*/
if ($type1['realid']) {
$clip_forum = isset($_GET['clip']) ? '&amp;clip' : '';
$vote_user = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote_users` WHERE `user`='$user_id' AND `topic`='$id'"), 0);
$topic_vote = mysql_fetch_assoc(mysql_query("SELECT `name`, `time`, `count` FROM `cms_forum_vote` WHERE `type`='1' AND `topic`='$id' LIMIT 1"));
echo '<div  class="mainblok"><div  class="gmenu"><b>' . functions::checkout($topic_vote['name']) . '</b><br />';
$vote_result = mysql_query("SELECT `id`, `name`, `count` FROM `cms_forum_vote` WHERE `type`='2' AND `topic`='" . $id . "' ORDER BY `id` ASC");
if (!$type1['edit'] && !isset($_GET['vote_result']) && $user_id && $vote_user == 0) {
// B?oA??p? c o?oca?
echo '<form action="index.php?act=vote&amp;id=' . $id . '" method="post">';
while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
echo '<input type="radio" value="' . $vote['id'] . '" name="vote"/> ' . functions::checkout($vote['name'], 0, 1) . '<br />';
}
echo '<p><input type="submit" name="submit" value="' . $lng['vote'] . '"/><br /><a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;vote_result' . $clip_forum .
'">' . $lng_forum['results'] . '</a></p></form></div>';
} else {
// B?oA?pe???? A?co???
echo '<small>';
while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
$count_vote = $topic_vote['count'] ? round(100 / $topic_vote['count'] * $vote['count']) : 0;
echo functions::checkout($vote['name'], 0, 1) . ' [' . $vote['count'] . ']<br />';
echo '<img src="vote_img.php?img=' . $count_vote . '" alt="' . $lng_forum['rating'] . ': ' . $count_vote . '%" /><br />';
}
echo '</small></div><div class="phdrblack">' . $lng_forum['total_votes'] . ': ';

if ($datauser['rights'] > 6)
echo '<a href="index.php?act=users&amp;id=' . $id . '">' . $topic_vote['count'] . '</a>';
else
echo $topic_vote['count'];
echo '</div></div>';
if ($user_id && $vote_user == 0)
echo '<div class="bmenu"><a href="index.php?id=' . $id . '&amp;start=' . $start . $clip_forum . '">' . $lng['vote'] . '</a></div>';
}
}
$curators = !empty($type1['curators']) ? unserialize($type1['curators']) : array();
$curator = false;
if ($rights < 6 && $rights != 3 && $user_id) {
if (array_key_exists($user_id, $curators)) $curator = true;
}
/*
-----------------------------------------------------------------
??a???p?A ?c? ???
-----------------------------------------------------------------
*/
if (($set_forum['postclip'] == 2 && ($set_forum['upfp'] ? $start < (ceil($colmes - $kmess)) : $start > 0)) || isset($_GET['clip'])) {
$postreq = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
ORDER BY `forum`.`id` LIMIT 1");
$postres = mysql_fetch_assoc($postreq);
echo '<div class="topmenu"><p>';
if ($postres['sex'])
echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($postres['sex'] == 'm' ? 'm' : 'w') . ($postres['datereg'] > time() - 86400 ? '_new.png" width="14"' : '.png" width="10"') . ' height="10"/>&#160;';
else
echo '<img src="../images/del.png" width="10" height="10" alt=""/>&#160;';
if ($user_id && $user_id != $postres['user_id']) {
echo '<a href="../users/profile.php?user=' . $postres['user_id'] . '&amp;fid=' . $postres['id'] . '"><b>' . $postres['from'] . '</b></a> ' .
'<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '"> ' . $lng_forum['reply_btn'] . '</a> ' .
'<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '&amp;cyt"> ' . $lng_forum['cytate_btn'] . '</a> ';
} else {
echo '<b>' . $postres['from'] . '</b> ';
}
$user_rights = array(
1 => 'Kil',
3 => 'Moderator',
6 => 'CoAdmin',
7 => 'Admin',
8 => 'President'
);
echo @$user_rights[$postres['rights']];
echo (time() > $postres['lastdate'] + 300 ? '<span class="red"> &bull;</span>' : '<span class="green"> &bull;</span>');
echo ' <span class="gray">(' . functions::display_date($postres['time']) . ')</span><br/>';
if ($postres['close']) {
echo '<span class="red">' . $lng_forum['post_deleted'] . '</span><br/>';
}
echo functions::checkout(mb_substr($postres['text'], 0, 500), 0, 2);
if (mb_strlen($postres['text']) > 500)
echo '...<a href="index.php?act=post&amp;id=' . $postres['id'] . '">' . $lng_forum['read_all'] . '</a>';
echo '</p></div>';
}
if ($filter)
echo '<div class="rmenu">' . $lng_forum['filter_on'] . '</div>';
// ?Ae??a?? cop?po??(??e ??y / ?epxy)
if ($user_id)
$order = $set_forum['upfp'] ? 'DESC' : 'ASC';
else
$order = ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) ? 'ASC' : 'DESC';
// ??oc ?@?
$req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`postforum`,`users`.`podpis`, `users`.`datereg`, `users`.`pangkat`
FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'"
. ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "$sql ORDER BY `forum`.`id` $order LIMIT $start, $kmess");
// Bepx?e ?? "Ha?ca?"
if (($user_id && !$type1['edit'] && $set_forum['upfp'] && $set['mod_forum'] != 3) || ($rights >= 7 && $set_forum['upfp'])) {
echo '<div class="phdr">Quick Reply</div><div class="gmenu"><form name="form1" action="index.php?act=say&amp;id=' . $id . '" method="post">';
if ($set_forum['farea']) {
echo '<p>' .
(!$is_mobile ? bbcode::auto_bb('form1', 'msg') : '') .
'<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea></p>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'] .
($set_user['translit'] ? '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'] : '') .
'</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div>';
} else {
echo '<p><input type="submit" name="submit" value="' . $lng['write'] . '"/></p></form></div>';
}
}
if ($rights == 3 || $rights >= 6)
echo '<form action="index.php?act=massdel" method="post">';
$i = 1;
$nomer = $page ? $page * 10 + 1 : 1;
while (($res = mysql_fetch_assoc($req)) !== false) {
if ($res['close'])
echo '<div class="rmenu">';
else
echo $i % 2 ? '<div class="mainblok">' : '<div class="mainblok">';
// ?pe?p ?ppa
echo '<div class="phdr"><table width="100%" cellpadding="0" cellspacing="0"><tr>' .
'<td width="auto"><img src="../images/op.gif"> ' . counters::lama_waktu($res['time']) . '</td>' .
'<td width="auto" align="right">#<a href="'.$home.'/forum/' . functions::gantiurl($type1['text']) . '_p' . $res['id'] . '.html">'.($nomer - 10).'</a></td></tr></table></div>';
echo '<div class="newsx">';
if ($set_user['avatar']) {
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td width="32" align="left" valign="top">';
if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
echo '<span class="avatar"><img src="../files/users/avatar/'. $res ['user_id']. '.png" width ="32" height="32" alt =" '. $res ['from'].' "/></span>';
else
echo '<span class="avatar"><img src="../images/empty.png" width="32" height="32" alt ="'. $res ['from']. '"/></span>';
}
echo '</td><td width="auto" align="left" valign="top">';
// H? ?epa ?cc?? ? eA a?e?
if ($user_id && $user_id != $res['user_id']) {
echo '<a href="../users/profile.php?user=' . $res['user_id'] . '"><b>'.nick($res['user_id']).'</b></a> ';
} else {
echo '<a href="../users/profile.php?user=' . $res['user_id'] . '"><b>'.nick($res['user_id']).'</b></a>';
}
// Me?a O?a? / O?a?
echo (time() > $res['lastdate'] + 300 ? '<span class="red"> &bull;</span>':'<span class="green"> &bull;</span>');
echo '<br />';
if ($res['postforum'] != 0) {
$arank = $res['postforum'];
if ($arank <= 75)
$arank = 'Newbie';
elseif ($arank <= 200)
$arank = 'Panahan User';
elseif ($arank <= 400)
$arank = 'Aktivis Panahan';
elseif ($arank <= 600)
$arank = 'Panahan Holic';
elseif ($arank <= 850)
$arank = 'Panahan Addict';
elseif ($arank <= 1200)
$arank = 'Panahan Maniac';
elseif ($arank <= 3200)
$arank = 'Panahan Geek';
elseif ($arank <= 4500)
$arank = 'Panahan Freak';
elseif ($arank >= 5000)
$arank = 'Made in Panahan';
}
if (!empty($res['pangkat'])){
$jenenge = '' . bbcode::tags($res['pangkat']). '';
}else{
$jenenge = ''.$arank.'';
}
// Me?a A??c?
$user_rights = array(
0 => '' . $jenenge . '',
3 => '<span class="red">Moderator</span>',
6 => '<span class="red">CoAdmin</span>',
7 => '<span class="red">Admin</span>',
9 => '<span class="red"><b>Owner</b></span>'
);
echo @$user_rights[$res['rights']];
echo '<br />';
#Mod thanks
include ('prus_mod/ngusere_seneng.php');
include ('prus_mod/ngusere.php');
echo '</td><td width="auto" align="right" valign="top">';
//PM TOTAL POST
if ($user_id && $user_id != $res['user_id'])
echo '<a href="../users/pradd.php?act=write&amp;adr=' . $res['user_id'] . '"><b>PM <img src="../images/pm.png"></b></a><br/>';
echo 'Post: <a href="/users/profile.php?act=activity&amp;user=' . $res['user_id'] . '">' . $res['postforum'] . '</a>';
$fadil = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_thank` WHERE `user` = " . $res['user_id'] . ";"), 0);
echo '<br/><img src="jempol.gif" width="14" height="14" alt="thanx"/> ' . $fadil . '';
if (!empty($res['status']))
echo '<br/>' . $res['status'] . '';
if ($set_user['avatar'])
echo '<br/>';
echo '</td></tr></table>';
include ('includes/rank.php');
echo '</div><div class="textx">';
/*
-----------------------------------------------------------------
B?oA??? ?c?
-----------------------------------------------------------------
*/
$text = $res['text'];
if ($set_forum['postcut']) {
// Ec? ???A??? o@e?e??Ae?cc?? ? ??? ?p??
switch ($set_forum['postcut']) {
case 2:
$cut = 1000;
break;

case 3:
$cut = 3000;
break;
default :
$cut = 500;
}
}
if ($set_forum['postcut'] && mb_strlen($text) > $cut) {
$text = mb_substr($text, 0, $cut);
$text = functions::checkout($text, 1, 1);
$text = preg_replace('#\[c\](.*?)\[/c\]#si', '<div class="quote">\1</div>', $text);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] ? 1 : 0);
echo bbcode::notags($text) . '...<br /><a href="'.$home.'/forum/' . functions::gantiurl($type1['text']) . '_p' . $res['id'] . '.html">' . $lng_forum['read_all'] . ' &gt;&gt;</a>';
} else {
// ?? o@a@??e??A ???A??c????
$text = functions::checkout($text, 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] ? 1 : 0);
echo $text;
/* ADS HERE
if (($start + $i) == 1){
echo '<br/>';
echo '<a href="http://">ADS</a><br/>';
}
*/
}

if ($res['kedit']) {
// Ec? ?c?peA??o??? ????e?????Aa
echo '<br/><br/><div class="block"><small>Edited: <b>' . $res['edit'] . '</b><br/>' . functions::display_date($res['tedit']). ' [' . $res['kedit'] . ']</small></div>';
}
// Ec? ec? ??pe?e?? ??, ??A?eA o?ca?e
$freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] . "'");
if (mysql_num_rows($freq) > 0) {
$fres = mysql_fetch_assoc($freq);
$fls = round(@filesize('../files/forum/attach/' . $fres['filename']) / 1024, 2);
echo '<br /><div class="func"><span class="gray">' . $lng_forum['attached_file'] . ':';
// ?eApoc?? ?o@a???
$att_ext = strtolower(functions::format('./files/forum/attach/' . $fres['filename']));
$pic_ext = array(
'gif',
'jpg',
'jpeg',
'png'
);
if (in_array($att_ext, $pic_ext)) {
echo '<div><a href="index.php?act=file&amp;id=' . $fres['id'] . '">';
echo '<img src="thumbinal.php?file=' . (urlencode($fres['filename'])) . '" alt="' . $lng_forum['click_to_view'] . '" /></a></div>';
} else {
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 5){
echo '<br /><span class="red">File Locked!</span>';
echo '<p><span class="red">You need to post min 5 posts, to download this file</span></p>';
} else {
if ($user_id && $user_id != $res['user_id'] && (mysql_result($checkthank, 0) < 1))
echo '<br/><font color="#ff0000">Click thanks to download</font>';
else
echo '<br /><a href="index.php?act=file&amp;id=' . $fres['id'] . '">' . $fres['filename'] . '</a>';
}
}
echo ' (' . $fls . ' kb)<br/>';
echo $lng_forum['downloads'] . ': ' . $fres['dlcount'] . ' ' . $lng_forum['time'] . '</span></div>';
$file_id = $fres['id'];
if ($rights >= 6)
echo' <br/><a href="index.php?act=xoafile&amp;id=' . $fres['id'] . '">Delete File</a>';
if ($fls == 0) {
echo'<br/>File Empty Size';
}
}
echo '</div>';

#Mod. Signature
if(!empty($res['podpis']))
echo '<div class="signature">&#160;<small>' . functions::smileys(bbcode::tags($res['podpis'])) . '</small></div>';
# Bpe? ?c?
echo '<div class="forumb">';
echo '<table width="100%" cellspacing="0" cellpadding="0"><tr><td width="auto" align="left">';
if (($start + $i) == 1){
if ($user_id && $user_id != $res['user_id']) {
if (!$datauser['karma_off'] && (!$user['rights'] || ($user['rights'] && !$set_karma['adm'])) && $user['ip'] != $datauser['ip']) {
$sum = mysql_result(mysql_query("SELECT SUM(`points`) FROM `karma_users` WHERE `user_id` = '$user_id' AND `time` >= '" . $datauser['karma_time'] . "'"), 0);
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `karma_users` WHERE `user_id` = '$user_id' AND `karma_user` = '" .$res['user_id']. "' AND `time` > '" . (time() - 86400) . "'"), 0);
if (!$ban && $datauser['postforum'] >= $set_karma['forum'] && $datauser['total_on_site'] >= $set_karma['karma_time'] && ($set_karma['karma_points'] - $sum) > 0 && !$count) {
echo '<a href="/users/profile.php?act=karma&amp;mod=vote&amp;user=' .$res['user_id']. '"><b><span class="green">Cendol</span></b></a>&nbsp;';
}
}
}
}
if ($user_id && $user_id != $res['user_id']) {
include ('prus_mod/ngusere_prus.php');
}

// Cc?? ? o?e????po??e
echo '</td><td width="auto" align="right">';
if ($user_id && $user_id != $res['user_id']) {
echo ' <a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '"><img src="../images/reply.png" alt="Reply" /></a>&#160;' .
'<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '&amp;cyt"><img src="../images/fquote.png" alt="Quote" /></a>';
}

// impor dan upload
if ( $user_id == $res [ 'user_id' ])
echo '<font color="blue"><a href="index.php?id=' . $res [ 'id' ]. '&act=addfile">Upload</a></font>';
if ( $user_id == $res [ 'user_id' ])
echo ' | <font color="blue"><a href="index.php?id=' . $res[ 'id' ]. '&act=import">Import</a></font>';
echo '</td></tr></table></div>';

if ((($rights == 3 || $rights >= 6 || $curator) && $rights >= $res['rights']) || ($res['user_id'] == $user_id && !$set_forum['upfp'] && ($start + $i) == $colmes && $res['time'] > time() - 300) || ($res['user_id'] == $user_id && $set_forum['upfp'] && $start == 0 && $i == 1 && $res['time'] > time() - 300)) {
// Cc?? ? peA??o??e / yA??e ?c??
$menu = array(
'<a href="index.php?act=editpost&amp;id=' . $res['id'] . '">' . $lng['edit'] . '</a>',
($rights >= 7 && $res['close'] == 1 ? '<a href="index.php?act=editpost&amp;do=restore&amp;id=' . $res['id'] . '">' . $lng_forum['restore'] . '</a>' : ''),
($res['close'] == 1 ? '' : '<a href="index.php?act=editpost&amp;do=del&amp;id=' . $res['id'] . '">' . $lng['delete'] . '</a>')
);
echo '<div class="sub">';
if ($rights == 3 || $rights >= 6)
echo '<input type="checkbox" name="delch[]" value="' . $res['id'] . '"/>&#160;';
echo functions::display_menu($menu);
if ($res['close']) {
echo '<div class="red">' . $lng_forum['who_delete_post'] . ': <b>' . $res['close_who'] . '</b></div>';
} elseif (!empty($res['close_who'])) {
echo '<div class="green">' . $lng_forum['who_restore_post'] . ': <b>' . $res['close_who'] . '</b></div>';
}
if ($rights == 3 || $rights >= 6) {
if ($res['ip_via_proxy']) {
echo '<div class="gray"><b class="red"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip']) . '">' . long2ip($res['ip']) . '</a></b> - ' .
'<a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip_via_proxy']) . '">' . long2ip($res['ip_via_proxy']) . '</a>' .
' - ' . $res['soft'] . '</div>';
} else {
echo '<div class="gray"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip']) . '">' . long2ip($res['ip']) . '</a> - ' . $res['soft'] . '</div>';
}
}
echo '</div>';
}
echo '</div>';
++$nomer;
++$i;
}
if ($rights == 3 || $rights >= 6) {
echo '<div class="omenu"><input type="submit" value=" ' . $lng['delete'] . ' "/></div>';
echo '</form>';
}
// H??e ?? "Ha?ca?"
if (($user_id && !$type1['edit'] && !$set_forum['upfp'] && $set['mod_forum'] != 3) || ($rights >= 7 && !$set_forum['upfp'])) {
echo '<div class="mainblok"><div class="phdr">Quick Reply</div><div class="gmenu"><form name="form2" action="index.php?act=say&amp;id=' . $id . '" method="post">';
if ($set_forum['farea']) {
echo '<p>';
if (!$is_mobile)
echo bbcode::auto_bb('form2', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/></p>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'];
if ($set_user['translit'])
echo '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'];
echo '</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div></div>';
} else {
echo bbcode::auto_bb('form2', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea>
</p>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'];
if ($set_user['translit'])
echo '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'];
echo '</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div></div>';
}
}
echo '<div class="mainblok">';
echo '<div class="phdr"><a name="down" id="down"></a><a href="#up">' .
'<img src="../theme/' . $set_user['skin'] . '/images/up.png" alt="' . $lng['up'] . '" width="20" height="10" border="0"/></a>' .
'&#160;&#160;' . $lng['total'] . ': ' . $colmes . '</div>';
if ($colmes > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div></div>' .
'<form action="index.php?id=' . $id . '" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
'</form>';
}else{
echo '</div>';
}
// Share social link bbcode
echo '<div class="mainblok">
<div class="phdrblack">Share This On</div>
<b>BB Code:</b><br/><input type="text" size="17" value="Check this article: [url='.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html]'.$type1["text"].'[/url] thanks:)"/><br/><b>Link:</b><br/><input type="text" size="17" value="'.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html"/><br/><b>Social Networks:</b><br/>';
require_once ('../pages/share.php');
echo '</div>';
/*
-----------------------------------------------------------------
Similiar Topic
-----------------------------------------------------------------
*/
//Mod. Similar Topic
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `refid`='$type1[refid]' AND `id`!='$id' ORDER BY `vip` DESC, `time` DESC LIMIT 8");
$total = mysql_num_rows($req);
if($total!=0){
echo '<div class="mainblok"><div class="phdrblack">Similar topics</div><div>';
while ($res = mysql_fetch_assoc($req)) {
echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
if ($res['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
if ($res['tiento'] ==1) {
echo'<b><font color="red">[SHARE]</font></b>';
} elseif ($res['tiento'] ==2) {
echo'<b><font color="blue">[HELP]</font></b>';
} elseif ($res['tiento'] ==3) {
echo'<b><font color="red">[HOT]</font></b>';
} elseif ($res['tiento'] ==4) {
echo'<b><font color="red">[NOTIFICATION]</font></b>';
} elseif ($res['tiento'] ==5) {
echo'<b><font color="green">[DISCUSSION]</font></b>';
} elseif ($res['tiento'] ==6) {
echo'<b><font color="blue">[INSTRUCTION]</font></b>';
}
echo '<a href="'.$home.'/forum/'.functions::gantiurl($res['text']).'_' . $res['id'] . '.html">' . $res['text'] . '</a>';
echo '</div>';
++$i;
}
echo '</div>';
echo '<div class="phdrblack">';
if ($filter)
echo '<div><a href="index.php?act=filter&amp;id=' . $id . '&amp;do=unset">' . $lng_forum['filter_cancel'] . '</a></div>';
else
echo '<a href="index.php?act=filter&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['filter_on_author'] . '</a> ' .
'| <a href="index.php?act=tema&amp;id=' . $id . '">' . $lng_forum['download_topic'] . '</a>';
echo '</div></div>';
}
/*
-----------------------------------------------------------------
Cc?? ? ?Apa?pc?e ????
-----------------------------------------------------------------
*/
if ($curators) {
$array = array();
foreach ($curators as $key => $value)
$array[] = '<a href="../users/profile.php?user=' . $key . '">' . $value . '</a>';
echo '<p><div class="func">' . $lng_forum['curators'] . ': ' . implode(', ', $array) . '</div></p>';
}
if ($rights == 3 || $rights >= 6) {
echo '<p><div class="func">';
if ($rights >= 7)
echo '<a href="index.php?act=curators&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['curators_of_the_topic'] . '</a><br />';
echo isset($topic_vote) && $topic_vote > 0
? '<a href="index.php?act=editvote&amp;id=' . $id . '">' . $lng_forum['edit_vote'] . '</a><br/><a href="index.php?act=delvote&amp;id=' . $id . '">' . $lng_forum['delete_vote'] . '</a><br/>'
: '<a href="index.php?act=addvote&amp;id=' . $id . '">' . $lng_forum['add_vote'] . '</a><br/>';
echo '<a href="index.php?act=ren&amp;id=' . $id . '">' . $lng_forum['topic_rename'] . '</a><br/>';
// ????- o?p????
if ($type1['edit'] == 1)
echo '<a href="index.php?act=close&amp;id=' . $id . '">' . $lng_forum['topic_open'] . '</a><br/>';
else
echo '<a href="index.php?act=close&amp;id=' . $id . '&amp;closed">' . $lng_forum['topic_close'] . '</a><br/>';
// ?a?? - ?cc???? ??
if ($type1['close'] == 1)
echo '<a href="index.php?act=restore&amp;id=' . $id . '">' . $lng_forum['topic_restore'] . '</a><br/>';
echo '<a href="index.php?act=deltema&amp;id=' . $id . '">' . $lng_forum['topic_delete'] . '</a><br/>';
if ($type1['vip'] == 1)
echo '<a href="index.php?act=vip&amp;id=' . $id . '">' . $lng_forum['topic_unfix'] . '</a>';
else
echo '<a href="index.php?act=vip&amp;id=' . $id . '&amp;vip">' . $lng_forum['topic_fix'] . '</a>';
echo '<br/><a href="index.php?act=per&amp;id=' . $id . '">' . $lng_forum['topic_move'] . '</a></div></p>';
}
break;

default:
/*
-----------------------------------------------------------------
Ec? ??p?e A??, ????e?o?@y
-----------------------------------------------------------------
*/
echo functions::display_error($lng['error_wrong_data']);
break;
}
} else {
/*
-----------------------------------------------------------------
C?co?Ka?Ap? ?py?
-----------------------------------------------------------------
*/
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
echo '<div class="mainblok"><div class="phdr"><b>' . $lng['forum'] . '</b></div>' .
'<div class="topmenu"><a href="search.php">' . $lng['search'] . '</a></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
echo $i % 2 ? '<div class="menu">' : '<div class="list1">';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a> [' . $count . ']';
if (!empty($res['soft']))
echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
echo '</div>';
++$i;
}
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
echo '<div class="phdr">' . ($user_id ? '<a href="index.php?act=who">' . $lng_forum['who_in_forum'] . '</a>' : $lng_forum['who_in_forum']) . '&#160;(' . $online_u . '&#160;/&#160;' . $online_g . ')</div></div>';
unset($_SESSION['fsort_id']);
unset($_SESSION['fsort_users']);
}

// Ha?A????y c?a??
echo '<p>' . ($id ? '<a href="index.php">' . $lng['to_forum'] . '</a><br />' : '');
if (!$id) {
echo '<a href="../pages/faq.php?act=forum">' . $lng_forum['forum_rules'] . '</a><br/>';
echo '<a href="index.php?act=moders">' . $lng['moders'] . '</a>';
}
echo '</p>';
if (!$user_id) {
if ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) {
echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newup">' . $lng_forum['new_on_top'] . '</a>';
} else {
echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newdown">' . $lng_forum['new_on_bottom'] . '</a>';
}
}
}

require_once('../incfiles/end.php');

?>
