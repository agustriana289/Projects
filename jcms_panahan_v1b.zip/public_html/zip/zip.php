<?php
//Script By nekaters
//http://nekaters.com
//Remodif By drawrs
//http://drawrs.16mb.com
require_once ('../zip/head.php');
echo '<html>
<body class="body">';

if($_GET['url']) {
$down = 'download.php?url';
$url = $_GET[url];
$jar = basename($url);
$jar = explode('?', $jar);
$jar = trim($jar[0]);
$zip = str_replace('jar', 'zip', $jar);
$zip = explode('?', $zip);
$zip = trim($zip[0]);
$download = $down.'='.$url;
echo '<div class="mainblok">';
echo '<div class="phdr">Download '.$zip.'</div>';
echo '<div class="menu">
<b>Url Asal File : </b><a href="'.$url.'">'.$url.'</a><br /><b>Nama file :</b>'.$jar.'<br />
<b>Di Namai Ulang Menjadi :</b>'.$zip.'<br /><br />
<a href="'.$down.'='.$url.'"><center><img src="http://drawrs.16mb.com/a.png" alt="download"/><br><b>'.$zip.'</b></center></a>
<b>Copy Url</b><br /><input size="20" value="http://panahan.tk/zip/'.$down.'='.$url.'"/>';
//drawrs//
echo '<br /><a href="http://panahan.tk/zip/zip.php"><center><b>&laquo; Kembali</b></a></center></div>';
echo '</div>';
} else {
echo '<div class="mainblok">';
echo '<div class="title">Download Jar as Zip</div><div class="menu">';
//drawrs//
echo 'Service Download Jar as Zip hanya media download file .Jar yang direname menjadi .Zip, Setelah download selesai silahkan rename kembali menjadi existensi .Jar<br />
<center><b>Masukan Url File</b></center></br><form action="" method="GET">
<input type="text" name="url" size="18" value="http://" />
<br /><input type="submit" class="submit" value="Submit" /></form></div>';
echo '</div>';
}
echo '</body></html>';
require_once ('../zip/foot.php');
?>
