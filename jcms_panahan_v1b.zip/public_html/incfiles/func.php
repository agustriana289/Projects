<?php

function nick($id, $mod = false) {
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'"));
if($ban > 0) {
$out .= '<font color="black">'.($mod == 1 ? '<small>' : '<b>').'<s>' . $user['name'] . '</s>'.($mod == 1 ? '</small>' : '</b>').'</font>';
} else {
if($user['rights'] > 1) {
if($user['rights'] == 3) {$font = '<font color="green">';}
if($user['rights'] > 3) {$font = '<font color="red">';}
if($user['rights'] == 6) {$font = '<font color="#993399">';}
if($user['rights'] == 7) {$font = '<font color="gold">';}
if($user['rights'] == 9) {$font = '<font color="red">';}
if($user['rights'] == 10) {$font = '<font color="#7192a8">';}
$out .= ''.$font.'' . $user['name'] . '</font>';
} else {
$out .= '<font color="blue">' . $user['name'] . '</font>';
}
}
return $out;
}
?>