<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// РеР�Р�аР�Р�ыР� бР�Р�Р� саР�та
if (!empty($cms_ads[2]))
echo '<div class="gmenu">' . $cms_ads[2] . '</div>';

/*
* Ads
echo '<div class="mainblok"><div class="menu"><div style="text-align:center">';
if ($headmod == 'mainpage') {
include'adiquity.php';
include'mobgold.php';
} else {
include_once ('mobgold.php');
include_once ('adiquity.php');
}
echo '</div></div></div>';
*/

// СчетчиР� Р�Р�сетитеР�еР� Р�Р�Р�аР�Р�
if ($headmod == 'mainpage') {
if ($user_id){
echo '<div class="orangex">' . $lng['member'] . ': <a href="../users/index.php"> ' . counters::users() . ' </a><br/>';
include_once('member.php');
}else{
echo '<div class="orangex">' . counters::online() . '</div>';
}
}
echo '</div>';
echo '</div><div class="footer" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
echo '' . $set['copyright'] . '';
echo '</td><td width="auto" align="right">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</a></td></tr></table></div>';
////////////////////////////////////////////////////////////// СчетчиР�и Р�атаР�Р�гР�в
functions::display_counters();

// РеР�Р�аР�Р�ыР� бР�Р�Р� саР�та
if (!empty($cms_ads[3]))
echo '<div style="text-align:center">' . $cms_ads[3];

/*
-----------------------------------------------------------------
ВНИМАНИЕ!!!
ATTENTION!!!
The copyright could not be removed within 60 days of installation scripts
-----------------------------------------------------------------
*/

echo '<div style="text-align:center">';
if($user_id){
echo '<b><a href="/constitution">Terms</a>|<a href="/faq">Faq</a>|<a href="/goblogs">Blog</a></b>' . ($headmod == 'mainpage' && count(core::$lng_list) > 1 ? '<td align="right"><a href="' . $set['homeurl'] . '/go.php?lng"><b>|' . strtoupper(core::$lng_iso) . '</b></a>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</td>' : '') .
'';
}
echo '<div><small> &copy; '.strtoupper($_SERVER['HTTP_HOST']).' 2012</small></div>';

echo '</div></body></html>';
