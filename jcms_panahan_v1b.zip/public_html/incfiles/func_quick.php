<?
{
$roq = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");;
while ($res = mysql_fetch_array($roq))
{
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout">' : '<div class="textshout">';
// icon seks
global $set_user, $realtime, $user_id, $admp, $home;
$ontimes = $res['lastdate'] + 300;
if (time() > $ontimes)
{
echo '<span class="red">&bull;&nbsp;</span>';
}
else
{
echo '<font color="#00AA00">&bull;&nbsp;</font>';
}
if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="' . $set['homeurl'] . '/users/profile.php?user=' . $res['user_id'] . '"><b>' . $res['name'] . '</b></a> ';
} else{
echo '<b>' . $res['name'] . '</b>&nbsp;';
}
// Online / Offline
$ontime = $res['lastdate'] + 300;
if ($realtime > $ontime){
echo ': ';
}else{
echo ': ';
}
if (!empty($res['status']))
$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
if ($res['user_id']) {
// show smileys
$text = functions::checkout(mb_substr($res['text'], 0, 100), 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] >= 1 ? 1 : 0);
} else {
// antilink
$res['name'] = functions::checkout($res['name']);
$text = functions::antilink(functions::checkout($res['text'], 0, 2));
}

// Tampilkan text posting
echo $text;
if (mb_strlen($res['text']) > 100)
echo '...<a href="../users/qchat.php">more</a>';
echo '</div>';
++$i;
}
}
?>
