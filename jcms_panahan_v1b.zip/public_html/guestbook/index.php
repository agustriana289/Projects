<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'guestbook';
require('../incfiles/core.php');
if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);

// ezNEe?e2euNENZeue? e'NEeze2ez e'e?N?N,N?e'ez e2 e?e'e?e?e?-ese"N?e+
if (isset($_SESSION['ga']) && $rights < 1)
    unset($_SESSION['ga']);

// e-eze'ezeue? e.eze3e?e"e?e2eze? N?N,NEeze?e?N?N<
$textl = isset($_SESSION['ga']) ? $lng['admin_club'] : $lng['guestbook'];
require('../incfiles/head.php');

// eAN?e"e? e3e?N?N,eue2ezNZ e.ezezNEN<N,ez, e2N<e2e?e'e?e? N?e?e?e+Neeue?e?eu e? e.ezezNEN<e2ezeue? e'e?N?N,N?e' (ezNEe?e?eu e?e'e?e?e?e?e2)
if (!$set['mod_guest'] && $rights < 7) {
    echo '<div class="rmenu"><p>' . $lng['guestbook_closed'] . '</p></div>';
    require('../incfiles/end.php');
    exit;
}
switch ($act) {
    case 'delpost':
        /*
        -----------------------------------------------------------------
        eee'eze"eue?e?eu e?N,e'eue"NSe?e?e3e? e'e?N?N,ez
        -----------------------------------------------------------------
        */
        if ($rights >= 6 && $id) {
            if (isset($_GET['yes'])) {
                mysql_query("DELETE FROM `guest` WHERE `id`='" . $id . "'");
                header("Location: index.php");
            } else {
                echo '<div class="phdr"><a href="index.php"><b>' . $lng['guestbook'] . '</b></a> | ' . $lng['delete_message'] . '</div>' .
                     '<div class="rmenu"><p>' . $lng['delete_confirmation'] . '?<br/>' .
                     '<a href="index.php?act=delpost&amp;id=' . $id . '&amp;yes">' . $lng['delete'] . '</a> | ' .
                     '<a href="index.php">' . $lng['cancel'] . '</a></p></div>';
            }
        }
        break;

    case 'say':
        /*
        -----------------------------------------------------------------
        e"e?e+eze2e"eue?e?eu e?e?e2e?e3e? e'e?N?N,ez
        -----------------------------------------------------------------
        */
        $admset = isset($_SESSION['ga']) ? 1 : 0; // e-eze'ezeue? ezN?e'ez e2N?N,eze2e"NZeue?, e2 e?e'e?e?e? eze"N?e+ (1), e?e"e? e2 e"ezN?N,e?e2N?NaN? (0)
        // ezNEe?e?e?e?ezeue? e? e?e+NEeze+ezN,N<e2ezeue? e'eze?e?N<eu
        $name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 20) : '';
        $msg = isset($_POST['msg']) ? mb_substr(trim($_POST['msg']), 0, 5000) : '';
        if($user_id) {
           $msg = str_replace('[you]', $login, $msg);
        } else {
           $msg = str_replace('[you]', 'Guest', $msg);
        }
        $trans = isset($_POST['msgtrans']) ? 1 : 0;
        $code = isset($_POST['code']) ? trim($_POST['code']) : '';
        $from = $user_id ? $login : mysql_real_escape_string($name);
        // ecNEeze?N?e"e?N, N?e?e?e+Neeue?e?NZ
        if ($trans)
            $msg = functions::trans($msg);
        // ezNEe?e2euNENZeue? e?ez e?N^e?e+eze?
        $error = array();
        $flood = false;
        if (!$user_id && empty($_POST['name']))
            $error[] = $lng['error_empty_name'];
        if (empty($_POST['msg']))
            $error[] = $lng['error_empty_message'];
        if ($ban['1'] || $ban['13'])
            $error[] = $lng['access_forbidden'];
        // CAPTCHA e'e"NZ e3e?N?N,eue1
        if (!$user_id && (empty($code) || mb_strlen($code) < 4 || $code != $_SESSION['code']))
            $error[] = $lng['error_wrong_captcha'];
        unset($_SESSION['code']);
        if ($user_id) {
            // e?e?N,e?N"e"N?e' e'e"NZ e.ezNEeue3e?N?N,NEe?NEe?e2eze?e?N<Na e'e?e"NSe.e?e2ezN,eue"eue1
            $flood = functions::antiflood();
        } else {
            // e?e?N,e?N"e"N?e' e'e"NZ e3e?N?N,eue1
            $req = mysql_query("SELECT `time` FROM `guest` WHERE `ip` = '$ip' AND `browser` = '" . mysql_real_escape_string($agn) . "' AND `time` > '" . (time() - 60) . "'");
            if (mysql_num_rows($req)) {
                $res = mysql_fetch_assoc($req);
                $flood = time() - $res['time'];
            }
        }
        if ($flood)
            $error = $lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'];
        if (!$error) {
            // ezNEe?e2euNEezez e?ez e?e'e?e?ezeze?e2N<eu N?e?e?e+Neeue?e?NZ
            $req = mysql_query("SELECT * FROM `guest` WHERE `user_id` = '$user_id' ORDER BY `time` DESC");
            $res = mysql_fetch_array($req);
            if ($res['text'] == $msg) {
                header("location: index.php");
                exit;
            }
        }
        if (!$error) {
            // e'N?N,eze2e"NZeue? N?e?e?e+Neeue?e?eu e2 e+eze.N?
            include 'bot.php';
            mysql_query("INSERT INTO `guest` SET
                `adm` = '$admset',
                `time` = '" . time() . "',
                `user_id` = '$user_id',
                `name` = '$from',
                `text` = '" . mysql_real_escape_string($msg) . "',
                `ip` = '" . core::$ip . "',
                `browser` = '" . mysql_real_escape_string($agn) . "'
            ");
            // eAe?ezN?e?NEN?eue? e2NEeue?NZ e'e?N?e"eue'e?eue3e? e'e?N?N,ez (eze?N,e?N?e'eze?)
            if ($user_id) {
                $postguest = $datauser['postguest'] + 1;
                mysql_query("UPDATE `users` SET `postguest` = '$postguest', `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
            }
            $ref = isset($_POST['ref']) ? base64_decode($_POST['ref']) : '/index.php';
            header("Location: $ref");
        } else {
            echo functions::display_error($error, '<a href="index.php">' . $lng['back'] . '</a>');
        }
        break;

    case 'otvet':
        /*
        -----------------------------------------------------------------
        e"e?e+eze2e"eue?e?eu "e?N,e2euN,ez e?e'e?e?e?ez"
        -----------------------------------------------------------------
        */
        if ($rights >= 6 && $id) {
            if (isset($_POST['submit'])) {
                mysql_query("UPDATE `guest` SET
                    `admin` = '$login',
                    `otvet` = '" . mysql_real_escape_string(mb_substr($_POST['otv'], 0, 5000)) . "',
                    `otime` = '" . time() . "'
                    WHERE `id` = '$id'
                ");
                header("location: index.php");
            } else {
                echo '<div class="phdr"><a href="index.php"><b>' . $lng['guestbook'] . '</b></a> | ' . $lng['reply'] . '</div>';
                $req = mysql_query("SELECT * FROM `guest` WHERE `id` = '$id'");
                $res = mysql_fetch_assoc($req);
                echo '<div class="menu">' .
                     '<div class="quote"><b>' . $res['name'] . '</b>' .
                     '<br />' . functions::checkout($res['text']) . '</div>' .
                     '<form name="form" action="index.php?act=otvet&amp;id=' . $id . '" method="post">' .
                     '<p><h3>' . $lng['reply'] . '</h3>' . bbcode::auto_bb('form', 'otv') .
                     '<textarea rows="' . $set_user['field_h'] . '" name="otv">' . functions::checkout($res['otvet']) . '</textarea></p>' .
                     '<p><input type="submit" name="submit" value="' . $lng['reply'] . '"/></p>' .
                     '</form></div>' .
                     '<div class="phdr"><a href="faq.php?act=trans">' . $lng['translit'] . '</a> | <a href="faq.php?act=smileys">' . $lng['smileys'] . '</a></div>' .
                     '<p><a href="index.php">' . $lng['back'] . '</a></p>';
            }
        }
        break;

    case 'edit':
        /*
        -----------------------------------------------------------------
        e?eue'ezezN,e?NEe?e2eze?e?eu e'e?N?N,ez
        -----------------------------------------------------------------
        */
        if ($rights >= 6 && $id) {
            if (isset($_POST['submit'])) {
                $req = mysql_query("SELECT `edit_count` FROM `guest` WHERE `id`='$id'");
                $res = mysql_fetch_array($req);
                $edit_count = $res['edit_count'] + 1;
                $msg = mb_substr($_POST['msg'], 0, 5000);
                mysql_query("UPDATE `guest` SET
                    `text` = '" . mysql_real_escape_string($msg) . "',
                    `edit_who` = '$login',
                    `edit_time` = '" . time() . "',
                    `edit_count` = '$edit_count'
                    WHERE `id` = '$id'
                ");
                header("location: index.php");
            } else {
                $req = mysql_query("SELECT * FROM `guest` WHERE `id` = '$id'");
                $res = mysql_fetch_assoc($req);
                $text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
                echo '<div class="phdr"><a href="index.php"><b>' . $lng['guestbook'] . '</b></a> | ' . $lng['edit'] . '</div>' .
                     '<div class="rmenu">' .
                     '<form action="index.php?act=edit&amp;id=' . $id . '" method="post">' .
                     '<p><b>' . $lng['author'] . ':</b> ' . $res['name'] . '</p>' .
                     '<p><textarea rows="' . $set_user['field_h'] . '" name="msg">' . $text . '</textarea></p>' .
                     '<p><input type="submit" name="submit" value="' . $lng['save'] . '"/></p>' .
                     '</form></div>' .
                     '<div class="phdr"><a href="faq.php?act=trans">' . $lng['translit'] . '</a> | <a href="faq.php?act=smileys">' . $lng['smileys'] . '</a></div>' .
                     '<p><a href="index.php">' . $lng['back'] . '</a></p>';
            }
        }
        break;

    case 'clean':
        /*
        -----------------------------------------------------------------
        ezN?e?N?N,ezez e"e?N?N,eue2e?e1
        -----------------------------------------------------------------
        */
        if ($rights >= 7) {
            if (isset($_POST['submit'])) {
                // ezNEe?e2e?e'e?e? e?N?e?N?N,ezN? e"e?N?N,eue2e?e1, N?e?e3e"ezN?e?e? e.eze'eze?e?N<e? e'ezNEeze?euN,NEeze?
                $adm = isset($_SESSION['ga']) ? 1 : 0;
                $cl = isset($_POST['cl']) ? intval($_POST['cl']) : '';
                switch ($cl) {
                    case '1':
                        // eOe?N?N,e?e? N?e?e?e+Neeue?e?NZ, N?N,ezNEN^eu 1 e'e?NZ
                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm' AND `time` < '" . (time() - 86400) . "'");
                        echo '<p>' . $lng['clear_day_ok'] . '</p>';
                        break;

                    case '2':
                        // ezNEe?e2e?e'e?e? e'e?e"e?N?NZ e?N?e?N?N,ezN?
                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm'");
                        echo '<p>' . $lng['clear_full_ok'] . '</p>';
                        break;
                    default :
                        // eOe?N?N,e?e? N?e?e?e+Neeue?e?NZ, N?N,ezNEN^eu 1 e?eue'eue"e?
                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm' AND `time`<='" . (time() - 604800) . "';");
                        echo '<p>' . $lng['clear_week_ok'] . '</p>';
                }
                mysql_query("OPTIMIZE TABLE `guest`");
                echo '<p><a href="index.php">' . $lng['guestbook'] . '</a></p>';
            } else {
                // e-eze'NEe?N? e'ezNEeze?euN,NEe?e2 e?N?e?N?N,eze?
                echo '<div class="phdr"><a href="index.php"><b>' . $lng['guestbook'] . '</b></a> | ' . $lng['clear'] . '</div>' .
                     '<div class="menu">' .
                     '<form id="clean" method="post" action="index.php?act=clean">' .
                     '<p><h3>' . $lng['clear_param'] . '</h3>' .
                     '<input type="radio" name="cl" value="0" checked="checked" />' . $lng['clear_param_week'] . '<br />' .
                     '<input type="radio" name="cl" value="1" />' . $lng['clear_param_day'] . '<br />' .
                     '<input type="radio" name="cl" value="2" />' . $lng['clear_param_all'] . '</p>' .
                     '<p><input type="submit" name="submit" value="' . $lng['clear'] . '" /></p>' .
                     '</form></div>' .
                     '<div class="phdr"><a href="index.php">' . $lng['cancel'] . '</a></div>';
            }
        }
        break;

    case 'ga':
        /*
        -----------------------------------------------------------------
        ezeuNEeueze"NZN?eue?e?eu NEeue?e?e?ez NEeze+e?N,N< e"e?N?N,eue2ezNZ / e?e'e?e?e?-eze"N?e+
        -----------------------------------------------------------------
        */
        if ($rights >= 1) {
            if (isset($_GET['do']) && $_GET['do'] == 'set') {
                $_SESSION['ga'] = 1;
            } else {
                unset($_SESSION['ga']);
            }
        }

    default:
        /*
        -----------------------------------------------------------------
        ezN,e?e+NEeze?ezeue? e"e?N?N,eue2N?NZ, e?e"e? e?e'e?e?e? eze"N?e+
        -----------------------------------------------------------------
        */
        if (!$set['mod_guest'])
            echo '<div class="alarm">' . $lng['guestbook_closed'] . '</div>';
        echo '<div class="phdr"><b>' . $lng['guestbook'] . '</b></div>';
        if ($rights > 0) {
            $menu = array();
            $menu[] = isset($_SESSION['ga']) ? '<a href="index.php?act=ga">' . $lng['guestbook'] . '</a>' : '<b>' . $lng['guestbook'] . '</b>';
            $menu[] = isset($_SESSION['ga']) ? '<b>' . $lng['admin_club'] . '</b>' : '<a href="index.php?act=ga&amp;do=set">' . $lng['admin_club'] . '</a>';
            if ($rights >= 7)
                $menu[] = '<a href="index.php?act=clean">' . $lng['clear'] . '</a>';
            echo '<div class="topmenu">' . functions::display_menu($menu) . '</div>';
        }
        // eAe?NEe?ez e2e2e?e'ez e?e?e2e?e3e? N?e?e?e+Neeue?e?NZ
        if (($user_id || $set['mod_guest'] == 2) && !isset($ban['1']) && !isset($ban['13'])) {
            echo '<div class="gmenu"><form name="form" action="index.php?act=say" method="post">';
            if (!$user_id)
                echo $lng['name'] . ' (max 25):<br/><input type="text" name="name" maxlength="25"/><br/>';
            echo '<b>' . $lng['message'] . '</b> <small>(max 5000)</small>:<br/>';
            if (!$is_mobile)
                echo bbcode::auto_bb('form', 'msg');
            echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/>';
            if ($set_user['translit'])
                echo '<input type="checkbox" name="msgtrans" value="1" />&nbsp;' . $lng['translit'] . '<br/>';
            if (!$user_id) {
                // CAPTCHA e'e"NZ e3e?N?N,eue1
                echo '<img src="../captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng['captcha'] . '"/><br />';
                echo '<input type="text" size="5" maxlength="5"  name="code"/>&#160;' . $lng['captcha'] . '<br />';
            }
            echo '<input type="submit" name="submit" value="' . $lng['sent'] . '"/></form></div>';
        } else {
            echo '<div class="rmenu">' . $lng['access_guest_forbidden'] . '</div>';
        }
        if (isset($_SESSION['ga']) && $rights >= "1") {
            $req = mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='1'");
        } else {
            $req = mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'");
        }
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='" . (isset($_SESSION['ga']) ? 1 : 0) . "'"), 0);
        echo '<div class="mainblok"><div class="phdr"><b>' . $lng['comments'] . '</b></div>';
        if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div></div>';
}else{
echo '</div>'; }

        if ($total) {
            if (isset($_SESSION['ga']) && $rights >= "1") {
                // e-eze'NEe?N? e'e"NZ e?e'e?e?e? eze"N?e+ez
                echo '<div class="rmenu"><b>Admin</b></div>';
                $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
                FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                WHERE `guest`.`adm`='1' ORDER BY `time` DESC LIMIT $start, $kmess");
            } else {
                // e-eze'NEe?N? e'e"NZ e?e+N<N?e?e?e1 e"ezN?N,e?e2N?Nae?
                $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
                FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT $start, $kmess");
            }
            $i = 0;
            while (($res = mysql_fetch_assoc($req)) !== false) {
                $text = '';
                echo $i % 2 ? '<div class="mainblok"><div class="phdr"># ' . functions::display_date($res['time']) . '</div><div class="list2">' : '<div class="mainblok"><div class="phdr"># ' . functions::display_date($res['time']) . '</div><div class="list2">';
                if (empty($res['id'])) {
                    // e-eze'NEe?N? e'e? e3e?N?N,NZe?
                    $req_g = mysql_query("SELECT `lastdate` FROM `cms_guests` WHERE `session_id` = '" . md5($res['ip'] . $res['browser']) . "' LIMIT 1");
                    $res_g = mysql_fetch_assoc($req_g);
                    $res['lastdate'] = $res_g['lastdate'];
                }
                // e'NEeue?NZ N?e?e.e'eze?e?NZ e'e?N?N,ez
                if ($res['user_id']) {
                    // e"e"NZ e.ezNEeue3e?N?N,NEe?NEe?e2eze?e?N<Na e'e?ezeze.N<e2ezeue? N?N?N<e"eze? e? N?e?eze1e"N<
                    $post = functions::checkout($res['text'], 1, 1);
                    $post = functions::antilink(functions::checkout($res['text'], 0, 2));
                    if ($set_user['smileys'])
                        $post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
                } else {
                    // e"e"NZ e3e?N?N,eue1 e?e+NEeze+ezN,N<e2ezeue? e?e?NZ e? N"e?e"NSN,NEN?eue? N?N?N<e"eze?
                    $res['name'] = functions::checkout($res['name']);
                }
                if ($res['edit_count']) {
                    // eAN?e"e? e'e?N?N, NEeue'ezezN,e?NEe?e2eze"N?NZ, e'e?ezeze.N<e2ezeue? ezeue? e? eze?e3e'ez
                    $post .= '<br /><span class="gmenu"><small>e~e.e?. <b>' . $res['edit_who'] . '</b> (' . functions::display_date($res['edit_time']) . ') <b>[' . $res['edit_count'] . ']</b></small></span>';
                }
                if (!empty($res['otvet'])) {
                    // ezN,e2euN, e?e'e?e?e?e?N?N,NEezN?e?e?
                    $otvet = functions::checkout($res['otvet'], 1, 1);
                    if ($set_user['smileys'])
                        $otvet = functions::smileys($otvet, 1);
                    $post .= '<div class="reply"><b>' . $res['admin'] . '</b>: (' . functions::display_date($res['otime']) . ')<br/>' . $otvet . '</div>';
                }
                if ($rights >= 6) {
                    $subtext = '<a href="index.php?act=otvet&amp;id=' . $res['gid'] . '">' . $lng['reply'] . '</a>' .
                               ($rights >= $res['rights'] ? ' &raquo; <a href="index.php?act=edit&amp;id=' . $res['gid'] . '">' . $lng['edit'] . '</a> &raquo; <a href="index.php?act=delpost&amp;id=' . $res['gid'] . '">' . $lng['delete'] . '</a>' : '');
                } else {
                    $subtext = '';
                }
                $arg = array(
                    'header' => $text,
                    'body' => $post,
                    'sub' => $subtext
                );
                echo functions::display_user($res, $arg);
                echo '</div></div>';
                ++$i;
            }
        } else {
            echo '<div class="mainblok"><div class="phdr">Empty!</div><div class="menu"><p>' . $lng['guestbook_empty'] . '</p></div></div>';
        }
        echo '<div class="mainblok"><div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess) {
            echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div></div>';
                echo '<p><form action="index.php" method="get"><input type="text" name="page" size="2"/>' .
                 '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
        } else {
echo '</div>';
}

        break;
}

require('../incfiles/end.php');
?>