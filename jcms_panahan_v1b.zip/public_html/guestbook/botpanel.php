<?php
/*
////////////////////////////////////////////////////////////////////////////////
// GocMaster Community
// Home: http://gocmaster.com
// Developer: Ari(Tuan)
// Development Team: GMT
// Mod By Aan Gabriel
// Home: http://malware.us.to
////////////////////////////////////////////////////////////////////////////////
*/
define('_IN_JOHNCMS', 1);

$headmod = 'guestbook';
$textl = 'BOT Panel';
require('../incfiles/core.php');
require('../incfiles/head.php');
$id = $_GET['id'];
if ($rights >= 1) {
switch($act) {
default:
echo '<div class="mainblok"><div class="phdr"><b>Set for bot</b></div>';
echo '<div class="gmenu"><form action="botpanel.php?act=say" method="post">Key<span class="red">*</span>:<br><input type="text" name="key"><br>Text<span class="red">*</span>:<br><input type="text" name="text"><br>Text 1<br><input type="text" name="txt1"><br>Text 2<br><input type="text" name="txt2"><br>Text 3<br><input type="text" name="txt3"><br>Text 4<br><input type="text" name="txt4"><br>Text 5<br><input type="text" name="txt5"><br><input type="submit" value="ADD"></form></div></div>';
echo '<div class="mainblok"><div class="topmenu">Info<span class="red">*</span>: <br><b>{user}</b> To nick user<br><b>{text}</b> Text<br><b>{reply}</b> Reply</div></div>';
echo '<div class="phdr"><b>Total</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot`;"), 0);
if($total == 0) {
echo 'No messages';
} else {
$req = mysql_query("SELECT * FROM `bot` ORDER BY `time` DESC LIMIT $start, $kmess");
$i=0;
while ($bot = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="mainblok"><div class="list2">' : '<div class="mainblok"><div class="list1">';
echo '<b>Key: </b> '.$bot['key'].'<br><b>Text: </b> '.$bot['text'].'<br>'.($bot['txt1'] ? '<b>Text 1:</b> '.$bot['txt1'].'<br>' : '').''.($bot['txt2'] ? '<b>Text 2:</b> '.$bot['txt2'].'<br>' : '').''.($bot['txt3'] ? '<b>Text 3:</b> '.$bot['txt3'].'<br>' : '').''.($bot['txt4'] ? '<b>Text 4:</b> '.$bot['txt4'].'<br>' : '').''.($bot['txt5'] ? '<b>Text 5:</b> '.$bot['txt5'].'<br>' : '').'<b>Add:</b> '.$bot['user'].'<br><b>Time:</b> '.functions::display_date($bot['time']).'';
if($login = $bot['user']|| $rights >= 9) {
echo '<br/><a href="?act=edit&id='.$bot['id'].'">[edit]</a> | <a href="?act=del&id='.$bot['id'].'">[delete]</a>';
}
echo '</div></div>';
++$i;
}

        echo '<div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
        // eteze2e?e3ezN?e?NZ e'e? N?N,NEeze?e?N?eze?
        if ($total > $kmess) {
            echo '<p>' . functions::display_pagination('botpanel.php?', $start, $total, $kmess) . '</p>';
            echo '<p><form action="botpanel.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
        }
}
break;
case 'say':
$key = $_POST['key'];
$text = $_POST['text'];
$txt1 = $_POST['txt1'];
$txt2 = $_POST['txt2'];
$txt3 = $_POST['txt3'];
$txt4 = $_POST['txt4'];
$txt5 = $_POST['txt5'];
$check = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `key`='$key';"), 0);
if(!$key) {
$error .= 'Error bot filed! Key already added';
}
if(!$text) {
$error .= 'Error bot filed! Text already added';
}
if($check > 0) {
$error .= 'Error bot filed! Not found';
}
if(!$error) {
mysql_query("INSERT INTO `bot` SET
  `time` = '".time()."',
  `user` = '$login',
  `text` = '" . mysql_real_escape_string($text) . "',
  `txt1` = '" . mysql_real_escape_string($txt1) . "',
  `txt2` = '" . mysql_real_escape_string($txt2) . "',
  `txt3` = '" . mysql_real_escape_string($txt3) . "',
  `txt4` = '" . mysql_real_escape_string($txt4) . "',
  `txt5` = '" . mysql_real_escape_string($txt5) . "',
  `key` = '" . mysql_real_escape_string($key) . "'");
echo '<a href="botpanel.php">Continue &raquo;</a>';
header("Location: botpanel.php");
} else {echo '<div class="rmenu">Error: '.$error.'</div>';}
break;
case 'del':
$exist = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `id`='$id';"), 0);
$uexist = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `id`='$id' AND `user`='$login';"), 0);
if($exist == 0) {
$err .= 'Error!';
}
if($uexist == 0 && $rights < 9) {
$err .= 'Error!';
}
if(!$err) {
mysql_query("DELETE FROM `bot` WHERE `id`='" . $id . "'");
echo '<a href="botpanel.php">Continue &raquo;</a>';
} else {
echo '<div class="rmenu">'.$err.'</div>';
}
break;
case 'edit':
$ekey = $_POST['key'];
$etext = $_POST['text'];
$etxt1 = $_POST['etxt1'];
$etxt2 = $_POST['etxt2'];
$etxt3 = $_POST['etxt3'];
$etxt4 = $_POST['etxt4'];
$etxt5 = $_POST['etxt5'];
$echeck = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `key`='$key';"), 0);
$edit = mysql_fetch_array(mysql_query("SELECT * FROM `bot` WHERE `id`='$id' LIMIT 1"));
$euexist = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `id`='$id' AND `user`='$login';"), 0);
$eexist = mysql_result(mysql_query("SELECT COUNT(*) FROM `bot` WHERE `id`='$id';"), 0);
if($euexist == 0 && $rights < 9) {
$err .= 'Error!';
}
if(!$ekey) {
$error1 .= 'Key error';
}
if($echeck > 0) {
$error1 .= 'Not Found';
}
if(!$error1 && $_GET['act'] == 'edit' && $_GET['id'] && $_GET['ok']) {
mysql_query("UPDATE `bot` SET
  `time` = '".time()."',
  `text` = '" . mysql_real_escape_string($etext) . "',
  `txt1` = '" . mysql_real_escape_string($etxt1) . "',
  `txt2` = '" . mysql_real_escape_string($etxt2) . "',
  `txt3` = '" . mysql_real_escape_string($etxt3) . "',
  `txt4` = '" . mysql_real_escape_string($etxt4) . "',
  `txt5` = '" . mysql_real_escape_string($etxt5) . "',
  `key` = '" . mysql_real_escape_string($ekey) . "' WHERE `id`='$id' LIMIT 1");
echo '<a href="botpanel.php">Continue &raquo;</a>';
header("Location: botpanel.php");
} else {
if($_GET['act'] == 'edit' && $_GET['id'] && $_GET['ok']) {
echo '<div class="rmenu">Error: '.$error1.'</div>';}}
if($_GET['act'] == 'edit' && $_GET['id'] && !$_GET['ok']) {
echo '<div class="mainblok"><div class="phdr"><b>Set BOT</b></div>';
echo '<div class="gmenu"><form action="botpanel.php?act=edit&&id='.$id.'&&ok=1" method="post">Edit Key<br><input type="text" name="key" value="'.$edit['key'].'"><br>Text key<br><input type="text" name="text" value="'.$edit['text'].'"><br>Text 1<br><input type="text" name="etxt1" value="'.$edit['txt1'].'"><br>Text 2<br><input type="text" name="etxt2" value="'.$edit['txt2'].'"><br>Text 3<br><input type="text" name="etxt3" value="'.$edit['txt3'].'"><br>Text 4<br><input type="text" name="etxt4" value="'.$edit['txt4'].'"><br>Text 5<br><input type="text" name="etxt5" value="'.$edit['txt5'].'"><br><input type="submit" value="submit"></form></div></div>';
}
break;
}
} else {
echo 'You not here!';
}
require('../incfiles/end.php');
?>