<?
define('_IN_JOHNCMS', 1);

$headmod = 'Grab Maker';
$textl = 'Grab Maker';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
?>
