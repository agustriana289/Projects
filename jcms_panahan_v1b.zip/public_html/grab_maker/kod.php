<?php

// SimpleWAP Personal CMS
// Versions: 1.1
// Languange: PHP MySQL
// Relase: 11 May 2012
// (c) simplewap.net all rights reserved
// Please do not remove this

// moduls grab Scms by chodot
// http://chapink.com

include 'head.php';

if (!empty($_POST['site']) and  preg_match('|^[a-z0-9\.\/\?\-\_\=\+\*\&\;\:\#\@\!\,]+$|i',$_POST['site'],$out))
{

$site='http://'.preg_replace('|http\:\/\/|i','',$out[0]);

$text='<?php
$file=file_get_contents(\''.$site.'?\'.$_SERVER[\'QUERY_STRING\']);
';
for($i=1; $i<count($_POST); $i++)
{
if (!empty($_POST['search_'.$i]))
{
$search=$_POST['search_'.$i];
$replace=$_POST['replace_'.$i];
$text.='$file=str_replace(\''.$search.'\',\''.$replace.'\',$file);
';
}
}


$text.='echo $file;
?>';
$array=explode("\r\n",$text);
$rows=count($array)+1;
echo'<div class="mainblok"><div class="phdr">
<span style="font-size:16px;">Copy paste kode php di bawah ini !<br/></span>
</div>
<div class="menu">
<textarea cols="50" rows="'.$rows.'">
'.htmlspecialchars(stripslashes($text), ENT_QUOTES).'
</textarea>
</div>
';
}
else
{
echo '<div class="gmenu">
anda dapat mengulang!<br/>
</div></div>
';
}
echo'</body>
</html>
';
include 'foot.php';
?>
