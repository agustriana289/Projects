<?php

// SimpleWAP Personal CMS
// Versions: 1.1
// Languange: PHP MySQL
// Relase: 11 May 2012
// (c) simplewap.net all rights reserved
// Please do not remove this

// moduls grab Scms by chodot

include 'head.php';
if ($user_id){

if(!$_GET['source'])
{
switch($_GET['go'])
{
default:
echo '<div class="mainblok"><div class="phdr"><b><center>Grab Maker</center></b></div>';
echo'<form action="kod.php" method="post">';

echo'<div class="menu">Url situs:<br/>
<input name="site" value="http://"/>
<br/>
nama link:<br/>
<input name="search_1"/><br>
ganti nama:<br>
<input name="replace_1"/>
<br/>
nama link:<br/>
<input name="search_2"/>
<br/>
ganti nama:<br/>
<input name="replace_2"/>
<br/>
nama link:<br/>
<input name="search_3"/><br>
ganti nama:<br/>
<input name="replace_3"/>
<br/>
nama link:<br/>
<input name="search_4"/><br/>
ganti nama:<br/>
<input name="replace_4"/>
<br/>
nama link:<br/>
<input name="search_5"/><br>
ganti nama:<br/>
<input name="replace_5"/>
<br/>
nama link:<br/>
<input name="search_6"/><br>
ganti nama link:<br/>
<input name="replace_6"/>
<br/>
<input type="reset" value="delete">
<br/>
<input value="GET" type="submit"/></form>';
echo'<br/></body></html>';
echo '</div>';
}

}
} else {
echo '<div class="omenu"> Acces for member only please <a href="/login.php">LOGIN</a> or <a href="/registration.php">REGISTRATION</a> for access full site</div>';
}
include 'foot.php';
?>
