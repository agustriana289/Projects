<?php
// modul created by panahWAP
// http://panahwap.tk

include 'head.php';
?>
<div class="title"><b>INDIA TEXT GENERATOR </b></div>
<SCRIPT type="text/javascript">var normal="abcdefghijklmnopqrstuvwxyz0123456789!#%&'()*+,-./:;<=>?@[\]^_"
var changed="ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยקฬאץz"


function change(_in, _out)
{
var s="";
var n=_in.value.toLowerCase();

///if (_in.value.length=="0") _arab.value="";

for(i=0; i<n.length; i++)
{
var c=n.charAt(i);
for(j=0; (j<normal.length)&&(c!=normal.charAt(j)); j++);
if (j<normal.length) {
s+=changed.charAt(j);} else {
s+=c;
}
}

_out.value=s;

}

function focusFirst() {

if (els = oTD.getElementsByTagName("input")) {
els[0].focus();
}
}

function highlight(field) {
field.focus();
field.select();
}</SCRIPT><div class="menu" align="center"> <br />
<FORM name="yform"> <TEXTAREA class="genTxt" name="textin" style="color:#f00;height:65px;width:100%">Masukkan text disini</TEXTAREA><br />
</div>
<div class="menu" align="center"><INPUT name="button" type="button" class="button" style="width:100%" onclick="change(textin, message);" value="Create"></div><div class="title" align="center">Copy Here:<br />
</div>



<TEXTAREA name="message" input style="color:#f00;height:65px;width:100%"></TEXTAREA></br>

<?php
include 'foot.php';
?>
