<?php
// modul created by panahWAP
// http://panahwap.tk

include 'head.php';
?>
<div class="title"><b>SONY TEXT GENERATOR </b></div>
<SCRIPT type="text/javascript">var normal="abcdefghijklmnopqrstuvwxyz0123456789!#%&'()*+,-./:;<=>?@[\]^_"
var changed="âßčðĕʆģħïĵķℓɱñøþqřşţůþωxŷz"


function change(_in, _out)
{
var s="";
var n=_in.value.toLowerCase();

///if (_in.value.length=="0") _arab.value="";

for(i=0; i<n.length; i++)
{
var c=n.charAt(i);
for(j=0; (j<normal.length)&&(c!=normal.c
