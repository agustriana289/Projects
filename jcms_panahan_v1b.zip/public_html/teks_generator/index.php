<?php
// SimpleWAP Personal CMS
// Versions: 1.1
// Languange: PHP MySQL
// Relase: 11 May 2012
// (c) simplewap.net all rights reserved
// Please do not remove this

// moduls grab Scms by panahWAP
// http://panah.16mb.com

include'head.php';
if ($user_id){
echo '<div class="mainblok">';
echo "<div class='title'><center>TEXT GENERATOR</center></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='bb.php'> Text BB</a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahan.tk'/><a href='funky.php'> Funky Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='plat.php'> Text Plat </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='chinese.php'> Chinese Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='indian.php'> Indian Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='unitext.php'> Unitext </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='crazy.php'> Crazy Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='stupid.php'> Stupid Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='pandawa.php'> Pandawa Text </a></div>";

echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='myblog.php'> Text Blogging </a></div>";

echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='rusia.php'> Russian Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='simbol.php'> Simbol Text </a></div>";

echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='india.php'> India Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='small.php'> Small Text </a></div>";

echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='sony.php'> Sony Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='arabian.php'> Text Arabian </a></div>";

echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='gothic.php'> Text Gothic </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='jepang.php'> Jepang Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='cool_english.php'> Cool Text </a></div>";
echo "<div class='menu'> <img src='/images/text.png' alt='panahwap.tk'/><a href='terbalik.php'> Text Terbalik </a></div>";
echo '</div>';
} else {
echo '<div class="omenu"> Acces for member online please <a href="/login.php">LOGIN</a> or <a href="/registration.php">REGISTRATION</a> for access full site</div>';
}

include 'foot.php';
?>
