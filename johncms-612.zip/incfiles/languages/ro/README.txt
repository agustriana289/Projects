Romanian, Moldavian language pack
============================================================
DRAFT! Require additional editing
============================================================
TRANSLATION AUTHORS:
tomsim