German language pack
============================================================
DRAFT! Required to edit
============================================================
TRANSLATION AUTHORS:
TraNe