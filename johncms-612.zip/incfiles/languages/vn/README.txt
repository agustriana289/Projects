Vietnamese language pack
============================================================
TRANSLATION AUTHORS:
Kieu Duc Linh (http://johnone.info, duclinh.kdl@gmail.com), Tạo JohnCMS dễ dàng với JohnOne  (Create a forum JohnCMS easily with JohnOne)