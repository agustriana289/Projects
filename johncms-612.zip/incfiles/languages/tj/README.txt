Tajik language pack
============================================================
TRANSLATION AUTHORS:
MATIN (http://tjwap.ru, m.matin@mail.ru)