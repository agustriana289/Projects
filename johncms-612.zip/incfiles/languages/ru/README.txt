RUSSIAN LANGUAGE PACK
============================================================
Source language. All other translates were made on the basis
============================================================
TRANSLATION AUTHORS:
Oleg Kasyanov aka AlkatraZ (http://johncms.com, info@johncms.com)