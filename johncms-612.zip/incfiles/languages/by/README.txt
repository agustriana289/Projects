Беларускі моўны пакет  .  	
Версія ад 7.03.2015 .
Аўтар перакладу: Borisov .

Калі ў вас узнікнуць да мяне пытанні або пажаданні, 
вы можаце са мной звязацца па наступным кантактам :


Web : " http://johncms.com/users/profile.php?act=info&user=15251 " ;
Email : " Serzhan.borisov2010@yandex.ru " ;
ICQ : 136902888 ;
.