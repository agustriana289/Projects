MyBlog Modul rev2_170813
=========================
Site http://sakahayang.se.gp
Remodif by http://waptok.asia

Instalasi
Installasi bagi yang belum menginstall:
- Ekstrak arsip di root
- chmod 777 folder files/myblog
- Akses http://situsmu/myblog/install.php
- Hapus Install.php setelah sukses terinstall
- Credit to krite http://upcoder.net
Update
Update bagi yang udah menginstall:
- Ekstrak semua arsip ke folder myblog/

Fitur:
==================
- Menambah kategori Blog
- Menambahkan gambar di blog/upload image
- Memanbahkan icon di kategori dan blog
- Memberi komentar
- Menghitung Views
Revision 1_fix
==================
fixed:
- memperbaiki hak akses kini users harus login untuk membuat blog
- memperbaiki kini users tidak bisa memanage blog kategori
- memperbaiki tamu bisa melihat blog tapi tidak bisa membuat blog
- memperbaiki link yang tidak bisa diakses
- menghilangkan $lng_news
Revision 2_fix
=================
Added:
- Menghilangkan folder includes
- html redirect url
- Share to socialnetwork with icon

Tambahkan fungsi ganti url di incfiles/classes/functions.php (jika sudah ada ga usah)
    /*
   -----------------------------------------------------------------
   Convert URL
   -----------------------------------------------------------------
   */
   public static function gantiurl($text){
      $text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
      $text=str_replace(" ","-", $text);
      $text=str_replace("--","-", $text);
      $text=str_replace("@","-",$text);
      $text=str_replace("/","-",$text);
      $text=str_replace("\\","-",$text);
      $text=str_replace(":","",$text);
      $text=str_replace("\"","",$text);
      $text=str_replace("'","",$text);
      $text=str_replace("<","",$text);
      $text=str_replace(">","",$text);
      $text=str_replace(",","",$text);
      $text=str_replace("?","",$text);
      $text=str_replace(";","",$text);
      $text=str_replace(".","",$text);
      $text=str_replace("[","",$text);
      $text=str_replace("]","",$text);
      $text=str_replace("(","",$text);
      $text=str_replace(")","",$text);
      $text=str_replace("*","",$text);
      $text=str_replace("!","",$text);
      $text=str_replace("$","-",$text);
      $text=str_replace("&","-and-",$text);
      $text=str_replace("%","",$text);
      $text=str_replace("#","",$text);
      $text=str_replace("^","",$text);
      $text=str_replace("=","",$text);
      $text=str_replace("+","",$text);
      $text=str_replace("~","",$text);
      $text=str_replace("`","",$text);
      $text=str_replace("--","-",$text);
      $text = preg_replace("/(||&#7841;|&#7843;|||&#7847;|&#7845;|&#7853;|&#7849;|&#7851;|&#259;|&#7857;|&#7855;|&#7863;|&#7859;|&#7861;)/", 'a', $text);
      $text = preg_replace("/(||&#7841;|&#7843;|||&#7847;|&#7845;|&#7853;|&#7849;|&#7851;|&#259;|&#7857;|&#7855;|&#7863;|&#7859;|&#7861;)/", 'a', $text);
      $text = preg_replace("/(||&#7865;|&#7867;|&#7869;||&#7873;|&#7871;|&#7879;|&#7875;|&#7877;)/", 'e', $text);
      $text = preg_replace("/(||&#7865;|&#7867;|&#7869;||&#7873;|&#7871;|&#7879;|&#7875;|&#7877;)/", 'e', $text);
      $text = preg_replace("/(||&#7883;|&#7881;|&#297;)/", 'i', $text);
      $text = preg_replace("/(||&#7883;|&#7881;|&#297;)/", 'i', $text);
      $text = preg_replace("/(||&#7885;|&#7887;|||&#7891;|&#7889;|&#7897;|&#7893;|&#7895;|&#417;|&#7901;|&#7899;|&#7907;|&#7903;|&#7905;)/", 'o', $text);
      $text = preg_replace("/(||&#7885;|&#7887;|||&#7891;|&#7889;|&#7897;|&#7893;|&#7895;|&#417;|&#7901;|&#7899;|&#7907;|&#7903;|&#7905;)/", 'o', $text);
      $text = preg_replace("/(||&#7909;|&#7911;|&#361;|&#432;|&#7915;|&#7913;|&#7921;|&#7917;|&#7919;)/", 'u', $text);
      $text = preg_replace("/(||&#7909;|&#7911;|&#361;|&#432;|&#7915;|&#7913;|&#7921;|&#7917;|&#7919;)/", 'u', $text);
      $text = preg_replace("/(&#7923;||&#7925;|&#7927;|&#7929;)/", 'y', $text);
      $text = preg_replace("/(&#273;)/", 'd', $text);
      $text = preg_replace("/(&#7923;||&#7925;|&#7927;|&#7929;)/", 'y', $text);
      $text = preg_replace("/(&#273;)/", 'd', $text);
      $text = preg_replace("/(||&#7840;|&#7842;|||&#7846;|&#7844;|&#7852;|&#7848;|&#7850;|&#258;|&#7856;|&#7854;|&#7862;|&#7858;|&#7860;)/", 'A', $text);
      $text = preg_replace("/(||&#7840;|&#7842;|||&#7846;|&#7844;|&#7852;|&#7848;|&#7850;|&#258;|&#7856;|&#7854;|&#7862;|&#7858;|&#7860;)/", 'A', $text);
      $text = preg_replace("/(||&#7864;|&#7866;|&#7868;||&#7872;|&#7870;|&#7878;|&#7874;|&#7876;)/", 'E', $text);
      $text = preg_replace("/(||&#7864;|&#7866;|&#7868;||&#7872;|&#7870;|&#7878;|&#7874;|&#7876;)/", 'E', $text);
      $text = preg_replace("/(||&#7882;|&#7880;|&#296;)/", 'I', $text);
      $text = preg_replace("/(||&#7882;|&#7880;|&#296;)/", 'I', $text);
      $text = preg_replace("/(||&#7884;|&#7886;|||&#7890;|&#7888;|&#7896;|&#7892;|&#7894;|&#416;|&#7900;|&#7898;|&#7906;|&#7902;|&#7904;)/", 'O', $text);
      $text = preg_replace("/(||&#7884;|&#7886;|||&#7890;|&#7888;|&#7896;|&#7892;|&#7894;|&#416;|&#7900;|&#7898;|&#7906;|&#7902;|&#7904;)/", 'O', $text);
      $text = preg_replace("/(||&#7908;|&#7910;|&#360;|&#431;|&#7914;|&#7912;|&#7920;|&#7916;|&#7918;)/", 'U', $text);
      $text = preg_replace("/(||&#7908;|&#7910;|&#360;|&#431;|&#7914;|&#7912;|&#7920;|&#7916;|&#7918;)/", 'U', $text);
      $text = preg_replace("/(&#7922;||&#7924;|&#7926;|&#7928;)/", 'Y', $text);
      $text = preg_replace("/(&#272;)/", 'D', $text);
      $text = preg_replace("/(&#7922;||&#7924;|&#7926;|&#7928;)/", 'Y', $text);
      $text = preg_replace("/(&#272;)/", 'D', $text);
      $text=strtolower($text);
      return $text;
   }

- Untuk menampilkan 3 blog terakhir di mainmenu.php
-------tambahkan kode berikut-----------------
//myblog modul
echo '<a href="myblog/"><div class="phdr"><b>Update MyBlog</b></div></a><div class="menu">';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog`"), 0);
      if($total) {
         $req = mysql_query("SELECT `id`,`user_id`, `name`, `count`, `text`, `time` FROM `myblog` ORDER BY `id` DESC LIMIT 3");
         $i = 1;
         while (($row = mysql_fetch_assoc($req)) !== false) {
            echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
            if(file_exists('files/myblog/small_news_' . $row['id'] . '.jpg') !== false) {
               echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="32">';
               echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../files/myblog/small_news_' . $row['id'] . '.jpg" alt="" width="32" height="32"/>&#160;';
               echo '</td><td>';
               echo '<a href="../myblog/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html"><div class="menu">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '<br/>(' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/></div></a>';
               echo '</td></tr></table>';
            } else {
               echo '<a href="../myblog/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html"><div class="menu">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '<br/> (' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/></div></a>';
            }
            echo '<div class="sub"></div>';
            $text = $row['text'];
            if(mb_strlen($text) > 100) {
               $str = mb_substr($text, 0, 100);
               $text = mb_substr($str, 0, mb_strrpos($str, ' ')) . '...';
            }
            echo functions::checkout($text, 2, 1);
            
            $us = mysql_query("SELECT `id`, `name` FROM `users` WHERE `id` = '".$row['user_id']."'");         
              if (mysql_num_rows($us)) {
         $rowuse = mysql_fetch_assoc($us);
         $name_use = $user_id ? '<a href="../users/profile.php?id=' . $rowuse['id'] . '">' . $rowuse['name'] . '</a>' : $rowuse['name'];
      } else {
         $name_use = $lng['guest'];
      }
             
            
             
              echo '<br/><a href="../myblog/comments.php?id=' . $row['id'] . '">Comment :</a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog_comments` WHERE `refid`= '".$row['id']."' "), 0) . ')';
              echo '<br/>Posted by:<a href="../users/profile.php?user=' . $rowuse['id'] . '"> ' . $rowuse['name'] . '</a>';
            echo '<br/>Posted On: ' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . '';
              echo '<br/>View: '.$row['count'].' kali ';
            echo '</div>';
            
            ++$i;
         }
         }

