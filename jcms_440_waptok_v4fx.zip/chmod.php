<html>
<body style="background:black;color:#00ff00;text-align:center;">
<?php
chmod("blogs",0777);
chmod("goblogs",0777);
chmod("myblog",0777);
chmod("download/arctemp",0777);
chmod("download/files",0777);
chmod("download/graftemp",0777);
chmod("download/screen",0777);
chmod("files/cache",0777);
chmod("files/forum/attach",0777);
chmod("files/blogs",0777);
chmod("files/goblogs",0777);
chmod("files/myblog",0777);
chmod("files/library",0777);
chmod("files/users/album",0777);
chmod("files/users/avatar",0777);
chmod("files/users/photo",0777);
chmod("files/users/pm",0777);
chmod("forum/file",0777);
chmod("library/temp",0777);
chmod("gallery/foto",0777);
chmod("gallery/temp",0777);
chmod("incfiles",0777);
chmod("library/java/textfile.txt",0666);
chmod("library/java/META-INF/MANIFEST.MF",0666);
?>
<a style="color:#00ff00;" href="install/index.php">Go To Installation Step</a>
<br /><br /><b><a style="color:#990000;" href="http://www.waptok.asia" target="_blank">WWW.WAPTOK.ASIA</a>
<br /><br />&copy; 2013 WHIZNOE&trade;
</b>
</body>
</html>