<?php

/** Moduls grab Jcms Mod by Whiznoe
* http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'grab maker';
$textl = 'Grab Maker';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");


if(!$_GET['source'])
{
switch($_GET['go'])
{
default:
echo'<form action="kod.php" method="post">';

echo'<div class="mainblok"><div class="phdr">Grab Maker</div>';
echo'<div class="menu">Url situs:<br/>
<input name="site" value="http://"/>
<br/>
nama link:<br/>
<input name="search_1"/><br>
ganti nama:<br>
<input name="replace_1"/>
<br/>
nama link:<br/>
<input name="search_2"/>
<br/>
ganti nama:<br/>
<input name="replace_2"/>
<br/>
nama link:<br/>
<input name="search_3"/><br>
ganti nama:<br/>
<input name="replace_3"/>
<br/>
nama link:<br/>
<input name="search_4"/><br/>
ganti nama:<br/>
<input name="replace_4"/>
<br/>
nama link:<br/>
<input name="search_5"/><br>
ganti nama:<br/>
<input name="replace_5"/>
<br/>
nama link:<br/>
<input name="search_6"/><br>
ganti nama link:<br/>
<input name="replace_6"/>
<br/>
<input type="reset" value="Delete">
<br/>
<input value="GET" type="submit"/></form>';
echo'<br/></body></html>';

}

}
echo'<br></div></div>';
require_once ("../incfiles/end.php");

?>
