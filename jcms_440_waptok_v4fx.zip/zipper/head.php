<?php
/** 
* moduls grab Jcms by whiznoe
* http://waptok.asia

*/

define('_IN_JOHNCMS', 1);

$headmod = 'wap zipper';
$textl = 'Wap Zipper Online';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

?>
