<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS v.1.1.0                     30.05.2008                             //
// Официальный сайт сайт проекта:      http://johncms.com                     //
// Дополнительный сайт поддержки:      http://gazenwagen.com                  //
////////////////////////////////////////////////////////////////////////////////
// JohnCMS core team:                                                         //
// Евгений Рябинин aka john77          john77@gazenwagen.com                  //
// Олег Касьянов aka AlkatraZ          alkatraz@gazenwagen.com                //
//                                                                            //
// Плагиат и удаление копирайтов заруганы на ближайших родственников!!!       //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
    die('Error: restricted access');
echo '<div class="phdr"><a href="index.php"><b>' . $lng['admin_panel'] . '</b></a> | Welcome Message</div>';
if (isset ($_POST['submit'])) {
    if (empty($_POST['email_theme']) || empty($_POST['email_text'])) {
        echo '<p>ERROR<br />You did not insert a topic or text<br /><a href="index.php?act=email">Back</a></p>';
        require_once ("../incfiles/end.php");
        exit;
    } 
    mysql_query("UPDATE `cms_settings` SET `val`='" . (isset ($_POST['email']) ? intval($_POST['email']) : 0) . "' WHERE `key`='welcome'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['email_theme']) . "' WHERE `key` = 'email_theme'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['email_text']) . "' WHERE `key` = 'email_text'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['email_sender']) . "' WHERE `key` = 'email_sender'");
    $req = mysql_query("SELECT * FROM `cms_settings`");
    $set = array();
    while ($res = mysql_fetch_row($req)) $set[$res[0]] = $res[1];
    echo '<div class="rmenu">Welcome message successfuly changed</div>';
} 
echo '<form action="index.php?act=email" method="post"><div class="menu"><p>';
echo '<h3>Send a welcome message?</h3>';
echo '<input type="radio" value="1" name="email" ' . ($set['welcome'] == 1 ? 'checked="checked"' : '') . '/>&nbsp;Yes,send welcome message.<br />';
echo '<input type="radio" value="0" name="email" ' . (!$set['welcome'] ? 'checked="checked"' : '') . '/>&nbsp;No, do not send welcome message.';
echo '</p><p><h3>Text Message</h3>';
$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = bbcode::tags($text);
echo '&nbsp;Title:<br/>&nbsp;<input type="text" name="email_theme" value="' . htmlentities($set['email_theme'], ENT_QUOTES, 'UTF-8') . '"/><br/>';
echo '&nbsp;Text:<br />&nbsp;<textarea cols="20" rows="4" name="email_text">' . $set['email_text'] . '</textarea>';
echo '</p><p><h3>Sender</h3>';
echo '<select name="email_sender">';
$sql = mysql_query("SELECT `id`, `name` FROM `users` WHERE `rights` >= 9");
while ($res = mysql_fetch_array($sql)) {
    echo '<option value="' . $res['id'] . '"' . ($set['email_sender'] == $res['id'] ? ' selected="selected">' : '>') . $res['name'] . '</option>';
} 
echo '</select>';
echo '</p><p><input type="submit" value="Save" name="submit" /></p></div>';
echo '</form><div class="phdr">&nbsp;</div>';
echo '<p><a href="index.php">' . $lng['admin_panel'] . '</a></p>';

?>