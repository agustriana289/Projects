<?
/** Popular Topic Forum Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * Modify by Whiznoe
 * http://waptok.asia
 * http://indozona.tk
 */

echo '<div class="mainblok">';
echo '<div class="phdr"><b>' . $lng['popular_topic'] . '</b></div>';
$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 
$req = mysql_query("SELECT *, `id` AS `indozona`, (SELECT COUNT(*) FROM `forum` WHERE `refid` = `indozona` AND `type` = 'm' AND `close` != '1') AS `total_post` FROM `forum` WHERE `type`='t' AND `edit` != '1' AND `close` != '1' ORDER BY `total_post` DESC LIMIT 5");

$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
echo '<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html'. ($cpg > 1 && $_SESSION['uppost'] ? '&amp;clip&amp;page=' . $cpg : '') . '">' . $res['text'] . '</a>&#160;[' . $colmes1 . ']';
if ($cpg > 1)
echo '<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&rarr;</a>';
echo '<span class="gray">&nbsp;by: '.$res['from'].'</span>';
echo '</div>';
++$i;
}
    if ($startreq > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php' . $id . '?', $startreq, $total, $kmessreq) . '</div>';

}


if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo '</div>';

?>