<?php
/** Forum Category Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * http://www.waptok.asia
 * http://indozona.tk
 * http://waptok.tk
 */

switch($act) 
{ 
default: 
echo '<div class="mainblok"><div class="phdr"><b>Forum Category</b></div>';
echo '<div class="topmenu"><b>Forum Category</b> | <a href="/index.php?act=top_forum"><b>Top Forum</b></a></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        while (($res = mysql_fetch_array($req)) !== false) {
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
            echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_'.$res['id'].'.html">' . $res['text'] . '</a> [<font color="red">' . $count . '</font>]';
            if (!empty($res['soft']))
                echo '<div class="func"><span class="gray">' . $res['soft'] . '</span></div>';
            echo '</div>';
            ++$i;
        }

           if ($count == 0)
{
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}

echo '</div>';
// add
break;
case 'top_forum':
$waptok = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while (($dd = mysql_fetch_array($waptok)) !== false) {
echo '<div class="mainblok"><div class="phdr"><b>Forum Category</b></div>';
echo '<div class="topmenu"><a href="/index.php"><b>Forum Category</b></a> | <b>Top Forum</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`='" . $dd['id'] . "' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
$indo = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' and `refid`='" . $res['id'] . "'"), 0);
echo '<div class="'.(++$j%2==0 ? "list2" : "list1").'">&bull; <a href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a>        Topics : '.$indo.'<br/>';
if ($user_id) {
echo '<a class="omenu" href="/forum/index.php?act=nt&id=' . $res['id'] . '">Add Post</a>';
}
echo '</div>';
if ($rights >= 9) 
{ 
echo '<div class="rmenu">[<a href="/panel/index.php?act=forum&mod=edit&id=' . $res['id'] . '">Edit</a>] | [<a href="/panel/index.php?act=forum&mod=del&id=' . $res['id'] . '">Delete</a>]</div>';
}
++$j;
}
echo '</div>';
}

}
//echo '</div>';

?>