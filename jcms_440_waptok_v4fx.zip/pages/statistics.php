<?
/**
 * Statistics Mod
 * Copyright (C) 2008-2011 JohnCMS 440
 * Author http://johncms.com/about
 * Mod http://www.waptok.asia
 */

switch($act) 
{ 
default: 
echo '<div class="mainblok"><div
class="phdr"><b>' . $lng['statistics'] . '</b></div>';
echo '<div class="topmenu"><b>' . $lng['statistics'] . '</b> | <a href="/index.php?act=top"><b>Users Top</b></a> | <a href="/index.php?act=load"><b>' . $lng['new_files'] . '</b></a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `download` WHERE `time` > '" . (time() - 259200) . "' AND `type` = 'file'"), 0) . ')</div>';
echo'<div class="list2">&#x2022; Total Blogs: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog`"), 0) . '</b></div>';
//echo'<div class="list1">&#x2022; Total Manga: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `manga`"), 0) . '</b></div>';
echo'<div class="list1">&#x2022; Total Files: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . '</b></div>';
echo'<div class="list2">&#x2022; Total Topic: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `close` != '1'"), 0) . '</b></div>';
echo'<div class="list1">&#x2022; Total Post: <b>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `close` != '1'"), 0) . '</b></div>';
$thanhvienmoi=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` ORDER BY `datereg` DESC LIMIT 1"));
$all_users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`;"), 0);

$users_boys = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'm';"), 0);

$users_girls = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex` = 'zh';"), 0);
 echo '<div class="list2">&#x2022; Member: <b>' . $users_boys . ' Boys </b>and <b>' . $users_girls . ' Girls</b></div>'; 
echo'</div>';

break;
case 'top':
echo '<div class="mainblok"><div class="phdr"><b>' . $lng['statistics'] . '</b></div>';
echo '<div class="topmenu"><a href="/index.php"><b>' . $lng['statistics'] . '</b></a> | <b>Users Top</b> - <a href="../users/index.php?act=top"><b>Detail</b></a> | <a href="/index.php?act=load"><b>' . $lng['new_files'] . '</b></a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `download` WHERE `time` > '" . (time() - 259200) . "' AND `type` = 'file'"), 0) . ')</div>';

function get_top($order = 'postforum') {
global $lng;
$req = mysql_query("SELECT * FROM `users` WHERE `$order` > 0 ORDER BY `$order` DESC LIMIT 3");
if (mysql_num_rows($req)) {
$out = '';
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
$out .= $i % 2 ? '<div class="list2">' : '<div class="list1">';
$out .= functions::display_user
($res, array ('header' =>
('<b>' . $res[$order]) . '<b>')) .
'</div>';
++$i;
}
return $out;
} else {
return '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
}
echo get_top('postforum');
echo'</div>';
break;
case 'load':
$req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `type` = 'file'");
$total = mysql_result($req, 0);
    
    $req = mysql_query("SELECT * FROM `download` WHERE `type` = 'file' ORDER BY `id` DESC LIMIT 5");
$i = 0;
 {
echo '<div class="mainblok"><div class="phdr"><b>' . $lng['statistics'] . '</b></div>';
echo '<div class="topmenu"><a href="/index.php"><b>' . $lng['statistics'] . '</b></a> | <a href="/index.php?act=top"><b>Users Top</b></a> | <b>' . $lng['new_files'] . '</b> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `download` WHERE `time` > '" . (time() - 259200) . "' AND `type` = 'file'"), 0) . ')</div>'; 
    while ($newf = mysql_fetch_array($req)) {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        $fsz = filesize("download/$newf[adres]/$newf[name]");
        $fsz = round($fsz / 1024, 2);
        $ft = functions::format("$newf[adres]/$newf[name]");
        switch ($ft) {
            case "mp3" :
                $imt = "mp3.png";
                break;
            case "zip" :
                $imt = "rar.png";
                break;
            case "jar" :
                $imt = "jar.png";
                break;
            case "gif" :
                $imt = "gif.png";
                break;
            case "jpg" :
                $imt = "jpg.png";
                break;
            case "png" :
                $imt = "png.png";
                break;
            default :
                $imt = "file.gif";
                break;
        }
        echo '<img class="middle" src="images/arrow.png" alt="last upload"/> <a href="/download/?act=view&amp;file=' . $newf['id'] . '">' . htmlentities($newf['name'], ENT_QUOTES, 'UTF-8') . '</a> (' . $fsz . ' kB)';
        $l = mb_strlen($pat);
        $pat1 = mb_substr($pat, 0, $l - 1);
echo '</div>';
        ++$i;
    }
    if ($total == 0) {
    echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo'</div>';
}

}
?>