<?php 
/** Update Post Forum Jcms 
 * Copyright Jcms 4.4.0 
 * Author http://johncms.com/about 
 * http://waptok.asia 
 * http://waptok.tk 
 * http://indozona.tk 
 */ 
                                                                                                                        
switch($act) 
{ 
default: 
echo '<div class="mainblok"><div class="phdr"><b>Update Forum</b></div>';
echo '<div class="topmenu"><b>Recent Post</b> | <a href="/index.php?act=new"><b>New Post</b></a> | <a href="/index.php?act=popular"><b>Popular Topic</b></a></div>';
$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 
 
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `time` DESC LIMIT $startreq, $kmessreq"); 
while ($arr = mysql_fetch_assoc($req)) { 
$nikuser = mysql_query("SELECT `from`,`id`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "' ORDER BY time DESC"); 
$colmes1 = mysql_num_rows($nikuser); 
$cpg = ceil($colmes1 / $kmess); 
$nam = mysql_fetch_assoc($nikuser);
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
if ($arr['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
echo '<b>';
switch ($arr['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;

default:
break;
}
echo '</b>';
//echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '_p' . $cpg . '.html">' . $arr['text'] . '</a> [' . $colmes1 . ']';
echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '.html">' . $arr['text'] . '</a> [' . $colmes1 . ']';
if ($cpg > 1)
echo '<small> <a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&gt;&gt;</a></small>';
echo '<div class="sub">'.$arr['from'].' &raquo;&nbsp;';
if ($colmes1 > 1){
echo ''.$nam['from'].'';
}else
echo ''.$arr['from'].'';
echo '&nbsp;<span class="gray">' . counters::update_time($arr['time']) . '</span>';
echo '</div></div>';
$i++;
}

    if ($total > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php' . $id . '?', $startreq, $total, $kmessreq) . '</div>';

}


if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}

echo '</div>';
break;
case 'new':
$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 

echo '<div class="mainblok"><div class="phdr"><b>Update Forum</b></div>';
echo '<div class="topmenu"><a href="/index.php"><b>Recent Post</b></a> | <b>New Post</b> | <a href="/index.php?act=popular"><b>Popular Topic</b></a></div>'; 
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `id` DESC LIMIT $startreq, $kmessreq"); 
while ($arr = mysql_fetch_assoc($req)) { 
$nikuser = mysql_query("SELECT `from`,`id`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "' ORDER BY time DESC"); 
$colmes1 = mysql_num_rows($nikuser); 
$cpg = ceil($colmes1 / $kmess); 
$nam = mysql_fetch_assoc($nikuser);
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
if ($arr['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>';
echo '<b>';
switch ($arr['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;

default:
break;
}
echo '</b>';
//echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '_p' . $cpg . '.html">' . $arr['text'] . '</a> [' . $colmes1 . ']';
echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '.html">' . $arr['text'] . '</a> [' . $colmes1 . ']';
if ($cpg > 1)
echo '<small> <a href="'.$home.'/forum/' . functions::gantiurl($arr['text']) . '_' . $arr['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&gt;&gt;</a></small>';
echo '<div class="sub">'.$arr['from'].' &raquo;&nbsp;';
if ($colmes1 > 1){
echo ''.$nam['from'].'';
}else
echo ''.$arr['from'].'';
echo '&nbsp;<span class="gray">' . counters::update_time($arr['time']) . '</span>';
echo '</div></div>';
$i++;
}

    if ($total > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php?act=new&amp;' . $id . '', $startreq, $total, $kmessreq) . '</div>';

  
}


if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}

echo '</div>';

break;
case 'popular':
echo '<div class="mainblok"><div class="phdr"><b>Update Forum</b></div>';
echo '<div class="topmenu"><a href="/index.php"><b>Recent Post</b></a> | <a href="/index.php?act=new"><b>New Post</b></a> | <b>Popular Topic</b></div>';
$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 
$req = mysql_query("SELECT *, `id` AS `onespot`, (SELECT COUNT(*) FROM `forum` WHERE `refid` = `onespot` AND `type` = 'm' AND `close` != '1') AS `total_post` FROM `forum` WHERE `type`='t' AND `edit` != '1' AND `close` != '1' ORDER BY `total_post` DESC LIMIT $startreq, $kmessreq");

$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
echo '&#160;<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html'. ($cpg > 1 && $_SESSION['uppost'] ? '&amp;clip&amp;page=' . $cpg : '') . '">' . $res['text'] . '</a>&#160;[' . $colmes1 . ']';
if ($cpg > 1)
echo '&#160;<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&rarr;</a>';
echo '<span class="gray">&nbsp;by: '.$res['from'].'</span>';
echo '</div>';
++$i;
}
    if ($total > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php?act=popular&amp;' . $id . '', $startreq, $total, $kmessreq) . '</div>';

}

if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo '</div>';

}
                                                                                                                                                                                   
?>