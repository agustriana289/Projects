<html>
<body style="background:black;color:#00ff00;text-align:center;">
<?php
#AUTO CHMOD SETELAH INSTALASI
chmod("incfiles/db.php",0644);
chmod("incfiles",0755);
chmod("install",0600);
unlink("chmod.php");
unlink("install");

?>
<center><a style="color:#ff3300;" href="panel">Goto Admin Panel</a><br /><br /><a href="../index.php">Goto Site</a><br/><br/>&copy; 2013 [whiznoe]&trade;
</center>
</body>
</html>
