<?
/*
Originally by: FIKTIFisme
Modded by kayukalek.org
*/

$user_u = $res['user_id'];
$req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_u' LIMIT 1");
$res_u = mysql_fetch_array($req_u);
$exp = $res_u['postforum'] + $res_u['postguest'] + $res_u['komm'];
if ($res_u['rights']<3){

if ($exp>=0 && $exp<=50)
echo 'Newbie';
if ($exp>=50 && $exp<=100)
echo 'SundaWap Users';
if ($exp>=100 && $exp<=200)
echo 'Aktivis SundaWap';
if ($exp>=200 && $exp<=500)
echo 'SundaWap Holic';
if ($exp>=500 && $exp<=750)
echo 'SundaWap Addict';
if ($exp>=750 && $exp<=1000)
echo 'SundaWap Maniac';
if ($exp>=1000 && $exp<=1200)
echo 'SundaWap Geek';
if ($exp>=1200 && $exp<=1500)
echo 'SundaWap Freak';
if ($exp>=1500 && $exp<=2000)
echo 'Made in SundaWap';
}else{
$user_rights = array(
3 => 'Moderator',
6 => 'Staff',
7 => 'Admin',
9 => '<font color="#CC6600">Admin Global</font>'
);
echo @$user_rights[$res['rights']];
}
?>