<?php
/** Multi Search & Load Files Jcms
* by http://4alka.tk
* Moduls Grab repack by http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'search & load files';
$textl = 'Search & Load Files';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

?>
