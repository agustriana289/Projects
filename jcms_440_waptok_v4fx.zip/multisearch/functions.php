<?php
######################
## forged on 4alka.TK#
## http://waptok.asia#
######################

function format_bytes($a_bytes)
{//taken from php.net
if ($a_bytes < 1024) {
return $a_bytes .' B';
} elseif ($a_bytes < 1048576) {
return round($a_bytes / 1024, 2) .' KB';
} elseif ($a_bytes < 1073741824) {
return round($a_bytes / 1048576, 2) . ' MB';
} elseif ($a_bytes < 1099511627776) {
return round($a_bytes / 1073741824, 2) . ' GB';
} elseif ($a_bytes < 1125899906842624) {
return round($a_bytes / 1099511627776, 2) .' TB';
} elseif ($a_bytes < 1152921504606846976) {
return round($a_bytes / 1125899906842624, 2) .' PB';
} elseif ($a_bytes < 1180591620717411303424) {
return round($a_bytes / 1152921504606846976, 2) .' EB';
} elseif ($a_bytes < 1208925819614629174706176) {
return round($a_bytes / 1180591620717411303424, 2) .' ZB';
} else {
return round($a_bytes / 1208925819614629174706176, 2) .' YB';
}
}

function utf8_format($item){
$onlyutf8=preg_replace('/' . '[\x00-\x08\x10\x0B\x0C\x0E-\x19\x7F]' .
'[0x20]' . '|[\x00-\x7F][\x80-\xBF]+' . '|([\xC0\xC1]|[\xF0-\xFF])[\x80-\xBF]*' .
'|[\xC2-\xDF]((?![\x80-\xBF])|[\x80-\xBF]{2,})' . '|[\xE0-\xEF](([\x80-\xBF](?![\x80-\xBF]))|' .
'(?![\x80-\xBF]{2})|[\x80-\xBF]{3,})' . '/','_',$item);

$onlyutf8 = preg_replace('/[^[:print:]]/', '', $onlyutf8);

return $onlyutf8;
}

function easyhtmlink($content){

$content=preg_replace('#http://www\\.4shared\\.com\/download\/(.*?)\/(.*?)\\.htm#','\1&mod=\2',$content);

return  $content;}

?>
