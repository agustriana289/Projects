<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$name=htmlentities($_GET['name']);
$page=htmlentities($_GET['page']);

$req=mysql_query("SELECT * FROM category WHERE site_id = '" . $site_id . "' AND link = '" . mysql_real_escape_string($name) . "'");

if (mysql_num_rows($req) == 0)
{
require_once('themes/desktop/header.php');
echo '<div id="content"><div class="post"><h2 class="title">'.str_replace('::name::','',$LANG['category_not_found']).'</h2></div></div>';
require_once('themes/desktop/footer.php');
}
else {
$cat = mysql_fetch_array($req);

// Cek follower
$is_follower = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '" . $user_id . "' AND url = '" . mysql_real_escape_string($site_url) . "'"), 0);

$head_title = $cat['name'];
require_once('themes/desktop/header.php');

echo '<div id="content">';

if ($page == 1 || empty($page) || $page > (ceil(count(explode(",",$cat['blog_id'])))))
$page = 0;
$max_view = $site['num_post_main'];
$pgs = $page * $max_view;
$lmt = $pgs + $max_view;

echo '<h3>Menampilkan posting pada kategori <i>' . htmlspecialchars($cat['name']) . '</i></h3>';
if (!empty($cat['blog_id']))
{
$eks = explode(",",$cat['blog_id']);
$count = count($eks);
if ($count < $lmt)
$lmt = $count;
$i = $pgs;
while ($i < $lmt)
{
if (!empty($eks[$i]) && ctype_digit($eks[$i]))
{
$blog = mysql_fetch_array(mysql_query("SELECT * FROM blog WHERE id='".mysql_real_escape_string($eks[$i])."' AND site_id='".$site['id']."' AND draft='0'"));

echo '<div class="post"><h2><a href="' . $site['url'] . '/' . $blog['link'] . '.xhtml">' . htmlspecialchars($blog['title']) . '</a></h2>';

echo '<p class="meta">oleh ' . iwbid($site_id) . ' pada ' . waktu($blog['time']) . '</p><div style="float: left;"></div>';

if ($site['desc_post_main'] == 1 || mb_strlen(strip_tags($blog['description'])) < 300)
$description = $blog['description'];
else
$description='' . substr($blog['description'], 0, 300) . ' ...<a href="' . $site_url . '/' . $blog['link'] . '.xhtml">Selengkapnya &raquo;</a>';

$komentar = mysql_result(mysql_query("SELECT COUNT(*) FROM comment WHERE blog_id = '" . $blog['id'] . "' AND status = '1'"), 0);

if ($blog['private'] == 1) {
if ($user_id)
echo '<p>' . iwb_html($description) . '</p>';
else
echo '<p>'.$LANG['post_only_for_member'].'</p>';
}
elseif ($blog['private'] == 2) {
if ($is_follower > 0 || $user_id == $site_id)
echo '<p>' . iwb_html($description) . '</p>';
else
echo '<p>'.$LANG['post_only_for_follower'].'</p>';
}
else {
echo '<p>' . iwb_html($description) . '</p>';
}
echo '<p class="comment-meta"><a href="' . $site_url . '/' . $blog['link'] . '.xhtml">' . $komentar . '</a></p><div style="clear:both"></div></div>';
$i++;
}
}
$total = $count;
$link = '' . $site_url . '/category/' . $cat['link'] . '/';
$q='.xhtml';
if (empty($page))
$page = 1;
$pages = ceil($total/$max_view);
if ($pages>1)
{
echo '<div id="pagination_links">'.$LANG['page'].':<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</div></div>';
}
echo '</div>';
}
else {
echo '<div class="post"><h2 class="title">'.$LANG['category_empty'].'</h2></div></div>';
}
require_once('themes/desktop/footer.php');
}
?>