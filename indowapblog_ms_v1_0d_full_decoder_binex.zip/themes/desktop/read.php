<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

if (substr($_SERVER['REQUEST_URI'], -12) == "translate=en")
{
$blog_description = GoogleTranslate($blog_description,"en");
}
elseif (substr($_SERVER['REQUEST_URI'], -12) == "translate=ru")
{
$blog_description = GoogleTranslate($blog_description,"ru");
}
else {
$blog_description = $blog_description;
}
$Trans2RU='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=ru">RU</a>]';
$Trans2EN='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=en">EN</a>]';

$t = htmlentities($_GET['t']);

$cek = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND link = '".mysql_real_escape_string($t)."' AND draft = '0'");
if (mysql_num_rows($cek) == 0)
{
require_once('themes/desktop/header.php');
echo '<div id="content"><div class="post-single"><h2>'.$LANG['blog_not_found'].'</h2><div style="float: left;"></div>
	<p>'.$LANG['blog_not_found'].'</p></div></div>';
require_once('themes/desktop/footer.php');
exit;
}
else {
$blogs = mysql_fetch_array($cek);

$tot = $blogs['count'] + 1;
mysql_query("UPDATE blog SET count = '".$tot."' WHERE id = '".$blogs['id']."'");

$is_follower = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '".$user_id."' AND url = '".mysql_real_escape_string($site_url)."'"), 0);
if ($blogs['private'] == 1) {
if ($user_id)
$blog_description = $blogs['description'];
else
$blog_description = $LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2) {
if ($site_id == $user_id || $is_follower > 0)
$blog_description = $blogs['description'];
else
$blog_description = $LANG['post_only_for_follower'];
}
else {
$blog_description = $blogs['description'];
}
$head_description = $blog_description;
$head_title = $blogs['title'];
require_once('themes/desktop/header.php');

echo '<div id="content"><div class="post-single"><h2>'.htmlspecialchars($blogs['title']).'</h2> <p class="meta">'.$LANG['by'].' '.iwbid($site_id).' '.$LANG['on'].' '.waktu($blogs['time']).'</p><div style="float: left;"></div><p>'.iwb_html($blogs['description']).'</p><br /><p class="share_button"><a href="http://www.facebook.com/sharer.php?u='.$site['url'].'/'.$blogs['link'].'.xhtml" rel="nofollow"><img src="'.$site['url'].'/files/fb_share.gif" alt="Share on Facebook" /></a></p>';

if (!empty($blogs['category']))
{
echo '<p>'.$LANG['category'].': ';
$exkt = explode(",",$blogs['category']);
$countexp = count($exkt) -1;
for ($e = 0; $e <= $countexp; $e++)
{
$ktname = mysql_fetch_array(mysql_query("SELECT * FROM category WHERE id = '".mysql_real_escape_string($exkt[$e])."' AND site_id = '".$site['id']."'"));
echo '<a href="'.$site['url'].'/category/'.$ktname['link'].'/1.xhtml">'.htmlentities($ktname['name']).'</a>, ';
}
if (!empty($blogs['tag'])) {
echo '<br />'.$LANG['tag'].': ';
$exp = explode(",", $blogs['tag']);
if ($exp) {
$count = count($exp) - 1;
for ($i = 0; $i <= $count; $i++) {
echo '<a href="'.$site_url.'/tag/'.$exp[$i].'/1.xhtml">'.str_replace('-', ' ', $exp[$i]).'</a> ';
}
}
else {
echo '<a href="'.$site_url.'/tag/'.$blogs['tag'].'/1.xhtml">'.str_replace('-', ' ', $blogs['tag']).'</a>';
}
}
echo '</p>';
}
echo '<div style="clear:both"></div>
    </div>';
function show_comments()
{
global $blogs, $site, $user_id, $user_name, $user_site, $user_email, $t, $limit, $max_view;
echo '<div id="comment">
        <h2><a name="comment">'.$GLOBALS['LANG']['comments'].'</a> <small>(<a href="'.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'/rss.xml">RSS</a> / <a href="'.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'/subscribe.xhtml">'.$GLOBALS['LANG']['email'].'</a>)</small></h2>';
$total_comments = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM comment WHERE blog_id = '".$GLOBALS['blogs']['id']."' AND status = '1'"), 0);
if ($total_comments > 0)
{
echo '<h3>'.$total_comments.' Respon untuk
&quot;'.htmlspecialchars($GLOBALS['blogs']['title']).'&quot;</h3>';
}
else
{
echo '<h3>'.$GLOBALS['LANG']['comment_empty'].'</h3>';
}
if ($GLOBALS['site']['display_count'] == 1)
echo '<h3>Dilihat sebanyak &quot;'.$GLOBALS['blogs']['count'].'&quot; kali</h3>';
if ($total_comments > 0)
{
$comment = mysql_query("SELECT * FROM comment WHERE blog_id = '".$GLOBALS['blogs']['id']."' AND status = '1' ORDER BY time ASC");
while ($comments = mysql_fetch_array($comment))
{
echo '<div class="comment"><h3>';
if (!empty($comments['site']))
echo '<a href="'.htmlentities($comments['site']).'/" rel="nofollow">'.htmlspecialchars($comments['name']).'</a>';
else
echo htmlspecialchars($comments['name']);
echo '<small> ['.waktu($comments['time']).']</small></h3>
<p>'.bbsm($comments['text']).'</p>
</div>';
}
}

if ($GLOBALS['blogs']['allow_comment'] == 1)
{
echo '<h2><a name="new_comment">'.$GLOBALS['LANG']['add_comment'].'</a></h2>';
$skrg='/'.$blogs['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil = $GLOBALS['LANG']['incorrect_security_code'];
if ($string == 'err_msg')
$hasil = $GLOBALS['LANG']['empty_text'];
if ($string == 'err_mail')
$hasil = $GLOBALS['LANG']['empty_email'];
if ($string == 'err_invalid_email')
$hasil = $GLOBALS['LANG']['incorrect_email'];
if ($string == 'err_leng_email')
$hasil = $GLOBALS['LANG']['lenght_email'];
if ($string == 'err_name')
$hasil = $GLOBALS['LANG']['empty_name'];
if ($string == 'ok')
$hasil = $GLOBALS['LANG']['comment_waiting_approved'];
if ($string == 'success')
$hasil = $GLOBALS['LANG']['comment_successfully_added'];
if (!empty($hasil))
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hasil.'</li></ol>';
if ($GLOBALS['user_id'])
{
$form_title = $GLOBALS['user_name'];
$form_site = $GLOBALS['user_site'];
$form_email = $GLOBALS['user_email'];
}
else
{
$form_title = stripslashes($_SESSION['nama']);
$form_site = stripslashes($_SESSION['url']);
$form_email = stripslashes($_SESSION['email']);
}
echo '<form
id="comment_form"
action="'.$GLOBALS['site']['url'].'/comment.xhtml"
method="post">
<p>';
$redir=''.$GLOBALS['site']['url'].'/'.$blogs['link'].'.xhtml#new_comment';
if (!$GLOBALS['user_id'])
echo '[<a
href="'.$GLOBALS['site']['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['login'].'</a>]
<br/>';
else
echo '[<a
href="'.$GLOBALS['site']['url'].'/login.php?iwb=logout&amp;redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['logout'].'</a>]<br/>';
echo ''.$GLOBALS['LANG']['name'].'<br/>
<input type="text"
name="title" value="'.$form_title.'"/><br />'.$GLOBALS['LANG']['site'].'<br/>
<input type="text"
name="site" value="'.$form_site.'"/>';
if ($GLOBALS['site']['comment_email'] == 1)
echo '<br/>'.$GLOBALS['LANG']['email'].'<br/>
<input type="text"
name="email" value="'.$form_email.'"/>';
echo '<br/>'.$GLOBALS['LANG']['comments'].'<br/><textarea
name="body" rows="4"/></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($GLOBALS['site']['comment_captcha'] == 1)
{
echo '<br />'.$GLOBALS['LANG']['security_code'].'<br /><img src="'.$GLOBALS['site']['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" value=""/>';
}
else {
echo '<input type="hidden" name="code" value="'.htmlentities($_SESSION['captcha_code']).'">';
}
echo '</p><p><input type="hidden"
name="t" value="'.$GLOBALS[t].'"/><input
name="comment"
type="submit" id="comment"
value="'.$GLOBALS['LANG']['send'].'"/></p></form>';
}
else {
echo '<h2><a name="new_comment">'.$GLOBALS['LANG']['comment_closed'].'</a></h2>';
}
echo '</div>';
}

if (($blogs['private'] == 1 && $user_id) || $blogs['private'] == 0 || ($blogs['private'] == 2 && ($site_id == $user_id || $is_follower > 0))) {
show_comments();
}
else {
echo '<div id="comment"><h2>'.$LANG['comment_hidden'].'</h2></div>';
}

echo '</div>';
require_once('themes/desktop/footer.php');
}
?>