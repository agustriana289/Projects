<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

if ($_SERVER['REDIRECT_STATUS'] == 400)
{
$head_title='Bad Request';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 403)
{
$head_title='Access Forbidden';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 404)
{
$head_title='Halaman Tidak Ditemukan';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 414)
{
$head_title='Long URI';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 500)
{
$head_title='Internal Server Error';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 502)
{
$head_title='Bad Gateway';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 503)
{
$head_title='Layanan Tidak Tersedia';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 505)
{
$head_title='HTTP Tidak Didukung';
}
else
{
$head_title='Ooopps...';
}

require_once('themes/default/header.php');
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">Beranda</a></td><td width="50%" class="nav-menu current">Kesalahan</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post"><!-- post-list start --><div class="post-list"><h1>'.htmlspecialchars($head_title).'</h1></p>Error Status: '.htmlspecialchars($head_title).'</p></div><!-- post-list end --></div><!-- post end -->';
require_once('themes/default/footer.php');
?>