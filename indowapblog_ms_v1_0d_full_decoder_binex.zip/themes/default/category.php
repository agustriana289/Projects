<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$name=htmlentities($_GET['name']);
$page=htmlentities($_GET['page']);

$req=mysql_query("select * from category where site_id='".$site['id']."' and link='".mysql_real_escape_string($name)."'");

if (mysql_num_rows($req) == 0)
{
$head_title=$LANG['category'];
require_once('themes/default/header.php');
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['category'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">
<div class="post-list"><p>'.str_replace('::name::',htmlspecialchars($name),$LANG['category_not_found']).'</p></div></div>';
}
else
{
$cat=mysql_fetch_array($req);
$head_title=$cat['name'];
require_once('themes/default/header.php');
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['category'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">';

if (!ctype_digit($page) || $page == 1 || empty($page) || $page > (ceil(count(explode(",",$cat['blog_id'])))))
$page='0';
$max_view=$site['num_post_main'];
$pgs=$page*$max_view;
$lmt=$pgs+$max_view;

echo '<div class="notice">'.htmlspecialchars($cat['name']).'</div>';
if (!empty($cat['blog_id']))
{
$eks=explode(",",$cat['blog_id']);
$count=count($eks);
if ($count < $lmt)
$lmt=$count;
$i=$pgs;
while ($i<$lmt)
{
if (!empty($eks[$i]) && ctype_digit($eks[$i]))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".mysql_real_escape_string($eks[$i])."' and draft='0'"));

$desc_leng=strlen(htmlentities(strip_tags($blog['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blog['description']),0,150);
if (($desc_mainpage=='1') || ($desc_leng<='149'))
$description=$blog['description'];
else
$description=$desc_put;
$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' and url='".mysql_real_escape_string($site_url)."'"), 0);

if ($blog['private'] == 1)
{
if ($user_id)
$show_description=$description;
else
$show_description=$LANG['post_only_for_member'];
}
elseif ($blog['private'] == 2)
{
if ($user_id && ($cf != "0" || $site_id == $user_id))
$show_description=$description;
else
$show_description=$LANG['post_only_for_follower'];
}
else
{
$show_description=$description;
}

$kat=explode(",",$blog['category']);
$kategori=mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id='".mysql_real_escape_string($kat[0])."' and site_id='".$site['id']."'"));

$total_komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."' and status='1'"),0);

echo '<!-- post-list start --><div class="post-list"><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%" class="post-date"><div class="month">'.date("M",$blog['time']).'</div><div class="date">'.date("d",$blog['time']).'</div></td><td width="80%" class="post-title"><a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a></td></tr></tbody></table><p>'.iwb_html($show_description).'</p><div class="post-info"><span class="category"><a href="'.$site['url'].'/category/'.$kategori['link'].'/1.xhtml">'.htmlspecialchars(stripslashes($kategori['name'])).'</a></span>&nbsp;&nbsp;<span class="comment-count">'.$total_komentar.'</span>';
if ($site['display_count'] == 1)
echo '&nbsp;&nbsp;<span class="hit-count">'.$blog['count'].'</span>';
echo '</div></div><!-- post-list end -->';
echo '<div class="ads">';
iwb_ads();
echo '</div>';

$i++;
}
}
echo '</div><!-- post end -->';

$total=$count;
$link=''.$site['url'].'/category/'.$cat['link'].'/';
$q='.xhtml';
$pagination="on";
}
else
{
echo '<div class="post-list"><p>'.str_replace('::name::',htmlspecialchars(stripslashes($cat['name'])),$LANG['category_empty']).'</p></div></div>';
}
}
require_once('themes/default/footer.php');
?>