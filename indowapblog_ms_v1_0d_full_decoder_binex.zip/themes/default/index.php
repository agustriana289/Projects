<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$search = htmlentities(urlencode($_GET['search']));
$tag = htmlentities($_GET['tag']);
$page = htmlentities($_GET['page']);

if (isset($_GET['search']))
{
$total=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id='".$site['id']."' and (title LIKE '%".mysql_real_escape_string(urldecode($search))."%' or description LIKE '%".mysql_real_escape_string(urldecode($search))."%') and draft='0'"),0);
$head_title=''.$LANG['search_for'].': '.urldecode($search);
}
elseif (isset($_GET['tag']))
{
$total=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id='".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft='0'"), 0);
$head_title=''.$LANG['tag'].': '.str_replace('-', ' ', $tag);
}
else {
$total=mysql_result(mysql_query("select count(*) as Num from blog where site_id='".$site['id']."' and draft='0'"),0);
}
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

require_once('themes/default/header.php');
if (isset($_GET['search']))
{
echo '<div class="notice"><span id="search-result">'.str_replace('::number::',$total,str_replace('::query::',htmlentities(urldecode($search)),$LANG['search_result'])).'</span></div>';
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site['url'].'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['search'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">';
$blog=mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' and (title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%') and draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
}
elseif (isset($_GET['tag']))
{
echo '<div class="notice"><span id="search-result">'.$LANG['tag'].': '.str_replace('-', ' ', $tag).'</span></div>';
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site['url'].'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['tag'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">';
$blog=mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
}
else
{
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu current">'.$LANG['homepage'].'</td><td width="50%" class="nav-menu"><!-- <a href="'.$site['url'].'/posts/popular.xhtml">Populer</a> -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">';
$blog=mysql_query("select * from blog where site_id='".$site['id']."' and draft='0' order by time desc limit $limit,$max_view");
}

if ($total > 0)
{
while ($blogs=mysql_fetch_array($blog))
{
$desc_leng=strlen(htmlentities(strip_tags($blogs['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blogs['description']),0,150);
if ($desc_mainpage == 1 || $desc_leng < 149)
$description=$blogs['description'];
else
$description = $desc_put;
$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' and url='".mysql_real_escape_string($site_url)."'"), 0);

if ($blogs['private'] == 1)
{
if ($user_id)
$show_description = $description;
else
$show_description=$LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2)
{
if ($user_id && ($cf != "0" || $site_id == $user_id))
$show_description = $description;
else
$show_description=$LANG['post_only_for_follower'];
}
else
{
$show_description = $description;
}
$kat=explode(",",$blogs['category']);
$kategori=mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id='".mysql_real_escape_string($kat[0])."' and site_id='".$site['id']."'"));

$total_komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blogs['id']."' and status='1'"),0);

echo '<!-- post-list start --><div class="post-list"><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%" class="post-date"><div class="month">'.date("M",$blogs['time']).'</div><div class="date">'.date("d",$blogs['time']).'</div></td><td width="80%" class="post-title"><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">'.htmlspecialchars($blogs['title']).'</a></td></tr></tbody></table><p>'.iwb_html($show_description).'</p><div class="post-info"><span class="category"><a href="'.$site['url'].'/category/'.$kategori['link'].'/1.xhtml">'.htmlspecialchars($kategori['name']).'</a></span>&nbsp;&nbsp;<span class="comment-count">'.$total_komentar.'</span>';
if ($site['display_count'] == 1)
echo '&nbsp;&nbsp;<span class="hit-count">'.$blogs['count'].'</span>';
echo '</div></div><!-- post-list end -->';
echo '<div class="ads">';
iwb_ads();
echo '</div>';
}
}
else {
if (isset($_GET['search']))
{
echo '<div class="post"><p>'.$LANG['search_not_found'].'</p></div>';
}
elseif (isset($_GET['tag']))
{
echo '<div class="post"><p>'.$LANG['tag'].' '.str_replace('-', ' ', $tag).' '.$LANG['empty'].'</p></div>';
}
else {
echo '<div class="post"><p>'.$LANG['blog_empty'].'</p></div>';
}
}
echo '</div><!-- post end -->';
if (isset($_GET['search']))
{
$link=''.$site['url'].'/?search='.$search.'&amp;page=';
$q='';
$pagination="on";
$homepage="on";
}
elseif (isset($_GET['tag']))
{
$link=''.$site['url'].'/tag/'.$tag.'/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}
else {
$link=''.$site['url'].'/page/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}
show_pagination($page,$max_view,$total,$link,$q);
if ($site['cat_loc']=="index")
{
show_category();
}
if ($site['display_following'] == '1' && mysql_num_rows(mysql_query("select url from following where site_id='".$site['id']."'")) > 0)
{
echo '<h1 id="following">'.$LANG['following'].'</h1><!-- following start --><div class="following">';
$rq=mysql_query("select title, url from following where site_id='".$site['id']."' order by id desc");
while($rs=mysql_fetch_array($rq))
{
echo '<!-- following-list start --><div class="following-list"><a href="'.$rs['url'].'">'.htmlspecialchars($rs['title']).'</a></div><!-- following-list end -->';
}
echo '</div><!-- following end -->';
}
require_once('themes/default/footer.php');
?>