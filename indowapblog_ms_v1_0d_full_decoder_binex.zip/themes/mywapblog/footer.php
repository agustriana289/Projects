<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}

if ($site['cat_loc']=="foot")
{
$cat_loc="bottom";
echo category($cat_loc);
}
echo '<div id="navigation"><h2>Navigasi</h2><ol>';
if ($pagination=="on")
{
pagination($page,$max_view,$total,$link,$q);
}
if ($homepage != 'off')
echo '<li><a href="'.$site['url'].'">Beranda</a></li>';
$nav=mysql_query("select * from navigation where site_id='".$site['id']."' order by place asc");
while ($navs=mysql_fetch_array($nav))
{
echo '<li>'.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$site['url'],$navs['code']))).'</li>';
}
echo '<li class="link-top"><a accesskey="*" href="#top">Ke Atas</a></li>';
echo '</ol></div>';
if ($site['display_following'] == '1' && $disfoll != 'off' && mysql_num_rows(mysql_query("select url from following where site_id='".$site['id']."'")) > 0)
{
echo '<div id="blogroll"><h2>Following</h2><ol>';
$rq=mysql_query("select title, url from following where site_id='".$site['id']."' order by id desc");
while($rs=mysql_fetch_array($rq))
{
echo '<li><a href="'.$rs['url'].'">'.htmlspecialchars($rs['title']).'</a></li>';
}
echo '</ol></div>';
}
echo '<div id="footer"><p>';

$t_day=date('d-m-Y', time());
$qr=mysql_query("select total from stats where site_id='".$site['id']."' and time='$t_day'");
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set site_id='".$site['id']."', total='1', time='$t_day'");
}
else
{
mysql_query("update stats set total='$new_count' where site_id='".$site['id']."' and time='$t_day'");
}

if ($site['display_count'] == 1)
{
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats where site_id='".$site['id']."'"));
echo 'Total Pengunjung: <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;">'.$t_all['total'].'</span><br/>';
}
echo '&copy; '.date('Y', time()).' <a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a>.<br /><small>Powered by <a href="http://indowapblog.com">IndoWapBlog.com</a></small</p></div></body></html>';
mysql_close($iwb_connect);
?>