<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');
$head_title=isset($head_title) ? $head_title : $site['name'];

if ($head_title != $site['name'])
$head_title=''.htmlspecialchars($head_title).' | '.htmlspecialchars($site['name']).'';
else
$head_title=htmlspecialchars($head_title);

$head_description=isset($head_description) ? $head_description : $site['description'];
$head_description=strip_tags($head_description);
$head_description=substr($head_description,0,200);

header("Cache-Control: public");
header('Content-type: application/xhtml+xml; charset=UTF-8');

echo '<?xml version="1.0" encoding="iso-8859-1"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>'.$head_title.'</title><link rel="icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" /><link rel="shortcut icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" /><meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=iso-8859-1" /><meta name="HandheldFriendly" content="true"/><meta name="description" content="'.htmlentities(strip_tags($head_description)).'" /><meta name="keywords" content="'.htmlentities($site['keywords']).'" /><link rel="alternate"
type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml"/>';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';

echo '<link rel="stylesheet" type="text/css" href="'.$site['url'].'/theme/mywapblog/style.css" />';
echo '</head><body class="mobile_body">';

if (!empty($site['logo']))
{
$headitem='<img src="'.$site['url'].'/content/'.htmlentities($site['logo']).'" alt="'.htmlentities($site['name']).'"/>';
}
else
{
$headitem=htmlspecialchars($site['name']);
}

echo '<div id="header"><h1><a name="top" href="'.$site['url'].'">'.$headitem.'</a></h1><p>'.htmlspecialchars($site['description']).'</p></div>';

if ($site['cat_loc'] == 'index')
{
$cat_loc='top';
echo category($cat_loc);
}

echo '<form id="search_form" method="get" action="'.$site['url'].'/"><input type="text" name="search" value=""/><input type="submit" value="Cari"/></form><p id="nav_shortcut">[#] <a href="#navigation" accesskey="#">Navigasi</a></p>';
if ($user_id)
{
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
if ($indowapblog['ban'] == '1')
{
echo '<div class="post"><h2 class="title">Pemblokiran Akun <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, akun Anda dengan data dibawah ini:<br/><br/>ID : '.$user_id.'<br/>Username : '.$user_username.'<br/>Email : '.$user_email.'<br/><br/>saat ini akun tersebut telah diblokir untuk sementara waktu atau selamanya. Silakan keluar dari akun ini atau kembali berkunjung ke '.htmlspecialchars($site['name']).' setelah beberapa saat lagi!</p></div>';
require_once('themes/mywapblog/footer.php');
exit;
}else{}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
if (mysql_num_rows($ip_cek) != 0)
{
$ip_blocked=mysql_fetch_array($ip_cek);
echo '<div class="post"><h2 class="title">Pemblokiran IP <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, untuk sementara waktu IP yang Anda gunakan (<b>'.$ip_blocked['ip'].'</b>) dilarang untuk mengakses '.htmlspecialchars($site['name']).'!</p></div>'; 
require_once('themes/mywapblog/footer.php');
exit;
}else{}
}
?>