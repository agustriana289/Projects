<?php

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$dbhost = '';
$dbname = '';
$dbuser = '';
$dbpass = '';
$iwb_main_domain = 'indowapblog.com';
?>
