<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang');

if (!$user_id)
relogin();

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'free_credit':
if (!$user_id)
relogin();

$head_title=$LANG['free_credit'];
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=credit">'.$LANG['credit'].'</a> | <a href="admin.php?iwb=credit&amp;action=transfer">'.$LANG['transfer_credit'].'</a> | '.$LANG['payout_credit'].'</div>';
if ($indowapblog['credit'] < 200 && (date("D", time()) == 'Sat' || date("D", time()) == 'Sun'))
{
$kr = $indowapblog['credit'] + 500;
mysql_query("UPDATE user SET credit='".$kr."' WHERE id='".$user_id."'");
echo '<p>'.str_replace('::number::','500',$LANG['free_credit_was_sent']).'</p>';
}
else
{
echo '<p>'.$LANG['free_credit_not_sent'].'<br />'.$LANG['free_credit_term'].'</p>';
}
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'tukar':
if (!$user_id)
relogin();

if (isset($_POST['send']))
{
$hp=$_POST['hp'];
$jml=$_POST['jml'];
if (!ctype_digit($hp) || mb_strlen($hp) < 10 || mb_strlen($hp) > 14)
$err .='<li>'.$LANG['incorrect_phone_number'].'</li>';
if (!ctype_digit($jml) || empty($jml))
$err .='<li>'.$LANG['invalid_credit'].'</li>';
if ($indowapblog['credit'] < $jml)
$err .='<li>'.$LANG['credit_not_enough'].'</li>';
$err .= $LANG['service_unavailable'];
if (empty($err))
{
$kr = $indowapblog['credit'] - $jml;
mysql_query("UPDATE user SET credit='".$kr."' WHERE id='".$user_id."'");
$tm = time();
$pesan='TUKAR KREDIT#[iwbid='.$user_id.']#PULSA#'.$hp.'#'.$jml.'#'.$tm.'-'.$user_id.'';
mysql_query("insert into `pm` set `receiver_id`='1', `sender_id`='1', `name`='TUKAR KREDIT', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".$tm."'") or die(mysql_error());
$transaksi = ''.$tm.'-'.$user_id;
$pesan=str_replace('::rp::',strrev(wordwrap(strrev($jml),3,".",true)),str_replace('::transaksi::',$transaksi,$LANG['payout_credit_notification']));
mysql_query("insert into `pm` set `receiver_id`='".mysql_real_escape_string($user_id)."', `sender_id`='1', `name`='NOTIFIKASI', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".$tm."'") or die(mysql_error());
$hasil='<ol id="success"><li>'.$LANG['payout_credit_successfully'].'</li></ol>';
}
else
{
$hasil='<ol id="error">'.$err.'</ol>';
}
}
$head_title=$LANG['payout_credit'];
require_once('inc/head.php');
echo '<div id="message">';
if ($hasil)
echo $hasil;
echo '</div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=credit">'.$LANG['credit'].'</a> | <a href="admin.php?iwb=credit&amp;action=transfer">'.$LANG['transfer_credit'].'</a> | '.$LANG['payout_credit'].'</div>';
echo str_replace('::rp::',strrev(wordwrap(strrev($indowapblog['credit']),3,".",true)),$LANG['total_credit']).'<br /><h1>'.$LANG['payout_credit'].'</h1><form method="post" action="admin.php?iwb=credit&amp;action=tukar"><b>'.$LANG['phone_number'].'</b><br /><input class="iwb-text" type="text" name="hp" value=""/><br /><b>'.$LANG['credit'].'</b><br/><select class="iwb-select" name="jml"><option value="12000">Rp 12.000</option><option value="27000">Rp 27.000</option></select><br /><center><input class="iwb-button" type="submit" name="send" value="'.$LANG['send'].'"/></center></form></p>';
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'transfer':
if (!$user_id)
relogin();

$to = isset($_GET['to']) ? trim($_GET['to']) : $_POST['to'];
$rp = isset($_GET['rp']) ? trim($_GET['rp']) : $_POST['rp'];
$code = $_POST['code'];
if (isset($_POST['send']))
{
if (empty($to) || !ctype_digit($to))
$err .='<li>'.$LANG['receiver_not_found'].'</li>';
if (empty($rp) || !ctype_digit($rp))
$err .='<li>'.$LANG['invalid_redit'].'</li>';
$cek_id=mysql_query("SELECT `credit` FROM `user` WHERE `id`='".mysql_real_escape_string($to)."'");
if (mysql_num_rows($cek_id) == 0)
$err .='<li>'.$LANG['receiver_not_found'].'</li>';
if ($indowapblog['credit'] < $rp)
$err .='<li>'.$LANG['credit_not_enough'].'</li>';
if (($indowapblog['credit'] - $rp) < 2000)
$err .='<li>'.str_replace('::rp::','2.000',$LANG['credit_after_transfer']).'</li>';
if ($rp < 1000)
$err .='<li>'.str_replace('::rp::','1.000',$LANG['transfer_minimum']).'</li>';
if ($code != $_SESSION['captcha_code'])
$err .='<li>'.$LANG['incorrect_security_code'].'</li>';
if (empty($err))
{
$uid=mysql_fetch_array($cek_id);
$kredit = $uid['credit'] + $rp;
mysql_query("UPDATE user SET credit='".$kredit."' WHERE id='".mysql_real_escape_string($to)."'");
$my_kredit = $indowapblog['credit'] - $rp;
mysql_query("UPDATE user SET credit='".$my_kredit."' WHERE id='".mysql_real_escape_string($user_id)."'");
$pesan=str_replace('::rp::',strrev(wordwrap(strrev($rp),3,".",true)),str_replace('::name::','[iwbid='.$user_id.']',$LANG['transfer_notification']));
mysql_query("insert into `pm` set `receiver_id`='".mysql_real_escape_string($to)."', `sender_id`='1', `name`='NOTIFIKASI', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".time()."'") or die(mysql_error());
$hasil='<ol id="success"><li>'.str_replace('::rp::',strrev(wordwrap(strrev($rp),3,".",true)),str_replace('::name::',iwbid($to),$LANG['transfer_successfully'])).'</li></ol>';
}
else
{
$hasil='<ol id="error">'.$err.'</ol>';
}
}
$head_title=$LANG['transfer_credit'];
require_once('inc/head.php');
echo '<div id="message">';
if ($hasil)
echo $hasil;
echo '</div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=credit">'.$LANG['credit'].'</a> | '.$LANG['transfer_credit'].' | <a href="admin.php?iwb=credit&amp;action=tukar">'.$LANG['payout_credit'].'</a></div>';
echo '<p>'.str_replace('::rp::',strrev(wordwrap(strrev($indowapblog['credit']),3,".",true)),$LANG['total_credit']).'.<br /><form method="post" action="admin.php?iwb=credit&amp;action=transfer">';
if (isset($_GET['to']))
echo '<h4>'.$LANG['to'].'</h4><img src="'.$site['url'].'/img.php?img='.htmlentities($to).'.jpg&amp;w=40&amp;h=40" alt=""/> '.iwbid($to).'<br />(ID: '.htmlentities($to).')<input type="hidden" name="to" value="'.htmlentities($to).'"/><br />';
else 
echo '<h4>'.$LANG['receiver_id'].'</h4><input class="iwb-text" type="text" name="to" value="'.htmlentities($to).'"/><br />';
if (isset($_GET['rp']))
echo '<h4>'.$LANG['credit'].'</h4><b>'.htmlentities($rp).'</b><input type="hidden" name="rp" value="'.htmlentities($rp).'"/><br />';
else
echo '<h4>'.$LANG['credit'].'</h4><input class="iwb-text" type="text" name="rp" value="'.htmlentities($rp).'"/><br />';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>'.$LANG['security_code'].'</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><br/><div class="two-col-btn"><input class="iwb-button" type="submit" name="send" value="'.$LANG['send'].'"/><input class="iwb-button" type="submit" name="reset" value="'.$LANG['reset'].'"/></div></form></p>';
echo '</div></div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();
$head_title=$LANG['credit'];
require_once('inc/head.php');
echo '<div id="message">';
echo '</div><div id="content"><div id="main-content"><div id="show_bar">'.$LANG['credit'].' | <a href="admin.php?iwb=credit&amp;action=transfer">'.$LANG['transfer_credit'].'</a> | <a href="admin.php?iwb=credit&amp;action=tukar">'.$LANG['payout_credit'].'</a></div>';
if (isset($_POST['add']))
{
$voucher = htmlentities($_POST['voucher']);
if (empty($voucher) || !ctype_digit($voucher) || mb_strlen($voucher) != 16)
{
echo '<p>'.$LANG['invalid_voucher_code'].'<br /><a href="admin.php?iwb=credit">&laquo; '.$LANG['back'].'</a></p>';
}
else
{
$pesan='TAMBAH KREDIT#[iwbid='.$user_id.']#VOUCHER#'.$voucher.'';
mysql_query("insert into `pm` set `receiver_id`='1', `sender_id`='1', `name`='TAMBAH KREDIT', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".time()."'") or die(mysql_error());
echo '<p>'.$LANG['add_credit_successfully'].'</p>';
}
}
else
{
echo '<p>'.str_replace('::rp::',strrev(wordwrap(strrev($indowapblog['credit']),3,".",true)),$LANG['total_credit']).'</b>.<br /><br /><h2>'.$LANG['add_credit'].'</h2><br /><b>iPaymu Beli</b><br /><!-- iPaymu.com PAYMENT FORM Buy Credit -->
<a href="https://my.ipaymu.com/process.htm?product=676&member=indowapblog&action=product&send=yes" target="new">
<img src="https://my.ipaymu.com/images/buttons/single/tombol_beli.png" style="border:none;">
</a>
<!-- iPaymu.com PAYMENT FORM --><br /><h1>'.$LANG['pulsa'].'</h1><form method="post" action="admin.php?iwb=credit">'.$LANG['voucher_code'].' (XL Axiata)<br /><input class="iwb-text" type="text" name="voucher" value=""/><br /><center><input class="iwb-button" type="submit" name="add" value="'.$LANG['send'].'"/></center></form><br />'.str_replace('::link::','<a href="'.$site_url.'/admin.php?iwb=credit&amp;action=free_credit">'.$LANG['click_here'].'</a>',$LANG['get_free_credit']).'.</p>';
}
echo '</div></div>';
require_once('inc/foot.php');
break;
}
?>
