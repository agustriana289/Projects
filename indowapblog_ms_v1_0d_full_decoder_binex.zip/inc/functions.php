<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/ 

defined('_IWB_') or die('Kesalahan: pembatasan akses');
include("".$root."inc/smileys.php");
function iwb_tags($var)
{
if ($exp = explode(",",$var)) {
$count = count($exp) -1;
for ($i = 0; $i <= $count; $i++)
{
$vars[] = str_replace('--','-',strtolower(preg_replace('#([\W_]+)#','-',$exp[$i])));
}
$var = implode(",",$vars);
}
else {
$var = str_replace('--','-',strtolower(preg_replace('#([\W_]+)#','-',$var)));;
}
return $var;
}

function iwb_html($var) {
return str_replace("\r\n","<br />",iwb_code(html_entity_decode(bbsm($var))));
}
function lihat_kode($source_code)
    {

        if (is_array($source_code))
            return false;
       
        $source_code = explode("\n", str_replace(array("\r\n", "\r"), "\n", $source_code));
        $line_count = 1;

        foreach ($source_code as $code_line)
        {
            $formatted_code .= '<!-- '.$line_count.' -->';
            $line_count++;
           
            if (ereg('<\?(php)?[^[:graph:]]', $code_line))
                $formatted_code .= str_replace(array('<code>', '</code>'), '', highlight_string($code_line, true));
            else
                $formatted_code .= ereg_replace('(&lt;\?php&nbsp;)+', '', str_replace(array('<code>', '</code>'), '', highlight_string('<?php '.$code_line, true)));
        }

        return stripslashes($formatted_code);
    }

function iwb_code($var) {
$var = preg_replace("/\[code\](.+?)\[\/code\]/ise", "lihat_kode('$1')", $var);
return $var;
}

function GoogleTranslate($text,$to)
{
$ua = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.4.29476/28.1914; U; id) Presto/2.8.119 Version/11.10";
ini_set("user_agent", $ua);
$gt = implode("",file("http://translate.google.co.id/m?hl=id&sl=auto&tl=".$to."&ie=UTF-8&prev=_m&q=".rawurlencode(strip_tags($text))));
$gt = preg_replace("#(.*?)<div dir=\"ltr\" class=\"t0\">(.*?)</div>(.*?)</html>#si","$2",$gt);
if (preg_match("#The document has moved#i",$gt))
return $text;
else
return $gt;
}

function pendekin($varURL)
{
return "http://adf.ly/1624156/".$varURL;
}
function angka($var)
{
if (ctype_digit($var))
return $var;
else
return '';
}

function iwbid($var)
{
$fetch_iwb_name=mysql_fetch_array(mysql_query("SELECT `name`,`ban` FROM `user` WHERE `id`='".mysql_real_escape_string($var)."'"));
if ($fetch_iwb_name)
$var='<a href="'.$GLOBALS['site']['url'].'/user.php?id='.$var.'">'.htmlspecialchars($fetch_iwb_name['name']).'</a>';
else
$var='';
return $var;
}

function minim_credit()
{
echo '<div id="message"></div>
<div id="content">
<div id="main-content"><p>'.str_replace('::number::','...',str_replace('::more:','<a href="'.$GLOBALS['site']['url'].'/admin.php?iwb=credit">'.$GLOBALS['LANG']['more'].' &raquo;</a>',$GLOBALS['LANG']['minim_credit'])).'</p></div></div>';
}
/*Membuat permalink*/
function permalink($var)
{
global $user_id;
$var=preg_replace('#([\W_]+)#',' ',$var);
$var=str_replace(' ','-',$var);
$var=strtolower($var);
$cek=mysql_query("select * from blog where site_id='".$user_id."' and link='".mysql_real_escape_string($var)."'");
$count=mysql_num_rows($cek);
$addnum = $count+1;
if ($count != 0)
{$var=''.$var.'-'.$addnum.'';}else{$var = $var;}
return $var;
}

function time_ago($date,$granularity=2) {
$difference = time() - $date;
$periods = array($GLOBALS['LANG']['decade'] => 315360000, $GLOBALS['LANG']['year'] => 31536000, $GLOBALS['LANG']['month'] => 2628000, $GLOBALS['LANG']['week'] => 604800, $GLOBALS['LANG']['day'] => 86400, $GLOBALS['LANG']['hour'] => 3600, $GLOBALS['LANG']['minute'] => 60, $GLOBALS['LANG']['second'] => 1);
if ($difference < 5) { $retval = $GLOBALS['LANG']['just_now'];
return $retval;
} else {
foreach ($periods as $key => $value) {
if ($difference >= $value)
{
$time = floor($difference/$value);
$difference %= $value;
$retval .= ($retval ? ' ' :
'').$time.' ';
$retval .= (($time > 1) ?
$key.'' : $key);
$granularity--;
}
if ($granularity == '0')
{ break; }
}
return ''.$retval.' '.$GLOBALS['LANG']['ago'];
}
}

function page_not_found()
{
echo '<div id="message"></div><div id="content"><div id="main-content">'.$GLOBALS['LANG']['page_not_found'].'</div></div>';
}


function bbsm($var)
{
$replace_text = mysql_query("SELECT * FROM `replace_text` WHERE `type` != 'smiley'");
if (mysql_num_rows($replace_text) == 0) {
}
else {
while ($sml=mysql_fetch_array($replace_text))
{
$var=str_ireplace($sml['key'],$sml['value'],$var);
}
}
$var = htmlspecialchars($var);
$search = array(
'/\&lt;data(.*?)\&gt;/is',
'/\onclick(.*?)\&gt;/is',
'/\&lt;\/body\&gt;/is',
'/\&lt;\/html\&gt;/is',
'/\&lt;form(.*?)\&gt;/is',
'/\&lt;\/form\&gt;/is',
'/\&lt;meta(.*?)\&gt;/is',
'/\&lt;\/iframe\&gt;/is',
'/\&lt;ifram(.*?)\&gt;/is',
'/\&lt;\/script\&gt;/is',
'/\&lt;scrip(.*?)\&gt;/is',
'/\[color\=(.*?)\](.*?)\[\/color\]/is',
'/\[b\](.*?)\[\/b\]/is',
'/\[i\](.*?)\[\/i\]/is',
'/\[u\](.*?)\[\/u\]/is',
'/\[url\=(.*?)\](.*?)\[\/url\]/is',
'/\[textarea\](.*?)\[\/textarea\]/is');
$replace = array(
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'<font color="$1">$2</font>',
'<strong>$1</strong>',
'<em>$1</em>',
'<u>$1</u>',
'<a href="[shorten=$1]">$2</a>',
'<textarea>$1</textarea>'
);
$var=preg_replace($search,$replace,$var);
$var = str_replace(array_keys($GLOBALS['sm_code']),array_values($GLOBALS['sm_code']),$var);
$var = preg_replace(array('#\[iwbid\=([0-9]{1,15})\]#se'), array("''.iwbid('$1').''"), $var);
return preg_replace(array('#\[shorten\=(.*?)\]#se'), array("''.pendekin('$1').''"), $var);
}

function hapus_array($item,$array)
{
$ex=explode(",",$array);

$co=count($ex);
for ($i=0;$i<$co;$i++)
{
if ($ex[$i] == $item)
continue;
$ar[] = $ex[$i];
}
$array=implode(",",$ar);
return $array;
}
function show_category()
{
echo '<h1 id="category">'.$GLOBALS['LANG']['category'].'</h1><div class="category">';
$cat=mysql_query("select * from category where site_id='".$GLOBALS['site']['id']."' order by name");
while ($cats=mysql_fetch_array($cat))
{
if (empty($cats['blog_id']))
{
$cat_count='0';
}
else
{
$bid=explode(",",$cats['blog_id']);
$cat_count=count($bid);
}
echo '<div class="category-list"><a href="'.$GLOBALS['site']['url'].'/category/'.permalink($cats['name']).'/1.xhtml">'.htmlspecialchars($cats['name']).'&nbsp;&nbsp;<span>('.$cat_count.')</span></a></div>';
}
echo '</div>';
}

function category($cat_loc)
{
echo '<div id="category-'.$cat_loc.'"><h2>'.$GLOBALS['LANG']['category'].'</h2><ol>';
$cat=mysql_query("select * from category where site_id='".$GLOBALS['site']['id']."' order by name");
while ($cats=mysql_fetch_array($cat))
{
if (empty($cats['blog_id']))
{
$cat_count='0';
}
else
{
$bid=explode(",",$cats['blog_id']);
$cat_count=count($bid);
}
echo '<li><a href="'.$GLOBALS['site']['url'].'/category/'.permalink($cats['name']).'/1.xhtml">'.htmlspecialchars($cats['name']).'</a> ('.$cat_count.')</li>';
}
echo '</ol></div>';
}

function forbidden()
{
echo '<div id="message"></div><div id="content"><div id="main-content"><p>'.$GLOBALS['LANG']['forbidden'].'</p></div></div>';
}

function waktu($var)
{
$gmt=$GLOBALS['site']['gmt'];
$jm='3600';
$var=$var+($gmt*$jm);
$var = gmdate('d M Y - H:i',$var);
if ($GLOBALS['default_lang'] == "id") {
$arr = array(
'Jan' => 'Januari',
'Feb' => 'Februari',
'Mar' => 'Maret',
'Apr' => 'April',
'May' => 'Mei',
'Jun' => 'Juni',
'Jul' => 'Juli',
'Aug' => 'Agustus',
'Sep' => 'September',
'Oct' => 'Oktober',
'Nov' => 'November',
'Dec' => 'Desember'
);
$var=str_replace(array_keys($arr),array_values($arr),$var);
}
else {
}
if ($GLOBALS['site']['id'] == 1)
return ''.$var.' WIB';
else
return $var;
}

function relogin()
{
$relogin='http://'.$_SERVER['HTTP_HOST'].str_replace('&amp;','&',htmlentities($_SERVER['REQUEST_URI']));
$relogin=base64_encode($relogin);
header('location: login.php?redir='.$relogin.'');
exit;
}

function show_pagination($page,$max_view,$total,$link,$q)
{
echo '<div class="pagination">';
$total_pages = $total;
 if (empty($page) || ($page == 0)) $page = 1;
 $prev = $page - 1;       
 $next = $page + 1;      
 $lastpage = ceil($total_pages/$max_view);
 $lpm1 = $lastpage - 1;  if($lastpage > 1)
 { 
  if ($page > 1) 
   echo '<a href="'.$link.$prev.$q.'">&laquo;</a>';
  else
   echo ''; 
  
  
  if ($lastpage < 7 + (3 * 2)) 
  { 
   for ($counter = 1; $counter <= $lastpage; $counter++)
   {
    if ($counter == $page)
     echo '<span>'.$counter.'</span>';
    else
     echo '<a href="'.$link.$counter.$q.'">'.$counter.'</a>';     
   }
  }
  elseif($lastpage > 5 + (3 * 2)) 
  {
  
   if($page < 1 + (3 * 2))  
   {
    for ($counter = 1; $counter < 4 + (3 * 2); $counter++)    {
     if ($counter == $page)
      echo '<span>'.$counter.'</span>';
     else
      echo '<a href="'.$link.$counter.$q.'">'.$counter.'</a>';     
    }
    echo '<span>...</span>';
    echo '<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>';
    echo '<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>';  
   }
  
   elseif($lastpage - (3 * 2) > $page && $page > (3 * 2))
   {
    echo '<a href="'.$link.'1'.$q.'">1</a>';
    echo '<a href="'.$link.'2'.$q.'">2</a>';
    echo '<span>...</span>';
    for ($counter = $page - 3; $counter <= $page + 3; $counter++)
    {
     if ($counter == $page)
     echo '<span>'.$counter.'</span>';
     else
      echo '<a href="'.$link.$counter.$q.'">'.$counter.'</a>';     
    }
    echo '<span>...</span>';
    echo '<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>';
    echo '<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>';  
   }
   //close to end; only hide early pages
   else
   {    echo '<a href="'.$link.'1'.$q.'">1</a>';
    echo '<a href="'.$link.'2'.$q.'">2</a>';
    echo '<span>...</span>';
    for ($counter = $lastpage - (2 + (3 * 2)); $counter <= $lastpage; $counter++)
    {
     if ($counter == $page)
     echo '<span>'.$counter.'</span>';
     else
      echo '<a href="'.$link.$counter.$q.'">'.$counter.'</a>';     
    }
   }
  }
  if (($page < $counter - 1) || ($page < $lastpage))
   echo '<a href="'.$link.$next.$q.'">&raquo;</a>';
  else
   echo '';
   }
echo '</div>';
}

function pagination($page,$max_view,$total,$link,$q)
{
$total_pages = $total;
 
if (empty($page) || ($page == 0)) $page = 1;
 $prev = $page - 1;       
 $next = $page + 1;      
 $lastpage = ceil($total_pages/$max_view);
 $lpm1 = $lastpage - 1;  if($lastpage > 1)
 { 
echo '<li class="link-page">'.$GLOBALS['LANG']['page'].': ';
  if ($page > 1) 
   echo ' [<a href="'.$link.$prev.$q.'">&laquo;</a>] ';
  else
   echo ''; 
  
  
  if ($lastpage < 7 + (3 * 2)) 
  { 
   for ($counter = 1; $counter <= $lastpage; $counter++)
   {
    if ($counter == $page)
     echo ' ['.$counter.'] ';
    else
     echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
   }
  }
  elseif($lastpage > 5 + (3 * 2)) 
  {
  
   if($page < 1 + (3 * 2))  
   {
    for ($counter = 1; $counter < 4 + (3 * 2); $counter++)    {
     if ($counter == $page)
      echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
    echo ' ... ';
    echo ' [<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>] ';
    echo ' [<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>] ';  
   }
  
   elseif($lastpage - (3 * 2) > $page && $page > (3 * 2))
   {
    echo ' [<a href="'.$link.'1'.$q.'">1</a>] ';
    echo ' [<a href="'.$link.'2'.$q.'">2</a>] ';
    echo ' ... ';
    for ($counter = $page - 3; $counter <= $page + 3; $counter++)
    {
     if ($counter == $page)
     echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
    echo ' ... ';
    echo ' [<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>] ';
    echo ' [<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>] ';  
   }
   //close to end; only hide early pages
   else
   {    echo ' [<a href="'.$link.'1'.$q.'">1</a>] ';
    echo ' [<a href="'.$link.'2'.$q.'">2</a>] ';
    echo ' ... ';
    for ($counter = $lastpage - (2 + (3 * 2)); $counter <= $lastpage; $counter++)
    {
     if ($counter == $page)
     echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
   }
  }
  
 
  if (($page < $counter - 1) || ($page < $lastpage))
   echo ' [<a href="'.$link.$next.$q.'">&raquo;</a>] ';
  else
   echo '';
   }
echo '</li>';
}

function ads_buzzcity($var)
{
if (!$bz_partnerid) $bz_partnerid = $var;
$alternate_link = 'http://click.buzzcity.net/click.php?partnerid=77202';
$bz_ads_domain = 'ads.buzzcity.net';
   $bz_click_domain = 'click.buzzcity.net';
$ip = '';
   if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      // Opera mini client
      $ip_str = $_SERVER['HTTP_X_FORWARDED_FOR'];
      if (preg_match('%(\d{1,3}(?:[.]\d{1,3}){3})%', $ip_str, $matches)) {
         $iptest = ip2long($matches[1]);
         $ip = urlencode(long2ip($iptest));
      }
   }

   if (empty($ip)) {
      $keyname_ip_arr = array('HTTP_REMOTE_ADDR_REAL','REMOTE_ADDR');
      foreach ($keyname_ip_arr as $keyname_ip) {
         if (!empty($_SERVER[$keyname_ip])) {
            $ip = urlencode($_SERVER[$keyname_ip]);

            break;
         }
      }
   }

   // extract UA info
   $keyname_ua_arr = array('HTTP_X_DEVICE_USER_AGENT','HTTP_X_OPERAMINI_PHONE_UA', 'HTTP_USER_AGENT');
   foreach ($keyname_ua_arr as $keyname_ua) {
      if (!empty($_SERVER[$keyname_ua])) {
         $ua = urlencode($_SERVER[$keyname_ua]);
         break;
      }
   }

   $bz_url = 'http://' . $bz_ads_domain . '/show.php?get=1&partnerid=' .
      $bz_partnerid . '&a=' . $ua . '&i=' . $ip;

   @$ad_serve = fopen($bz_url,'r');
   $contents = '';
   if ($ad_serve) {
      while (!feof($ad_serve))
          $contents .= fread($ad_serve,1024);
      fclose($ad_serve);
   }
   $bz_link = explode("\n", $contents);

   $bz_text = $bz_link[0];
   $bz_cid = $bz_link[1];
if (isset($bz_link) && !empty($bz_link)) {
      // display BuzzCity TextAd
      echo '<a href="http://' . $bz_click_domain . '/click.php?partnerid=' . $bz_partnerid . '&cid=' . $bz_cid . '">' . $bz_text . '</a>';
   }
   else {
      // no BuzzCity ad, display alternate
      echo $alternate_link;
   } 
}

function ads_mobgold($var)
{
$site_id = $var;
$version    = 'MG-20100406';
$test_mode  = 0;

$protocol = 'http';
if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off') $protocol = 'https';
$tps 	= isset( $_SERVER["HTTPS"] ) ? $_SERVER["HTTPS"] : '';
$ua 	= isset( $_SERVER["HTTP_USER_AGENT"] ) ? $_SERVER["HTTP_USER_AGENT"] : '';
$ua 	= isset( $_SERVER["HTTP_X_OPERAMINI_PHONE_UA"] ) ? $_SERVER["HTTP_X_OPERAMINI_PHONE_UA"] : $ua;
$ua 	= isset( $_SERVER["HTTP_X_ORIGINAL_USER_AGENT"] ) ? $_SERVER["HTTP_X_ORIGINAL_USER_AGENT"] : $ua;
$ua 	= isset( $_SERVER["HTTP_X_DEVICE_USER_AGENT"] ) ? $_SERVER["HTTP_X_DEVICE_USER_AGENT"] : $ua;
$xwp	= isset( $_SERVER["HTTP_X_WAP_PROFILE"] ) ? $_SERVER["HTTP_X_WAP_PROFILE"] : '';
$pro 	= isset( $_SERVER["HTTP_PROFILE"] ) ? $_SERVER["HTTP_PROFILE"] : '';
$xwc 	= isset( $_SERVER["HTTP_X_WAP_CLIENTID"] ) ? $_SERVER["HTTP_X_WAP_CLIENTID"] : '';
$ipr 	= isset( $_SERVER["REMOTE_ADDR"] ) ? $_SERVER["REMOTE_ADDR"] : '';

$ipx 	= isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : '';
$ipc 	= isset( $_SERVER["HTTP_CLIENT_IP"] ) ? $_SERVER["HTTP_CLIENT_IP"] : '';
$ref 	= isset( $_SERVER["HTTP_REFERER"] ) ? $_SERVER["HTTP_REFERER"] : '';
$hos 	= isset( $_SERVER["HTTP_HOST"] ) ? $_SERVER["HTTP_HOST"] : '';
$uri 	= isset( $_SERVER["REQUEST_URI"] ) ? $_SERVER["REQUEST_URI"] : '';
$acp 	= isset( $_SERVER["HTTP_ACCEPT"] ) ? $_SERVER["HTTP_ACCEPT"] : '';
$cha 	= isset( $_SERVER["HTTP_ACCEPT_CHARSET"] ) ? $_SERVER["HTTP_ACCEPT_CHARSET"] : '';
$lan 	= isset( $_SERVER["HTTP_ACCEPT_LANGUAGE"] ) ? $_SERVER["HTTP_ACCEPT_LANGUAGE"] : '';
$mg_params = array(
  'ua=' . urlencode($ua),
  'xwp=' . urlencode($xwp),
  'pro=' . urlencode($pro),
  'xwc=' . urlencode($xwc),
  'ipr=' . urlencode($ipr),
  'ipx=' . urlencode($ipx),
  'ipc=' . urlencode($ipc),
  'ref=' . urlencode($ref),
  'hos=' . urlencode($hos),
  'uri=' . urlencode($uri),
  'acp=' . urlencode($acp),
  'cha=' . urlencode($cha),
  'lan=' . urlencode($lan),
  'pt=' . urlencode("$protocol://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']),
  'sm=' . $site_id,
  'ver=' . urlencode($version),
  'test=' . $test_mode,
 );

$post = implode('&', $mg_params);
$request_timeout = 12; // 12 seconds timeout
$mg_contents = '';
$errno = 0;
$errstr = '';
$request = @fsockopen('ads.mobgold.com', 80, $errno, $errstr, $request_timeout);

if($request) {
  stream_set_timeout($request, $request_timeout);
  $post_body = "POST /request.php HTTP/1.0\r\nHost: ads.mobgold.com\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($post) . "\r\n\r\n" . $post;
  $post_body_len = strlen($post_body);
  $bytes_written = 0;
  $body = false;

  $current_bytes_written = fwrite($request, $post_body);

  while(!feof($request)) {
    $line = fgets($request);
    if(!$body && $line == "\r\n") $body = true;
    if($body && !empty($line)) $mg_contents .= $line;
    $info = stream_get_meta_data($request);
    $timeout = $info['timed_out'];
  }
  fclose($request);
}
else {
  $mg_contents = '';
}

if( null !== $mg_contents )
    echo $mg_contents;
}

function ads_mobday($var)
{
echo '<a href="http://ads.mobday.com/clkAd.php?pubid='.$var.'"><img src="http://ads.mobday.com/reqAd.php?pubid='.$var.'&amp;tm='.time().'" alt="" border="0" /></a>';
}

function ads_smaato($var)
{
// Smaato Code Snippet PHP
// Copyright Smaato, Inc., All rights reserved
// Rev: 20110115

// Version: 1.1

$phpsnip = 101;
$exsmaato=explode("-", $var);
// Your publisher-id
$pub=$exsmaato[0];

// The adspace-id
$adspace=$exsmaato[1];

// The user-id, the soma-server has generated at first request
// Attention:
// If it is possible to track each single user on your side, the user-parameter should be empty (&user=).
// Inside the response, there will be the "SomaUserID"-header, with a new generated user-id.
// This new generated "SomaUserID" should be used as "&user="-parameter
// for every following request of this particular user.
//
// If it is not possible on your side, to split apart different users
// (and re-recognize him afterwards at each request)
// please use the following ID for ALL users/requests
// ExampleValue: 900
$user_id=900;

// max. width of the wished ad (e.g. MMA small is 120)
$width='';

// max. height of the wished ad (e.g. MMA small is 20)
$height='';
// Position of the ad
$pos="top";

// Amount of ads which should be requested. Default is "1"
$ad_count=1;




// The wished format of the requested ad. Default: ALL (other possible values: "IMG" or "TXT")
$ad_format="TXT";

$beacon="TRUE";

/////////////////////////////////
// Do not edit below this line //
/////////////////////////////////
// This section defines Smaato functions and should be used AS IS.

$response_format="HTML";
// The user-agent of the client device
$ua = isset( $_SERVER["HTTP_USER_AGENT"] ) ? $_SERVER["HTTP_USER_AGENT"] : '';
$ua = isset( $_SERVER["HTTP_X_OPERAMINI_PHONE_UA"] ) ? $_SERVER["HTTP_X_OPERAMINI_PHONE_UA"] : $ua;
$ua = isset( $_SERVER["HTTP_X_ORIGINAL_USER_AGENT"] ) ? $_SERVER["HTTP_X_ORIGINAL_USER_AGENT"] : $ua;
$ua = isset( $_SERVER["HTTP_X_DEVICE_USER_AGENT"] ) ? $_SERVER["HTTP_X_DEVICE_USER_AGENT"] : $ua;

// Set the user-agent header inside the request
@ini_set("user_agent", $ua);
// The user-agent of the client device as encoded device-parameter
$device=rawurlencode($ua);

// The ip-address of the client
// First, have a look if the headers can be accessed via $_SERVER
// and a X-FORWARDED-FOR header exists. If not, use client_ip or remote_address.
$x_forwarded_for="";
$ip="";
if (isset($_SERVER)) {
	if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
		$x_forwarded_for=$_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	if (isset($_SERVER["HTTP_CLIENT_IP"])) {
		$ip=$_SERVER["HTTP_CLIENT_IP"];
	} else {
		$ip=$_SERVER["REMOTE_ADDR"];
	}
// If $_SERVER is not accessible, try to get the values out of the environment
} else  {
	if (getenv('HTTP_X_FORWARDED_FOR')) {
		$x_forwarded_for=getenv("HTTP_X_FORWARDED_FOR");
	}
	if (getenv('HTTP_CLIENT_IP')) {
		$ip=getenv('HTTP_CLIENT_IP');
	} else {
		$ip=getenv('REMOTE_ADDR');
	}
}

// Other client header informations, which are set using the prefix "X-MH-"
$mh_accept = isset($_SERVER["HTTP_ACCEPT"]) ? $_SERVER["HTTP_ACCEPT"] : '';

$mh_user_agent = isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : '';
$mh_accept_charset = isset($_SERVER["HTTP_ACCEPT_CHARSET"]) ? $_SERVER["HTTP_ACCEPT_CHARSET"] : '';
$mh_accept_language = isset($_SERVER["HTTP_ACCEPT_LANGUAGE"]) ? $_SERVER["HTTP_ACCEPT_LANGUAGE"] : '';
$mh_x_wap_profile = isset($_SERVER["HTTP_X_WAP_PROFILE"]) ? $_SERVER["HTTP_X_WAP_PROFILE"] : '';
$mh_profile = isset($_SERVER["HTTP_PROFILE"]) ? $_SERVER["HTTP_PROFILE"] : '';
$mh_operamini_ua = isset($_SERVER["HTTP_X_OPERAMINI_PHONE_UA"]) ? $_SERVER["HTTP_X_OPERAMINI_PHONE_UA"] : '';
$mh_original_ua = isset($_SERVER["HTTP_X_ORIGINAL_USER_AGENT"]) ? $_SERVER["HTTP_X_ORIGINAL_USER_AGENT"] : '';
$mh_device_ua = isset($_SERVER["HTTP_X_DEVICE_USER_AGENT"]) ? $_SERVER["HTTP_X_DEVICE_USER_AGENT"] : '';
$soma_url="http://soma.smaato.com/oapi/reqAd.jsp?pub=$pub&adspace=$adspace&adcount=$ad_count&response=$response_format&devip=$ip&user=$user_id&format=$ad_format&position=$pos&height=$height&width=$width&device=$device&beacon=$beacon&phpsnip=$phpsnip";

$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"X-Forwarded-For: $x_forwarded_for\r\n"
		. "User-Agent: $ua\r\n"
		. "X-MH-Accept: $mh_accept\r\n"
		. "X-MH-User-Agent: $mh_user_agent\r\n"
		. "X-MH-Accept-Charset: $mh_accept_charset\r\n"
		. "X-MH-Accept-Language: $mh_accept_language\r\n"
		. "X-MH-X-Wap-Profile: $mh_x_wap_profile\r\n"
		. "X-MH-Profile: $mh_profile\r\n"
		. "X-MH-X-Forwarded-For: $x_forwarded_for\r\n"
		. "X-MH-X-OperaMini-Phone-UA: $mh_operamini_ua\r\n"
		. "X-MH-X-Original-User-Agent: $mh_original_ua\r\n"
		. "X-MH-X-Device-User-Agent: $mh_device_ua\r\n"
  )
);
$context = stream_context_create($opts);
echo file_get_contents($soma_url, false, $context);
}

if (!function_exists('mime_content_type')) {
    function mimes_content_type($filename) {
$mime_types = array(
'txt' => 'text/plain',
'htm' => 'text/html',
'html' => 'text/html',
'php' => 'text/html',
'css' => 'text/css',
'js' => 'application/javascript',
'json' => 'application/json',
'xml' => 'application/xml',
'swf' => 'application/x-shockwave-flash',
'flv' => 'video/x-flv',
'png' => 'image/png',
'jpe' => 'image/jpeg',
'jpeg' => 'image/jpeg',
'jpg' => 'image/jpeg',
'gif' => 'image/gif',
'bmp' => 'image/bmp',
'ico' => 'image/vnd.microsoft.icon',
'tiff' => 'image/tiff',
'tif' => 'image/tiff',
'jar' => 'application/java.archive',
'sisx' => 'application/octet-stream',
'zip' => 'application/zip',
'sis' => 'application/vnd.symbian.install',
'exe' => 'application/x-msdownload',
'msi' => 'application/x-msdownload',
'cab' => 'application/vnd.ms-cab-compressed',
'mp3' => 'audio/mpeg',
'qt' => 'video/quicktime',
'mov' => 'video/quicktime',
'pdf' => 'application/pdf',
'psd' => 'image/vnd.adobe.photoshop',
'ai' => 'application/postscript',
'eps' => 'application/postscript',
'ps' => 'application/postscript',
'doc' => 'application/msword',
'rtf' => 'application/rtf',
'xls' => 'application/vnd.ms-excel',
'ppt' => 'application/vnd.ms-powerpoint',
'odt' => 'application/vnd.oasis.opendocument.text',
'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
        );
$ext = strtolower(array_pop(explode('.', $filename)));
        if (array_key_exists($ext, $mime_types)) {
            return $mime_types[$ext];
     }
     elseif (function_exists('finfo_open')) {
$finfo = finfo_open(FILEINFO_MIME);
$mimetype = finfo_file($finfo,$filename);
finfo_close($finfo);
        return $mimetype;
     }
     else {
        return 'application/octet-stream';
     }
   }
}

function iwb_ads()
{
$ads = mysql_query("SELECT * FROM ads WHERE site_id = '" . $GLOBALS['site']['id'] . "' AND status = '1'");
if (mysql_num_rows($ads) != 0) {
$ads = mysql_fetch_array($ads);
if ($ads['adby'] == 'mobgold') {
ads_mobgold($ads['adcode']);
}
elseif ($ads['adby'] == 'buzzcity') {
ads_buzzcity($ads['adcode']);
}
elseif ($ads['adby'] == 'smaato') {
ads_smaato($ads['adcode']);
}
elseif ($ads['adby'] == 'mobday') {
ads_mobday($ads['adcode']);
}
else {
}
}
else {
echo '<!-- Ads Empty -->';
}
}
?>