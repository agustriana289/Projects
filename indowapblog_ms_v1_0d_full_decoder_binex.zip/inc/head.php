<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$root=isset($root) ? $root : '';

$head_title=isset($head_title) ? $head_title : $site['name'];

$head_title=htmlspecialchars($head_title);
$deskripsi=isset($head_description) ? $head_description : $site['description'];

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>'.$head_title.'</title><link rel="icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><link rel="shortcut icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><meta name="description" content="'.htmlspecialchars($deskripsi).'" /><meta name="viewport" content="width=320" /><meta name="viewport" content="initial-scale=1.0" /><meta name="viewport" content="user-scalable=false" /><meta http-equiv="Cache-Control" content="max-age=1" /><meta name="HandheldFriendly" content="True" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="all"/><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="handheld"/><script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script>
</head>';
echo '<body><div id="header"><a href="'.$site['url'].'/">';
if (!empty($site['logo'])){
echo '<img src="'.$site['url'].'/content/'.htmlspecialchars($site['logo']).'" alt="'.htmlspecialchars($site['name']).'"/>';
}
else
{
echo htmlspecialchars($site['name']);
}
echo '</a>';
echo '<div id="navigation">';
if ($user_id)
{
echo '<a href="'.$site['url'].'/user.php">'.$LANG['profile'].'</a>&nbsp;&nbsp;<a href="'.$site['url'].'/dashboard.php">'.$LANG['dashboard'].'</a>&nbsp;&nbsp;<a href="'.$site['url'].'/chat.php">'.$LANG['chatroom'].'</a>&nbsp;&nbsp;<a href="'.$site['url'].'/message.php">'.$LANG['message'].'</a>&nbsp;&nbsp;';
if ($is_admin)
echo '<a href="'.$site['url'].'/owner.php">'.$LANG['admin_panel'].'</a>&nbsp;&nbsp;';
echo '<a href="'.$user_site.'/home.xhtml">'.$LANG['visit_blog'].'</a>&nbsp;&nbsp;<a href="'.$user_site.'/login.php?iwb=logout">'.$LANG['logout'].'</a><br><font color="white"><strong>'.htmlspecialchars($user_name).'</strong></font>';
}
else
{
echo '<a href="'.$site['url'].'/login.php">'.$LANG['login'].'</a>&nbsp;&nbsp;<a href="'.$site['url'].'/register.php?">'.$LANG['registration'].'</a>';
}
echo '<center><a href="'.$site_url.'/language.php?lang=id&amp;back_uri='.urlencode(''.$site_url . $_SERVER['REQUEST_URI'].'').'"><img src="'.$site_url.'/images/id.gif" alt="ID"/></a>&nbsp;<a href="'.$site_url.'/language.php?lang=en&amp;back_uri='.urlencode(''.$site_url . $_SERVER['REQUEST_URI'].'').'"><img src="'.$site_url.'/images/en.gif" alt="EN"/></a></center></div>';
echo '<h2>'.htmlspecialchars($head_title).'</h2></div>';

if ($user_id)
{
if ($indowapblog['ban'] == 1)
{
echo '<div id="message"></div><div id="content">
<div id="main-content">';
echo '<p>'.str_replace('::id::',$user_id,str_replace('::username::',$user_username,str_replace('::email::',$user_email,$LANG['user_blocked']))).'</p></div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");

if (mysql_num_rows($ip_cek) != 0)
{
$ip_blocked=mysql_fetch_array($ip_cek);

echo '<div id="message"></div><div id="content">
<div id="main-content">';
echo '<p>'.str_replace('::ip::',$ip_blocked['ip'],$LANG['ip_blocked']).'</p></div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
}

if ($user_id)
{
$kuis=mysql_query("SELECT id, pertanyaan FROM kuis WHERE status='1' AND time > '".time()."' ORDER BY id DESC LIMIT 3;");
if (mysql_num_rows($kuis) != 0)
{
while ($quis=mysql_fetch_array($kuis))
{
$new .='<li>&raquo; '.$LANG['quiz'].': '.bbsm(substr($quis['pertanyaan'],0,30)).'...<a href="'.$site['url'].'/kuis.php?iwb=read&amp;id='.$quis['id'].'#show_bar">&raquo;</a></li>';
}
}
$total_pms=mysql_result(mysql_query("select count(*) as Num from `pm` where `receiver_id`='".$user_id."' and `read`='1'"), 0);
if ($total_pms > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/message.php?">'.$total_pms.'</a>',$LANG['pm_notification']).'</li>';
if ($dashboard == 'on')
{
$taim = time() - 172800;
$total_following_post=mysql_result(mysql_query("select count(*) as Num from `following_post` where `read` LIKE '%<".$user_id.">%' and `time`>'".$taim."'"), 0);
if ($total_following_post > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/admin.php?iwb=following&amp;action=read">'.$total_following_post.'</a>',$LANG['following_notification']).'</li>';

$total_kom=mysql_result(mysql_query("select count(*) as Num from `comment` where `site_id`='".$user_id."' and `status`='0'"), 0);

$total_gb=mysql_result(mysql_query("select count(*) as Num from `guestbook` where site_id='".$user_id."' and `status`='0'"), 0);

if ($total_kom > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_comment.php?iwb=unapproved">'.$total_kom.'</a>',$LANG['comment_notification']).'</li>';

if ($total_gb > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_guestbook.php?iwb=unapproved">'.$total_gb.'</a>',$LANG['guestbook_notification']).'</li>';
if ($indowapblog['no_hp'] == '')
$new .='<li>&raquo; Silakan masukan <a href="'.$site['url'].'/user.php?iwb=phone_number">Nomor HP</a> agar Kami bisa mengirim pemberitahuan Pesan Masuk ke HP Anda</li>';
} else { }
$notify=mysql_query("select `id`,`text`,`time` from `pm` where `receiver_id`='".$user_id."' and `read`='2' order by `time` desc limit 1;");
if (mysql_num_rows($notify) != 0)
{
$notice=mysql_fetch_array($notify);
$new .='<li>&raquo; '.html_entity_decode(bbsm($notice['text'])).'</li>';
mysql_query("DELETE FROM `pm` WHERE `id`='".$notice['id']."' OR `text`='".mysql_real_escape_string($notice['text'])."'");
}
if (!empty($new))
echo '<div id="message"><ol id="notice">'.$new.'</ol></div>';
}
include(''.$root.'inc/live_chat.php');

?>