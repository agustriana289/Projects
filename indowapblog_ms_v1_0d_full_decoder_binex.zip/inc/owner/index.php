<?php


/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');
if (!$user_id)
relogin();
$head_title='Owner Panel';
require_once('inc/head.php');
echo '<style type="text/css">
#iphone-list
{
  margin: 2px;
  padding: 2px;
}
#iphone-list li
{
    list-style-type: none;
    margin: 2px;
    padding: 2px;
}
#iphone-list .heading
{
    list-style-type: none;
    margin: 2px;
    padding: 6px 5px 6px 5px;
    background-color: #333333;
    color: #FFFFFF;
    font-weight: bold;
}
#iphone-list li a
{
    display:block;
    padding: 6px 5px 6px 5px;
}
.iphone-list-border li a
{
    border-top: 2px solid #B4B4B4;
}
#iphone-list li a:hover
{
    background-color: #E1E1E1;
}
</style>';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';

if (!$is_admin)
{
forbidden();
}
else
{
echo '<ul id="iphone-list">';

echo '<li class="heading">Owner Menu</li><li><a href="owner.php?iwb=post">Kelola Post</a></li><li><a href="owner.php?iwb=author">Kelola Author</a></li><li><a href="owner.php?iwb=filter">Word Filter</a></li><li><a href="owner.php?iwb=backup">Backup SQL</a></li>';
echo '</ul>';
}
echo '</div>
        </div>';
require_once('inc/foot.php');
?>