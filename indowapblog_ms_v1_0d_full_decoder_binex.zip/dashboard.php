<?php


/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
if ($defined != 'on')
{
define('_IWB_', 1);
include('inc/indowapblog.php');
}
else
{
defined('_IWB_') or die('ERROR'); // Opsional
}
if (!$user_id)
relogin();
$dashboard='on';
$head_title=$LANG['dashboard'];
require_once('inc/head.php');
echo '<style type="text/css">
#iphone-list
{
margin: 2px;
padding: 2px;
}
#iphone-list li
{
list-style-type: none;
margin: 2px;
padding: 2px;
}
#iphone-list .heading
{
list-style-type: none;
margin: 2px;
padding: 6px 5px 6px 5px;
background-color: #333333;
color: #FFFFFF;
font-weight: bold;
}
#iphone-list li a
{
display:block;
padding: 6px 5px 6px 5px;
}
.iphone-list-border li a
{
border-top: 2px solid #B4B4B4;
}
#iphone-list li a:hover
{
background-color: #E1E1E1;
}
</style>';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';

echo '<h2>'.$LANG['add_new'].'</h2><ul id="iphone-list"><li><a href="post.php">'.$LANG['post'].'</li><li><a href="admin.php?iwb=category">'.$LANG['category'].'</li><li><a href="file.php">'.$LANG['file'].'</a></li>';

echo '</ul><h2>'.$LANG['edit'].'</h2><ul id="iphone-list"><li><a href="post.php?iwb=manage">'.$LANG['post'].'</li><li><a href="file.php?">'.$LANG['file'].'</li><li><a href="manage_comment.php?">'.$LANG['comments'].'</a></li><li><a href="manage_guestbook.php?">'.$LANG['guestbook'].'</a></li><li><a href="admin.php?iwb=following">'.$LANG['following'].'</li>
<li><a href="admin.php?iwb=navigation">'.$LANG['navigation'].'</li><li><a href="admin.php?iwb=css_editor">'.$LANG['theme'].'</a></li>';
echo '</ul><h2>'.$LANG['settings'].'</h2><ul id="iphone-list"><li><a href="admin.php?iwb=settings">'.$LANG['blog'].'</li><li><a href="admin.php?iwb=ads">'.$LANG['ads'].'</li><li><a href="admin.php?iwb=domain_parking">'.$LANG['domain_parking'].'</li><li><a href="admin.php?iwb=google">'.$LANG['google_verification'].'</a></li>';

echo '</ul><h2>'.$LANG['community'].'</h2><ul id="iphone-list"><li><a href="chat.php">'.$LANG['chatroom'].'</a></li><li><a href="forum.php">'.$LANG['forum'].'</a></li><li><a href="user.php?iwb=list">'.$LANG['users_list'].'</a></li>';

echo '</ul><h2>'.$LANG['other'].'</h2><ul id="iphone-list"><li><a href="kb.php">'.$LANG['knowledge_base'].'</a></li><li><a href="admin.php?iwb=stats">'.$LANG['statistics'].'</a></li><li><a href="kuis.php?">'.$LANG['quiz'].'</a></li><li><a href="new.php">'.$LANG['latest_post'].'</a></li>';

echo '</ul>            </div>
</div><iframe src="http://www.facebook.com/plugins/like.php?href=facebook.com/profile.php?id=280908948632320&amp;show_faces=false&amp;colorscheme=dark" scrolling="no" frameborder="0" style="border:none; overflow:hidden; max-width:80%; height:100px;" allowTransparency="true"></iframe><br />';
require_once('inc/foot.php');

?>