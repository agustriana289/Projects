<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
$f=$_GET['f'];
$f=base64_decode($f);
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (file_exists($f))
{
unlink($f);
header('location: file.php?notif=file_deteted');
}
else
{
header('location: file.php?notif=file_not_found');
}
break;
default:
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$maxsize='5000';
$filename=$_FILES['file']['name'];

if (isset($_POST['upload']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if ((preg_match("/.php/i", $filename)) or (preg_match("/.pl/i", $filename)) or (preg_match("/.xml/i", $filename)) or (preg_match("/.xhtml/i", $filename)) or (preg_match("/.wml/i", $filename)) or ($filename == ".htaccess") or (preg_match("/.html/i", $filename)) or (preg_match("/.htm/i", $filename)))
$hsl='<ol id="error"><li>Jenis file tidak diijinkan</li></ol>';
if ($_FILES['file']['size'] > (1024*$maxsize))
$hsl='<ol id="error"><li>File maksimal berukuran 5Mb</li></ol>';
if(file_exists("files/{$_FILES['file']['name']}"))
$hsl='<ol id="error"><li>Nama file '.$filename.' sudah ada</li></ol>';
if (empty($filename))
$hsl='<ol id="error"><li>Silakan pilih file</li></ol>';

if (empty($hsl))
{
copy($_FILES['file']['tmp_name'], "files/{$_FILES['file']['name']}");
$hsl='<ol id="success"><li><b>'.$filename.'</b> berhasil diupload</li></ol>';
}
}
$notif=$_GET['notif'];
if($notif == 'file_deleted')
$hsl='<ol id="success"><li>File berhasil dihapus</li></ol>';
if ($notif == 'file_not_found')
$hsl='<ol id="error"><li>File tidak ditemukan</li></ol>';
$head_title='Files';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">
<form action="file.php" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="5242880" type="hidden"/>
    <h4>Pilih File</h4>
<input type="file" name="file"/>
    <input class="iwb-button" name="upload" type="submit" value="Upload"/></form>';
$total=count(glob("files/*"));
echo '<h4>Total Files '.$total.'</h4><ol>';
foreach (glob("files/*") as $file)
{
$f=base64_encode($file);
$ft = filemtime($file);
$ft = date("d M Y - H:i",$ft);
$fs=filesize($file);
$fs = round($fs / 1024, 2);
$files=basename($file);
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
if ($files == 'index.php')
{
continue;
}
echo '<a href="'.$site['url'].'/files/'.$files.'">'.$files.'</a> [<a href="file.php?iwb=delete&amp;f='.$f.'"><font color="red">X</font></a>]<br /><span>Diupload: '.$ft.'<br/>Ukuran: '.$fs.' kb</span>';
++$i;
echo '</li>';
}

echo '</ol>            </div>
        </div>';
include 'foot.php';
}
?>
