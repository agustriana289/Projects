<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'list':
if (!$user_id)
relogin();
$view=$_GET['view'];
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
if (empty($view))
$head_title='List Pengguna';

if ($view == 'member')
$head_title='List Member';

if ($view == 'guest')
$head_title='List Tamu';

if ($view == 'ban')
$head_title='Member Diblokir';

if ($view == 'author')
$head_title='List Penulis';

if ($view == 'admin')
$head_title='List Administrator';

include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">';
if (empty($view))
echo 'Semua';
else
echo '<a href="user.php?iwb=list">Semua</a>';
echo ' | ';
if ($view == 'member')
echo 'Member';
else
echo '<a href="user.php?iwb=list&amp;view=member">Member</a>';
echo ' | ';
if (($is_admin) && ($view == 'guest'))
echo 'Tamu';
else
echo '<a href="user.php?iwb=list&amp;view=guest">Tamu</a>';
echo ' | ';
if ($view == 'ban')
echo 'Diblokir';
else
echo '<a href="user.php?iwb=list&amp;view=ban">Diblokir</a>';
echo ' | ';
if ($view == 'author')
echo 'Penulis';
else
echo '<a href="user.php?iwb=list&amp;view=author">Penulis</a>';
echo ' | ';
if ($view == 'admin')
echo 'Administrator';
else
echo '<a href="user.php?iwb=list&amp;view=admin">Administrator</a>';
echo '</div>';
if (empty($view))
{
$total=mysql_result(mysql_query("select count(*) as num from user"), 0);
$req=mysql_query("select * from user order by name desc limit $limit,$max_view");
}

if ($view == 'member')
{
$total=mysql_result(mysql_query("select count(*) as num from user where author='0' and ban='0'"), 0);
$req=mysql_query("select * from user where author='0' and ban='0' order by name desc limit $limit,$max_view");
}

if (($is_admin) && ($view == 'guest'))
{
$total=mysql_result(mysql_query("select count(*) as num from guest"), 0);
$req=mysql_query("select * from guest order by session_id desc limit $limit,$max_view");
}


if ($view == 'ban')
{
$total=mysql_result(mysql_query("select count(*) as num from user where ban='1'"), 0);
$req=mysql_query("select * from user where ban='1' order by name desc limit $limit,$max_view");
}

if ($view == 'author')
{
$total=mysql_result(mysql_query("select count(*) as num from user where author='1' and ban='0'"), 0);
$req=mysql_query("select * from user where author='1' and ban='0' order by name desc limit $limit,$max_view");
}

if ($view == 'admin')
{
$total=mysql_result(mysql_query("select count(*) as num from user where admin='1'"), 0);
$req=mysql_query("select * from user where admin='1' order by name desc limit $limit,$max_view");
}

if ($total != 0)
{
echo '<ol>';
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
if (($is_admin) && ($view == 'guest'))
{
echo htmlspecialchars($res['user_agent']);
echo '<br/>IP: '.$res['ip_browser'].' (';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ')<br/>IP Proxy: '.$res['ip_proxy'].' (';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ')';
}
else
{
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'" /> <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a><br/>';
if ($res['author'] == 0)
echo '(<font color="black"><b>Member</b></font>)';

if (($res['author'] == 1) && ($res['admin'] == 0))
echo '(<font color="green"><b>Penulis</b></font>)';
if ($res['admin'] == 1)
echo '(<font color="#731174"><b>Administrator</b></font>)';

if (($is_admin) && ($res['id'] != $user_id))
{
echo '<br/>';
echo 'IP: '.$res['ip_browser'].' (';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ')<br/>IP Proxy: '.$res['ip_proxy'].' (';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ')';
}
}
++$i;
echo '</li>';
}
echo '</ol>';
}
else
{
echo '<p>'.$head_title.' kosong</p>';
}
echo '</div>';
if (empty($view))
$link='user.php?iwb=list&amp;page=';
else
$link='user.php?iwb=list&amp;view='.htmlentities($view).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
break;
case 'email':
if (!$user_id)
relogin();
if (isset($_POST['change']))
{
$email=$_POST['email'];
if (mb_strlen($email) < 2 || mb_strlen($email) > 250)
$err='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$err='Alamat email tidak benar';if (empty($email))
$err='Silakan masukan alamat email';
$check_email=mysql_query("select * from `user` where `email`='".mysql_real_escape_string($email)."' and `id`!='".$user_id."'");
if (mysql_num_rows($check_email) != 0)
$err='Alamat email telah digunakan';
if (empty($err))
{
mysql_query("update user set email='".mysql_real_escape_string($email)."' where id='".$user_id."'");
$hsl='<ol id="success"><li>Perubahan telah disimpan</li></ol>';
}
else
{
$hsl='<ol id="error"><li>'.$err.'</li></ol>';
}
}
$head_title='Ubah Email';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="user.php">Profil</a> | <a href="user.php?iwb=edit">Edit</a> | <a href="user.php?iwb=upload">Upload Foto</a> | <a href="user.php?iwb=password">Ubah Sandi</a></div>';
echo '<form method="post"
action="user.php?iwb=email">';

echo '<h4>Email</h4>
    <input class="iwb-text"
name="email" type="text" value="'.htmlspecialchars($user_email).'"
maxlength="49" size="30"/><br/>    <input class="iwb-button" name="change" type="submit" value="Simpan"/></form><br/>Mohon masukan alamat email dengan benar karena email ini digunakan jika Anda lupa Kata Sandi';
echo '</div></div>';
include 'foot.php';break;
case 'edit':
if (!$user_id)
relogin();


$USER=mysql_fetch_array(mysql_query("select * from user where id='".$user_id."'"));
if (isset($_POST['save']))
{
if (!$user_id)
relogin();

$name=$_POST['name'];
$gender=$_POST['gender'];
$birthday=$_POST['birthday'];
$situs=$_POST['situs'];
$address=$_POST['location'];
$about=$_POST['about'];

if (mb_strlen($name) < 2 || mb_strlen($name) > 40)
$error='Nama minimal 2 dan maksimal 40 karakter';
if (empty($name))
$error='Silakan masukan Nama anda';
if (!eregi("^[0-9]{2}-[0-9]{2}-[0-9]{4}\$", $birthday))
$error='Format tanggal lahir harus HH-BB-TTTT';

if (empty($error))
{
mysql_query("update user set name='".mysql_real_escape_string($name)."', gender='".mysql_real_escape_string($gender)."', birthday='".mysql_real_escape_string($birthday)."', address='".mysql_real_escape_string($address)."', site='".mysql_real_escape_string($situs)."', about='".mysql_real_escape_string($about)."' where id='".$user_id."'");
$hsl='<ol id="success"><li>Perubahan telah disimpan</li></ol>';
}
else
{
$hsl='<ol id="error"><li>'.$error.'</li></ol>';
}
}

$head_title='Edit Profile';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="user.php">Profil</a> | Edit | <a href="user.php?iwb=upload">Upload Foto</a> | <a href="user.php?iwb=password">Ubah Sandi</a></div>';
echo '<form method="post"
action="user.php?iwb=edit">
<h4>Foto Profil (<a
href="user.php?iwb=upload">Upload</a>)</h4>
<img src="img.php?img='.$user_id.'.jpg&amp;w=80&amp;h=80" alt="'.htmlspecialchars($USER['name']).'"/><h4>Nama</h4>
    <input class="iwb-text"
name="name" type="text" value="'.htmlspecialchars($USER['name']).'"
maxlength="49" size="30"/><br/>
<h4>Jenis Kelamin</h4><select class="iwb-select" name="gender">';
if ($USER['gender'] == 'female')
echo '<option value="female">Wanita</option><option value="male">Laki-laki</option>';
else
echo '<option value="male">Laki-laki</option><option value="female">Wanita</option>';
echo '</select><br/>';
echo '<h4>Tanggal lahir</h4>
    <input class="iwb-text" name="birthday" type="text" value="'.htmlentities($USER['birthday']).'" maxlength="49" size="30"/><br/><span>HH-BB-TTTT</span><br/><h4>Situs</h4>
    <input class="iwb-text" name="situs" type="text" value="'.htmlspecialchars($USER['site']).'" maxlength="60" size="30"/><br/><h4>Email (<a href="user.php?iwb=email">Ubah</a>)</h4>'.htmlentities($USER['email']).'<br/><h4>Alamat</h4><input class="iwb-text" name="location" type="text" value="'.htmlentities($USER['address']).'" maxlength="20" size="30"/><br/><h4>Tentang Anda</h4><textarea class="iwb-textarea" name="about" rows="3"/>'.htmlentities($USER['about']).'</textarea>
    <br/>
    <input class="iwb-button" name="save" type="submit" value="Simpan"/></form>';

echo '</div></div>';
include 'foot.php';

break;
case 'password':
if (!$user_id)
relogin();
if (isset($_POST['change']))
{
$old=$_POST['old_pass'];
$pass=$_POST['new_pass'];
$re_pass=$_POST['re_new_pass'];
$req=mysql_query("select * from user where id='".$user_id."' and password='".md5($old)."'");
if (mysql_num_rows($req) == 0)
$hasil='<ol id="error"><li>Kata sandi lama tidak benar</li></ol>';
if ($pass != $re_pass)
$hasil='<ol id="error"><li>Kata sandi tidak sama</li></ol>';
if (mb_strlen($pass) < 4 || mb_strlen($pass) > 12) $hasil='<ol id="error"><li>Kata sandi minimal 4 dan maksimal 12 karakter</li></ol>';if (empty($pass) || empty($re_pass)) $hasil='<ol id="error"><li>Silakan masukan kata sandi</li></ol>';
if (empty($hasil))
{
mysql_query("update user set password='".md5($pass)."' where id='".$user_id."'");
$hasil='<ol id="success"><li>Sandi berhasil diubah</li></ol>';
}
}

$head_title='Ubah Sandi';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="user.php">Profil</a> | <a href="user.php?iwb=edit">Edit</a> | <a href="user.php?iwb=upload">Upload Foto</a> | Ubah Sandi</div>';
echo '<form method="post" action="user.php?iwb=password"><h4>Sandi Lama</h4>
<input class="iwb-password" name="old_pass" type="password" size="30"/><h4>Sandi Baru</h4>
<input class="iwb-password" name="new_pass" type="password" size="30"/>
<h4>Ulangi Sandi Baru</h4>
<input class="iwb-password" name="re_new_pass" type="password" size="30"/><br/>    <input class="iwb-button" name="change" type="submit" value="Ubah"/></form>';
echo '</div></div>';
include 'foot.php';

break;

case 'upload':
if (!$user_id)
relogin();
$maxsize='200';
$filename=$_FILES['file']['name'];

if (isset($_POST['upload']))
{
if (!$user_id)
relogin();
$types = array("image/jpeg", "image/pjpeg","image/gif","image/x-png");
if (!in_array($_FILES['file']['type'], $types))
$hsl='<ol id="error"><li>Jenis file tidak diijinkan</li></ol>';
if ($_FILES['file']['size'] > (1024*$maxsize))
$hsl='<ol id="error"><li>Foto maksimal berukuran 200Kb</li></ol>';
if (empty($filename))
$hsl='<ol id="error"><li>Silakan pilih file</li></ol>';

if (empty($hsl))
{
copy($_FILES['file']['tmp_name'], "images/profile/$user_id.jpg");
$hsl='<ol id="success"><li>Foto berhasil diupload</li><li><img src="img.php?img='.$user_id.'.jpg&amp;w=64&amp;h=64" alt="'.htmlspecialchars($user_name).'" /></li></ol>';
}
}
$head_title='Upload Foto';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="user.php">Profil</a> | <a href="user.php?iwb=edit">Edit</a> | Upload Foto | <a href="user.php?iwb=password">Ubah Sandi</a></div>';
echo '<form action="user.php?iwb=upload" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="200000" type="hidden"/>
    <h4>Pilih Foto</h4><input type="file" name="file"/>
    <input class="iwb-button" name="upload" type="submit" value="Upload"/></form></div></div>';
include 'foot.php';


break;


default:
if (!$user_id)
relogin();
$id=$_GET['id'];
if (empty($id))
$id=$user_id;
$req=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($req) == 0)
{
include 'head.php';
echo '<div id="message"><ol id="error"><li>Pengguna dengan id '.htmlentities($id).' tidak ada</li></ol></div>';
include 'foot.php';
exit;
}
$USER=mysql_fetch_array($req);
$head_title=htmlspecialchars($USER['name']);
include 'head.php';
echo '<div id="message"></div><div id="content">
<div id="main-content">';
if ($USER['id'] == $user_id)
echo '<div id="show_bar">Profil | <a href="user.php?iwb=edit">Edit</a> | <a href="user.php?iwb=upload">Upload Foto</a> | <a href="user.php?iwb=password">Ubah Sandi</a></div>';
if (($is_admin) && ($USER['id'] != $user_id))
{
echo '<div id="show_bar">';
if ($USER['author'] == 1)
echo '<a href="admin.php?iwb=author&amp;action=delete&amp;id='.$USER['id'].'">Hapus Penulis</a>';
else
echo '<a href="admin.php?iwb=author&amp;action=add&amp;id='.$USER['id'].'">Jadikan Penulis</a>';
echo ' | ';
if ($USER['ban'] == 0)
echo '<a href="admin.php?iwb=banned&amp;id='.$USER['id'].'">Banned</a>';
else
echo '<a href="admin.php?iwb=unbanned&amp;id='.$USER['id'].'">Un Banned</a>';
echo ' | ';
echo '<a href="admin.php?iwb=delete_user&amp;id='.$USER['id'].'">Hapus Pengguna</a>';
echo '</div>';
}
echo '<table>
    <tr>
<td style="width: 50%;"><img src="img.php?img='.$USER['id'].'.jpg&amp;w=64&amp;h=64" style="width: 100%"/></td><td><strong>'.htmlspecialchars($USER['name']).'</strong><br/>';
if ($USER['author'] == 0)
echo '(<font color="black"><b>Member</b></font>)';

if (($USER['author'] == 1) && ($USER['admin'] == 0))
echo '(<font color="green"><b>Penulis</b></font>)';
if ($USER['admin'] == 1)
echo '(<font color="#731174"><b>Administrator</b></font>)';

echo '</td>
</tr>
</table>';
if ($USER['id'] != $user_id)
echo '<a href="message.php?iwb=write&amp;to='.$USER['id'].'">
<input class="iwb-button" type="submit" value="Kirim Pesan"/></a>';
echo '<h4>Informasi</h4>
<ol>
    <li>Nama Pengguna: '.htmlspecialchars($USER['username']).'</li><li>Nama: '.htmlspecialchars($USER['name']).'</li>
    <li>Jenis Kelamin: ';
if ($USER['gender'] == 'male')
echo 'Laki-laki';
else
echo 'Perempuan';
echo '</li>
<li>Tanggal Lahir: '.$USER['birthday'].'</li>
<li>Alamat: '.htmlentities($USER['address']).'</li>
<li>Situs:<a href="'.$USER['site'].'">'.$USER['site'].'</li><li>Terdaftar Sejak: '.waktu($USER['date_reg']).'</li><li>Terakhir Masuk: '.time_ago($USER['lastdate']).'</li><li>Tentang: '.htmlentities($USER['about']).'</li>';
if (($is_admin) && ($USER['id'] != $user_id))
{
echo '<li>IP: '.$USER['ip_browser'].' (';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($USER['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$USER['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=unblock_ip&amp;ip='.$USER['ip_browser'].'">Unblock</a>';

echo ')</li><li>IP Proxy: '.$USER['ip_proxy'].' (';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($USER['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$USER['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$USER['ip_proxy'].'">Unblock</a>';

echo ')</li>';
echo '<li>Browser: '.htmlentities($USER['user_agent']).'</li>';
}
echo '</ol>';
echo '<h4>Posting Terbaru</h4><ol>';
$totl=mysql_result(mysql_query("select count(*) as num from blog where user_id='".$USER['id']."' and draft='0'"), 0);
$Res=mysql_query("select * from blog where user_id='".$USER['id']."' and draft='0' order by time desc limit 5;");
while ($res=mysql_fetch_array($Res))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<a href="'.$site['url'].'/'.$res['link'].'.xhtml">'.htmlspecialchars($res['title']).'</a><br/>'.time_ago($res['time']).'<br/>';
$total=mysql_result(mysql_query("select count(*) as num from comment where blog_id='".$res['id']."'"), 0);
echo 'Komentar: <a href="'.$site['url'].'/'.$res['link'].'.xhtml#comments">'.$total.'</a>';
++$i;
echo '</li>';
}
if ($totl == 0)
{
if ($USER['id'] == $user_id)
echo '<p>Anda belum mempunyai postingan blog.</p>';
else
echo '<p>'.htmlspecialchars($USER['name']).' belum mempunyai postingan blog.</p>';
}
echo '</ol></div></div>';
include 'foot.php';
}
?>