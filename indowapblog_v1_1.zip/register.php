<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'terms':
$head_title='Ketentuan layanan';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="register.php?">Pendaftaran</a> | Ketentuan Layanan</div>';
echo '<p>Dengan melakukan pendaftaran pada situs <strong>'.htmlspecialchars($site['name']).'</strong> berarti Anda telah menyetujui peraturan dibawah ini</p><br/><p><ul><li>1. Jika Anda menjadi Author (penulis) blog dilarang untuk memposting konten yang berbau pornografi, sara atau kekerasan.</li><li>2. Dilarang membuat kericuhan pada situs <strong>'.htmlspecialchars($site['name']).'</strong>.</li><li>3. Dilarang membuat komentar atau pesan Spam.</li></li></p>';
echo '</div></div>';
include 'foot.php';
break;


default:
if ($site['allow_reg'] == 0)
{
$head_title='Pendaftaran';
include 'head.php';
echo '<div id="message"><ol id="notice"><li>Pendaftaran untuk sementara waktu ditutup</li></ol></div>';
include 'foot.php';
exit;
}
if ($user_id)
header('location: dashboard.php');
$username=$_POST['username'];
$pass=$_POST['pass'];
$re_pass=$_POST['re_pass'];
$name=$_POST['name'];
$email=$_POST['email'];
$code=$_POST['code'];
if (isset($_POST['register']))
{
if ($code != $_SESSION['captcha_code'])
$hasil='Kode keamanan salah';
if (mb_strlen($email) < 2 || mb_strlen($email) > 250)
$hasil='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hasil='Alamat email tidak benar';if (empty($email))
$hasil='Silakan masukan alamat email';
$check_email=mysql_query("select * from user where email='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$hasil='Alamat email telah digunakan';
if (mb_strlen($name) < 2 || mb_strlen($name) > 40)
$hasil='Nama minimal 2 dan maksimal 40 karakter';
if (empty($name))
$hasil='Silakan masukan Nama anda';
if ($pass != $re_pass)
$hasil='Kata sandi tidak sama';
if (mb_strlen($pass) < 4 || mb_strlen($pass) > 12) $hasil='Kata sandi minimal 4 dan maksimal 12 karakter';if (empty($pass) || empty($re_pass)) $hasil='Silakan masukan kata sandi';
if (mb_strlen($username) < 4 || mb_strlen($username) > 32)
$hasil='Username 4 dan maksimal 32 karakter';

if (preg_match("/[^a-z0-9\_\-]/", $username))
$hasil='Karakter Username hanya diperbolehkan a-z, 0-9, -, _';
if (empty($username))
$hasil='Silakan masukan Username';$check_username=mysql_query("select * from user where username='".mysql_real_escape_string($username)."'");
if (mysql_num_rows($check_username) != 0)
$hasil='Username telah digunakan';
if (empty($hasil))
{
if ($site['reg_email'] == 1)
{
$password='';
$passw=md5($pass);
$kod=rand(100000, 999999);
$konf=''.$passw.$kod.'';
}
else
{
$password=md5($pass);
$konf='0';
}
if ($site['reg_author'] == 1)
$author='1';
else
$author='0';
mysql_query("insert into user set username='".mysql_real_escape_string($username)."', password='".mysql_real_escape_string($password)."', email='".mysql_real_escape_string($email)."', name='".mysql_real_escape_string($name)."', author='".$author."', confirm='".$konf."', date_reg='".time()."'");
$new_id=mysql_insert_id();
if ($site['reg_email'] == 1)
{

$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $email;
$subject="Konfirmasi Akun ".$site['name']."";
$pesan="Berikut adalah Data Akun Anda\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "Username: ".$username."";
$pesan .= "\r\n\r\n";
$pesan .= "Kata Sandi: ".$pass."";
$pesan .= "\r\n\r\n";
$pesan .= "Kode Konfirmasi: ".$kod."";
$pesan .= "\r\n\r\n";
$pesan .= "\r\n\r\nSilakan pergi ke ".$site['url']."/login.php?iwb=conf dan masukan Kode Konfirmasi atau klik link di bawah ini\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= ''.$site['url'].'/login.php?iwb=conf&code='.$kod.'';$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$head_title='Pendaftaran';
include 'head.php';
echo '<div id="message"></div><div id="content"><div id="main-content"><p>Pendaftaran berhasil. Link konfirmasi telah kami kirim ke alamat email Anda. Silakan klik link tersebut untuk mengaktifkan akun Anda</p></div></div>';
include 'foot.php';
exit;
}
else
{
$user_id = $new_id;
setcookie("user_id", $user_id, time() +60 * 60 * 24 * 30);
setcookie("password", $password, time() +60 * 60 * 24 * 30);
mysql_query("update user set lastdate='".time()."', ip_proxy='".mysql_real_escape_string($_SERVER['REMOTE_ADDR'])."', ip_browser='".mysql_real_escape_string($_SERVER['HTTP_X_FORWARDED_FOR'])."', user_agent='".mysql_real_escape_string($_SERVER['HTTP_USER_AGENT'])."' where id='".$user_id."'");

header('location: user.php?iwb=edit');
}
}
}
$head_title='Pendaftaran';
include 'head.php';
echo '<div id="message">';
if (isset($_POST['register']))
echo '<ol id="notice"><li>'.$hasil.'</li></ol>';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Pendaftaran | <a href="register.php?iwb=terms">Ketentuan Layanan</a></div>';
echo '<form method="post" action="register.php">
<h4>Username</h4>
<input class="iwb-text" name="username" type="text" value="'.htmlentities($username).'" maxlength="32" size="30"/><br/>
<h4>Kata sandi</h4>
<input class="iwb-password" name="pass" type="password" maxlength="12" size="30"/><br/>
<h4>Ulangi Kata sandi</h4>
<input class="iwb-password" name="re_pass" type="password" maxlength="12" size="30"/><br/>
<h4>Nama</h4>
<input class="iwb-text" name="name" type="text" value="'.htmlentities($name).'" maxlength="49" size="30"/><br/>
<h4>Email</h4>
<input class="iwb-text" name="email" type="text" value="'.htmlentities($email).'" maxlength="35" size="30"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>Kode keamanan:</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><br/>';
echo '<p style="text-align:center;">Dengan mengklik &quot;Daftar&quot; berarti anda telah setuju dengan <a href="register.php?iwb=terms">Ketentuan Layanan</a> Kami.<br/>
<input class="iwb-button" name="register" type="submit" value="Daftar"/>
</p>
</form>            </div>
        </div>';
include 'foot.php';
}
?>