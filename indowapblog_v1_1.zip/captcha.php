<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

session_name('IndoWapBlog');
session_start();
if (!isset ($_SESSION['captcha_code']))
exit;

// Tentukan ukuran gambar
$imwidth = 85;
$imheight = 26;

$im = ImageCreate($imwidth, $imheight);
$background_color = ImageColorAllocate($im, 255, 255, 255);
$text_color = ImageColorAllocate($im, 0, 0, 0);
$border_color = ImageColorAllocate($im, 154, 154, 154);

// hasilkan gangguan dalam garis
$g1 = imagecolorallocate($im, 152, 152, 152);// menentukan garis garis warna
for ($i = 0; $i <= 100; $i += 6)
imageline($im, $i, 0, $i, 25, $g1);// Garis horizontal
for ($i = 0; $i <= 25; $i += 5)
imageline($im, 0, $i, 100, $i, $g1);// garis vertikal

// menghasilkan kode digital yang didasarkan pada sesi
$code = substr($_SESSION["captcha_code"], 0, 4);
$x = 0;
$stringlength = strlen($code);
for ($i = 0; $i < $stringlength; $i++) {
$x = $x + (rand(8, 21));
$y = rand(2, 10);
$font = rand(4, 25);
$single_char = substr($code, $i, 1);
imagechar($im, $font, $x, $y, $single_char, $text_color);
}

// mengirimkan gambar ke bowser
ob_start();
ImageGif($im);
ImageDestroy($im);
header("Content-Type: image/gif");
header('Content-Disposition: inline; filename=IndoWapBlog.gif');
header('Content-Length: ' . ob_get_length());
ob_end_flush();

?>
