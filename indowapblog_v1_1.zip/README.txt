//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

//*installasi*//

CHMOD Folder "/files" , folder "/images/profile" ke 777 dan "/images/smiley" ke 777

Call/Browse install.php dan masukan data sesuia kolom yang diminta.

Bermasalah pada saat installasi silakan kontak kami di achunk17[at]gmail[dot]com