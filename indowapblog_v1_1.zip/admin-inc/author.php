<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
if (isset($_GET['id']))
{
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
$head_title='Hapus Penulis';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=author">List Penulis</a> | <a href="admin.php?iwb=author&amp;action=add">Tambah Penulis</a> | Hapus Penulis</div><p>Tidak ada pengguna yang dipilih</p></div></div>';
include 'foot.php';
exit;
}
$res=mysql_fetch_array($cek);
if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("update user set author='0' where id='".mysql_real_escape_string($id)."'");
header('location: admin.php?iwb=author');
}
}
}
$head_title='Hapus Penulis';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=author">List Penulis</a> | <a href="admin.php?iwb=author&amp;action=add">Tambah Penulis</a> | Hapus Penulis</div>';
if (isset($_GET['id']))
{
echo '<p>Anda yakin ingin menghapus <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai penulis?<br/>[<a href="admin.php?iwb=author&amp;action=delete&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="admin.php?iwb=author">TIDAK</a>]</p>';
}
else
{
echo '<form action="admin.php" method="get"><input type="hidden" name="iwb" value="author"/><input type="hidden" name="action" value="delete"/>Pilih Penulis:<br/>
<select class="iwb-select" name="id">
<option value=""></option>';
$REQ=mysql_query("select * from user where author='1' and admin='0' order by name desc");
while ($RES=mysql_fetch_array($REQ))
{
echo '<option value="'.$RES['id'].'">'.htmlspecialchars($RES['name']).'</option>';
}

echo '</select><p><input class="iwb-button" type="submit" value="Hapus Penulis"/></p></form>';
}
echo '</div></div>';
include 'foot.php';
break;

case 'add':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
if (isset($_GET['id']))
{
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
$head_title='Tambah Penulis';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=author">List Penulis</a> | Tambah Penulis | <a href="admin.php?iwb=author&amp;action=delete">Hapus Penulis</a></div><p>Tidak ada pengguna yang dipilih</p></div></div>';
include 'foot.php';
exit;
}
$res=mysql_fetch_array($cek);

if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("update user set author='1' where id='".mysql_real_escape_string($id)."'");
header('location: admin.php?iwb=author');
}
}
}
$head_title='Tambah Penulis';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=author">List Penulis</a> | Tambah Penulis | <a href="admin.php?iwb=author&amp;action=delete">Hapus Penulis</a></div>';
if (isset($_GET['id']))
{
echo '<p>Anda yakin ingin menjadikan <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai penulis?<br/>[<a href="admin.php?iwb=author&amp;action=add&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="admin.php?iwb=author">TIDAK</a>]</p>';
}
else
{
echo '<form action="admin.php" method="get"><input type="hidden" name="iwb" value="author"/><input type="hidden" name="action" value="add"/>Pilih Member:<br/>
<select class="iwb-select" name="id">
<option value=""></option>';
$REQ=mysql_query("select * from user where author='0' order by name desc");
while ($RES=mysql_fetch_array($REQ))
{
echo '<option value="'.$RES['id'].'">'.htmlspecialchars($RES['name']).'</option>';
}

echo '</select><p><input class="iwb-button" type="submit" value="Jadikan Penulis"/></p></form>';
}
echo '</div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title='List Penulis';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">List Penulis | <a href="admin.php?iwb=author&amp;action=add">Tambah Penulis</a> | <a href="admin.php?iwb=author&amp;action=delete">Hapus Penulis</a></div>';
echo '<ol>';
$total=mysql_result(mysql_query("select count(*) as num from user where author='1' and admin='0'"), 0);
if ($total == 0)
{
echo '<li>Belum ada penulis lain selain Anda</li>';
}
else
{
$req=mysql_query("select * from user where author='1' and admin='0' order by name desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'" /> <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a><br/>';
echo 'IP: '.$res['ip_browser'].' <span class="action_links">[';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=unblock_ip&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ']</span><br/>IP Proxy: '.$res['ip_proxy'].' <span class="action_links">[';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=unblock_ip&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ']</span><br/><span class="action_links"><a class="delete" href="admin.php?iwb=author&amp;action=delete&amp;id='.$res['id'].'">Hapus Penulis</a></span>';
++$i;
echo '</li>';
}
}
echo '</ol></div>';
$link='admin.php?iwb=author&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>