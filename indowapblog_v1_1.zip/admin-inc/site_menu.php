<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from site_menu where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from site_menu where id='".mysql_real_escape_string($id)."'");
header('location: admin.php?iwb=site_menu');
}
}
$head_title='Hapus Item Menu';
include 'head.php';
echo '<div id="message"></div><div id="content">
<div id="main-content"><p>Anda yakin ingin menghapus item ini?<br/>[<a href="admin.php?iwb=site_menu&amp;action=delete&amp;id='.$id.'&amp;yes">YA</a>] [<a href="admin.php?iwb=site_menu">TIDAK</a>]</p></div></div>';
include 'foot.php';
break;

case 'edit':
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from site_menu where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_POST['cancel']))
{
header('location: admin.php?iwb=site_menu');
}
if (isset($_POST['save']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$item_url=$_POST['item_url'];
$item_name=$_POST['item_name'];
$perm=$_POST['perm'];
if ($perm == users)
$users='1';
if ($perm == author)
$author='1';
if ($perm == administrator)
$administrator='1';

if (!empty($item_url) || !empty($item_name))
{
mysql_query("update site_menu set link='".mysql_real_escape_string($item_url)."', name='".mysql_real_escape_string($item_name)."', user='".$users."', author='".$author."', admin='".$administrator."' where id='".$id."'");
header('location: admin.php?iwb=site_menu');
}
else
{
$hsl='<ol id="error"><li>Link atau Nama tidak boleh kosong.</li></ol>';
}
}
$nv=mysql_fetch_array($cek);
$head_title='Edit Item Menu';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content"><form method="post" action="admin.php?iwb=site_menu&amp;action=edit&amp;id='.$id.'"><h4>Link</h4><input class="iwb-text" type="text" name="item_url" value="'.htmlentities($nv['link']).'"/><br/><h4>Nama</h4><input class="iwb-text" type="text" name="item_name" value="'.htmlentities($nv['name']).'"/><br/><h4>Perijinan</h4><input type="radio"
name="perm"
value="users" ';
if ($nv['user'] == 1)
echo 'checked';
echo '/>Member<br/><input type="radio"
name="perm"
value="author" ';
if ($nv['author'] == 1)
echo 'checked';
echo '/>Penulis<br/><input type="radio"
name="perm"
value="administrator"  ';
if ($nv['admin'] == 1)
echo 'checked';
echo '/>Administrator<br/><div class="two-col-btn">
<input class="iwb-button" name="save" type="submit" value="Simpan"/>
<input class="iwb-button" name="cancel" type="submit" value="Batal"/>
</div>
</form>
</div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['add']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$item_url=$_POST['item_url'];
$item_name=$_POST['item_name'];
$perm=$_POST['perm'];
if ($perm == users)
$users='1';
if ($perm == author)
$author='1';
if ($perm == administrator)
$administrator='1';

if (!empty($item_url) || !empty($item_name))
{
mysql_query("insert into site_menu set link='".mysql_real_escape_string($item_url)."', name='".mysql_real_escape_string($item_name)."', user='".$users."', author='".$author."', admin='".$administrator."'");
$hsl='<ol id="success"><li>Item berhasil ditambahkan</li></ol>';
}
else
{
$hsl='<ol id="error"><li>Silakan masukan teks atau kode</li></ol>';
}
}
$head_title='Menu Situs';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">
<div id="action_bar"><a href="#add">Tambah Bru</a></div>';
$req=mysql_query("select * from site_menu order by id desc");
while ($nv=mysql_fetch_array($req))
{
$sn='_SITE_NAME_';
$su='_SITE_URL_';
echo '<li><a href="'.$nv['link'].'">'.$nv['name'].'</a><br/><span class="action_links">[<a
class="edit" href="admin.php?iwb=site_menu&amp;action=edit&amp;id='.$nv['id'].'">Ubah</a>] [<a class="delete" href="admin.php?iwb=site_menu&amp;action=delete&amp;id='.$nv['id'].'">Hapus</a>]</span></li>';
}
echo '<h3><a class="no-link" name="add">Tambah Item Baru</a></h3><form method="post" action="admin.php?iwb=site_menu"><h4>Link</h4><input class="iwb-text" name="item_url" value=""/><br/><h4>Nama</h4><input class="iwb-text" name="item_name" value=""/><br/><h4>Perijinan</h4><input type="radio"
name="perm"
value="users" checked/>Member<br/><input type="radio"
name="perm"
value="author"/>Penulis<br/><input type="radio"
name="perm"
value="administrator"/>Administrator<br/><input class="iwb-button"name="add" type="submit" value="Tambah"/></form></div></div>';
include 'foot.php';
}
?>