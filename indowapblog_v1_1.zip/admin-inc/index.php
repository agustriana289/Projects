<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$head_title='Admin Panel';
include 'head.php';
echo '<style type="text/css">
#iphone-list
{
  margin: 2px;
  padding: 2px;
}
#iphone-list li
{
    list-style-type: none;
    margin: 2px;
    padding: 2px;
}
#iphone-list .heading
{
    list-style-type: none;
    margin: 2px;
    padding: 6px 5px 6px 5px;
    background-color: #333333;
    color: #FFFFFF;
    font-weight: bold;
}
#iphone-list li a
{
    display:block;
    padding: 6px 5px 6px 5px;
}
.iphone-list-border li a
{
    border-top: 2px solid #B4B4B4;
}
#iphone-list li a:hover
{
    background-color: #E1E1E1;
}
</style>';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">
<ul id="iphone-list">';

echo '<li class="heading">Admin Panel</li><li><a href="admin.php?iwb=category">Kelola Kategori</a></li><li><a href="manage_guestbook.php?">Kelola Buku Tamu</a></li>

    <li><a href="admin.php?iwb=settings">Pengaturan Blog</a></li>
<li><a href="file.php">Upload File</a></li>    <li><a href="file.php?">Kelola File</a></li><li><a href="admin.php?iwb=navigation">Menu Navigasi</a></li><li><a href="admin.php?iwb=iwb_market">IWB Market</a></li><li><a href="admin.php?iwb=iwb_network">IWB Network</a></li><li><a href="admin.php?iwb=following">Following</a></li>';
$aMenu=mysql_query("select * from site_menu where admin='1' order by name");
while ($adMenu=mysql_fetch_array($aMenu))
{
echo '<li><a href="'.$adMenu['link'].'">'.$adMenu['name'].'</a></li>';
}
echo '<li><a href="admin.php?iwb=subscribe">Pelanggan Blog</a></li><li><a href="admin.php?iwb=author">Kelola Penulis</a></li><li><a href="admin.php?iwb=block_ip">Blokir IP</a></li><li><a href="bbsm.php">Perbarui Smiley</a></li><li><a href="admin.php?iwb=contact_iwb">Hubungi IWB</a></li>
<li><a href="admin.php?iwb=stats">Statistik</a></li>';
echo '</ul></div></div>';
include 'foot.php';
?>