<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$res=mysql_fetch_array($cek);

if ($res['admin'] == 1)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
mysql_query("delete from user where id='".mysql_real_escape_string($id)."'");


mysql_query("delete from blog where user_id='".mysql_real_escape_string($id)."'");


mysql_query("delete from comment where blog_user_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from comment where user_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from chat where user_id='".mysql_real_escape_string($id)."'");
mysql_query("delete from guestbook where user_id='".mysql_real_escape_string($id)."'");


mysql_query("delete from `pm` where `receiver_id`='".mysql_real_escape_string($id)."' or `sender_id`='".mysql_real_escape_string($id)."'");

header('location: user.php?iwb=list');
}


$head_title='Hapus Pengguna';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<p>Anda yakin ingin menghapus <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai pengguna?<br/>[<a href="admin.php?iwb=delete_user&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="user.php?iwb=list">TIDAK</a>]</p>';
echo '</div></div>';
include 'foot.php';
?>

