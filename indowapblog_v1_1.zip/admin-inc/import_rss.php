<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from import_rss where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from import_rss where id='".mysql_real_escape_string($id)."'");
header('location: admin.php?iwb=import_rss&action=list');
}
}
$head_title='Hapus RSS';
include 'head.php';
echo '<div id="message"></div><div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=import_rss">Import RSS</a> | <a href="admin.php?iwb=import_rss&amp;action=list">List Auto Import</a> | <a href="admin.php?iwb=import_rss&amp;action=help">Bantuan</a></div>';
echo '<p>Anda yakin ingin menghapus RSS ini?<br/>[<a href="admin.php?iwb=import_rss&amp;action=delete&amp;id='.$id.'&amp;yes">YA</a>] [<a href="admin.php?iwb=import_rss&amp;action=list">TIDAK</a>]</p></div></div>';
include 'foot.php';
break;

case 'help':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$head_title='Bantuan - Import RSS';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=import_rss">Import RSS</a> | <a href="admin.php?iwb=import_rss&amp;action=list">List Auto Import</a> | Bantuan</div>';
echo '<p>Di sini Anda bisa mengimport postingan pada blog lain dengan cara menyalin RSS pada blog tersebut, ada pun penuh atau tidaknya postingan atau deskripsi tergantung pada RSS yang diimport. Kalau di RSS tersebut isi deskripsi tidak penuh maka RSS Import pun menyalin isi deskripsinya tidak penuh, sebaliknya jika isi deskripsi pada Feed RSS penuh maka RSS Import akan menyalin semua isi deskripsi tersebut.<br/><b>Spesifikasi Penyalinan</b><br/><ol><li>Feed harus berjenis RSS, Jika Feed Atom atau lainnya maka RSS Import tidak dapat menyalin isinya.<li></li></ol><br/><b>Contoh Feed RSS</b><br/><ol><li>Blogspot: http://NAMA-SITUS.blogspot.com/feeds/posts/default?alt=rss</li><li>IndoWapBlog: http://NAMA-SITUS/rss.xml</li><li>MyWapBlog: http://NAMA-SITUS.mywapblog.com/rss.xml</li></ol><br/>Anda dapat menyalin isi RSS secara otomatis. Jika pada RSS tersebut ada posting terbaru maka akan disalin dan dipublikasikan pada <b>'.htmlspecialchars($site['name']).'</b></p>';
echo '</div></div>';
include 'foot.php';
break;

case 'list':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}

$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title='Import RSS Otomatis';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=import_rss">Import RSS</a> | List Auto Import | <a href="admin.php?iwb=import_rss&amp;action=help">Bantuan</a></div>';

$total=mysql_result(mysql_query("select count(*) as num from `import_rss` where `url_rss` != ''"), 0);
if ($total == 0)
{
echo '<p>Belum ada RSS yang diimport secara otomatis.</p>';
}
else
{
$req=mysql_query("select * from `import_rss` where `url_rss` != '' order by `id` desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<b>Feed RSS:</b> '.$res['url_rss'].'<br/><b>Ditambahkan:</b> '.waktu($res['time']).'<br/><span class="action_links">[<a class="delete" href="admin.php?iwb=import_rss&amp;action=delete&amp;id='.$res['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol>';
}
echo '</div></div>';
include 'foot.php';
break;

break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$rss=$_POST['rss'];
$auto=$_POST['auto'];
$new_time=$_POST['new_time'];
$kategori=$_POST['kategori'];
$sumber=$_POST['sumber'];
if (isset($_POST['import']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$rss=str_replace('http://','',$rss);
if (empty($rss))
$error='Silakan masukan URL RSS Feed';
if (empty($error))
{
$rss='http://'.$rss.'';
$hasil='<ol id="notice"><li>Import RSS '.$rss.'</li></ol>';
}
else
{
$hasil='<ol id="error"><li>'.$error.'</li></ol>';
}
}
$head_title='Import RSS';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Import RSS | <a href="admin.php?iwb=import_rss&amp;action=list">List Auto Import</a> | <a href="admin.php?iwb=import_rss&amp;action=help">Bantuan</a></div>';
echo '<form method="post" action="admin.php?iwb=import_rss">
<h4>RSS Feed</h4>
<input class="iwb-text" name="rss" type="text" value="http://'.str_replace('http://','',$rss).'" size="30"/><br/><h4>Kategori</h4>';
$kat=mysql_query("select * from category order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="radio" name="kategori" value="'.$kategoris['id'].'"';
if ($kategoris['id'] == '1')
echo 'checked';
echo '/>'.$kategoris['name'].'<br/>';
}
echo '<h4>Perbarui Tanggal</h4><input type="radio" name="new_time" value="1"/>Ya<br/><input type="radio" name="new_time" value="0" checked/>Tidak<br/><h4>Auto Import</h4><input type="radio" name="auto" value="1"/>Ya<br/><input type="radio" name="auto" value="0" checked/>Tidak<br/><h4>Tampilkan link sumber</h4><input type="radio" name="sumber" value="1"/>Ya<br/><input type="radio" name="sumber" value="0" checked/>Tidak<br/>
<p><input class="iwb-button" name="import" type="submit" value="Import"/></p></form>';
if (isset($_POST['import']) && empty($error))
{
echo '<ol>';

$feed=$rss;
$howmany='5';

$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

$xml = simplexml_load_file($feed);
if ($xml)
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;

if ($count>$howmany)
$howmany=$count;
if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$title = $item->title;
$link=htmlspecialchars($item->link);$tgl = strtotime($item->pubDate);
$deskrip = $item->description;
if ($sumber == 1)
$desc=''.$deskrip.'<br/>Sumber: <a href="'.$link.'">'.$link.'</a>';
else
$desc=$deskrip;
if ($new_time == 1)
$tanggal=time();
else
$tanggal=$tgl;
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<a href="'.$link.'">'.htmlspecialchars($title).'</a> <small>('.time_ago($tanggal).')</small><br/>';

echo html_entity_decode(htmlentities($desc));
$cek=mysql_query("select * from import_rss where url_post='".mysql_real_escape_string($link)."'") or die(mysql_error());
if (mysql_num_rows($cek) == 0)
{
$permalink=permalink($title);
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));
mysql_query("insert into `blog` set `user_id`='".$adm['id']."', `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($desc)."', `link`='".mysql_real_escape_string($permalink)."', `time`='".$tanggal."', `category`='".$kategori."', `allow_comment`='1', `draft`='0'") or die(mysql_error());
$blog_id=mysql_insert_id();
$kf=mysql_fetch_array(mysql_query("select * from category where id='".$kategori."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='".$kategori."'");

mysql_query("insert into `import_rss` set `url_post`='".mysql_real_escape_string($link)."', `time`='".time()."'") or die(mysql_error());
}
++$i;
echo '</li>';
}
}
}
if ($auto == 1)
{
$cek_r=mysql_query("select * from import_rss where url_rss='".$feed."'");
if (mysql_num_rows($cek_r) == 0)
{
mysql_query("insert into import_rss set url_rss='".$feed."', update_time='".$new_time."', category='".$kategori."', sumber='".$sumber."', time='".time()."'");
echo '<p>'.$feed.' berhasil ditambahkan ke auto Import.</p>';
}
else
{
echo '<p>'.$feed.' sebelumnya telah ditambahkan ke auto Import.</p>';
}
}
}
else
{
echo '<p>Tidak bisa menampilkan data RSS dari '.$feed.'. Pastikan '.$feed.' adalah Feed berjenis RSS dan minimal terdapat 1 posting (item).</p>';
}
echo '</ol>';
}



echo '</div></div>';
include 'foot.php';
}
?>