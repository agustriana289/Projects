<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'unblock':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$ip=$_GET['ip'];
if (isset($_GET['ip']))
{
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}

$cek=mysql_query("select * from blocked where ip='".mysql_real_escape_string($ip)."'");
if (mysql_num_rows($cek) == 0)
$error='IP '.htmlentities($ip).' belum ada pada daftar pemblokiran';
if (empty($error))
{
mysql_query("delete from blocked where ip='".mysql_real_escape_string($ip)."'");
$hasil='<ol id="success"><li>IP '.htmlentities($ip).' berhasil dihapus dari pemblokiran</li></ol>';
}
else
{
$hasil='<div id="error"><li>'.$error.'</li></ol>';
}
}
$head_title='Unblock IP';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content"><div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=block_ip">IP Blocked</a> | Unblock IP</div>';
echo '<form method="get" action="admin.php"><h4>Masukan IP</h4><input type="hidden" name="iwb" value="block_ip"/><input type="hidden" name="action" value="unblock"/><input class="iwb-text" name="ip" type="text" maxlength="15" size="20"/><p align="center"><input class="iwb-button" type="submit" value="Batalkan Pemblokiran"/></p></form>';
echo '</div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$ip=$_GET['ip'];
if (isset($_GET['ip']))
{
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}

$cek=mysql_query("select * from blocked where ip='".mysql_real_escape_string($ip)."'");
if (mysql_num_rows($cek) != 0)
{
$hsl='<ol id="error"><li>IP '.htmlentities($ip).' sebelumnya telah ada dalam daftar pemblokiran</li></ol>';
}
else
{
mysql_query("insert into blocked set ip='".mysql_real_escape_string($ip)."'");
$hsl='<ol id="success"><li>IP '.htmlentities($ip).' berhasil ditambahkan ke daftar pemblokiran</li></ol>';
}
}
$head_title='Blokir IP';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>';
echo '<div id="content"><div id="main-content">';
echo '<form method="get" action="admin.php"><h4>Masukan IP</h4><input type="hidden" name="iwb" value="block_ip"/><input class="iwb-text" name="ip" type="text" maxlength="15" size="20"/><p align="center"><input class="iwb-button" type="submit" value="Blokir"/></p></form><div id="action_bar">List IP diblokir</div>';
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

echo '<ol>';

$total=mysql_result(mysql_query("select count(*) as num from blocked"), 0);
if ($total == 0)
{
echo '<li>Belum ada IP yang diblokir</li>';
}
else
{
$rek=mysql_query("select * from blocked order by id desc limit $limit,$max_view");
while ($rez=mysql_fetch_array($rek))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<strong>'.$rez['ip'].'</strong><br/><span class="action_links"><a class="delete" href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$rez['ip'].'">Unblock</a></span>';
++$i;
echo '</li>';
}
}
echo '</ol></div>';

$link='admin.php?iwb=block_ip&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>