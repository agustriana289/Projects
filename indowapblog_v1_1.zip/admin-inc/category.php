<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
$cid=$_GET['cid'];
if (!$user_id)
relogin();

if (!$is_admin || $cid == 1)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (mysql_num_rows(mysql_query("select * from category where id='".mysql_real_escape_string($cid)."'") < 1))
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin || $cid == 1)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from category where id='".mysql_real_escape_string($cid)."'");
header('location: admin.php?iwb=category');
}
}
$head_title='Hapus Kategori';
include 'head.php';
echo '<div id="message"></div><div id="content"><div id="main-content"><p>Anda yakin untuk menghapus kategori ini?<br/>[<a href="admin.php?iwb=category&amp;action=delete&amp;cid='.$cid.'&amp;yes">YA</a>] [<a href="admin.php?iwb=category">TIDAK</a>]</p></div></div>';
include 'foot.php';
break;

case 'edit':
$cid=$_GET['cid'];
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$cat=mysql_query("select * from category where id='".mysql_real_escape_string($cid)."'");
if (mysql_num_rows($cat) < 1)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$kat=mysql_fetch_array($cat);
if (isset($_POST['change']))
{
$newname=$_POST['newname'];
$permalink=permalink($newname);
if ((mb_strlen($newname) < 2) || (mb_strlen($newname) > 20))
$error='Nama kategory minimal 2 dan maksimal 20 karakter';

elseif (empty($newname))
$error='Silakan masukan nama kategori';
if (mysql_num_rows(mysql_query("select * from category where link='".mysql_real_escape_string($permalink)."'") != 0))
$error='Nama kategori sudah ada';
if (empty($error))
{
mysql_query("update category set name='".mysql_real_escape_string($newname)."', link='".mysql_real_escape_string($permalink)."' where id='".mysql_real_escape_string($cid)."'");
header('location: admin.php?iwb=category');
}
else
{
$hasil='<ol id="error"><li>'.$error.'</li></ol>';
}
}
$head_title='Ubah Kategori';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div><div id="content"><div id="main-content"><form method="post" action="admin.php?iwb=category&amp;action=edit&amp;cid='.$cid.'"><h4>Nama Kategori</h4><input class="iwb-text" name="newname" type="text" size="30" value="'.htmlentities($kat['name']).'"/><p align="center"><input class="iwb-button" name="change" type="submit" value="Ubah"/></p></form></div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['add_category']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
$name=$_POST['name'];
if (mb_strlen($name) > 50)
$err='Nama kategori maksimal 50 karakter';
if (empty($name))
$err='Silakan masukan nama kategori';
$lkct=permalink($name);
$chk=mysql_query("select * from category where link='".mysql_real_escape_string($lkct)."'");
if (mysql_num_rows($chk) != 0)
$err='Nama kategori sudah ada';
if (empty($err))
{
mysql_query("insert into category set name='".mysql_real_escape_string($name)."', link='".mysql_real_escape_string($lkct)."'");
$hasil='<ol id="success"><li>Kategori berhasil ditambahkan</li></ol>';
}
else
{
$hasil='<ol id="error"><li>'.$err.'</li></ol>';
}
}
}

$head_title='Kelola Kategori';
include 'head.php';
echo '<div id="message">';
if ($hasil)
echo $hasil;
echo '</div><div id="content">
<div id="main-content"><ol>';
$total=mysql_result(mysql_query("select count(*) as Num from category"), 0);
$req=mysql_query("select * from category order by name desc");
while ($cat=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<strong>'.htmlspecialchars($cat['name']).'</strong><br/>';
if (empty($cat['blog_id']))
{
$count='0';
}
else
{
$exp=explode(",",$cat['blog_id']);
$count=count($exp);
}
echo 'Posting '.$count.'<br/><span class="action_links">[<a class="edit" href="admin.php?iwb=category&amp;action=edit&amp;cid='.$cat['id'].'">Ubah</a>]';
if ($cat['id'] != 1)
echo ' [<a class="delete" href="admin.php?iwb=category&amp;action=delete&amp;cid='.$cat['id'].'">Hapus</a>]';
echo '</span>';
++$i;
echo '</li>';
}
if ($total == 0)
echo '<li>Belum ada kategori</li>';
echo '</ol><h3><a name="add" class="no-link">Tambah kategori</a></h3>
<form action="admin.php?iwb=category" method="post"><input class="iwb-text" name="name" type="text" value=""/>
    <input class="iwb-button" name="add_category" type="submit" value="Tambah"/>
</form>            </div>
        </div>';
include 'foot.php';
}
?>