<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

/*Membuat permalink*/
function permalink($var)
{
$var=preg_replace('#([\W_]+)#',' ',$var);
$var=str_replace(' ','-',$var);
$var=strtolower($var);
$cek=mysql_query("select * from blog where link='$var'");
$count=mysql_num_rows($cek);
$addnum = $count+1;
if ($count != '0')
{$var=''.$var.'-'.$addnum.'';}else{$var = $var;}
return $var;}
?>
