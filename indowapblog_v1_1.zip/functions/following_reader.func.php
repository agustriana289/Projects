<?php//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

function following_reader()
{
$flw=mysql_fetch_array(mysql_query("select * from following order by Rand() limit 1;"));
$feed=$flw['url'];
if (!empty($feed))
{
$feed=''.$feed.'/rss.xml';
$howmany='5';
$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

$xml = simplexml_load_file($feed);
if ($xml)
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;
if ($count>$howmany)
$howmany=$count;

if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$judul = $item->title;
$link = $item->link;$tggl = $item->pubDate;
$tggl=strtotime($tggl);
$teks = $item->description;
$cek=mysql_query("select * from following_post where following_id='".$flw['id']."' and link='".mysql_real_escape_string($link)."'") or die(mysql_error());
if (mysql_num_rows($cek) == 0)
{
mysql_query("insert into `following_post` set `following_id`='".$flw['id']."', `title`='".mysql_real_escape_string($judul)."', `description`='".mysql_real_escape_string($teks)."', `link`='".mysql_real_escape_string($link)."', `read`='1', `time`='".$tggl."'") or die(mysql_error());
}}}}}}}
?>
