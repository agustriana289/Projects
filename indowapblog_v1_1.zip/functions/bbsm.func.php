<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

function bbsm($var)
{
$var=htmlentities($var);
$search=array('/\[textarea\](.*?)\[\/textarea\]/is','/\[color\=(.*?)\](.*?)\[\/color\]/is','/\[b\](.*?)\[\/b\]/is','/\[i\](.*?)\[\/i\]/is','/\[u\](.*?)\[\/u\]/is','/\[url\](.*?)\[\/url\]/is','/\[url\=(.*?)\](.*?)\[\/url\]/is');
$replace=array('<textarea rows=\"4\" cols=\"20\">$1</textarea>','<font color="$1">$2</font>','<strong>$1</strong>','<em>$1</em>','<u>$1</u>','<a href="$1">$1</a>','<a href="$1">$2</a>');
$var=preg_replace($search,$replace,$var);
$sm=mysql_query("select * from `replace_text`");
while ($sml=mysql_fetch_array($sm))
{
$var=str_replace($sml['key'],$sml['value'],$var);
}
return $var;
}
?>
