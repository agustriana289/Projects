<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');


function time_ago($date,$granularity=2) {
$difference = time() - $date;
$periods = array('dekade' => 315360000, 'tahun' => 31536000, 'bulan' => 2628000, 'minggu' => 604800, 'hari' => 86400, 'jam' => 3600, 'menit' => 60, 'detik' => 1);
if ($difference < 5) { $retval = "baru saja";
return $retval;
} else {
foreach ($periods as $key => $value) {
if ($difference >= $value)
{
$time = floor($difference/$value);
$difference %= $value;
$retval .= ($retval ? ' ' :
'').$time.' ';
$retval .= (($time > 1) ?
$key.'' : $key);
$granularity--;
}
if ($granularity == '0')
{ break; }
}
return ''.$retval.' yang lalu';
}
}
?>
