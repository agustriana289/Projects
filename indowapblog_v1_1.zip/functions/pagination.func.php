<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

/*Membuat pagination*/
function pagination($page,$max_view,$total,$link,$q)
{
if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1)
{
echo '<li class="link-page">Halaman:';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</li>';
}
}
?>
