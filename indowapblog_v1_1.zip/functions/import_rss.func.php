<?php//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

function import_rss()
{
$flw=mysql_fetch_array(mysql_query("select * from `import_rss` where `url_rss` != '' order by Rand() limit 1;"));
$feed=$flw['url_rss'];
if (!empty($feed))
{
$feed=$feed;
$howmany='5';
$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

$xml = simplexml_load_file($feed);
if ($xml)
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;
if ($count>$howmany)
$howmany=$count;

if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$judul = $item->title;
$link = $item->link;$tggl = $item->pubDate;
$tggl=strtotime($tggl);
$tek = $item->description;
if ($flw['sumber'] == 1)
$teks=''.$tek.'<br />Sumber: <a href="'.$link.'">'.$link.'</a>';
else
$teks=$tek;

$cek=mysql_query("select * from import_rss where url_post='".mysql_real_escape_string($link)."'") or die(mysql_error());
if (mysql_num_rows($cek) == 0)
{
if ($flw['update_time'] == 1)
$tgl=time();
else
$tgl=$tggl;
$permalink=permalink($judul);
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));
mysql_query("insert into `blog` set `user_id`='".$adm['id']."', `title`='".mysql_real_escape_string($judul)."', `description`='".mysql_real_escape_string($teks)."', `link`='".mysql_real_escape_string($permalink)."', `time`='".$tgl."', `category`='".$flw['category']."', `allow_comment`='1', `draft`='0'") or die(mysql_error());
$blog_id=mysql_insert_id();
$kf=mysql_fetch_array(mysql_query("select * from category where id='".$flw['category']."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='".$flw['category']."'");

mysql_query("insert into `import_rss` set `url_post`='".mysql_real_escape_string($link)."', `time`='".time()."'") or die(mysql_error());
}}}}}}}
?>
