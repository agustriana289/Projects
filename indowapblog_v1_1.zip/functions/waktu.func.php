<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

function waktu($var)
{
$sit=mysql_fetch_array(mysql_query("select * from site"));
$gmt=$sit['gmt'];
$jm='3600';
$var=$var+($gmt*$jm);
return gmdate('d M Y - H:i',$var);
}

?>
