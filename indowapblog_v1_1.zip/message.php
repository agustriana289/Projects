<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'write':
if (!$user_id)
relogin();
$to=$_POST['to'];
if (empty($to))
$to=$_GET['to'];
$msg=$_POST['msg'];
$req=mysql_query("select * from `user` where `id`='".mysql_real_escape_string($to)."' and `username`!='".$user_username."' and `ban`='0'");

if (isset($_POST['send']))
{
if (mysql_num_rows($req) == 0)
$hsl='<ol id="error"><li>Maaf penerima pesan tidak ada atau sudah dihapus dari sistem kami.</li></ol>';
if (mb_strlen($msg) > 500)
$hsl='<ol id="error"><li>Pesan maksimal 500 karakter.</li></ol>';
elseif (empty($msg))
$hsl='<ol id="error"><li>Silakan masukan pesan anda.</li></ol>';
if (empty($hsl))
{
mysql_query("insert into `pm` set `receiver_id`='".mysql_real_escape_string($to)."', `sender_id`='".$user_id."', `name`='".mysql_real_escape_string($user_name)."', `email`='".mysql_real_escape_string($user_email)."', `text`='".mysql_real_escape_string($msg)."', `read`='1', `time`='".time()."'") or die(mysql_error());
header('location: message.php?send_successfully');
}
}
$head_title='Kirim Pesan';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="message.php">Kotak Masuk</a> | Kirim Pesan</div>';

echo '<form action="message.php?iwb=write" method="post"><h4>Untuk</h4>';
if (mysql_num_rows($req) == 0)
{
echo '<div class="two-col-btn">
<select class="iwb-
select" name="to"><option value="">--pilih--</option>';
$res=mysql_query("select * from `user` where `id`!='".$user_id."' and `ban`='0' order by `name` desc");
while ($ke=mysql_fetch_array($res))
{
echo '<option value="'.$ke['id'].'">'.htmlspecialchars($ke['name']).'</option>';
}
echo '</select></div>';
}
else
{
$untuk=mysql_fetch_array($req);
echo '<a href="user.php?id='.$untuk['id'].'">'.htmlspecialchars($untuk['name']).'</a><input type="hidden" name="to" value="'.$untuk['id'].'">';
}
echo '<h4>Pesan</h4>
<textarea class="iwb-textarea" name="msg" rows="5" cols="30"></textarea><br/>
<input class="iwb-button" name="send" type="submit" value="Kirim"/></form>';
echo '</div></div>';
include 'foot.php';


break;
case 'delete':
$pms_id=$_GET['pms_id'];
if (!$user_id)
relogin();
$cek=mysql_query("select * from `pm` where `id`='".mysql_real_escape_string($pms_id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$pm=mysql_fetch_array($cek);
if ($pm['receiver_id'] != $user_id)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
mysql_query("delete from `pm` where `id`='".mysql_real_escape_string($pms_id)."'");
header('location: message.php?deleted_successfully');
}
$head_title='Hapus Pesan';
include 'head.php';

echo '<div id="message"><ol id="notice"><li>Anda yakin ingin menghapus pesan ini?<br/>[<a href="message.php?iwb=delete&amp;pms_id='.$pms_id.'&amp;yes">YA</a>] [<a href="message.php">TIDAK</a>]</div>';
include 'foot.php';

break;
case 'read':
$pms_id=$_GET['pms_id'];
if (!$user_id)
relogin();
$cek=mysql_query("select * from `pm` where `id`='".mysql_real_escape_string($pms_id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$pm=mysql_fetch_array($cek);
if ($pm['receiver_id'] != $user_id)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}

if (isset($_POST['button']))
{
if (!$user_id)
relogin();
if ($pm['receiver_id'] != $user_id)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$reply=$_POST['reply'];
if (empty($reply))
$hsl='<ol id="error"><li>Silakan masukan pesan Anda</li></ol>';
if (empty($hsl) && ($pm['sender_id'] != 0))
{
mysql_query("insert into `pm` set `receiver_id`='".$pm['sender_id']."', `sender_id`='".$user_id."', `name`='".mysql_real_escape_string($user_name)."', `email`='".mysql_real_escape_string($user_email)."', `text`='".mysql_real_escape_string($reply)."', `read`='1', `time`='".time()."'") or die(mysql_error());
header('location: message.php?send_successfully');
}
if (empty($hsl) && ($pm['sender_id'] == 0))
{
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $pm['email'];
$subject="RE: FeedBack From ".$site['name']."";
$pesan="Kami telah membaca Feedback Anda yang berisi\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= $pm['text'];
$pesan .= "\r\n\r\n";
$pesan .= "\r\n\r\nBerikut adalah balasan dari Kami\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= $reply;$pesan .= "\r\n\r\n";

$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
header('location: message.php?send_successfully');
}
}
$head_title='Baca Pesan';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="message.php">Kotak Masuk</a> | <a href="message.php?iwb=write">Kirim Pesan</a></div>';
echo '<h4>Dari: ';
if ($pm['sender_id'] != 0)
echo '<a href="user.php?id='.$pm['sender_id'].'">'.htmlspecialchars($pm['name']).'</a>';
else
echo htmlspecialchars($pm['name']);
echo '</h4><p class="row0">'.htmlentities($pm['text']).'<br/><span>Dikirim: '.waktu($pm['time']).'<br/>';
if ($pm['sender_id'] == 0)
echo 'Email: '.htmlentities($pm['email']).'<br/>';
echo '<a href="message.php?iwb=delete&amp;pms_id='.$pm['id'].'">Hapus pesan</a></span></p>';

if ($pm['sender_id'] != $user_id)
{
echo '<h4>Balas Pesan</h4><ul><li><form method="post" action="message.php?iwb=read&amp;pms_id='.$pm['id'].'"><textarea class="iwb-textarea" rows="5" cols="30" name="reply"/></textarea><br/><input class="iwb-button" type="submit" name="button" value="Kirim"/>
</form></li></ul>';
}

mysql_query("update `pm` set `read`='0' where `id`='".$pm['id']."'");
echo '</div></div>';
include 'foot.php';
break;

default:
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;if (!$user_id)
relogin();
if (isset($_GET['send_successfully']))
$notif='Pesan Anda telah terkirim';
if (isset($_GET['deleted_successfully']))
$notif='Pesan Anda telah dihapus';
$head_title='Pesan';
include 'head.php';
echo '<div id="message">';
if (!empty($notif))
echo '<ol id="success"><li>'.$notif.'</li></ol>';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Kotak Masuk | <a href="message.php?iwb=write">Kirim Pesan</a></div>';
echo '<ol>';
$pm=mysql_query("select * from `pm` where `receiver_id`='".$user_id."' order by `time` desc limit $limit,$max_view");
while ($pms=mysql_fetch_array($pm))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
echo '<a href="message.php?iwb=read&amp;pms_id='.$pms['id'].'">'.htmlspecialchars($pms['name']).'</a> [<a href="message.php?iwb=delete&amp;pms_id='.$pms['id'].'"><font color="red">X</font></a>]<br/><span>Dikirim: '.waktu($pms['time']).'<br/>Status: ';
if ($pms['read'] == 1)
echo '<blink>Belum dibaca</blink>';
else
echo '<strike>Sudah dibaca</strike>';
echo '</span>';
++$i;
echo '</li>';
}
$total=mysql_result(mysql_query("select count(*) as Num from `pm` where `receiver_id`='".$user_id."'"), 0);
if ($total == 0)
echo '<li>Anda belum memiliki pesan</li>';
echo '</ol></div>';
$link='message.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>