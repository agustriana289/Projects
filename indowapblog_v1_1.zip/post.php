<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'edit':
if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$blog_id=$_GET['blog_id'];
if (empty($blog_id))
$blog_id=$_POST['bid'];
else
$blog_id=$_GET['blog_id'];
$blog_uid=$_POST['blog_uid'];
$uptime=$_POST['uptime'];
$title=$_POST['title'];
$body=$_POST['body'];
$kateg=$_POST['kategori'];
$allow_comment=$_POST['allow_comment'];
$pp=$_POST['pp'];

$file=$_POST['file'];
if (!empty($blog_id))
{
$bl=mysql_fetch_array(mysql_query("select * from blog where id='".mysql_real_escape_string($blog_id)."'"));
if (!$is_admin)
{
if ($user_id != $bl['user_id'])
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
}
}
if (isset($_POST['save']))
$draft='1';
if (isset($_POST['publish']))
$draft='0';
if ((isset($_POST['publish'])) || (isset($_POST['save'])))
{
$blog_uid=$_POST['blog_uid'];
if (!$is_admin)
{
if ($user_id != $blog_uid)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
}
$blog_uid=$_POST['blog_uid'];
$uptime=$_POST['uptime'];
$update_time=$_POST['update_time'];
if ($update_time == 0)
$time=$uptime;
else
$time=time();
$blog_id=$_POST['bid'];
$title=$_POST['title'];
$body=nl2br($_POST['body']);
$kateg=$_POST['kategori'];
$allow_comment=$_POST['allow_comment'];

if (empty($kateg))
$kate='1';
else
$kate=implode(",",$kateg);
if (empty($title) || empty($body))
$error='Silakan masukan judul atau teks';
if (empty($error))
{
if (empty($bl['count']))
$hit='0';
else
$hit=$bl['count'];
if (($draft == 0) && ($hit < 1))
{
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));
if ($pp== 1)
{
$psn='Postingan ini hanya untuk Member '.htmlspecialchars($site['name']).'. Untuk melihat postingan ini silakan login atau register terlebih dahulu.';
}
elseif ($pp == 2)
{
$psn='Postingan ini hanya untuk Penulis (Author) '.htmlspecialchars($site['name']).'.';
}
else
{
if (mb_strlen($body) > 200)
$psn=''.strip_tags(substr($body,0,200)).' [...]';
else
$psn=strip_tags($body);
}
$oleh=mysql_fetch_array(mysql_query("select * from user where id='".$blog_uid."'"));
$ceksub=mysql_query("select * from subscribe where sub='new_posts' and status='1'");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$email = $subscribe['email'];
$subject="Posting Baru: ".$title."";
$pesan="Posting terbaru: ".$title."\r\n\r\n---\r\n\r\nOleh: ".$oleh['name']."\r\n\r\nPada: ".waktu($time)."\r\n\r\n...\r\n\r\n".$psn."\r\n\r\n...\r\n\r\nUntuk mengomentari postingan ini silakan klik ".$site['url']."/".$bl['link'].".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$site['url']."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}else{}}else{}


mysql_query("update `blog` set `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($body)."', `time`='".$time."', `category`='".mysql_real_escape_string($kate)."', `allow_comment`='".$allow_comment."', `draft`='".$draft."', `private`='".$pp."' where id='".$blog_id."'") or die(mysql_error());
$K=mysql_query("select * from `category` order by `id` desc");
while ($KAT=mysql_fetch_array($K))
{
$item=$blog_id;
$array=$KAT['blog_id'];
$upd=hapus_array($item,$array);
mysql_query("update `category` set `blog_id`='".mysql_real_escape_string($upd)."' where `id`='".$KAT['id']."'");
}
if (!empty($kateg))
{
$_kt=implode(",",$kateg);

$count=count($_kt);
for ($i=0;$i<$count;$i++)
{
$kf=mysql_fetch_array(mysql_query("select * from category where id='".$_kt[$i]."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='".$_kt[$i]."'");
}
}
else
{
$kf=mysql_fetch_array(mysql_query("select * from category where id='1'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='1'");
}
if ($draft == 0)
header('location: post.php?iwb=manage&notif=post_successfully_publish');
else
header('location: post.php?iwb=manage&notif=post_successfully_saved');
}
}
if (isset($_POST['go']))
{
$iwbfile=substr($file,-3);

if (($iwbfile=='gif') || ($iwbfile=='jpg') || ($iwbfile=='peg') || ($iwbfile=='png'))
$files='<a href="'.$site['url'].'/files/'.$file.'"><img src="'.$site['url'].'/files/'.$file.'" alt=""/></a><br/>';
elseif (($iwbfile=='jar') || ($iwbfile=='jad') || ($iwbfile=='zip') || ($iwbfile=='sis') || ($iwbfile=='mp3') || ($iwbfile=='mp4') || ($iwbfile=='3gp') || ($iwbfile=='txt') || ($iwbfile=='nth') || ($iwbfile=='isx') || ($iwbfile=='amr') || ($iwbfile=='tar'))
$files='<a href="'.$site['url'].'/files/'.$file.'">'.$file.'</a><br/>';
elseif (empty($file))
$files='';
else
$files=''.$site['url'].'/files/'.$file.'';
}
$head_title='Edit Posting';
include 'head.php';
echo '<style
type="text/css">
.frmt-button
{
width: 12px;
height: 12px;
margin: 1px;
padding:
4px;
background:
#DDDDDD;
}
</style>';
echo '<div id="message">';
if (!empty($error))
echo '<ol id="error"><li>'.$error.'</li></ol>';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="post.php">Tulis Blog</a> | <a href="post.php?iwb=manage">Kelola Blog</a></div>';
echo '<form
method="post" action="post.php?iwb=edit&amp;blog_id='.$blog_id.'">
<h4>Judul</h4>
    <input class="iwb-text"
name="title" type="text"
value="'.htmlentities(''.$title.' '.$bl['title'].'').'" size="30"/>
    <h4>Teks</h4>Kode HTML diperbolehkan.
        <div id="format-buttons"/>
    <textarea class="iwb-textarea" id="body" name="body" cols="30" rows="15"/>'.htmlentities(''.$files.' '.$body.' '.$bl['description'].'').'</textarea><br/>
        <h4>Tambahkan File</h4>
    <div class="two-col-btn">
<select class="iwb-
select" id="file" name="file"><option value=""></option>';
foreach (glob("files/*") as $file)
{
$files=basename($file);
echo '<option value="'.$files.'">'.$files.'</option>';
}
echo '</select>
<input class="iwb-button" type="submit" name="go" id="go-btn" value="Go" onclick="add(document.getElementById("file").value, "files/", true);"/><br/>
    </div>
<h4>Kategori</h4>';
$kat=mysql_query("select * from category order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="checkbox" name="kategori[]" value="'.$kategoris['id'].'">'.$kategoris['name'].'<br/>';
}
echo '<h4>Perijinan</h4><input type="radio"
name="pp"
value="0" ';
if ($bl['private'] == 0)
echo 'checked';
echo '/>Untuk semua orang<br/><input type="radio"
name="pp"
value="1" ';
if ($bl['private'] == 1)
echo 'checked';
echo '/>Hanya untuk member<br/><input type="radio"
name="pp"
value="2" ';
if ($bl['private'] == 2)
echo 'checked';
echo '/>Hanya untuk penulis<br/><h4>Ijinkan komentar</h4>    <input type="radio"
name="allow_comment"
value="1" checked/>Ya<br/><input type="radio"
name="allow_comment"
value="0"/>Tidak<br/>
    <h4>Perbaharui Tanggal</h4>    <input type="radio"
name="update_time"
value="1"/>Ya<br/><input type="radio"
name="update_time"
value="0" checked/>Tidak<br/>
    <div class="two-col-btn"><input type="hidden" name="bid" value="'.$blog_id.'"/><input type="hidden" name="blog_uid" value="'.$bl['user_id'].'"/><input type="hidden" name="uptime" value="'.$bl['time'].'"/><input class="iwb-button" type="submit" name="publish" value="Terbitkan"/>
<input class="iwb-button" type="submit" name="save" value="Konsep"/>
    </div>
</form>            </div>
        </div>';
include 'foot.php';

break;


case 'search':
if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$search=isset($_POST['search']) ? trim($_POST['search']) : '';
if (empty($search))
$search=isset($_GET['search']) ? trim($_GET['search']) : '';
$head_title='Pencarian untuk: '.$search.'';
include 'head.php';
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
if ($is_admin)
{
$total=mysql_result(mysql_query("select count(*) as Num from blog where title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%'"), 0);
$req=mysql_query("select * from blog where title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%' order by time desc limit $limit,$max_view");
}
if ($is_author && !$is_admin)
{
$total=mysql_result(mysql_query("select count(*) as Num from blog where user_id='".$user_id."' and title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%'"), 0);
$req=mysql_query("select * from blog where user_id='".$user_id."' and title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%' order by time desc limit $limit,$max_view");
}
echo '<div id="message">';
if ($total != 0)
echo '<ol id="success"><li>Ditemukan <i>'.$total.'</i> untuk pencarian <i>'.htmlentities($search).'</i></li></ol>';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="post.php">Tulis Blog</a> | <a href="post.php?iwb=manage">Kelola Blog</a></div>';
echo '<form method="post" action="post.php?iwb=search"><div class="two-col-btn">
<input class="iwb-text" name="search" type="text" value=""/>
<input class="iwb-button" name="save" type="submit" style="width: 20%" value="Cari"/>
</div>
</form>
<ol>';
while ($blog=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
if ($blog['draft'] == 0)
echo '<a href="'.$site['url'].'/'.$blog['link'].'.xhtml" accesskey="1">'.htmlspecialchars($blog['title']).'</a> Diterbitkan';
else
echo ''.htmlspecialchars($blog['title']).' Konsep';
echo '<br/>Tanggal: '.waktu($blog['time']).'<br/>';
$kom=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."'"), 0);
if ($blog['draft'] == 0)
echo 'Komentar: <a href="post.php?iwb=comment&amp;blog_id='.$blog['id'].'">'.$kom.'</a><br/>';
echo '<span class="action_links">[<a href="post.php?iwb=edit&amp;blog_id='.$blog['id'].'">Ubah</a>] [<a class="delete" href="post.php?iwb=delete&amp;blog_id='.$blog['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol></div>';
if ($total == 0)
echo '<div id="message"><ol id="notice"><li>Pencarian dengan kata kunci '.htmlentities($search).' tidak ditemukan</li></ol></div>';
$link='post.php?iwb=search&amp;search='.htmlentities($search).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';

break;
case 'delete':
$blog_id=$_GET['blog_id'];
if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$req=mysql_fetch_array(mysql_query("select * from blog where id ='".mysql_real_escape_string($blog_id)."'"));
if (isset($_GET['yes']))
{
if ($is_admin)
{
mysql_query("delete from blog where id='".mysql_real_escape_string($blog_id)."'");
mysql_query("delete from comment where blog_id='".mysql_real_escape_string($blog_id)."'");
$cate=mysql_query("select * from category order by id");
while ($cat=mysql_fetch_array($cate))
{
$item=$blog_id;
$array=$cat['blog_id'];
$rep=hapus_array($item,$array);
mysql_query("update category set blog_id='".mysql_real_escape_string($rep)."' where id='".$cat['id']."'");
}

header('location: post.php?iwb=manage&notif=post_successfully_deleted');
}
if ($is_author && !$is_admin)
{
if ($user_id != $req['user_id'])
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from blog where id='".mysql_real_escape_string($blog_id)."' and user_id='".$user_id."'");
mysql_query("delete from comment where blog_id='".mysql_real_escape_string($blog_id)."'");
$cate=mysql_query("select * from category order by id");
while ($cat=mysql_fetch_array($cate))
{
$item=$blog_id;
$array=$cat['blog_id'];
$rep=hapus_array($item,$array);
mysql_query("update category set blog_id='".mysql_real_escape_string($rep)."' where id='".$cat['id']."'");
}
header('location: post.php?iwb=manage&notif=post_successfully_deleted');
}
}
}
$head_title='Hapus blog';
include 'head.php';
if ($is_admin)
echo '<div id="message"><ol id="notice">
<li><strong>'.htmlspecialchars($req['title']).'</strong><br/>Anda yakin ingin menghapus postingan ini?<br/><a href="post.php?iwb=delete&amp;blog_id='.$blog_id.'&amp;yes">Ya</a> | <a href="post.php?iwb=manage">Tidak</a></li></ol></div>';

if ($is_author && !$is_admin)
{
if ($user_id != $req['user_id'])
forbidden();
else
echo '<div id="message"><ol id="notice">
<li><strong>'.htmlspecialchars($req['title']).'</strong><br/>Anda yakin ingin menghapus postingan ini?<br/><a href="post.php?iwb=delete&amp;blog_id='.$blog_id.'&amp;yes">Ya</a> | <a href="post.php?iwb=manage">Tidak</a></li></ol></div>';

}
include 'foot.php';
break;
case 'manage':
if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$head_title='Kelola Posting';
include 'head.php';
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

//*Pencarian Posting*//

$notif=$_GET['notif'];
if ($notif == 'post_successfully_publish')
$ntf='Posting berhasil diterbitkan';
if ($notif == 'post_successfully_saved')
$ntf='Posting berhasil disimpan sebagai konsep';
if ($notif == 'post_successfully_deleted')
$ntf='Posting berhasil dihapus';
if (!empty($ntf))
echo '<div id="message"><ol id="success"><li>'.$ntf.'</li></ol></div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="post.php">Tulis Blog</a> | Kelola Blog</div>';
echo '<form method="post" action="post.php?iwb=search"><div class="two-col-btn">
<input class="iwb-text" name="search" type="text" value=""/>
<input class="iwb-button" name="save" type="submit" style="width: 20%" value="Cari"/>
</div>
</form>
<ol>';
if ($is_admin)
{
$total=mysql_result(mysql_query("select count(*) as Num from blog"), 0);
$req=mysql_query("select * from blog order by time desc limit $limit,$max_view");
}
if ($is_author && !$is_admin)
{
$total=mysql_result(mysql_query("select count(*) as Num from blog where user_id='".$user_id."'"), 0);
$req=mysql_query("select * from blog where user_id='".$user_id."' order by time desc limit $limit,$max_view");
}
while ($blog=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
if ($blog['draft'] == 0)
echo '<a href="'.$site['url'].'/'.$blog['link'].'.xhtml" accesskey="1">'.htmlspecialchars($blog['title']).'</a> (Diterbitkan)';
else
echo ''.htmlspecialchars($blog['title']).' (Konsep)';
if ($is_admin)
{
$user=mysql_fetch_array(mysql_query("select * from user where id='".$blog['user_id']."'"));
echo '<br/>Penulis: <a href="user.php?id='.$blog['user_id'].'">'.htmlspecialchars($user['name']).'</a>';
}
echo '<br/>Tanggal: '.waktu($blog['time']).'<br/>Kategori: ';
$exp=explode(",",$blog['category']);
$expcount=count($exp);
for ($i=0;$i<$expcount;$i++)
{
$kat=mysql_fetch_array(mysql_query("select * from category where id='".$exp[$i]."'"));
echo htmlspecialchars($kat['name']);
echo ', ';
}
echo '<br/>';
$kom=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."'"), 0);
if ($blog['draft'] == 0)
echo 'Komentar: <a href="manage_comment.php?bid='.$blog['id'].'">'.$kom.'</a><br/>';
echo '<span class="action_links">[<a href="post.php?iwb=edit&amp;blog_id='.$blog['id'].'">Ubah</a>] [<a class="delete" href="post.php?iwb=delete&amp;blog_id='.$blog['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol></div>';
if ($total == 0)
echo '<div id="message"><ol id="notice"><li>Anda belum mempunyai satu pun postingan</li></ol></div>';
$link='post.php?iwb=manage&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$title=$_POST['title'];
$body=$_POST['body'];
$kateg=$_POST['kategori'];
$allow_comment=$_POST['allow_comment'];
$file=$_POST['file'];
if (isset($_POST['save']))
$draft='1';
if (isset($_POST['publish']))
$draft='0';
if ((isset($_POST['publish'])) || (isset($_POST['save'])))
{
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$title=$_POST['title'];
$body=nl2br($_POST['body']);
$kateg=$_POST['kategori'];
$allow_comment=$_POST['allow_comment'];
$pp=$_POST['pp'];
$leng=strlen($title);
if ($leng > 60)
$link=substr($title,0,60);
else
$link=$title;
$permalink=permalink($link);
if (empty($kateg))
$kate='1';
else
$kate=implode(",",$kateg);
if (empty($title) || empty($body))
$error='Silakan masukan judul atau teks';
if (empty($error))
{
if ($draft == 0)
{
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));
if ($pp== 1)
{
$psn='Postingan ini hanya untuk Member '.htmlspecialchars($site['name']).'. Untuk melihat postingan ini silakan login atau register terlebih dahulu.';
}
elseif ($pp == 2)
{
$psn='Postingan ini hanya untuk Penulis (Author) '.htmlspecialchars($site['name']).'.';
}
else
{
if (mb_strlen($body) > 200)
$psn=''.strip_tags(substr($body,0,200)).' [...]';
else
$psn=strip_tags($body);
}

$ceksub=mysql_query("select * from subscribe where sub='new_posts' and status='1'");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$email = $subscribe['email'];
$subject="Posting Baru: ".$title."";
$pesan="Posting terbaru: ".$title."\r\n\r\n---\r\n\r\nOleh: ".$user_name."\r\n\r\nPada: ".waktu(time())."\r\n\r\n...\r\n\r\n".$psn."\r\n\r\n...\r\n\r\nUntuk mengomentari postingan ini silakan klik ".$site['url']."/".$permalink.".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$site['url']."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}else{}}else{}

mysql_query("insert into `blog` set `user_id`='".$user_id."', `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($body)."', `link`='".mysql_real_escape_string($permalink)."', `time`='".time()."', `category`='".mysql_real_escape_string($kate)."', `allow_comment`='".$allow_comment."', `draft`='".$draft."', `private`='".$pp."'") or die(mysql_error());
$blog_id=mysql_insert_id();
if (!empty($kateg))
{
$_kt=implode(",",$kateg);

$count=count($_kt);
for ($i=0;$i<$count;$i++)
{
$kf=mysql_fetch_array(mysql_query("select * from category where id='".$_kt[$i]."'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='".$kf['id']."'");
}
}
else
{
$kf=mysql_fetch_array(mysql_query("select * from category where id='1'"));
if (empty($kf['blog_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['blog_id'].'';
mysql_query("update category set blog_id='".$o."' where id='".$kf['id']."'");
}
if ($draft == 0)
header('location: post.php?iwb=manage&notif=post_successfully_publish');
else
header('location: post.php?iwb=manage&notif=post_successfully_saved');
}
}
if (isset($_POST['go']))
{
$iwbfile=substr($file,-3);

if (($iwbfile=='gif') || ($iwbfile=='jpg') || ($iwbfile=='peg') || ($iwbfile=='png'))
$files='<a href="'.$site['url'].'/files/'.$file.'"><img src="'.$site['url'].'/files/'.$file.'" alt=""/></a><br/>';
elseif (($iwbfile=='jar') || ($iwbfile=='jad') || ($iwbfile=='zip') || ($iwbfile=='sis') || ($iwbfile=='mp3') || ($iwbfile=='mp4') || ($iwbfile=='3gp') || ($iwbfile=='txt') || ($iwbfile=='nth') || ($iwbfile=='isx') || ($iwbfile=='amr') || ($iwbfile=='tar'))
$files='<a href="'.$site['url'].'/files/'.$file.'">'.$file.'</a><br/>';
elseif (empty($file))
$files='';
else
$files=''.$site['url'].'/files/'.$file.'';
}
$head_title='Tulis Blog';
include 'head.php';
echo '<style
type="text/css">
.frmt-button
{
width: 12px;
height: 12px;
margin: 1px;
padding:
4px;
background:
#DDDDDD;
}
</style>';
echo '<div id="message">';
if (!empty($error))
echo '<ol id="error"><li>'.$error.'</li></ol>';
echo '</div>
<div id="content">
<div id="main-content">';

echo '<div id="show_bar">Tulis Blog | <a href="post.php?iwb=manage">Kelola Blog</a></div>';
echo '<form
method="post" action="post.php">
<h4>Judul</h4>
    <input class="iwb-text"
name="title" type="text"
value="'.htmlentities($title).'" size="30"/>
    <h4>Teks</h4>Kode HTML diperbolehkan.
        <div id="format-buttons"/>
    <textarea class="iwb-textarea" id="body" name="body" cols="30" rows="15"/>'.htmlentities(''.$files.' '.$body.'').'</textarea><br/>
        <h4>Tambahkan File</h4>
    <div class="two-col-btn">
<select class="iwb-
select" id="file" name="file"><option value=""></option>';
foreach (glob("files/*") as $file)
{
$files=basename($file);
if (substr($files,-4) != '.php')
{
echo '<option value="'.$files.'">'.$files.'</option>';
}
}
echo '</select>
<input class="iwb-button" type="submit" name="go" id="go-btn" value="Go" onclick="add(document.getElementById("file").value, "files/", true);"/><br/>
    </div>
<h4>Kategori</h4>';
$kat=mysql_query("select * from category order by name");
while ($kategoris=mysql_fetch_array($kat))
{
echo '<input type="checkbox" name="kategori[]" value="'.$kategoris['id'].'">'.$kategoris['name'].'<br/>';
}
echo '<h4>Perijinan</h4><input type="radio"
name="pp"
value="0" checked/>Untuk semua orang<br/><input type="radio"
name="pp"
value="1"/>Hanya untuk member<br/><input type="radio"
name="pp"
value="2"/>Hanya untuk penulis<br/><h4>Ijinkan komentar</h4>    <input type="radio"
name="allow_comment"
value="1" checked/>Ya<br/><input type="radio"
name="allow_comment"
value="0"/>Tidak<br/>
    <div class="two-col-btn">
<input class="iwb-button" type="submit" name="publish" value="Terbitkan"/>
<input class="iwb-button" type="submit" name="save" value="Konsep"/>
    </div>
</form>            </div>
        </div>';
include 'foot.php';
}
?>
