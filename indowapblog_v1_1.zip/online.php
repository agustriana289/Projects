<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'guest':
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$guest_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM guest WHERE lastdate > $ol"), 0);

$head_title='Tamu Online';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="online.php">Member</a> ('.$user_ol.') | Tamu ('.$guest_ol.')</div>';

echo '<ol>';
$list=mysql_query("SELECT * FROM guest WHERE lastdate > $ol ORDER BY 'user_agent' ASC LIMIT $limit,$max_view");
while ($res=mysql_fetch_array($list))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo ''.htmlspecialchars($res['user_agent']).'</a> <br/>Online: '.time_ago($res['lastdate']).'<br/>Lokasi: <a href="'.$res['ref'].'">'.$res['place'].'</a>';
if ($is_admin)
{
echo '<br/>IP: '.$res['ip_browser'].' (';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ')<br/>IP Proxy: '.$res['ip_proxy'].' (';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ')';
}
++$i;
echo '</li>';
}
if ($guest_ol == 0)
echo '<p>Tidak ada tamu yang online</p>';
echo '</ol></div>';
$total=$guest_ol;
$link='online.php?iwb=guest&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';

break;
default:
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$guest_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM guest WHERE lastdate > $ol"), 0);

$head_title='Member Online';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Member ('.$user_ol.') | <a href="online.php?iwb=guest">Tamu</a> ('.$guest_ol.')</div>';

echo '<ol>';$list=mysql_query("SELECT * FROM user WHERE lastdate>'".$ol."' ORDER BY 'name' ASC LIMIT $limit,$max_view");
while ($res=mysql_fetch_array($list))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<img src="img.php?img='.$res['id'].'.jpg&amp;w=40&amp;h=40" alt="'.htmlspecialchars($res['name']).'"/> <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a><br/>';
if ($res['author'] == 0)
echo '(<font color="black"><b>Member</b></font>)';

if (($res['author'] == 1) && ($res['admin'] == 0))
echo '(<font color="green"><b>Penulis</b></font>)';
if ($res['admin'] == 1)
echo '(<font color="#731174"><b>Administrator</b></font>)';

echo '<br/>Online: '.time_ago($res['lastdate']).'<br/>Lokasi: <a href="'.$res['ref'].'">'.$res['place'].'</a>';
if (($is_admin) && ($res['id'] != $user_id))
{
echo '<br/>IP: '.$res['ip_browser'].' (';

$cekip=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_browser'])."'");
if (mysql_num_rows($cekip) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_browser'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_browser'].'">Unblock</a>';

echo ')<br/>IP Proxy: '.$res['ip_proxy'].' (';

$cekip1=mysql_query("select * from blocked where ip='".mysql_real_escape_string($res['ip_proxy'])."'");
if (mysql_num_rows($cekip1) == 0)
echo '<a href="admin.php?iwb=block_ip&amp;ip='.$res['ip_proxy'].'">Block</a>';
else
echo '<a href="admin.php?iwb=block_ip&amp;action=unblock&amp;ip='.$res['ip_proxy'].'">Unblock</a>';

echo ')';
}
++$i;
echo '</li>';
}
if ($user_ol == 0)
echo '<p>Tidak ada member yang online</p>';
echo '</ol></div>';
$total=$user_ol;
$link='online.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>