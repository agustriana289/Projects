<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';

$detect = new mobile_detect();
if ($detect->isMobile())
$mode='';
else
$mode='.web';

$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';

if (isset($_GET['iwb']) && file_exists('main-inc/'.$iwb.$mode.'.php'))
{
include 'main-inc/'.$iwb.$mode.'.php';
}
else
{
include 'main-inc/index'.$mode.'.php';
}
?>
