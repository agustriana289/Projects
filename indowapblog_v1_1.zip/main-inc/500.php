<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$head_title='Kesalahan Internal Server';
include 'main-inc/header.php';
echo '<div class="post"><h2 class="title">Kesalahan Internal Server</h2>';
echo '</p>Terjadi kesalahan pada internal server!</p></div>';
include 'main-inc/footer.php';

?>