<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

echo '<div class="sidebar">';

echo '<div class="widget"><form id="search_form" method="get" action="'.$site['url'].'/"><input type="text" name="search" value="" /><input type="submit" value="Cari" /></form></div>';

echo '<div class="widget"><h2>Posting Terbaru</h2><ul>';
$recents=mysql_query("select * from blog where draft='0' order by time desc limit 10;");
while ($recent=mysql_fetch_array($recents))
{
echo '<li><a href="'.$site['url'].'/'.$recent['link'].'.xhtml">'.htmlspecialchars($recent['title']).'</a></li>';
}
echo '</ul></div>';

echo '<div class="widget"><h2>Kategori</h2><ul>';
$cat=mysql_query("select * from category order by name");
while ($cats=mysql_fetch_array($cat))
{
if (empty($cats['blog_id']))
{
$cat_count='0';
}
else
{
$bid=explode(",",$cats['blog_id']);
$cat_count=count($bid);
}
echo '<li><a href="'.$site['url'].'/category/'.permalink($cats['name']).'/1.xhtml">'.htmlspecialchars($cats['name']).'</a> ('.$cat_count.')</li>';
}
echo '</ul></div></div>';
echo '<div class="sidebar">';

echo '<div class="widget"><h2>Navigasi</h2><ul>';

if ($homepage != 'off')
echo '<li><a href="'.$site['url'].'">Beranda</a></li>';
$nav=mysql_query("select * from navigation order by id asc");
while ($navs=mysql_fetch_array($nav))
{
$sn='_SITE_NAME_';
$su='_SITE_URL_';
echo '<li>'.html_entity_decode(htmlentities(str_replace($sn,$site['name'],str_replace($su,$site['url'],$navs['code'])))).'</li>';
}
if ($user_id)
{
echo '<li><a href="'.$site['url'].'/dashboard.php">Dashboard</a></li>';
echo '<li><a href="'.$site['url'].'/login.php?iwb=logout">Keluar</a></li>';
}
else
{
echo '<li><a href="'.$site['url'].'/login.php">Masuk</a></li>';
}
if ((!$user_id) && ($site['allow_reg'] == 1))
echo '<li><a href="'.$site['url'].'/register.php">Pendaftaran</a></li>';
echo '</ul></div>';
if (($site['display_following'] == 1) && ($disfoll != 'off'))
{
echo '<div class="widget"><h2>Following</h2><ul>';
$rq=mysql_query("select * from following order by id desc limit 50;");
while($rs=mysql_fetch_array($rq))
{
echo '<li><a href="'.$rs['url'].'">'.htmlspecialchars($rs['title']).'</a></li>';
}
echo '</ul></div>';
}
echo '</div></div>';

echo '<div style="clear:both"></div></div></div>';
echo '<div id="footer">';

$t_day=date('d-m-Y', time());
$qr=mysql_query("select * from stats where time='$t_day'");
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set total='1', time='$t_day'");
}
else
{
mysql_query("update stats set total='$new_count' where time='$t_day'");
}

if ($site['display_count'] == 1)
{
$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$guest_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM guest WHERE lastdate > $ol"), 0);
echo 'Online : <span><a href="'.$site['url'].'/online.php">'.$user_ol.'/'.$guest_ol.'</a></span> ';
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats"));

echo 'Total Konter: <span>'.$t_all['total'].'</span><br/>';
}
echo '&copy; '.date('Y', time()).' <a href="'.$site['url'].'">'.$site['name'].'</a>.<br /><small>Powered by <a href="http://indowapblog.com.nu">IndoWapBlog</a></small></div></body></html>';
following_reader();
import_rss();
mysql_close($iwb_connect);
?>