<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$t=$_POST['t'];
$nama=$_POST['title'];
$mail=$_POST['email'];
$psn=$_POST['body'];
$code=intval($_POST['code']);
if (empty($user_id))
$user_id='0';
$comment_captcha=$site['comment_captcha'];
$situs=$_POST['url'];
if (!empty($situs))
{
$situs=str_replace('http://','',$situs);
$situs='http://'.$situs.'';
}
$blogs=mysql_fetch_array(mysql_query("select * from blog where link='".mysql_real_escape_string($t)."'"));
if ($blogs['allow_comment'] == '1')
{
if (($comment_captcha == 1) && ($code != $_SESSION['captcha_code']))
$err='err_code';
if (empty($psn))
$err='err_msg';
if ($site['comment_email'] == 1)
{
if (empty($mail))
$err='err_email';
elseif (mb_strlen($mail) < 2 || mb_strlen($mail) > 250)$err='err_leng_email';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $mail))
$err='err_invalid_email';
}
if (empty($nama))
$err='err_name';

if (($blogs['private'] == 1) && (!$user_id))
{
$err='member_only';
}
elseif (($blogs['private'] == 2) && (!$is_author))
{
$err='author_only';
}


if (empty($err))
{
if ($site['comment_mod'] == 1)
{
if ($is_author)
$sts='1';
else
$sts='0';
}
else
{
$sts='1';
}

mysql_query("insert into comment set user_id='".$user_id."', blog_id='".$blogs['id']."', blog_user_id='".$blogs['user_id']."', name='".mysql_real_escape_string($nama)."', site='".mysql_real_escape_string($situs)."', email='".mysql_real_escape_string($mail)."', text='".mysql_real_escape_string($psn)."', status='".$sts."', time='".time()."'");

//*Kirim email*//
if ($blogs['private'] == 1)
{
$kom='Komentar disembunyikan. Silakan kunjungi '.$site['name'].' untuk melihat komentar ini.';
}
elseif ($blogs['private'] == 2)
{
$kom='Komentar disembunyikan. Silakan kunjungi '.$site['name'].' untuk melihat komentar ini.';
}
else
{
$kom=$psn;
}

$ceksub=mysql_query("select * from subscribe where sub='".mysql_real_escape_string($t)."' or sub='new_comments' and status='1'");
if (mysql_num_rows($ceksub) != 0)
{
while ($subscribe=mysql_fetch_array($ceksub))
{
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $subscribe['email'];
$subject="Komentar Baru: ".$blogs['title']."";
$pesan="Komentar baru dari postingan: ".$blogs['title']."\r\n\r\n---\r\n\r\nOleh: ".$nama."\r\n\r\nPada: ".waktu(time())."\r\n\r\nKomentar: ".$kom."\r\n\r\n...\r\n\r\nUntuk membalas komentar ini silakan klik ".$site['url']."/".$t.".xhtml\r\n\r\n---\r\n\r\nAnda menerima email ini karena Anda telah berlangganan komentar.\r\n\r\nUntuk berhenti berlangganan silakan klik ".$site['url']."/unsubscribe/".$subscribe['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
}}
$_SESSION['nama']=$nama;
$_SESSION['url']=$situs;
$_SESSION['email']=$mail;
unset($_SESSION['captcha_code']);
if ($site['comment_mod'] == 1)
{
if ($is_author)
header('location: '.$site['url'].'/'.$t.'.xhtml?success#new_comment');
else
header('location: '.$site['url'].'/'.$t.'.xhtml?ok#new_comment');
}
else
{
header('location: '.$site['url'].'/'.$t.'.xhtml?success#new_comment');
}
}
else
{
header('location: '.$site['url'].'/'.$t.'.xhtml?'.$err.'#new_comment');
}
}
else
{
header('location: '.$site['url'].'/'.$t.'.xhtml');
}
?>