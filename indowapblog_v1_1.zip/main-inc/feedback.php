<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$head_title='Umpan Balik';
include 'main-inc/header.php';
echo '<div class="post"><h2 class="title">Umpan Balik</h2>';

if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$sender=$user_id;
}
else
{
$nama=$_POST['senders_name'];
$email=$_POST['senders_email'];
$sender='0';
}
$pesan=$_POST['message'];
$code=intval($_POST['captcha']);
$admin=mysql_fetch_array(mysql_query("select * from user where admin='1' order by id asc limit 1;"));
$receiver=$admin['id'];

if (isset($_POST['send']))
{
if ($site['comment_captcha'] == 1)
{
if ($code != $_SESSION['captcha_code'])
$hsl='Kode keamanan yang Anda masukan tidak benar';
}
if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl='Pesan minimal 2 dan maksimal 500 karakter';
if (empty($pesan))
$hsl='Silakan masukan pesan Anda';
if (empty($email))
$hsl='Silakan masukam Email Anda';
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)$hsl='Panjang email minimal 5 dan maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl='Alamat Email tidak benar';
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl='Nama minimal 2 dan maksimal 30 karakter';
if (empty($nama))
$hsl='Silakan masukan nama Anda';
if (empty($hsl))
{
//*Belum dibaca set 1*//
mysql_query("insert into `pm` set `receiver_id`='".$receiver."', `sender_id`='".$sender."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".time()."'") or die(mysql_error());
$hsl='Pesan Anda telah terkirim';
}
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hsl.'</li></ol>';
}

echo '<form name="feedback" action="'.$site['url'].'/feedback.xhtml" method="post"><p>Nama Anda:<br/>';
if ($user_id)
echo '<b>'.htmlspecialchars($user_name).'</b>';
else
echo '<input type="text" name="senders_name" value=""/>';
echo '<br/>Email Anda:<br/>';
if ($user_id)
echo '<b>'.$user_email.'</b>';
else
echo '<input type="text" name="senders_email" value=""/>';
echo '<br/>Pesan:<br/>
<textarea name="message" rows="3"/></textarea><br/>';
if ($site['comment_captcha'] == 1)
{
$_SESSION['captcha_code'] = rand(1000, 9999);
echo 'Keamanan:<br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/>(Masukan kode keamanan)<br/>
<input type="text" name="captcha" value=""/><br/>';
}
echo '<input type="submit" name="send" value="Kirim"/></p></form></div>';
include 'main-inc/footer.php';
?>