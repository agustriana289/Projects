<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');


/*Header*/
$head_title=isset($head_title) ? $head_title : $site['name'];
$head_description=isset($head_description) ? $head_description : $site['description'];$head_description=strip_tags($head_description);$head_description=substr($head_description,0,400);


header("Cache-Control: public");
header('Content-type: application/xhtml+xml; charset=UTF-8');
header("Expires: " . date("r",  time() + 60));

echo '<?xml version="1.0" encoding="iso-8859-1"?>';
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">';
echo '<html xmlns="http://www.w3.org/1999/xhtml"><head>';
echo '<title>'.htmlspecialchars($head_title).'';
if ($head_title != $site['name'])
echo ' | '.htmlspecialchars($site['name']).'';
echo '</title><link rel="icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><link rel="shortcut icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=iso-8859-1" />';
echo '<meta name="HandheldFriendly" content="true"/>';
echo '<meta name="description" content="'.htmlentities(strip_tags($head_description)).'" />
<meta name="keywords" content="'.htmlentities($site['keywords']).'" /><link rel="alternate"
type="application/rss+xml" title="RSS '.htmlentities($site['name']).'" href="'.$site['url'].'/rss.xml"/>';
if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

if ($user_id)
{
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];

$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';

$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}

mysql_query("UPDATE `user` SET `ip_proxy`='".mysql_real_escape_string($ip_via_proxy)."', `ip_browser`='".mysql_real_escape_string($ip)."', `user_agent`='".mysql_real_escape_string($user_agent)."', `ref`='".mysql_real_escape_string($ref)."', `place` = '$head_title' WHERE `id` = '$user_id'");
}
else
{
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';

$session = md5($ip . $ip_via_proxy . $user_agent);
$req = mysql_query("SELECT * FROM `guest` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req))
{
mysql_query("UPDATE `guest` SET `lastdate`= '".time()."', `sestime`='" .time()."', `ref`='".mysql_real_escape_string($ref)."', `place`='$head_title' WHERE `session_id` = '$session'");
} else {

mysql_query("INSERT INTO `guest` SET
`session_id` = '" . $session . "',
`ip_browser` = '" . mysql_real_escape_string($ip) . "',
`ip_proxy` = '" . mysql_real_escape_string($ip_via_proxy) . "',
`user_agent` = '" . mysql_real_escape_string($user_agent) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',`ref` = '" . mysql_real_escape_string($ref) . "',

`place` = '$head_title'");
}
}
$sub_end = time() - 18000;
mysql_query("delete FROM subscribe WHERE status='0' and time < $sub_end");

if ($detect->isMobile())
echo '<link rel="stylesheet" type="text/css" href="'.$site['url'].'/themes/'.$site['theme'].'.css" />';
else
echo '<link rel="stylesheet" type="text/css" href="'.$site['url'].'/default.css" />';
echo '</head><body class="mobile_body">';

if (!empty($site['logo']))
{$headitem='<img src="'.$site['url'].'/files/'.$site['logo'].'" alt="'.htmlentities($site['name']).'"/>';
}else{$headitem=htmlentities($site['name']);}
echo '<div id="header"><h1><a name="top" href="'.$site['url'].'">'.$headitem.'</a></h1><p>'.htmlspecialchars($site['description']).'</p></div>';




$cat_loc=$site['cat_loc'];
if ($cat_loc=="top")
{
$cat_loc="top";
echo category($cat_loc);
}
echo '<form id="search_form" method="get" action="'.$site['url'].'/"><input type="text" name="search" value=""/><input type="submit" value="Cari"/></form><p id="nav_shortcut">[#] <a href="#navigation" accesskey="#">Navigasi</a></p>';

$user_blocked=mysql_fetch_array(mysql_query("select * from user where id='".$user_id."'"));
if ($user_blocked['ban'] == '1')
{
echo '<div class="post"><h2 class="title">Pemblokiran Akun <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, akun Anda dengan data dibawah ini:<br/><br/>ID : '.$user_id.'<br/>Username : '.$user_username.'<br/>Email : '.$user_email.'<br/><br/>saat ini akun tersebut telah diblokir untuk sementara waktu atau selamanya. Silakan keluar dari akun ini atau kembali berkunjung ke '.htmlspecialchars($site['name']).' setelah beberapa saat lagi!</p></div>';
include 'main-inc/footer.php';
exit;
}

$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
$ip_blocked=mysql_fetch_array($ip_cek);
if (mysql_num_rows($ip_cek) != 0)
{
echo '<div class="post"><h2 class="title">Pemblokiran IP <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, untuk sementara waktu IP yang Anda gunakan (<b>'.$ip_blocked['ip'].'</b>) dilarang untuk mengakses '.htmlspecialchars($site['name']).'!</p></div>'; 
include 'main-inc/footer.php';
exit;
}
?>
