<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
if (isset($_POST['follow']))
{
$my_iwb=$_POST['my_iwb'];
$my_iwb=str_replace('http://','',$my_iwb);
if (empty($my_iwb))
{
$error='Silakan masukan URL Blog IndoWapBlog (IWB) Anda';
}
else
{
$my_iwb='http://'.$my_iwb.'';
$my_iwb=parse_url($my_iwb);
$my_iwb=$my_iwb['host'];
$my_iwb='http://'.$my_iwb.'';
header('location: '.$my_iwb.'/admin.php?iwb=following&action=follow&url='.$site['url'].'&title='.htmlentities($site['name']).'');
}
}

$head_title='Follow';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Follow</h2><div style="float: left;"></div>';
if (!empty($error))
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$error.'</li></ol>';
echo '<p>Layanan ini khusus untuk para administrator blog yang memakai Script/Engine IndoWapBlog (IWB). Dengan layanan ini Anda bisa melihat postingan terbaru pada blog '.htmlspecialchars($site['name']).'</p><p>NB: Dilarang menyalin sebagian atau seluruh postingan tanpa seijin '.htmlspecialchars($site['name']).' atau tanpa menyertakan Link sumber yang mengarahkan pengunjung ke blog '.htmlspecialchars($site['name']).'</p><div style="float: left;"></div><p><form method="post" action="'.$site['url'].'/follow.xhtml"><b>URL Blog IWB Anda</b><br/>';
if (($user_id) && (!empty($user_site)))
echo '<input type="text" name="my_iwb" value="'.$user_site.'" />';
else
echo '<input type="text" name="my_iwb" value="http://" />';
echo '<br/><input type="submit" name="follow" value="Follow"/>
</form>
</p>
<div style="float: left;"></div></div>';
echo '</div>';
include 'main-inc/footer.web.php';

?>