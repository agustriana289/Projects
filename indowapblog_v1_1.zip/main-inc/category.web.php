<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$name=$_GET['name'];
$page=$_GET['page'];
if (($page=='1') || (empty($page)))
$page='0';
$max_view=$site['num_post_main'];
$pgs=$page*$max_view;
$lmt=$pgs+$max_view;
$cat=mysql_fetch_array(mysql_query("select * from category where link='" . mysql_real_escape_string($name) . "'"));
$head_title=$cat['name'];
include 'main-inc/header.web.php';
echo '<div id="content"><h3>Menampilkan posting pada kategori <i>'.$cat['name'].'</i></h3>';
if (!empty($cat['blog_id']))
{
$cbid=$cat['blog_id'];
$eks=explode(",",$cbid);
$count=count($eks);
if ($count < $lmt)
$lmt=$count;
$i=$pgs;
while ($i<$lmt)
{if (!empty($eks[$i]))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".$eks[$i]."' and draft='0'"));
echo '<div class="post"><h2><a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a></h2>';$posted=mysql_fetch_array(mysql_query("select * from user where id='".$blog['user_id']."'"));
echo '<p class="meta">oleh <a href="'.$site['url'].'/user.php?id='.$posted['id'].'">'.htmlspecialchars($posted['name']).'</a> pada '.waktu($blog['time']).'</p><div style="float: left;"></div>';
$desc_leng=strlen(htmlentities(strip_tags($blog['description'])));
$desc_mainpage=$site['desc_post_main'];$desc_put=substr(strip_tags($blog['description']),0,300);
if (($desc_mainpage=='1') || ($desc_leng<='299'))
$description=$blog['description'];
else
$description=''.$desc_put.'...<a href="'.$site['url'].'/'.$blog['link'].'.xhtml">[Read More]</a>';
$komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."' and status='1'"),0);

if ($blog['private'] == 1)
{
if ($user_id)
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
else
echo '<p>Postingan ini hanya untuk Member <b>'.htmlspecialchars($site['name']).'</b>. Untuk melihat postingan ini silakan login atau register terlebih dahulu.</p>';
}
elseif ($blog['private'] == 2)
{
if ($is_author)
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
else
echo '<p>Postingan ini hanya untuk Penulis (Author) <b>'.htmlspecialchars($site['name']).'</b>.</p>';
}
else
{
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
}
echo '<p class="comment-meta"><a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.$komentar.'</a></p><div style="clear:both"></div></div>';
$i++;
}
}
$total=$count;
$link=''.$site['url'].'/category/'.$cat['link'].'/';$q='.xhtml';
if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1)
{
echo '<div id="pagination_links">Halaman:<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</div></div>';
}
echo '</div>';
}
else
{
echo '<div class="post"><h2 class="title">Kategori Kosong</h2><p>Belum ada post dalam kategori '.htmlspecialchars($cat['name']).'</p></div></div>';
}
include 'main-inc/footer.web.php';
?>
