<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$search=$_GET['search'];
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

//*Pencariar request*//
if (isset($_GET['search']))
$head_title='Pencarian untuk: '.$search.'';
include 'main-inc/header.php';
if (isset($_GET['search']))
{
$results=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%' and draft='0'"),0);
echo '<p class="search_info"><i>'.$results.'</i> ditemukan untuk &quot;<i>'.htmlspecialchars($search).'</i>&quot;</p>';
}
echo '<div id="content">';
if (isset($_GET['search']))
{
$blog=mysql_query("SELECT * FROM blog WHERE title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%' and draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
}else{
$blog=mysql_query("select * from blog where draft='0' order by time desc limit $limit,$max_view");
}
if (isset($_GET['search']))
{
$total=$results;
}
else
{
$total=mysql_result(mysql_query("select count(*) as Num from blog where draft='0'"),0);
}

if ($total != 0)
{
while ($blogs=mysql_fetch_array($blog))
{echo '<div class="post"><h2 class="title"><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">'.htmlspecialchars($blogs['title']).'</a><br /><small>['.waktu($blogs['time']).']</small></h2>';
$desc_leng=strlen(htmlentities(strip_tags($blogs['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blogs['description']),0,150);
if (($desc_mainpage == 1) || ($desc_leng < 149))
$description=$blogs['description'];
else
$description=''.$desc_put.'...<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">[Read More]</a>';

$komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blogs['id']."' and status='1'"),0);

if ($blogs['private'] == 1)
{
if ($user_id)
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
else
echo '<p>Postingan ini hanya untuk Member <b>'.htmlspecialchars($site['name']).'</b>. Untuk melihat postingan ini silakan login atau register terlebih dahulu.</p>';
}
elseif ($blogs['private'] == 2)
{
if ($is_author)
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
else
echo '<p>Postingan ini hanya untuk Penulis (Author) <b>'.htmlspecialchars($site['name']).'</b>.</p>';
}
else
{
echo '<p>'.html_entity_decode(htmlentities($description)).'</p>';
}
echo '<p>[<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml#comments">'.$komentar.' Komentar</a>]';
if ($site['display_count'] == 1)
echo ' ['.$blogs['count'].' Dilihat]';
echo '</p></div>';
}
}
else
{
if (isset($_GET['search']))
echo '<div class="post"><h2 class="title">Pencarian tidak ditemukan</h2><p><li>Pencarian dengan kata kunci &quot;'.htmlspecialchars($search).'&quot; tidak ditemukan.</li></p></div>';
else
echo '<div class="post"><h2 class="title">Blog Tidak Ada</h2><p><li>Belum ada satu pun blog yang dipublikasikan.</li></p></div>';
}
echo '</div>';if (isset($_GET['search']))
{
$link=''.$site['url'].'/?search='.$search.'&amp;page=';
$q='';
$pagination="on";
$homepage="on";
}
else
{
$link=''.$site['url'].'/page/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}


include 'main-inc/footer.php';
?>