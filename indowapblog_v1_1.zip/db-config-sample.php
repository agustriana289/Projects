<?php
defined('_IWB_') or die ('Kesalahan: pembatasan akses');

/*Database Konfigurasi*/
$dbhost='localhost';
$dbuser='';
$dbpass='';
$dbname='';
?>