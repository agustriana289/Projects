<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
$res=$_GET['res'];
if (!$user_id)
relogin();

$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);
$res=$_GET['res'];
if ($res != 'all')
{
$cek=mysql_query("select * from chat where id='".mysql_real_escape_string($res)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$us=mysql_fetch_array($cek);
if (($user_id != $us['user_id']) && 
(!$is_admin))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
}

if (isset($_GET['yes']))
{
if (($res == 'all') && ($is_admin))
{
mysql_query("TRUNCATE TABLE chat");
}
if ($res != 'all')
{
if (($us['user_id'] == $user_id) || ($is_admin))
{
mysql_query("delete from chat where id='".$us['id']."'");
}
}
header('location: chat.php');
}

$head_title='Hapus Pesan Chat';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="chat.php?">Chat</a> | <a href="chat.php?write">Tulis</a> | <a href="online.php">Online</a> ('.$user_ol.') | Hapus Semua</a>';
echo '</div>';
if ($res == 'all')
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
echo '<p>Anda yakin ingin menghapus semua pesan pada Chat Room?<br/>[<a href="chat.php?iwb=delete&amp;res=all&amp;yes">YA</a>] [<a href="chat.php">TIDAK</a>]</p>';
}

if ($res != 'all')
echo '<p>Anda yakin ingin menghapus pesan ini?<br/>[<a href="chat.php?iwb=delete&amp;res='.$res.'&amp;yes">YA</a>] [<a href="chat.php">TIDAK</a>]</p>';
echo '</div></div>';
include 'foot.php';
break;
default:
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;if (!$user_id)
relogin();
if (isset($_POST['chat']))
{
if (!$user_id)
relogin();
$msg=$_POST['msg'];
if (mb_strlen($msg) > 500)
$err='Pesan maksimal 500 karakter';
if (empty($msg))
$err='Silakan masukan pesan Anda';
if (empty($err))
{
mysql_query("insert into chat set user_id='".$user_id."', user_name='".mysql_real_escape_string($user_name)."', text='".mysql_real_escape_string($msg)."', time='".time()."'");
header('location: chat.php');
}
else
{
$notif='<ol id="error"><li>'.$err.'</li></ol>';
}
}

$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$head_title='Chat Room';
include 'head.php';
echo '<div id="message">';
if (!empty($notif))
echo $notif;
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="chat.php?write">Tulis</a> | <a href="bbsm.php?iwb=smiley">Smiley</a> | <a href="bbsm.php?iwb=bbcode">BBCode</a> | <a href="chat.php?'.time().'">Refresh</a> | <a href="online.php">Online</a> ('.$user_ol.')';
if ($is_admin)
echo ' | <a href="chat.php?iwb=delete&amp;res=all">Hapus Semua</a>';
echo '</div>';
if (isset($_GET['write']))
{
echo '<form action="chat.php?write" method="post"><textarea class="iwb-textarea" name="msg" rows="3" cols="30"></textarea><br/><input class="iwb-button" name="chat" type="submit" value="Simpan"/></form>';
}
echo '<ol style="list-style: none; margin: 10px 0px 0px 0px; padding: 0px;">';


$req=mysql_query("select * from chat order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row0">' : '<li class="row1">';
$usr=mysql_fetch_array(mysql_query("select * from user where id='".$res['user_id']."'"));
echo '<a href="user.php?id='.$res['user_id'].'">';
if (($usr['author'] == '0') && ($usr['admin'] == '0'))
echo '<font color="black">'.htmlspecialchars($res['user_name']).'</font>';

if (($usr['author'] == '1') && ($usr['admin'] == '0'))
echo '<font color="green">'.htmlspecialchars($res['user_name']).'</font>';

if ($usr['admin'] == '1')
echo '<font color="#731174">'.htmlspecialchars($res['user_name']).'</font>';

echo '</a> ('.time_ago($res['time']).'): '.bbsm($res['text']).'';
if (($res['user_id'] == $user_id) || ($is_admin))
echo '[<a href="chat.php?iwb=delete&amp;res='.$res['id'].'">X</a>]';
++$i;
echo '</li>';
}
$total=mysql_result(mysql_query("select count(*) as num from chat"), 0);
if ($total == 0)
echo '<li>Chat Kosong</li>';
echo '</ol> </div>';

$link='chat.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);

echo '</div>';
include 'foot.php';
}
?>
