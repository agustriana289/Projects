<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';

if (isset($_GET['iwb']) && file_exists('admin-inc/'.$iwb.'.php'))
{
include 'admin-inc/'.$iwb.'.php';
}
else
{
include 'admin-inc/index.php';
}
?>