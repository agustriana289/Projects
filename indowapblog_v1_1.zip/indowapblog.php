<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

@ini_set('session.use_trans_sid', '0');
@ini_set('arg_separator.output', '&amp;');
mb_internal_encoding('UTF-8');
date_default_timezone_set('UTC');
@ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
session_name('IndoWapBlog');
session_start();$root = isset($root) ? $root : '';

if (!file_exists('db-config.php'))
{
header('location: install.php');
}
else
{
require_once ''.$root.'db-config.php';
}
$iwb_connect=mysql_connect($dbhost,$dbuser,$dbpass);
if (!$iwb_connect)
{
echo 'Tidak dapat terhubung ke database!';
exit;
}

$iwb_select_db=mysql_select_db($dbname);
if (!$iwb_select_db)
{echo 'Tidak dapat terhubung ke database yang dipilih!';
exit;}
$site=mysql_fetch_array(mysql_query("select * from site"));
$site_name=$site['name'];
$site_url=$site['url'];
/*Melakukan koneksi ke database untuk melihat pengaturan situs*/

if ((isset($_COOKIE['user_id'])) && (isset($_COOKIE['password'])))
{
$iwb_id = $_COOKIE['user_id'];
$iwb_pwd = $_COOKIE['password'];
}
elseif ((isset($_SESSION['user_id'])) && (isset($_SESSION['password'])))
{
$iwb_id = $_SESSION['user_id'];
$iwb_pwd = $_SESSION['password'];
}
else
{
$iwb_id='';
$iwb_pwd='';
}
$iwb_req=mysql_query("select * from user where id='".$iwb_id."' and password='".$iwb_pwd."'");
$indowapblog=mysql_fetch_array($iwb_req);
if (mysql_num_rows($iwb_req) != 0)
{
$user_id=$indowapblog['id'];
$user_username=$indowapblog['username'];
$user_name=$indowapblog['name'];
$user_email=$indowapblog['email'];
$user_site=$indowapblog['site'];
$user_admin=$indowapblog['admin'];
$user_author=$indowapblog['author'];
$is_admin = $user_admin == 1;
$is_author = $user_author == 1;$user_lastdate=$indowapblog['lastdate'];
}
$Files=glob('functions/*.func.php');
foreach ($Files as $File)
{
if (file_exists($File))
include $File;
}

?>
