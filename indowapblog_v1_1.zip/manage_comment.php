<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$rd='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';
$rd=base64_encode($rd);
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
$comid=$_GET['comid'];
$all=$_GET['all'];
$redir=$_GET['redir'];
$back=base64_decode($redir);
if (!$user_id)
relogin();
$del=mysql_fetch_array(mysql_query("select * from comment where id='".mysql_real_escape_string($comid)."'"));
if ((!$is_admin) && ($del['blog_user_id'] != $user_id))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
$redir=base64_decode($_GET['redir']);
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if ($all == 'approved')
$sts='1';
if ($all == 'unapproved')
$sts='0';
if ($all == 'spam')
$sts='2';

if ($all && !$is_admin)
mysql_query("delete from comment where blog_user_id='".$user_id."' and status='".$sts."'")
;
if ($all && $is_admin)
mysql_query("delete from comment where status='".$sts."'")
;
if ($comid)
{
if ((!$is_admin) && ($del['blog_user_id'] != $user_id))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
mysql_query("delete from comment where id='".$del['id']."'");
}
header('location: '.$redir.'');
}
$head_title='Hapus komentar';
include 'head.php';
echo '<div id="message"><ol id="notice"><li>';

if ($all == 'approved')
echo 'Anda yakin ingin menghapus semua komentar yang telah disetujui?<br/>[<a href="manage_comment.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($all == 'unapproved')
echo 'Anda yakin ingin menghapus semua komentar yang belum disetujui?<br/>[<a href="manage_comment.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($all == 'spam')
echo 'Anda yakin ingin menghapus semua komentar Spam?<br/>[<a href="manage_comment.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($comid)
echo 'Anda yakin ingin menghapus komentar ini?<br/>[<a href="manage_comment.php?iwb=delete&amp;comid='.$comid.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

echo '</li></ol></div>';
include 'foot.php';
break;
case 'approved':
case 'unapproved':
case 'spam':
$comid=$_GET['comid'];
$in=$_GET['iwb'];
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
if (isset($_GET['comid']))
{
$redir=$_GET['redir'];
$redir=base64_decode($redir);
if ($in == 'approved')
$status='1';
if ($in == 'unapproved')
$status='0';
if ($in == 'spam')
$status='2';
$Com=mysql_fetch_array(mysql_query("select * from comment where id='".mysql_real_escape_string($comid)."'"));
if ((!$is_admin) && ($Com['blog_user_id'] != $user_id))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
mysql_query("update comment set status='".$status."' where id='".$Com['id']."'");
header('location: '.$redir.'');
}


if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if ($in == 'unapproved')
$head_title='Komentar Ditangguhkan';
if ($in == 'approved')
$head_title='Komentar Disetujui';
if ($in == 'spam')
$head_title='Komentar Spam';

include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="manage_comment.php">Semua</a> | ';
if ($in == 'approved')
echo 'Disetujui';
else
echo '<a href="manage_comment.php?iwb=approved">Disetujui</a>';
echo ' |
';
if ($in == 'unapproved')
echo 'Ditangguhkan';
else
echo '<a href="manage_comment.php?iwb=unapproved">Ditangguhkan</a>';
echo ' | ';
if ($in == 'spam')
echo 'Spam';
else
echo '<a href="manage_comment.php?iwb=spam">Spam</a>';
echo '</div>';
echo '<ol>';
if ((!$is_admin) && ($in == 'approved'))
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_user_id='".$user_id."' and status='1'"), 0);
$req=mysql_query("select * from comment where blog_user_id='".$user_id."' and status='1' order by time desc limit $limit,$max_view");
}
if (($is_admin) && ($in == 'approved'))
{
$count=mysql_result(mysql_query("select count(*) from comment where status='1'"), 0);
$req=mysql_query("select * from `comment` where `status`='1' order by `time` desc limit $limit,$max_view");
}
if ((!$is_admin) && ($in == 'unapproved'))
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_user_id='".$user_id."' and status='0'"), 0);
$req=mysql_query("select * from comment where blog_user_id='".$user_id."' and status='0' order by time desc limit $limit,$max_view");
}
if (($is_admin) && ($in == 'unapproved'))
{
$count=mysql_result(mysql_query("select count(*) from comment where status='0'"), 0);
$req=mysql_query("select * from `comment` where `status`='0' order by `time` desc limit $limit,$max_view");
}

if ((!$is_admin) && ($in == 'spam'))
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_user_id='".$user_id."' and status='2'"), 0);
$req=mysql_query("select * from comment where blog_user_id='".$user_id."' and status='2' order by time desc limit $limit,$max_view");
}
if (($is_admin) && ($in == 'spam'))
{
$count=mysql_result(mysql_query("select count(*) from comment where status='2'"), 0);
$req=mysql_query("select * from `comment` where `status`='2' order by `time` desc limit $limit,$max_view");
}

while ($com=mysql_fetch_array($req))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".$com['blog_id']."'")) or die(mysql_error());
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.$site['url'].'/'.$blog['link'].'.xhtml#comments" accesskey="1">'.htmlspecialchars($com['name']).'</a><br/>['.waktu($com['time']).']<br/>';
if (mb_strlen($com['text']) > 100)
$koment=substr($com['text'],0,100);
else
$koment=$com['text'];
echo ''.bbsm($koment).'<br/><span class="action_links">';
if ($com['status'] == 1)
echo '[<a class="reply" href="manage_comment.php?iwb=reply&amp;comid='.$com['id'].'">Balas</a>] ';
if ($com['status'] == 0)
echo '[<font color="black">Tangguhkan</font>] ';
else
echo '[<a href="manage_comment.php?iwb=unapproved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Tangguhkan</a>] ';

if ($com['status'] == 1)
echo '[<font color="black">Setujui</font>] ';
else
echo '[<a href="manage_comment.php?iwb=approved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Setujui</a>] ';

if ($com['status'] == 2)
echo '[<font color="black">Spam</font>] ';
else
echo '[<a href="manage_comment.php?iwb=spam&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Spam</a>] ';

echo '[<a class="delete" href="manage_comment.php?iwb=delete&amp;comid='.$com['id'].'&amp;redir='.$rd.'"><font color="red">Hapus</font></a>]</span>';
++$i;
echo '</li>';
}
if ($count == 0)
echo '<p>Anda belum memiliki '.htmlspecialchars($head_title).'</p>';
else
echo '<p><a href="manage_comment.php?iwb=delete&amp;all='.$in.'&amp;redir='.$rd.'"><input class="iwb-button" type="submit" value="Hapus semua pesan"/></a></p>';
echo '</ol></div>';
$total=$count;
if ($in == 'approved')
$link='manage_comment.php?iwb=approved&amp;page=';
elseif ($in == 'unapproved')
$link='manage_comment.php?iwb=unapproved&amp;page=';
else
$link='manage_comment.php?iwb=spam&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';


break;
case 'reply':
$comid=$_GET['comid'];
$reply=$_POST['reply'];
if (!$user_id)
relogin();
$req=mysql_query("select * from comment where id='".mysql_real_escape_string($comid)."'");
if (mysql_num_rows($req) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$res=mysql_fetch_array($req);
if ((!$is_admin) && ($user_id != $res['blog_user_id']))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['send']))
{
if ((!$is_admin) && ($user_id != $res['blog_user_id']))
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (mb_strlen($reply) > 500)
$hsl='Pesan maksimal 500 karakter';
elseif (empty($reply))
$hsl='Silakan tulis komentar Anda';
if (empty($hsl))
{
mysql_query("insert into comment set user_id='".$user_id."', blog_id='".$res['blog_id']."', blog_user_id='".$res['blog_user_id']."', name='".mysql_real_escape_string($user_name)."', text='".mysql_real_escape_string($reply)."', site='".$site['url']."/user.php?id=".$user_id."', status='1', time='".time()."'");
header('location: manage_comment.php?reply_successfully');
}
}
$head_title='Balas Komentar';
include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="manage_comment.php?">Semua</a> | <a href="manage_comment.php?iwb=approved">Disetujui</a> |
<a href="manage_comment.php?iwb=unapproved">Ditangguhkan</a> | <a href="manage_comment.php?iwb=spam">Spam</a></div>';

echo '<h4>Balas untuk  komentar</h4>
<p class="row0">
<strong>';
if ($res['user_id'] != 0)
echo '<a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a>';
else
echo htmlspecialchars($res['name']);
echo '</strong><br/>['.waktu($res['time']).']<br/>'.bbsm($res['text']).'</p>
<form action="manage_comment.php?iwb=reply&amp;comid='.$res['id'].'" method="post"><h4>Balas</h4>
<textarea class="iwb-textarea" name="reply" rows="5" cols="30">@'.htmlentities($res['name']).',
</textarea><br/>
<input class="iwb-button" name="send" type="submit" value="Kirim"/>';
echo '</div></div>';
include 'foot.php';
break;

default:
$page=$_GET['page'];
$bid=$_GET['bid'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;if (!$user_id)
relogin();
if (!$is_author)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (!$is_admin)
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_user_id='".$user_id."'"), 0);
$req=mysql_query("select * from comment where blog_user_id='".$user_id."' order by time desc limit $limit,$max_view");
}
if ($is_admin)
{
$count=mysql_result(mysql_query("select count(*) from comment"), 0);
$req=mysql_query("select * from `comment` order by `time` desc limit $limit,$max_view");
}
if ((!$is_admin) && (isset($_GET['bid'])))
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_id='".mysql_real_escape_string($bid)."' and blog_user_id='".$user_id."'"), 0);
$req=mysql_query("select * from comment where blog_id='".mysql_real_escape_string($bid)."' and blog_user_id='".$user_id."' order by time desc limit $limit,$max_view");
}
if (($is_admin) && (isset($_GET['bid'])))
{
$count=mysql_result(mysql_query("select count(*) from comment where blog_id='".mysql_real_escape_string($bid)."'"), 0);
$req=mysql_query("select * from `comment` where `blog_id`='".mysql_real_escape_string($bid)."' order by `time` desc limit $limit,$max_view");
}
$B=mysql_fetch_array(mysql_query("select * from blog where id='".mysql_real_escape_string($bid)."'"));
if (isset($_GET['bid']))
$head_title='Komentar: '.htmlspecialchars($B['title']).'';
else
$head_title='Kelola Komentar';
include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar">';
if (isset($_GET['bid']))
echo '<a href="manage_comment.php">Semua</a>';
else echo 'Semua';
echo ' | <a href="manage_comment.php?iwb=approved">Disetujui</a> |
<a href="manage_comment.php?iwb=unapproved">Ditangguhkan</a> | <a href="manage_comment.php?iwb=spam">Spam</a></div>';
echo '<ol>';
while ($com=mysql_fetch_array($req))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".$com['blog_id']."'")) or die(mysql_error());
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.$site['url'].'/'.$blog['link'].'.xhtml#comments" accesskey="1">'.htmlspecialchars($com['name']).'</a><br/>['.waktu($com['time']).']<br/>';
if (mb_strlen($com['text']) > 100)
$koment=substr($com['text'],0,100);
else
$koment=$com['text'];
echo ''.bbsm($koment).'<br/><span class="action_links">';
if ($com['status'] == 1)
echo '[<a class="reply" href="manage_comment.php?iwb=reply&amp;comid='.$com['id'].'">Balas</a>] ';
if ($com['status'] == 0)
echo '[<font color="black">Tangguhkan</font>] ';
else
echo '[<a href="manage_comment.php?iwb=unapproved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Tangguhkan</a>] ';

if ($com['status'] == 1)
echo '[<font color="black">Setujui</font>] ';
else
echo '[<a href="manage_comment.php?iwb=approved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Setujui</a>] ';

if ($com['status'] == 2)
echo '[<font color="black">Spam</font>] ';
else
echo '[<a href="manage_comment.php?iwb=spam&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Spam</a>] ';
echo '[<a class="delete" href="manage_comment.php?iwb=delete&amp;comid='.$com['id'].'&amp;redir='.$rd.'"><font color="red">Hapus</font></a>]</span>';
++$i;
echo '</li>';
}
if ($count == 0)
{
echo '<li>Belum ada komentar';
if (isset($_GET['bid']))
echo ' untuk '.htmlspecialchars($B['title']).'';
echo '</li>';
}
echo '</ol></div>';
$total=$count;
if (isset($_GET['bid']))
$link='manage_comment.php?bid='.htmlentities($bid).'&amp;page=';
else
$link='manage_comment.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}?>