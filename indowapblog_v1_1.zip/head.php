<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

if (empty($head_title))
$head_title=$site['name'];


echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml"><head>';
echo '<title>'.htmlspecialchars($head_title).'</title><link rel="icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><link rel="shortcut icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><meta name="viewport" content="width=320" /><meta name="viewport" content="initial-scale=1.0" /><meta name="viewport" content="user-scalable=false" /><meta http-equiv="Cache-Control" content="max-age=1" /><meta name="HandheldFriendly" content="True" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="all"/><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="handheld"/>';

if ($user_id)
{
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];

$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';

$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}

mysql_query("UPDATE `user` SET `ip_proxy`='".mysql_real_escape_string($ip_via_proxy)."', `ip_browser`='".mysql_real_escape_string($ip)."', `user_agent`='".mysql_real_escape_string($user_agent)."', `ref`='".mysql_real_escape_string($ref)."', `place` = '$head_title' WHERE `id` = '$user_id'");
}
else
{
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';

$session = md5($ip . $ip_via_proxy . $user_agent);
$req = mysql_query("SELECT * FROM `guest` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req))
{
mysql_query("UPDATE `guest` SET `lastdate`= '".time()."', `sestime`='" .time()."', `ref`='".mysql_real_escape_string($ref)."', `place`='$head_title' WHERE `session_id` = '$session'");
} else {


mysql_query("INSERT INTO `guest` SET
`session_id` = '" . $session . "',
`ip_browser` = '" . mysql_real_escape_string($ip) . "',
`ip_proxy` = '" . mysql_real_escape_string($ip_via_proxy) . "',
`user_agent` = '" . mysql_real_escape_string($user_agent) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',`ref` = '" . mysql_real_escape_string($ref) . "',

`place` = '$head_title'");
}
}

$sub_end = time() - 18000;
mysql_query("delete FROM subscribe WHERE status='0' and time < $sub_end");

echo '<script type="text/javascript">';
echo '<![CDATA[
function init()
{
    // Try to clear attcahed onclick events
    var hrefs = document.getElementsByTagName("a");
    for (i = 0; i < hrefs.length; i++)
    {
if(hrefs[i].className != null)
{
    hrefs[i].onclick = null;
}
}
}
//]]></script>';
echo '</head><body onload="javascript:init()"><div id="header"><a href="'.$site['url'].'/">';
if (!empty($site['logo']))
{
echo '<img src="'.$site['url'].'/files/'.$site['logo'].'" alt="'.htmlentities($site['name']).'"/>';
}else{
echo htmlspecialchars($site['name']);
}
echo '</a>';
echo '<div id="navigation">';
$relogin=''.$ite['url'].$_SERVER['REQUEST_URI'].'';
$relogin=base64_encode($relogin);
if ($user_id)
{
echo '<a href="'.$site['url'].'/user.php">Profil</a> | <a href="'.$site['url'].'/dashboard.php">Dashboard</a> | <a href="message.php">Pesan</a> | ';
if ($is_admin)
echo '<a href="admin.php">Admin Panel</a> | ';
echo '<a href="'.$site['url'].'/">Lihat blog</a> | <a href="login.php?iwb=logout">Keluar</a><br>(<strong>'.htmlspecialchars($user_name).'</strong>)';
}
else
{
echo '<a href="'.$site['url'].'/login.php">Masuk</a> | <a href="register.php?">Pendaftaran</a>';
}
echo '</div>';
echo '<h2>'.htmlspecialchars($head_title).'</h2>
</div>';


$user_blocked=mysql_fetch_array(mysql_query("select * from user where id='".$user_id."'"));
if ($user_blocked['ban'] == '1')
{
echo '<div id="message"></div><div id="content">
<div id="main-content"><div id="show_bar">Pemblokiran User</div>';
echo '<p>Maaf, akun Anda dengan data dibawah ini:<br/><br/>ID : '.$user_id.'<br/>Username : '.$user_username.'<br/>Email : '.$user_email.'<br/><br/>saat ini akun tersebut telah diblokir untuk sementara waktu atau selamanya. Silakan keluar dari akun ini atau kembali berkunjung ke '.htmlspecialchars($site['name']).' setelah beberapa saat lagi!</p></div></div>';
include 'foot.php';
exit;
}

$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
$ip_blocked=mysql_fetch_array($ip_cek);
if (mysql_num_rows($ip_cek) != 0)
{
echo '<div id="message"></div><div id="content">
<div id="main-content"><div id="show_bar">Pemblokiran IP</div>';

echo '<p>Maaf, untuk sementara waktu IP yang Anda gunakan (<b>'.$ip_blocked['ip'].'</b>) dilarang untuk mengakses '.htmlspecialchars($site['name']).'!</p></div></div>'; 
include 'foot.php';
exit;
}


if (($is_author) && (!$is_admin))
{
$total_kom=mysql_result(mysql_query("select count(*) as Num from `comment` where `blog_user_id`='".$user_id."' and `status`='0'"), 0);
}
if ($is_admin)
{
$total_kom=mysql_result(mysql_query("select count(*) as Num from `comment` where `status`='0'"), 0);
$total_gb=mysql_result(mysql_query("select count(*) as Num from `guestbook` where `status`='0'"), 0);
$total_following_post=mysql_result(mysql_query("select count(*) as Num from `following_post` where `read`='1'"), 0);
}
if ($total_kom > 0)
$new='<ol id="notice"><li>Ada <a href="manage_comment.php?iwb=unapproved">'.$total_kom.'</a> komentar blog menunggu moderasi</li></ol>';

if ($total_gb > 0)
$new='<ol id="notice"><li>Ada <a href="manage_guestbook.php?iwb=unapproved">'.$total_gb.'</a> pesan buku tamu menunggu moderasi</li></ol>';
if ($total_following_post > 0)
$new='<ol id="notice"><li>Ada <a href="admin.php?iwb=following&amp;action=read">'.$total_following_post.'</a> postingan terbaru dari blog yang Anda ikuti</a> </li></ol>';

$total_pms=mysql_result(mysql_query("select count(*) as Num from `pm` where `receiver_id`='".$user_id."' and `read`='1'"), 0);
if ($total_pms > 0)
$new='<ol id="notice"><li>Anda mendapat <a href="message.php?">'.$total_pms.'</a> pesan baru</li></ol>';
if (!empty($new))
echo '<div id="message">'.$new.'</div>';
?>
