<?
{
$roq = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");;
while ($res = mysql_fetch_array($roq))
{
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
// icon seks
global $set_user, $realtime, $user_id, $admp, $home;
if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="' . $set['homeurl'] . '/users/profile.php?user=' . $res['user_id'] . '"><b>' . $res['name'] . '</b></a> ';
}
else {
echo '<b>' . $res['name'] . '</b>';
}
$ontimes = $res['lastdate'] + 300;
if (time() > $ontimes)
{
echo ' <span class="red"><img src="../images/off.png" alt="[OFF]" /"></span>';
}
else
{
echo ' <font color="#00AA00"><img src="../images/on.png" alt="[ON]" /"></font>';
}
echo ' ';
$post = functions::antilink(functions::checkout($res['text'], 0, 2));
$post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0); 
// text
if (mb_strlen($post) >= 100)
{
$post = mb_substr($post, 0, 150);
echo $post.' ';
}
else
{
echo $post; 
echo '<br>';
echo '&#8226; <font color="gray">';
echo functions::update_time($res['time']);
echo '</font>';
}
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '</div>' : '</div>';
++$i;
}
}
?>
