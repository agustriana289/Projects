<?
function color($text) {
$text=str_replace('<br />','',$text);
$arr=array('ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200','ff0000','ff6200','ff8000','ffc400','adcc00','5fcc00','11cc00','5fcc00','adcc00','ffc400','ff6200'
);
$str='';
$text=iconv('utf-8','windows-1251',$text);
for ($i=0; $i<strlen($text); $i++) {
$str.='<font color="#'.$arr[$i].'">'.$text[$i].'</font>';
}
$str=iconv('windows-1251','utf-8',$str);
return $str;
}
?>
