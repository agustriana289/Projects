<?php

/*if($user_id && $ban !='1' && $ban !='12') {
if ($headmod != "guestbook" && $headmod != "pradd" && $headmod != "load") {
echo '<div class="nfooter"><b>Shoutbox</b></div>';
$refer = base64_encode($_SERVER['REQUEST_URI']);
echo '<div class="currentpage"><form name="form" action="/guestbook/index.php?act=say" method="post">';
echo '<textarea cols="30" rows="1.5" name="msg"></textarea>';
echo '<input type="hidden" name="ref" value="'.$refer.'">';
echo '<input type="submit" name="submit" value="Shout"><br/></form></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
if ($total) {
$req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`lastdate`, `users`.`id`, `users`.`rights`, `users`.`name`
FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT 10");
echo '<div class="">';
while ($gres = mysql_fetch_assoc($req)) {
$post = $gres['text'];
if(strlen($post) > 160) {
$post = substr($post, 0, 160).'....';
}
$post = functions::checkout($gres['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $gres['rights'] ? 1 : 0);
if($user_id) {
$post = str_replace('[you]', $login, $post);
} else {
$post = str_replace('[you]', 'Kha&#65533;ch', $post);
}
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">' : '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">';
echo (time() > $gres['lastdate'] + 900 ? '<font color="red">&#x2022;</font> ' : '<font color="green">&#x2022;</font> ');

if (!empty($user_id) && ($user_id != $gres['user_id'])) {
echo '<a href="../users/' . $gres['name'] . '"><b>'.functions::nickcolor($gres['user_id']).'</b></span></a> :&nbsp;';}
else{echo'<b>'.functions::nickcolor($gres['user_id']).'</b></span> :&nbsp;';}
if (mb_strlen($post) >= 200)
{
$post = mb_substr($post, 0, 200);
echo $post.' ';
echo '...<a href="../guestbook/index.php">more</a>';
}
else
{
echo $post;
}
echo '</div>';
++$i;
}
}else {
echo '<div class="textshout">' . $lng['guestbook_empty'] . '</div>';
}
echo '<div class="forumb"><center><a href="#">Refresh</a> &bull; <a href="/pages/img.php">BBimg</a> &bull; <a href="/guestbook/index.php">Shoutbox</a></center></div></div></div>';
echo'</div></div></div>';
}}
*/
if ($headmod = "mainpage") {
echo '<table class="prus-body" align="center" width="287"><tbody><tr>';
echo '<div class="nfooter"><b>Top Forum</b></div>';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
if ($user_id) {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Unread</a><font color="red">&nbsp;(<b>' . counters::forum_new() . '</b>)</font> | <a href="../forum/index.php?act=files">Files</a> <span class="red">(' . $count . ')</span></div>';
} else {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Last Activity</a> | <a href="../forum/index.php?act=files">Files</a> <span class="red">(' . $count . ')</span></div>'; }
$bonguyen = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while (($dd = mysql_fetch_array($bonguyen)) !== false) {
echo '<div class="nfooter"><b>'.$dd['text'].'</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`='" . $dd['id'] . "' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
$chude = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' and `refid`='" . $res['id'] . "'"), 0);
echo '<div class="'.(++$j%2==0 ? "list1" : "list2").'">&bull; <a href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a> ['.$chude.']<br/>';
//if ($user_id) {
//echo '<a class="omenu" href="/forum/index.php?act=nt&id=' . $res['id'] . '">Add Post</a>'; }
echo '</div>';
//if ($rights >= 9) { 
//echo '<div class="rmenu"><a href="/panel/index.php?act=forum&mod=edit&id=' . $res['id'] . '">Edit</a> | <a href="/panel/index.php?act=forum&mod=del&id=' . $res['id'] . '">Delete</a></div>'; 
//}
}
++$j;
}
echo '</div></div></div></div></div></td></tr></tbody></table></div>';
}
// Stats
$begin_day = strtotime(date("d F y", statistic::$system_time));
$my_url = parse_url($home);
$sql = "
(SELECT COUNT(*) FROM `counter` WHERE `robot` != '') UNION ALL
(SELECT COUNT(DISTINCT `pop`) FROM `counter` WHERE `robot` = '') UNION ALL
(SELECT COUNT(*) FROM `stat_robots` WHERE `date` > '".$begin_day."') UNION ALL
(SELECT COUNT(DISTINCT `country`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `operator`, `country`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `robot`) FROM `counter` WHERE `robot` != '') UNION ALL
(SELECT COUNT(DISTINCT `user`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `site`) FROM `counter` WHERE `site` NOT LIKE '%".$my_url['host']."')
";
$query = mysql_query($sql);
$count_stat = array();
while($result_array = mysql_fetch_array($query)) {
$count_stat[] = $result_array[0];
}
$hitnorob = statistic::$hity - $count_stat[0];
if ($headmod == 'mainpage') {
echo '<div class="mainblok"><h3 class="nfooter"> General Information</h3>
<div class="list1">Hits today: '.statistic::$hity.'</div>
<div class="list2">Hosts today: '.statistic::$hosty.'</div>
<div class="list1">Hits from robots: '.$count_stat[0].'</div>
<div class="list2">Hits without robots: '.$hitnorob.'</div>';
//////// ???????? ?????? //////
$maxhost = mysql_query("SELECT `date`, `host` FROM `countersall` ORDER BY `countersall`.`host` DESC LIMIT 0 , 1");
if(mysql_num_rows($maxhost) > 0){
$maxhost = mysql_fetch_array($maxhost);
/////// ???????? ????? ////////
$maxhits = mysql_fetch_array(mysql_query("SELECT `date`, `hits` FROM `countersall` ORDER BY `countersall`.`hits` DESC LIMIT 0 , 1"));
$max_host_time = date("d M Y", $maxhost['date']);
$max_hits_time = date("d M Y", $maxhits['date']);
echo '<div class="list1">Record host (<b>'.$maxhost['host'].'</b>) was <b>'.statistic::month($max_host_time).'.</b></div>
<div class="list2">Record hits (<b>'.$maxhits['hits'].'</b>) was <b>'.statistic::month($max_hits_time).'.</b></div>';
}
echo '<div class="list1">Average number of hits per visitor: '.round($hitnorob/statistic::$hosty).'</div></div></div>';
}
?>
