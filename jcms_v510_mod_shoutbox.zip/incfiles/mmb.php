function usersonline() {
    ////////////////////////////////////////////////////////////
    // counter online                             //
    ////////////////////////////////////////////////////////////
    global $realtime, $user_id, $home;
    $u_on = array();
    $ontime = $realtime - 300;
    $users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . ($realtime - 300) . "'"), 0);
    $guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_guests` WHERE `lastdate` > '" . ($realtime - 300) . "'"), 0);
    $qon = mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate`>='" . $ontime . "';");
    $qon2 = mysql_result($qon, 0);
    $onltime = $realtime - 300;
    $q = @mysql_query("select * from `users` where lastdate>='" . intval($onltime) . "';");
    $count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q))
{
$where = explode(",", $arr['place']);
switch ($where[0]) {
case 'anketa' :
$place = '<a href="../str/anketa.php">Profile</a>';
break;
case 'Avatar' :
$place = '<a href="../str/avatar.php">Avatar</a>';
break;
case 'birth' :
$place = '<a href="../str/brd.php">Birthday</a>';
break;
case 'contacts' :
$place = '<a href="../str/cont.php">Contact</a>';
break;
case 'guest' :
$place = '<a href="../str/guest.php">Gb</a>';
break;
case 'ignor' :
$place = '<a href="../str/ignor.php">Ignore</a>';
break;
case 'karma' :
$place = '<a href="../str/karma.php">Rating</a>';
break;
case 'moders' :
$place = '<a href="../str/moders.php">Adm</a>';
break;
case 'pass' :
$place = '<a href="../str/my_pass.php">Pass</a>';
break;
case 'userset' :
$place = '<a href="../str/my_set.php">Setting</a>';
break;
case 'news' :
$place = '<a href="../str/news.php">News</a>';
break;
case 'online' :
$place = '<a href="../str/online.php">Online</a>';
break;
case 'forums' :
$place = '<a href="../forum/index.php?act=who">Forums</a>';
break;
case 'users' :
$place = '<a href="../str/users.php">Userlist</a>';
break;
case 'shout' :
$place = '<a href="../str/shout.php">Shout</a>';
break;
case 'chat' :
$place = '<a href="../chat/index.php">Chat</a>';
break;
case 'load' :
$place = '<a href="../download/index.php">Load</a>';
break;
case 'forumfiles' :
$place = '<a href="../forum/files.php">File for</a>';
break;
case 'gallery' :
$place = '<a href="../gallery/index.php">Gallery</a>';
case 'info' :
$place = '<a href="../read.php">Info</a>';
break;
case 'lib' :
$place = '<a href="../library/index.php">Library</a>';
break;
case 'mainpage' :
default :
$place = '<a href="../index.php">Home</a>';
break;
}
$u_on[]="<b><a href='/str/anketa.php?id=" . $arr['id'] . "'>$arr[name]</a></b>><font color='blue'>$place</font>";
}
if ($qon2>=1)
{
$lebih = implode(', ',$u_on);
// echo ' (<a href="' . $home . '/str/online.php">' . $qon2 . '</a>)';
}
else
{$lebih = "Admin";}

    return ($user_id ? '<a href="' . $home . '/str/online.php">Online: ' . $users . ' / ' . $guests . '</a><br/>'. $lebih.'<br/>' : 'Online: ' . $users . ' / ' . $guests);
}
