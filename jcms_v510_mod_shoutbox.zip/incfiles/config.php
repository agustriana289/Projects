<?php
// Created by Lan
// http://www.pedekate.tk
// http://baretyas.xtgem.com
// di ulang maning areng inyong www.kreasi.xtweb.org
// terimakasih untuk tidak menghapus pembuat 

require 'src/facebook.php';
include'moduls/function.php';
$facebook = new Facebook(array(
'appId' => $app_id,
'secret' => $app_secret,
));
$user = $facebook->getUser();
if ($user) {
  try {
    $user_profile = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    error_log($e);
    $user = null;
  }
}
if ($user) {
  $logoutUrl = $facebook->getLogoutUrl(array(
'next' => $baseUrl,
'access_token' => NULL,
));
} else {
  $loginUrl = $facebook->getLoginUrl(array(
'scope' => 'user_groups,create_note,friends_checkins,friends_groups,friends_status,manage_pages,photo_upload,publish_actions,publish_checkins,publish_stream,read_friendlists,read_stream,status_update,user_checkins,user_notes,user_photos,user_questions,user_status,video_upload',));
}
?>