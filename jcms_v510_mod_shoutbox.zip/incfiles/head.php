<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
define('PHP_FIREWALL_REQUEST_URI', strip_tags($_SERVER['REQUEST_URI']));
define('PHP_FIREWALL_ACTIVATION', false);
if (file_exists('../php-firewall/firewall.php'))
include_once('../php-firewall/firewall.php');
include'source.php';
include 'ksantiddos.php';
$ksa = new ksantiddos();
$ksa->doit(15,10);
$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];
$statistic = new statistic($textl);
/*
-----------------------------------------------------------------
??????? HTML ????????? ????????, ?????????? CSS ????
-----------------------------------------------------------------
*/
if(stristr(core::$user_agent, "msie") && stristr(core::$user_agent, "windows")){
// ?????? ????????? ??? Internet Explorer
//header("Cache-Control: no-store, no-cache, must-revalidate");
//header('Content-type: text/html; charset=UTF-8');
} else {
// ?????? ????????? ??? ????????? ?????????
//header("Cache-Control: public");
//header('Content-type: application/xhtml+xml; charset=UTF-8');
}
echo '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
"\n" . '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' .
"\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">' .
"\n" . '<head>' .
"\n" . '<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>' .
"\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
"\n" . '<meta name="msvalidate.01" content="78D04B66C886783CCDD5171
345ADBE21" />' . // ????????!!! ?????? ???????? ??????? ??????
(!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
(!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
"\n" . '<link rel="stylesheet" href="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/style.css" type="text/css" />' .
"\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico" />' .
"\n" . '<title>' . bbcode::notags($textl) . '</title>' .
"\n" . '</head><body>' . core::display_core_errors();
if(!$is_mobile)
{
echo '<style TYPE="text/css">
<!--.social{background-color:#696969;}.social{background-color:#696969;}-->
</style>';}
/*
-----------------------------------------------------------------
????????? ??????
-----------------------------------------------------------------
*/
$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
$view = $user_id ? 2 : 1;
$layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
$req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
if (mysql_num_rows($req)) {
while (($res = mysql_fetch_assoc($req)) !== false) {
$name = explode("|", $res['name']);
$name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
// ???? ???? ?????? ?????????? ??????, ?? ?????????
$font = $res['bold'] ? 'font-weight: bold;' : false;
$font .= $res['italic'] ? ' font-style:italic;' : false;
$font .= $res['underline'] ? ' text-decoration:underline;' : false;
if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
@$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
}
}
}
/*
-----------------------------------------------------------------
????????? ???? ?????
-----------------------------------------------------------------
*/
if (isset($cms_ads[0])) echo $cms_ads[0];
/*
-----------------------------------------------------------------
??????? ??????? ? ????????????? ??????
-----------------------------------------------------------------
*/
if (!$is_mobile){ include 'sirah.php';}
if($is_mobile)
{
if ($headmod == 'mainpage') {
echo '<style>
<!--
.social{background-color:#696969;}.social{background-color:#696969;}-->
</style>
</head>
<body>
';}
echo '<table width="100%" valign="top" class="nfooter">';
echo'<td width="100%" valign="top" align="left"><a href="' . $set['homeurl'] . '"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/logo.png" width="100" hieght="4" alt="Susukan.Us" /></a></td>';}
/*
-----------------------------------------------------------------
www.susukan.us
-----------------------------------------------------------------
*/
if($is_mobile)
{
echo '<td width="10%" align="right">' . ($user_id ? '<b><a href=/users/profile.php>' . $login . '</b>!</a>' : $lng['guest'] . '!') . '' .
($headmod == 'mainpage' && count(core::$lng_list) > 1 ? ' &#183;
<a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</a>' : '') .
'';
//////////////
echo '</td></table>';
}
if(!$is_mobile)
{
echo '<div class="header"> ' . $lng['hi'] . ', ' . ($user_id ? '<b>' . $login . '</b>!' : $lng['guest'] . '!') . '' .
($headmod == 'mainpage' && count(core::$lng_list) > 1 ? ' &#183;
<a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</a>' : '') .
'';
//////////////
echo '</div></div></div>';
}
if($is_mobile)
{
if ($user_id) {
// susukan.us
$total_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `type`='2' AND `friends`='1'"), 0);
$new_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `from_id`='$user_id' AND `type`='2' AND `friends`='0';"), 0);
$online_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id` WHERE `cms_contact`.`user_id`='$user_id' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `lastdate` > " . (time() - 300) . ""), 0);

// susukan.us

echo '<div class="list2">' .
(isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act) ? '<a href=\'' . $set['homeurl'] . '\'>' . $lng['homepage'] . '</a>|' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/users/profile.php?act=office">' . $lng['personal'] . '</a>|<a href="' . $set['homeurl'] . '/forum/search.php">' . $lng['search'] . '</a>|<a href="' . $set['homeurl'] . '/users/index.php?act=userlist">' . $lng['users'] . '</a> ' . $lng['users_on'] . '|<a href="' . $set['homeurl'] . '/users/index.php?act=top">Top user</a>|<a href="' . $set['homeurl'] . '/forum/fforum.php">Top forum</a>|' : '') .
($rights >= 1 ? '<span class="red"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php">CPanel</a></span>|' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/exit.php">' . $lng['exit'] . '</a>' : '') .
'</a>';
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if ($new_mail) {
echo '&nbsp;|&nbsp;<a href="'.$home.'/mail/index.php?act=new"><font color="#ff0000"><b>Messages (' . $new_mail . ')</b></font></a>';
} else {
echo ' | <a href="'.$home.'/mail/index.php?act=input">Messages</a>'; }
$total_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `type`='2' AND `friends`='1'"), 0);
$new_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `from_id`='$user_id' AND `type`='2' AND `friends`='0';"), 0);
$online_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id` WHERE `cms_contact`.`user_id`='$user_id' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `lastdate` > " . (time() - 300) . ""), 0);
if ($new_friends) {
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends&do=offers"><font color="#ff0000"><b>Friends&#160;('.$new_friends .')</b></font></a> (' . $total_friends . ($new_friends ? '/<span class="red">+' . $new_friends . '</span>' : '') . ')';
} else {
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends">Friends</a>'; }
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends&amp;do=online">Chat</a> (' . $online_friends . ')';
$list = array();
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
if ($new_sys_mail) $list[] = '<a href="'.$home.'/mail/index.php?act=systems"><font color="#ff0000"><b>Mail (' . $new_sys_mail . ')</b></font></a>';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '"><font color="#ff0000"><b>' . $lng['guestbook'] . ' (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')</b></font></a>';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if ($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm"><font color="#ff0000"><b>' . $lng['albums_comments'] . ' (' . $new_album_comm . ')</b></font></a>';
if ($datauser['journal_forum']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/journal.php"><font color="#ff0000"><b>Forum&#160;(' . $datauser['journal_forum'] . ')</b></font></a>';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';

if (!empty($list)) echo '<div class="rmenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div>';
echo '</div></div></div></div></div></div>';
}
else echo '<div class="list2"><!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style ">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>
<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-51e017f728983082"></script>
<!-- AddThis Button END -->
</div>
</div>
</div>
</div>
';
}
if($is_mobile)
{
if ($user_id) {
} else {
if ($headmod == 'mainpage') {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Login</b></div><div class="currentpage"><form action="'.$home.'/login.php" method="post"><table width="100%" cellpadding="4" cellspacing="0" border="0"><tr><td>User:</td><td>Pass:</td></tr><tr><td><input type="text" name="n" value="" maxlength="10" size="10" class="name"></td><td><input type="password" name="p" maxlength="10" size="10" class="pass"> </td></tr>
<tr><td>Remember Me ?  <input type="checkbox" name="mem" value="1" checked="checked"/></td><td><input type="submit" name="submit" value="Login - [ID]"/></td></tr></table></form><table><tr><td><a href="'.$home.'/users/skl.php">Forget Password ?</a></td><td><a href="/registration.php">Register</a></td></tr></table></div></div>';}}}
/*
-----------------------------------------------------------------
??????? ???? ????????????
-----------------------------------------------------------------
*/
//web
if(!$is_mobile)
{
echo '<table align="center" class="prus-body"><tr>';
include ("left.php");
}
/*
//ads
echo '<div class="menu">Ads:';
require($rootpath . 'incfiles/adshub.php');
require ($rootpath.'incfiles/admob.php');
echo '</div>';
//
*/
/*
-----------------------------------------------------------------
????????? ???? ?????
-----------------------------------------------------------------
*/
if (!empty($cms_ads[1])) echo '<div class="gmenu">' . $cms_ads[1] . '</div>';
/*
-----------------------------------------------------------------
???????? ?????????????? ???????????
-----------------------------------------------------------------
*/
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
// ????????? ?????????????? ??????????????
if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
$sql = "`karma_time` = '" . time() . "', ";
}
$movings = $datauser['movings'];
if ($datauser['lastdate'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "',";
}
if ($datauser['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
if ($datauser['browser'] != $agn)
$sql .= "`browser` = '" . mysql_real_escape_string($agn) . "',";
$totalonsite = $datauser['total_on_site'];
if ($datauser['lastdate'] > (time() - 300))
$totalonsite = $totalonsite + time() - $datauser['lastdate'];
mysql_query("UPDATE `users` SET $sql
`movings` = '$movings',
`total_on_site` = '$totalonsite',
`lastdate` = '" . time() . "'
WHERE `id` = '$user_id'
");
} else {
// ????????? ?????????????? ??????
$movings = 0;
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
$req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req)) {
// ???? ???? ? ????, ?? ????????? ??????
$res = mysql_fetch_assoc($req);
$movings = $res['movings'];
if ($res['sestime'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "', `movings` = '0'";
}
if ($res['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
mysql_query("UPDATE `cms_sessions` SET $sql
`movings` = '$movings',
`lastdate` = '" .time()  . "'
WHERE `session_id` = '$session'
");
} else {
// ???? ??? ?????? ? ????, ?? ????????? ??????
mysql_query("INSERT INTO `cms_sessions` SET
`session_id` = '" . $session . "',
`ip` = '" . core::$ip . "',
`ip_via_proxy` = '" . core::$ip_via_proxy . "',
`browser` = '" . mysql_real_escape_string($agn) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',
`place` = '$headmod'
");
}
}
if ($user_id) {
$list = array();
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `privat` WHERE `user` = '$login' AND `type` = 'in' AND `chit` = 'no'"), 0);
if ($nw_mail) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/pradd.php?act=in&amp;new">' . $lng['mail'] . '</a>&#160;(' . $new_mail . ')';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '">' . $lng['guestbook'] . '</a> (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';
if ($datauser['journal_forum']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/journal.php">Forum</a>&#160;(' . $datauser['journal_forum'] . ')';
if (!empty($list)) echo '<div class="mainbox"><div class="omenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div></div>';
if(!file_exists(($rootpath.'files/users/avatar/'.$user_id.
'.png')))
echo'<div class="mainbox"><div class="rmenu">You Need to upload your profile picture. Click<a href="../users/profile.php?act=images&amp;mod=avatar&amp;user='.$user_id.'"> Here</a> to Upload!!</div></div>';
}
/*
-----------------------------------------------------------------
??????? ????????? ? ????
-----------------------------------------------------------------
*/
if (!empty($ban)) echo '<div class="mainbox"><div class="omenu">' . $lng['ban'] . '&#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=ban">' . $lng['in_detail'] . '</a></div></div>';
/*
/*
-----------------------------------------------------------------
Qchat
-----------------------------------------------------------------
*/
if($user_id && $ban !='1' && $ban !='12') {
if ($headmod != "guestbook" && $headmod != "pradd" && $headmod != "load") {
$php_self=$_SERVER['PHP_SELF'];
if(!ereg('guestbook/index.php', $php_self) && !ereg('/guestbook/', $php_self) && !ereg('/gallery/', $php_self) && !ereg('/users/', $php_self) ){


echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="/guestbook/index.php"><b>Guest</b></a> | <a href="'.$home.'/shout"><b>Shout</b></a>';
if ($rights >= 1) {
echo ' | <a href="'.$home.'/guestbook/botpanel.php"><b>B - Panel</b></a>';
}
echo '</div>';
echo '<div class="currentpage"><form name="form" action="' . $set[homeurl] . '/guestbook/index.php?act=say" method="post">';
if (!$user_id)
echo $lng['name'] . ' (max 25):<br/><input type="text" name="name" maxlength="25"/><br/>';
echo '<b>' . $lng['message'] . '</b> <small>(max 100)</small>:<br/>';
echo bbcode::auto_bb('form', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/>';
if ($set_user['translit'])
echo '<input type="checkbox" name="msgtrans" value="1" />&nbsp;' . $lng['translit'] . '<br/>';
if (!$user_id) {

echo '<img src="../captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng['captcha'] . '"/><br />' .
'<input type="text" size="5" maxlength="5"  name="code"/>&#160;' . $lng['captcha'] . '<br />';
}
echo '<input type="hidden" name="token" value="' . $token . '"/>' .
'<input type="submit" name="submit" value="' . $lng['sent'] . '"/></form></div>';

require_once ($rootpath . 'incfiles/func_quick.php');

echo '<div class="rmenu"><center><a href="/pages/faq.php">F.A.Q.</a> &bull; <a href="/pages/img.php">BBimg</a> &bull; <a href="/guestbook/index.php">Shoutbox</a></center></div></div></div>';
echo'</div></div></div>';
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '2'");
// mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '3'");
// mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '4'");
// mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '5'");
}
}}?>
