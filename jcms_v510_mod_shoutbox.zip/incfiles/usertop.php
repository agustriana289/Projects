<?

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

/*
-----------------------------------------------------------------
Mod main menu by: ton http://kashur.cz.cc
-----------------------------------------------------------------
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="nfooter"><b>User Top</b></div>';

function get_top($order = 'postforum') {
global $lng;
$req = mysql_query("SELECT * FROM `users` WHERE `$order` > 0 ORDER BY `$order` DESC LIMIT 3");
if (mysql_num_rows($req)) {
$out = '';
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
$out .= $i % 2 ? '<div class="list2">' : '<div class="list1">';
$out .= functions::display_user
($res, array ('iphide' =>1,
('<b>' . $res[$order]) . '<b>')) .
'</div>';
++$i;
}
return $out;
} else {
return '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
}

echo get_top('postforum');


$mp = new mainpage();


?>