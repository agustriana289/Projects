<?
echo '<td class="prus-right">';




defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $lng_profile['my_office'];
if ($user['id'] = $user_id) {
$list = array();
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
if ($new_sys_mail) $list[] = '<a href="' . $home . '/mail/index.php?act=systems">eAezN?N,elezez</a> (+' . $new_sys_mail . ')';
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if ($new_mail) $list[] = '<a href="' . $home . '/mail/index.php?act=new">' . $lng['mail'] . '</a> (+' . $new_mail . ')';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '">' . $lng['guestbook'] . '</a> (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if ($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';
if (!empty($list)) echo '<div class="omenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div>';
}
if ($user['id'] = $user_id) {

echo '<div class="nfooter"><b>User Menu</b></div>';
echo '<div class="menu"><p><h3><img src="../images/mail.png" width="16" height="16" class="left" />&nbsp;My Mail Box</h3><ul>';
$count_input = mysql_result(mysql_query("
SELECT COUNT(*)
FROM `cms_mail`
LEFT JOIN `cms_contact`
ON `cms_mail`.`user_id`=`cms_contact`.`from_id`
AND `cms_contact`.`user_id`='$user_id'
WHERE `cms_mail`.`from_id`='$user_id'
AND `cms_mail`.`sys`='0' AND `cms_mail`.`delete`!='$user_id'
AND `cms_contact`.`ban`!='1' AND `spam`='0'"), 0);
echo '<li><a href="../mail/index.php?act=input">Received</a>&nbsp;(' . $count_input . ($new_mail ? '/<span class="red">+' . $new_mail . '</span>' : '') . ')</li>';
//e~N?Naeze'NZNeezel N?ezezeaNeele"ezNZ
$count_output = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`from_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id'
WHERE `cms_mail`.`user_id`='$user_id' AND `cms_mail`.`delete`!='$user_id' AND `cms_mail`.`sys`='0' AND `cms_contact`.`ban`!='1'"), 0);
//e~N?Naeze'NZNeezel e"elezNEezN?ezN,eze"e"N<el N?ezezeaNeele"ezNZ
$count_output_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`from_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id'
WHERE `cms_mail`.`user_id`='$user_id' AND `cms_mail`.`delete`!='$user_id' AND `cms_mail`.`read`='0' AND `cms_mail`.`sys`='0' AND `cms_contact`.`ban`!='1'"), 0);
echo '<li><a href="../mail/index.php?act=output">Sent</a>&nbsp;(' . $count_output . ($count_output_new ? '/<span class="red">+' . $count_output_new . '</span>' : '') . ')</li>';
$count_systems = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail`
WHERE `from_id`='$user_id' AND `delete`!='$user_id' AND `sys`='1'"), 0);
//eAezN?N,eleze"N<el N?ezezeaNeele"ezNZ
$count_systems_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail`
WHERE `from_id`='$user_id' AND `delete`!='$user_id' AND `sys`='1' AND `read`='0'"), 0);
echo '<li><a href="../mail/index.php?act=systems">Systems</a>&nbsp;(' . $count_systems . ($count_systems_new ? '/<span class="red">+' . $count_systems_new . '</span>' : '') . ')</li>';
//eRezesetN<
$count_file = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail`
WHERE (`user_id`='$user_id' OR `from_id`='$user_id') AND `delete`!='$user_id' AND `file_name`!='';"), 0);
echo '<li><a href="../mail/index.php?act=files">' . $lng['files'] . '</a>&nbsp;(' . $count_file . ')</li>';
if (empty($ban['1']) && empty($ban['3'])) {
echo '<p><form action="../mail/index.php?act=write" method="post"><input type="submit" value="' . $lng['write'] . '"/></form></p>';
}
echo '</div>';
}
if($user_id){
echo '<div class="nfooter"><b>Last Forum Upload</b></div>';
$req = mysql_query("SELECT * FROM `cms_forum_files` ORDER BY `id` DESC LIMIT 5");
$i = 0;
while($file = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$path = $file['filename'];
$fls = round(@filesize('../files/forum/attach/' . $path) / 1024, 2);
echo '<img class="middle" src="images/file.gif" alt="'.$file['id'].'"/> <a href="forum/index.php?act=file&id='.$file['id'].'">'.$file['filename'].'</a> ('.$fls.'KB)';
echo '</div>';
++$i;
}}
echo '</div>';
require($rootpath . 'incfiles/usertop.php');
if ($headmod != "mainpage") {
echo '<div class="nfooter"><b>Last Blog</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs`"), 0);
$r = mysql_query
("SELECT * FROM `blogs` ORDER BY id DE
start, 1");
if ($total == 0)
echo '<div class="rmenu">No blogs!</div>';
$res = mysql_query("SELECT * FROM `blogs`
ORDER BY id DESC LIMIT 1");
while($req = mysql_fetch_array($res)) {
echo $i % 2 ? '<div class="list1">' : '<div class="">';
$totkom = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE `refid` = '$req[id]'"), 0);
$totlook = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE place_id='$req[id]' AND type='b'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$req[user]'"));
$set_user['avatar'] = 0;
echo '<img src="../images/pt.gif" alt=""/>&#160;<a href="blogs/view.php?id='.$req['id'].'">'.$req['name'].'</a><br/><small>Posted by</small> <a
href="'.$home.'/users/' . $user['name'] . '">' . $user['name'] . '</a><div class="gray">Date:<small>'.date("d F. h:ia", $req['time'] + $set_user['sdvig'] * 3600).'</small><br/>Comments: ' . $totkom . '<br/>';
++$i;
echo '</div></div></div>';
}}
else {
echo '<div class="nfooter"><b>Find Us On Facebook</b></div>';
echo '<div class="list1"><iframe src="http://www.facebook.com/plugins/like.php?href=http://fb.me/upapp.nu&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font=tahoma&amp;colorscheme=light" scrolling="no" frameborder="0" allowTransparency="true&quot; style="border:none; overflow:hidden; height:35px"></iframe></div>';
}
?>