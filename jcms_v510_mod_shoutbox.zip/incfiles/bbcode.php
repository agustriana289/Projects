<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

/*
-----------------------------------------------------------------
РћР±СЂР°Р±РѕС‚РєР° СЃСЃС‹Р»РѕРє Рё С‚СЌРіРѕРІ BBCODE РІ С‚РµРєСЃС‚Рµ
-----------------------------------------------------------------
*/
function rainbow($text) {
$text = trim(stripslashes($text));
$result="";
$font=0;
$turn=0;
while(
$font<=strlen($text)){ $font_color = mb_substr($text,$font,1,'UTF-8');
$font++;
if($turn==0){ $turn=1; $result.= "<FONT color=\"#ff00ff\">".$font_color."</FONT>"; }
else if($turn==1){ $turn=2; $result.= "<FONT color=\"#ff00cc\">".$font_color."</FONT>"; }
else if($turn==2){ $turn=3; $result.= "<FONT color=\"#ff0099\">".$font_color."</FONT>"; }
else if($turn==3){$turn=4; $result.= "<FONT color=\"#ff0066\">".$font_color."</FONT>"; } 
else if($turn==4){$turn=5; $result.= "<FONT color=\"#ff0033\">".$font_color."</FONT>"; } 
else if($turn==5){$turn=6; $result.= "<FONT color=\"#ff0000\">".$font_color."</FONT>"; } 
else if($turn==6){$turn=7; $result.= "<FONT color=\"#ff3300\">".$font_color."</FONT>"; } 
else if($turn==7){$turn=8; $result.= "<FONT color=\"#ff6600\">".$font_color."</FONT>"; }
else if($turn==8){$turn=9; $result.= "<FONT color=\"#ff9900\">".$font_color."</FONT>"; }
else if($turn==9){$turn=10; $result.= "<FONT color=\"#ffcc00\">".$font_color."</FONT>"; } 
else if($turn==10){$turn=11; $result.= "<FONT color=\"#ffff00\">".$font_color."</FONT>"; } 
else if($turn==11){$turn=12; $result.= "<FONT color=\"#ccff00\">".$font_color."</FONT>"; } 
else if($turn==12){$turn=13; $result.= "<FONT color=\"#99ff00\">".$font_color."</FONT>"; }
else if($turn==13){$turn=14; $result .= "<FONT color=\"#66ff00\">".$font_color."</FONT>"; } 
else if($turn==14){$turn=15; $result .= "<FONT color=\"#33ff00\">".$font_color."</FONT>"; } 
else if($turn==15){$turn=16; $result .= "<FONT color=\"#00ff00\">".$font_color."</FONT>"; } 
else if($turn==16){$turn=17; $result .= "<FONT color=\"#00ff33\">".$font_color."</FONT>"; } 
else if($turn==17){$turn=18; $result .= "<FONT color=\"#00ff66\">".$font_color."</FONT>"; } 
else if($turn==18){$turn=19; $result .= "<FONT color=\"#00ff99\">".$font_color."</FONT>"; } 
else if($turn==19){$turn=20; $result .= "<FONT color=\"#00ffcc\">".$font_color."</FONT>"; } 
else if($turn==20){$turn=21; $result .= "<FONT color=\"#00ffff\">".$font_color."</FONT>"; }
else if($turn==21){$turn=22; $result .= "<FONT color=\"#00ccff\">".$font_color."</FONT>"; } 
else if($turn==22){$turn=23; $result .= "<FONT color=\"#0099ff\">".$font_color."</FONT>"; } 
else if($turn==23){$turn=24; $result .= "<FONT color=\"#0066ff\">".$font_color."</FONT>"; } 
else if($turn==24){$turn=25; $result .= "<FONT color=\"#0033ff\">".$font_color."</FONT>"; } 
else if($turn==25){$turn=26; $result .= "<FONT color=\"#0000ff\">".$font_color."</FONT>"; } 
else if($turn==26){$turn=27; $result .= "<FONT color=\"#3300ff\">".$font_color."</FONT>"; } 
else if($turn==27){$turn=28; $result .= "<FONT color=\"#6600ff\">".$font_color."</FONT>"; } 
else if($turn==28){$turn=29; $result .= "<FONT color=\"#9900ff\">".$font_color."</FONT>"; } 
else if($turn==29){$turn=0; $result .= "<FONT color=\"#cc00ff\">".$font_color."</FONT>"; } 
}
$result = html_entity_decode($result ,ENT_QUOTES,'UTF-8');
return $result; 
}
function tags($var = '') {
$var= preg_replace(array ('#\[7mau\](.*?)\[\/7mau\]#se'), array ("''.rainbow('$1').''"), str_replace("]\n", "]", $var));
global $login;
$var = preg_replace(array('#\[php\](.*?)\[\/php\]#se'), array("''.highlight('$1').''"), str_replace("]\n", "]", $var));
$var = preg_replace('#\[code\](.*?)\[/code\]#si', '<div class="topmenu">Mã</div><div class="quote">\1</div>', $var);
$var = preg_replace('#\[text\](.*?)\[/text\]#si', 'TEXT:<br><textarea>\1</textarea><br>', $var);
$var = preg_replace('#\[vblue\](.*?)\[/vblue\]#si', '<span style="text-shadow: 1px 3px 9px blue;">\1</span>', $var);
$var = preg_replace('#\[vgreen\](.*?)\[/vgreen\]#si', '<span style="text-shadow: 1px 3px 9px green;">\1</span>', $var);
$var = preg_replace('#\[vred\](.*?)\[/vred\]#si', '<span style="text-shadow: 1px 3px 9px red;">\1</span>', $var);
$var = preg_replace('#\[b\](.*?)\[/b\]#si', '<span style="font-weight: bold;">\1</span>', $var);
$var = str_replace('[br]', '<br>', $var);
$var = preg_replace('#\[i\](.*?)\[/i\]#si', '<span style="font-style:italic;">\1</span>', $var);
$var = preg_replace('#\[u\](.*?)\[/u\]#si', '<span style="text-decoration:underline;">\1</span>', $var);
$var = preg_replace('#\[s\](.*?)\[/s\]#si', '<span style="text-decoration: line-through;">\1</span>', $var);
$var = preg_replace('#\[phai\](.+?)\[/phai\]#is', '<div align="right">\1</div>', $var );
$var = preg_replace('#\[center\](.+?)\[/center\]#is', '<div align="center">\1</div>', $var );
$var = preg_replace('#\[CENTER\](.+?)\[/CENTER\]#is', '<div align="center">\1</div>', $var );
$var = preg_replace('#\[LEFT\](.+?)\[/LEFT\]#is', '<div align="left">\1</div>', $var );
$var = preg_replace('#\[left\](.+?)\[/left\]#is', '<div align="left">\1</div>', $var );
$var = preg_replace('#\[right\](.+?)\[/right\]#is', '<div align="right">\1</div>', $var );
$var = preg_replace('#\[RIGHT\](.+?)\[/RIGHT\]#is', '<div align="right">\1</div>', $var );
$var = preg_replace('#\[trai\](.+?)\[/trai\]#is', '<div align="left">\1</div>', $var );
$var = preg_replace('#\[giua\](.+?)\[/giua\]#is', '<div align="center">\1</div>', $var );
$var = preg_replace('#\[red\](.*?)\[/red\]#si', '<span style="color:red">\1</span>', $var);
$var = preg_replace('#\[green\](.*?)\[/green\]#si', '<span style="color:green">\1</span>', $var);
$var = preg_replace('#\[black\](.*?)\[/black\]#si', '<span style="color:black">\1</span>', $var);
$var = preg_replace('#\[blue\](.*?)\[/blue\]#si', '<span style="color:blue">\1</span>', $var);
$var = preg_replace('#\[c\](.*?)\[/c\]#si', '<div class="topmenu">Trích dẫn</div><div class="quote">\1</div>', $var);
$var = preg_replace('#\[quote=(.*?)\](.*?)\[/quote\]#si', '<div class="topmenu">\1 đã viết</div><div class="quote">\2</div>', $var);
$var = preg_replace('#\[img=(.+?)\]#is', '<a href="http://\1"><img src="http://\1" alt="click" border="0" width="60" /></a><br/>', $var);
$var = preg_replace('#\[img](.+?)\[/img]#is', '<a href="http://\1"><img src="http://\1" alt="click" border="0" width="110" /></a><br/>', $var);
$var = preg_replace('#\[img=(.+?)\][/img]#is', '<a href="http://\1"><img src="http://\1" alt="click" border="0" width="110" /></a><br/>', $var);
$var = preg_replace('#\[COLOR=(.+?)\](.+?)\[/COLOR\]#is', '<font color="\1;">\2</font>', $var );
$var = preg_replace('#\[color=(.+?)\](.+?)\[/color\]#is', '<font style="color:\1;">\2</font>', $var );
$var = preg_replace('#\[SIZE=(.+?)\](.+?)\[/SIZE\]#is', '<font style="font-size:\1;">\2</font>', $var );
$var = preg_replace('#\[size=(.+?)\](.+?)\[/size\]#is', '<font style="font-size:\1;">\2</font>', $var );
$var = preg_replace('#\[FONT=(.+?)\](.+?)\[/FONT\]#is', '<font face="\1">\2</font>', $var );
$var = preg_replace('#\[font=(.+?)\](.+?)\[/font\]#is', '<font face="\1">\2</font>', $var );
$var = preg_replace("#\[url=(.+?)\](.+?)\[/url\]#is", "".("<a href=\"http://\\1\">\\2</a>")."", $var );
$var = preg_replace("#\[URL=(.+?)\](.+?)\[/URL\]#is", "".("<a href=\"http://\\1\">\\2</a>")."", $var );
$var = str_replace('[you]', $login, $var);
return $var;
}
//---Url---//
function auto_title($url) {
$u = $url;
$link = $u;
$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, $header); //trace header response
curl_setopt($ch, CURLOPT_NOBODY, $header); //return body
curl_setopt($ch, CURLOPT_URL, $u); //curl Targeted URL
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $ref); //fake referer
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$kq = curl_exec($ch);
curl_close($ch);
if(preg_match("/\<title\>(.*)\<\/title\>/", $kq, $title)) {
return $title[1];
} else {
return $url;
}
}
function url($var)
{
if (!function_exists('process_url')) {
function process_url($url)
{
if (!isset($url[3])) {
$tmp = parse_url($url[1]);
if ('http://' . $tmp['host'] == core::$system_set['homeurl'] || isset(core::$user_set['direct_url']) && core::$user_set['direct_url']) {
return '<a href="' . $url[1] . '">' . $url[2] . '</a>';
} else {
return '<a href="' . core::$system_set['homeurl'] . '/go.php?url=' . base64_encode($url[1]) . '">' . $url[2] . '</a>';
}
} else {
return '<a href="' . $url[3] . '" target="_blank">' . auto_title($url[3]) . '</a>';
}
}
}
$var = str_replace('[img=http://', '[img=', $var);
$var = str_replace('[IMG=http://', '[IMG=', $var);
$var = str_replace('[url=http://', '[url=', $var);
$var = str_replace('[URL=http://', '[URL=', $var);
$var = str_replace('[img]http://', '[img]', $var);
$var = str_replace('[IMG]http://', '[IMG]', $var);
return preg_replace_callback('~\\[url=(https?://.+?)\\](.+?)\\[/url\\]|(https?://(www.)?[0-9a-z\.-]+\.[0-9a-z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', 'process_url', $var);
}
function notags($var = '') {
$var = strtr($var, array (
'[green]' => '',
'[/green]' => '',
'[/vgreen]' => '',
'[/vred]' => '',
'[/vblue]' => '',
'[vgreen]' => '',
'[vred]' => '',
'[vblue]' => '',
'[red]' => '',
'[/red]' => '',
'[blue]' => '',
'[/blue]' => '',
'[b]' => '',
'[/b]' => '',
'[i]' => '',
'[/i]' => '',
'[u]' => '',
'[/u]' => '',
'[s]' => '',
'[/s]' => '',
'[c]' => '',
'[/c]' => ''
));

return $var;
}
function highlight($php) {
$php = strtr($php, array (
'<br />' => '',
'\\' => 'slash_JOHNCMS'
));

$php = html_entity_decode(trim($php), ENT_QUOTES, 'UTF-8');
$php = substr($php, 0, 2) != "<?" ? $php = "<?php\n" . $php . "\n?>" : $php;
$php = highlight_string(stripslashes($php), true);
$php = strtr($php, array (
'slash_JOHNCMS' => '&#92;',
':' => '&#58;',
'[' => '&#91;',
'&nbsp;' => ' '
));

return '<div class="phpcode">' . $php . '</div>';
}
?>
