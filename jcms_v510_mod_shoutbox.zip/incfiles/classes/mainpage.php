<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Restricted access');

class mainpage {
public $news;         // eceue?i'?N?N, e?i'?e?i'?e2e?i'?N?N,eue?i'?
public $newscount;    // eze+Neeueu e?i'?-e2e?i'? e?i'?e?i'?e2e?i'?N?N,eue?i'?
public $lastnewsdate; // e"ezN,ez e?i'?e?i'?N?e?i'?eue'e?i'?eue?i'? e?i'?e?i'?e2e?i'?N?N,e?
private $settings = array ();
function __construct() {
global $set;
$this->settings = unserialize($set['news']);
$this->newscount = $this->newscount() . $this->lastnewscount();
$this->news = $this->news();
}

// e-eze?i'?NEe?i'?N? N?e2eue?e?Na e?i'?e?i'?e2e?i'?N?N,eue?i'? e?i'?ez e"e?i'?eze2e?i'?N?NZ
private function news() {
global $lng;
if ($this->settings['view'] > 0) {
$reqtime = $this->settings['days'] ? time() - ($this->settings['days'] * 86400) : 0;
$req = mysql_query("SELECT * FROM `news` WHERE `time` > '$reqtime' ORDER BY `time` DESC LIMIT " . $this->settings['quantity']);
if (mysql_num_rows($req) > 0) {
$i = 0;
$news = '';
while (($res = mysql_fetch_array($req)) !== false) {
$text = $res['text'];
// eAN?e?i'?e? N,eue?i'?N?N, e+e?i'?e?i'?NSN^eu e.eze'eze?i'?e?i'?e?i'?e3e?i'? e?i'?NEeue'eue?i'?ez, e?i'?e+NEeue.ezeue?i'?
if (mb_strlen($text) > $this->settings['size']) {
$text = mb_substr($text, 0, $this->settings['size']);
$text = htmlentities($text, ENT_QUOTES, 'UTF-8');
$text .= ' <a href="news/index.php">' . $lng['next'] . '...</a>';
} else {
$text = htmlentities($text, ENT_QUOTES, 'UTF-8');
}
// eAN?e?i'?e? e2e?i'?e?i'?NZN?eue?i'?N< e?i'?euNEeue?i'?e?i'?N?N<, N,e?i'? e?i'?e+NEeze+ezN,N<e2ezeue?i'?
if ($this->settings['breaks'])
$text = str_replace("\r\n", "", $text);
// eze+NEeze+ezN,N<e2ezeue?i'? N,NTe3e?
if ($this->settings['tags']) {
$text = bbcode::tags($text);
} else {
$text = bbcode::notags($text);
}
// A?i'?A A'A?A?i'?A,A+A?i'?A A'A?A?i'?A,AzA?i'?A,A+A?i'?A,AzA?i'?A A'A?A?i'?A A'A?A?i'?A,A2A?i'?A,AzA?i'?A,AuA?i'? A?A A,A'A,A? A?i'?A A'A?A?i'? A?A A,A'A,A?A?i'?A,AzA?i'? A?A A,A'A,A?A?i'? A?A A,A'A,A?A?i'?A A'A?
if ($this->settings['smileys']) {
$text = functions::smileys($text);
}
// A?i'?A A'A?A?i'? A?A A,A'A,A?A?i'?A A'A?A?i'?A,AuA?i'?A,A'A?i'?A,AuA?i'? A?A A,A'A,A?A?i'?A A'A?A?i'?A,AuA?i'? A?A A,A'A,A? A?i'?A A'A?A?i'?A,AuA?i'?A,A?A?i'?A,A?A?i'? A?A A,A'A,A? A?i'? A?A A,A'A,A?A?i'?A A'A?A?i'? A?A A,A'A,A?A?i'?A A'A?A?i'? A?A A,A'A,A?A?i'? A?A A,A'A,A?A?i'?A A'A?A?i'?A A'A?A?i'?A,Az A?i'?A,A.A?i'?A,AzA?i'?A,A3A?i'? A?A A,A'A,A?A?i'? A?A A,A'A,A?A?i'? A?A A,A'A,A?A?i'?A,A2A?i'? A?A A,A'A,A?A?i'?A,Az - A?i'?A A'A?A?i'?A,AuA?i'? A?A A,A'A,A?A?i'?A A'A?A?i'?A A'A?A?i'?A,Az
$news .= '</div><div class="mainbox"><div class="mainblok"><div class="nfooter"><b><center><font color="red">' . $res['name'] . '</font></center></b></div><div class="list1">';
switch ($this->settings['view']) {
case 2:
$news .= '<a href="news/index.php">' . $res['name'] . '</a>';
break;

case 3:
$news .= $text;
break;
default :
$news .= '<b>' . $res['name'] . '</b><br />' . $text;
}
// e?N?N<e?i'?e?i'?ez e?i'?ez e?i'?eze?i'?eue?i'?N,N<
if (!empty($res['kom']) && $this->settings['view'] != 2 && $this->settings['kom'] == 1) {
$mes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `refid` = '" . $res['kom'] . "'");
$komm = mysql_result($mes, 0) - 1;
if ($komm >= 0)
$news .= '<br /><a href="../forum/?id=' . $res['kom'] . '">Comments</a> (' . $komm . ')';
}
$news .= '</div></div></div>';
++$i;
}
return $news;
} else {
return false;
}
}
}

// e?N?euN,N?e?e?i'? e2N?euNa e?i'?e?i'?e2e?i'?N?N,eue?i'?
private function newscount() {
$req = mysql_query("SELECT COUNT(*) FROM `news`");
$res = mysql_result($req, 0);
return ($res > 0 ? $res : '0');
}

// e?N?euN,N?e?e?i'? N?e2eue?e?Na e?i'?e?i'?e2e?i'?N?N,eue?i'?
private function lastnewscount() {
$req = mysql_query("SELECT COUNT(*) FROM `news` WHERE `time` > '" . (time() - 259200) . "'");
$res = mysql_result($req, 0);
return ($res > 0 ? '/<span class="red">+' . $res . '</span>' : false);
}
}
