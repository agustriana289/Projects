<?php

$mibile = mysql_fetch_assoc(mysql_query("select `mibile` from `users` where `id`='$idbot';"));
if ($mibile['mibile']) {
$keytime = $mibile['mibile'] + 600;
} esle {
$keytime = 0;
}
if (time() >= $keytime) {
$bottext = 'Receive them at the trash,
Happy happy bag open view
Chip in a letter I wrote three words:
"Brother tomorrow it takes you." | In what cheap by world away.
He is not sorry invited me to eat with.
Now I already ate it.
Two thousand paid on behalf of you remember him! | Emulation we decided to emulate
Emulation was decided the top
Top and know where to go?
Go top do not know themselves! | People increasingly crowded.
Thach Sanh less, reason, many. | My children as well between Eden.
A wise man who washed his leg, foot flesh! | Cooked shrimp potting Beard.
Her husband nodded chan wife sipped delicious compliment.
Sorry for the boy.What is standing outside flanking Good to know. | Tuber hands dating.
Let me get Kieu today.
Specifically look rolled his eyes and frowned.
No bribes, this fuck yeah. | Mama do not marry me away.
Cheep gibbons howl knows that once.
Mama do not marry close.
Longer over rice into contact many times but. | Fish not eat salt spoilage.
Husband argued wife pumping the road driving. | On the blue sky with clouds.
In the middle of the white clouds around the golden clouds.
If he took her, I would rather suffocate her in not. | Superintendents look supervised smile.
I looked at the supervisor of mine cry.
Towering university with.
Immense field to welcome you home. | This girl who. Why do my dare picking jasmine.
Picking and then ... marry me.
Not to pick me ... pick it over. | On the same run deep under contract.
My husband plowed the old guy was born. | Learn not love weaken and die
Tell them not not raised be. | White gold one sawn in half.
Half a pillow in, shed half mile.
Last night, I slept on the bed.Miss you wake, reached bed fractures. | One Hundred Years of sheep is sheep.
Finished washing the course. | The bed talking.
Neighbor, he had no teeth every play for the rest of my life boy, Rui silent cyclo quietly. | Dodder ... wrapped around pigsty.
Love them yourself spending too not you?? | Facial shrimp cooked with potting,
Husband eat spit broadly floor vote tame! | Thu going to the gold leaf, He went to her old guy. Serial autumn to autumn, serial election winner was born. | When old baby say you love me
He patented the little boy did not know what
Now she has puberty
He praised her beauty, her patented his old | The lamb jumps out mouth cup
Love them yourself sneaking her father
No doubt she knew what she was
He brought wedding presents to marry you | If God says love is destroyed
I believe humanity nobody
If God said love was a crime
Then I would take offense to be loved | When old baby Like hopscotch
Today she likes dating the same guy | light winds also make leaves
Little misunderstanding also split | Love is like a string
The situation has been the forum cord
This cord he replaced another
Lose me then you know instead? | Today drinking sentiments
Forgotten camera shooting video
I hold that I quietly
For him to go out and Ministry Steam | silk him stars too impersonal
responsible Nguyet stars too good to me
Just because the word love
Why do my part I save full | Yesterday, I came home you
About the mind that forget the five thousand
So he returned to find
I also sit in thousands of lost targets
Five thousand children took me target
I bought tickets for afternoon of play
Oh his unexpected hit damage
Silver caviar million they paid him five thousand. | The sky is why bad
Under my world who unfortunately
My life is unfortunate
On the way my love is lonely | Today March 8
Chi them women ngênh on
Macho not say no offers
Springboard for a somersault into the pond | multi spent sitting on the tree, the last month of each lunar skin to touch, Hang did not say no, Reaching gun Pang Pang, marry me | Yesterday I went to pick tea
Meet guys have to show it to you
I bow but it were
It puts the "father" it to
Put in both pleasure and pain
I as agonies, "it" as deep
Let me be a long time
The guy must wind to go away ""
The next day I went to pick tea
Looking forward to the wind ... back to me |
Thu Bon sat Thu Mai
Obtained Mai likes to touch shoulders Thu Bon
Thu Mai sat beside the Thu Bon
Thu four extremists L. .. Thu Mai | Hooray sisters stone bridge
Virgin dropped the shrimp down on top of him! | Young does not i ... on potty
Here is the tone Si Paul (slow) start. | Someone without hair
The following article "is cotton" vocals. | Birds wise perches high spike
Butterfly butterfly wisdom parked on ... first bird. | I wish I turn into buffalo
To him was he elected to the thigh
I wish he turned into fire
To you blender (I) date night. | Me home to stand at the top of the pass
Where suddenly seen a cat bears bears. | No Son unknown
Go and knew no more of the house
Map old house but bad though
But is the real rather than "paints". | Settlement in the right place
Drop-on shoesShock sing two boxes! (H2O)
Drop for the new hole right financial
Drop incorrect hole was still young!
Young, even young
Throw ordered a few "islands" have done?
How is that?!
Throwing order not to be unsanitary!
Hygiene and sanitation, even
Average, only this technique!
Thats it, go up the hill
Resolved then down here!
Up the hill to find memory seats
Sitting misplaced "it" shoots in the butt. | Red beautiful roses have thorns
Girl "beautiful" girl ... repeated abortions | When old carry the pen teacher,
Now I carry the plow buffaloes. | The only nice when things unfinished.
Married and died about as quickly. | Street on the night watch collectors.
See [you] BOT thought buffalo smiling. | Lemon Lemon Blossom middle of the garden.
What about children lilies had in ...... pond. | Do you drink alcohol the night.
Beans have big soft spike into the pond. And you sip ball.
Also say ecstatic to fall in love with you. | Commercial him nine to wait ten.
Until eleven, I ignored his left. | A horse in pain, both ships ... flee. | A very sharp, both jammed phone. | ​​The king shall be king
Doctors daughter extremely dry
Cocoon choose wild fish soup.
Mai the other in th projection cold blades. | Evening stood lane.
You willowy knife ... my chicken fat.
The chicken I cut it into three.
Oh there you are ..... you?? | Wind put bananas dust after summer.
Playful little one to ... have children. | On the shallow depth below the
Plowing her husband sitting in the floor playing. | Oh god never the end of suffering
To father also suffering under grinding forever choking | Learn enforced chi
Tu also fell much more bones | Discotheque safe place to play
Bien Hoa is resting place Wanderer | for bath Hong WAN instead
Rai rai replaced change | Learn to eat with tomato sauce
I also eat fish with sauce | bath very well at school
Study of bones, also naked shower | learn to do for the eyes to
To get your wife to rapid population growth | The school is prison
Books enemy
School is to become a monk
Teachers as assassin
Time as the rubber
Friends prawns | Through demand Hats look for
Bridges how much ... petrol cost much. | Bread with pate
Goat boy must have blood!!! | Doing boys are boys
Lang beng also cover, syphilis also!!! | Today pupil stirring to heaven
10 school 9 months of play
3 to Layer 2 months sleeping
And the other guy nodded. | Entering troops to fuzzy
Sat near her daughter not stupid!!
Drop that haircut from
Sitting near her daughter ..... stupid why do not touch!! | Yesterday he came to my house
Remember to forget 50 thousand. | Mommy, I want to be married
My son .... mother as well as hearts. | Peel the mango not to sour mango
Choose you do not leave you his father. | [You] here also chem gio Lime go yet chem 1 minh merchant! | Better kiss to be slapped than other watches Theng kiss you! | Love is lost in ... 1 bunch! | Without students, all teachers are lost! | Lost is lost, lost people is the loss of many ..... love both! | last minute of the World Security About: dark, brother turned swipe salt test gasoline or petrol all ... also ... the victim at the age of 20! | Quitting u, very easy .... I have give 100 rùi! | Something cow 4 women ... but only 2? ... that is the truth! | Take a decent day ... loss 10,000 rice Money | I will help you quit a bad habit, its breathing! | No bad woman, only bad women do not know. | Gasoline may be shallow, the tire can be worn ...... but number and chassis number has not changed! | It takes 3 seconds to say love .... take 3 hours to explain ... take 3 days to accept and take a lifetime to accomplish and regret ....! | Whether girls or boys .... themselves rai that easy! | Debt turn it into ...... debtor! | I do not know by who ... . but what is down I long 1m76! | If love is light, marriage is the electric bills! | Never Joneses bag when no one loves you! | Want rat, quickly most choose to buy a AK47 gun and 10 tape cartridge has high destructive power .... then lure the mouse into the house and shut the door .... you just have to stand outside and shoot through the window ...... as long as no longer hear the cries out loud ...... | If Adam and Eve ancient clothes, now we do not have to get dressed and then ..... unfortunately huh! | Hey girl, if the guy in front of you breathing regularly, everything normally, if he breathed heavily and overwhelmed, he fell in love with you .... even if he is breathing is irregular or difficult breathing, this girl ... lets look at the dress she was wearing was too short, as back buttons have installed or not, and try her pants pulled phecmotuya not! | I stand alone I m pretty Assembly .... ! | Womens weapons of mass destruction god created man to suppress ...! | You can not lick their elbows hands | Pigs can not look to the sky by bone | Riding the can not vomit | When your strong sneeze can break ribs ... but do not try to hold on because you will ruptured blood vessels. | Well this anymore .... 75% of users read on try to lick their elbows hands .....! ... ha ha ... | An idiot spending computers receive the following message "Can not found the printer" ... so he turned the monitor to the printer .... ! | I m not handsome .... but what Theng handsome than I have killed it already ..... some other boy did not complain! .... he he he ... | The words of a name after 5 hours sitting chatting: "Damn, today to meet us and ask!" | If your husband have diabetes, sick wife? ........ that is Sun that! | Do not try to find his name on the tombstone! | A girl with congenital urination at 6:30 am no less .... but the problem is that she always woke up at 7:30 ...... yeah ! | Looking directly at the sun did not feel the glare .... is 100% blind. | "subscriber you just call outside the coverage area, located within the breeding area and next to another subscriber"';
$counttext = substr_count($bottext,'|');
$botpk = explode('|',$bottext);
$randbot = rand(0,$counttext);
mysql_query("INSERT INTO `guest` SET
                `adm` = '$admset',
                `time` = '" . time() . "',
                `user_id` = '$idbot',
                `name` = 'BOT',
                `text` = '" . mysql_real_escape_string('' .$botpk[$randbot]. ' :' .rand(1,95). ':') . "',
                `ip` = '00000',
                `browser` = 'Opera Mini BOT 6.5'
            ");
mysql_query("UPDATE `users` SET `mibile`='" .time(). "' WHERE `id`='$idbot'");
}

?>