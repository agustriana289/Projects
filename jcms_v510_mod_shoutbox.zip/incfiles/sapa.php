<?php

//http://impotensia.kilu.de 
//hasil editan anak bandel...
$rx = gmdate("H",time()+7*3600);
$rx = str_replace("01","Selamat dini hari",$rx);
$rx = str_replace("02","Selamat dini hari",$rx);
$rx = str_replace("03","Selamat dini hari",$rx);
$rx = str_replace("04","Selamat dini hari",$rx);
$rx = str_replace("05","Selamat pagi",$rx);
$rx = str_replace("06","Selamat pagi",$rx);
$rx = str_replace("07","Selamat pagi",$rx);
$rx = str_replace("08","Selamat pagi",$rx);
$rx = str_replace("09","Selamat pagi",$rx);
$rx = str_replace("10","Selamat jelang siang",$rx);
$rx = str_replace("11","Selamat siang",$rx);
$rx = str_replace("12","Selamat siang",$rx);
$rx = str_replace("13","Selamat siang",$rx);
$rx = str_replace("14","Selamat siang",$rx);
$rx = str_replace("15","Selamat sore",$rx);
$rx = str_replace("16","Selamat sore",$rx);
$rx = str_replace("17","Selamat sore",$rx);
$rx = str_replace("18","Selamat petang",$rx);
$rx = str_replace("19","Selamat malam",$rx);
$rx = str_replace("20","Selamat malam",$rx);
$rx = str_replace("21","Selamat malam",$rx);
$rx = str_replace("22","Selamat malam",$rx);
$rx = str_replace("23","Selamat malam",$rx);
$rx = str_replace("24","Selamat malam",$rx);
$rx = str_replace("00","Selamat dini hari",$rx);
//SELESAI
//tampilkan sapaan


$teks = "$rx";
$hasil="";
$warna=0;
$turn=0;
while($warna<=strlen($teks)){ $warnahuruf = substr ($teks,$warna,1);

$warna++;
if($turn==0){ $turn=1;
$hasil.= "<FONT color=\"#ff00ff\">".$warnahuruf."</FONT>"; }
else
if($turn==1){ $turn=2;
$hasil.= "<FONT color=\"#ff00cc\">".$warnahuruf."</FONT>"; }
else
if($turn==2){ $turn=3;
$hasil.= "<FONT color=\"#ff0099\">".$warnahuruf."</FONT>"; }
else
if($turn==3){$turn=4;
$hasil.= "<FONT color=\"#ff0066\">".$warnahuruf."</FONT>"; } else if($turn==4){$turn=5;  $hasil.= "<FONT color=\"#ff0033\">".$warnahuruf."</FONT>"; }   else if($turn==5){$turn=6; $hasil.= "<FONT color=\"#ff0000\">".$warnahuruf."</FONT>"; } 
else if($turn==6){$turn=7; $hasil.= "<FONT color=\"#ff3300\">".$warnahuruf."</FONT>";  } else if($turn==7){$turn=8; $hasil.= "<FONT color=\"#ff6600\">".$warnahuruf."</FONT>"; }
else if($turn==8){$turn=9; $hasil.= "<FONT color=\"#ff9900\">".$warnahuruf."</FONT>"; }
else if($turn==9){$turn=10; $hasil.= "<FONT color=\"#ffcc00\">".$warnahuruf."</FONT>"; } 
else if($turn==10){$turn=11; $hasil.= "<FONT color=\"#ffff00\">".$warnahuruf."</FONT>"; } 
else if($turn==11){$turn=12; $hasil.= "<FONT color=\"#ccff00\">".$warnahuruf."</FONT>"; } 
else if($turn==12){$turn=13; $hasil.= "<FONT color=\"#99ff00\">".$warnahuruf."</FONT>"; }
else if($turn==13){$turn=14; $hasil .= "<FONT color=\"#66ff00\">".$warnahuruf."</FONT>"; } 
else if($turn==14){$turn=15; $hasil .= "<FONT color=\"#33ff00\">".$warnahuruf."</FONT>"; } 
else if($turn==15){$turn=16; $hasil .= "<FONT color=\"#00ff00\">".$warnahuruf."</FONT>"; } 
else if($turn==16){$turn=17; $hasil .= "<FONT color=\"#00ff33\">".$warnahuruf."</FONT>"; } 
else if($turn==17){$turn=18; $hasil .= "<FONT color=\"#00ff66\">".$warnahuruf."</FONT>"; } 
else if($turn==18){$turn=19; $hasil .= "<FONT color=\"#00ff99\">".$warnahuruf."</FONT>"; } 
else if($turn==19){$turn=20; $hasil .= "<FONT color=\"#00ffcc\">".$warnahuruf."</FONT>"; }  
else if($turn==20){$turn=21; $hasil .= "<FONT color=\"#00ffff\">".$warnahuruf."</FONT>"; }
else if($turn==21){$turn=22; $hasil .= "<FONT color=\"#00ccff\">".$warnahuruf."</FONT>"; } 
else if($turn==22){$turn=23; $hasil .= "<FONT color=\"#0099ff\">".$warnahuruf."</FONT>"; } 
else if($turn==23){$turn=24; $hasil .= "<FONT color=\"#0066ff\">".$warnahuruf."</FONT>"; } 
else if($turn==24){$turn=25; $hasil .= "<FONT color=\"#0033ff\">".$warnahuruf."</FONT>"; } 
else if($turn==25){$turn=26; $hasil .= "<FONT color=\"#0000ff\">".$warnahuruf."</FONT>"; } 
else if($turn==26){$turn=27; $hasil .= "<FONT color=\"#3300ff\">".$warnahuruf."</FONT>"; } 
else if($turn==27){$turn=28; $hasil .= "<FONT color=\"#6600ff\">".$warnahuruf."</FONT>"; } 
else if($turn==28){$turn=29; $hasil .= "<FONT color=\"#9900ff\">".$warnahuruf."</FONT>"; } 
else if($turn==29){$turn=0; $hasil .= "<FONT color=\"#cc00ff\">".$warnahuruf."</FONT>"; } }
echo "$hasil"; 
?>
