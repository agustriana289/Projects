<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
$ontime = $realtime - 600;
$checkon = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '$ontime' AND `rights` >= 3 AND `rights` < 10"), 0);
$checkkd = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and kedit='0' AND `kiemduyet` != '1' AND `close`!='1'"), 0);
if($checkon == 0 && $checkkd > 0) {
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `kiemduyet`!='1' AND `close`!='1' LIMIT $checkkd");
while($auto = mysql_fetch_assoc($req)) {
for ($i=1; $i<=$checkkd; $i++) {
$okkd = mysql_fetch_array(mysql_query("SELECT * FROM `forum` WHERE `type` = 'm' and kedit='0' AND `kiemduyet`!='1' AND `close`!='1' AND `refid`='".$auto['id']."'"));
$lentext = strlen($okkd['text']);
if($lentext > 50) {
mysql_query("UPDATE forum SET `kiemduyet`='1' WHERE `id`='".$auto['id']."'");
mysql_query("UPDATE forum SET `time`='$realtime' WHERE `id`='".$auto['id']."'");
mysql_query("UPDATE forum SET `kiemduyet_who`='BOT' WHERE `id`='".$auto['id']."'");
}
}
}
}
?>