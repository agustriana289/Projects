<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
$set[pasword]="12345";
$set[buku]="1000";
$set[shout]="250";
$set[waktu]="7";
$set[visitor]="BUNG";
$set[judul]="Susukan Us";
$set[footer]="<center>&copy; 2013 <a href='http://susukan.us'><font color='red'>chodot</font></a><br> All Rights Reserved<br>
</center>";
$set[description]="chapink,chodot, simple wapsite,free download,game,aplikasi,php script";
$set[rss]="http://my.opera.com/operamini/xml/rss/blog";
?>
