<?php
 function ua() {
  $data = curl( "http://tinytop.mobi/" ) ;
  if ( preg_match( "/REAL:\s(?P<Ua>.+)/", $data, $match ) ) {
   return $match["Ua"] ;
  } else {
   $match = explode( " ", $_SERVER["HTTP_USER_AGENT"] ) ;
   return $match[0] ;
  }
 }
 ###################
 function curl( $url ) {
  if ( in_array( "curl", get_loaded_extensions() ) ) {
   $ch = curl_init() ;
   curl_setopt( $ch, CURLOPT_URL, $url ) ;
   curl_setopt( $ch, CURLOPT_REFERER, $url ) ;
   curl_setopt( $ch, CURLOPT_HEADER, 0 ) ;
   curl_setopt( $ch, CURLOPT_FRESH_CONNECT, 1 ) ;
   curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 ) ;
   curl_setopt( $ch, CURLOPT_USERAGENT, ua() ) ;
   $result = curl_exec( $ch ) ;
   curl_close( $ch ) ;
   return $result ;
  } else {
   $result = file_get_contents( $url ) ;
   return $result ;
  }
 }
 ###################
 function google_cache( $url ) {
  $data = curl( "http://webcache.googleusercontent.com/search?q=cache:" . urlencode( $url ) ) ;
  preg_match( '#(\d{1,2}\s[a-zA-Z]{3}\s\d{4}\s\d{2}:\d{2}:\d{2}.*?)\.#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function google_indexed( $url ) {
  $data = curl( "http://www.google.com/search?q=site:" . urlencode( $url ) ) ;
  preg_match( '#About\s([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function google_backlinks( $url ) {
  $data = curl( "http://www.google.com/search?q=link:" . urlencode( $url ) ) ;
  preg_match( '#About\s([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ##################
 function delicious_indexed( $url ) {
  $data = curl( "http://www.delicious.com/search?p=site:" . urlencode( $url ) ) ;
  preg_match( '#<em>([0-9\,]+){1,}<\/em>\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ##################
 function delicious_backlinks( $url ) {
  $data = curl( "http://www.delicious.com/search?p=link:" . urlencode( $url ) ) ;
  preg_match( '#<em>([0-9\,]+){1,}<\/em>\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ##################
 function digg_indexed( $url ) {
  $data = curl( "http://digg.com/search?q=site:" . urlencode( $url ) ) ;
  preg_match( '#title\">([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ##################
 function digg_backlinks( $url ) {
  $data = curl( "http://digg.com/search?q=link:" . urlencode( $url ) ) ;
  preg_match( '#title\">([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function aol_indexed( $url ) {
  $data = curl( "http://search.aol.com/aol/search?q=site:" . urlencode( $url ) ) ;
  preg_match( '#&nbsp;<b>([0-9\,]+){1,}<\/b>\s<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function aol_backlinks( $url ) {
  $data = curl( "http://search.aol.com/aol/search?q=link:" . urlencode( $url ) ) ;
  preg_match( '#&nbsp;<b>([0-9\,]+){1,}<\/b>\s<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function yahoo_indexed( $url ) {
  $data = curl( "http://siteexplorer.search.yahoo.com/search?bwm=i&bwmf=s&p=" . urlencode( $url ) ) ;
  preg_match( '#Inlinks\s\(([0-9\,]+){1,}\)<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function yahoo_backlinks( $url ) {
  $data = curl( "http://siteexplorer.search.yahoo.com/search?bwm=i&p=" . urlencode( $url ) ) ;
  preg_match( '#Inlinks\s\(([0-9\,]+){1,}\)<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function bing_indexed( $url ) {
  $data = curl( "http://www.bing.com/search?q=site:" . urlencode( $url ) ) ;
  preg_match( '#of\s([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function bing_backlinks( $url ) {
  $data = curl( "http://www.bing.com/search?q=link:" . urlencode( $url ) ) ;
  preg_match( '#of\s([0-9\,]+){1,}\sresult#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function yippy_indexed( $url ) {
  $data = curl( "http://search.yippy.com/search?query=site:" . urlencode( $url ) ) ;
  preg_match( '#<span\sclass=\"intronum\">([0-9\,]+){1,}<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function yippy_backlinks( $url ) {
  $data = curl( "http://search.yippy.com/search?query=link:" . urlencode( $url ) ) ;
  preg_match( '#<span\sclass=\"intronum\">([0-9\,]+){1,}<\/span>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function alexa_backlinks( $url ) {
  $data = curl( "http://www.alexa.com/search?q=" . urlencode( $url ) ) ;
  preg_match( '#href=\"/site/linksin/' . urlencode( $url ) . '\">([0-9\,]+){1,}<\/a>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function alexa_rank( $url ) {
  $data = curl( "http://www.alexa.com/search?q=" . urlencode( $url ) ) ;
  preg_match( '#trafficstats\">\s([0-9\,]+){1,}<\/a>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function compete_rank( $url ) {
  $data = curl( "http://siteanalytics.compete.com/" . urlencode( $url ) . "/" ) ;
  preg_match( '/rank\s#([0-9\,]+){1,}/', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function StrToNum( $Str, $Check, $Magic ) {
  $Int32Unit = 4294967296 ;
  $length = strlen( $Str ) ;
  for ( $i = 0; $i < $length; $i++ ) {
   $Check *= $Magic ;
   if ( $Check >= $Int32Unit ) {
    $Check = ( $Check - $Int32Unit * ( int )( $Check / $Int32Unit ) ) ;
    $Check = ( $Check < -2147483648 ) ? ( $Check + $Int32Unit ) : $Check ;
   }
   $Check += ord( $Str{$i} ) ;
  }
  return $Check ;
 }
 function HashURL( $String ) {
  $Check1 = StrToNum( $String, 0x1505, 0x21 ) ;
  $Check2 = StrToNum( $String, 0, 0x1003F ) ;
  $Check1 >>= 2 ;
  $Check1 = ( ( $Check1 >> 4 ) & 0x3FFFFC0 ) | ( $Check1 & 0x3F ) ;
  $Check1 = ( ( $Check1 >> 4 ) & 0x3FFC00 ) | ( $Check1 & 0x3FF ) ;
  $Check1 = ( ( $Check1 >> 4 ) & 0x3C000 ) | ( $Check1 & 0x3FFF ) ;
  $T1 = ( ( ( ( $Check1 & 0x3C0 ) << 4 ) | ( $Check1 & 0x3C ) ) << 2 ) | ( $Check2 & 0xF0F ) ;
  $T2 = ( ( ( ( $Check1 & 0xFFFFC000 ) << 4 ) | ( $Check1 & 0x3C00 ) ) << 0xA ) | ( $Check2 & 0xF0F0000 ) ;
  return ( $T1 | $T2 ) ;
 }
 function CheckHash( $Hashnum ) {
  $CheckByte = 0 ;
  $Flag = 0 ;
  $HashStr = sprintf( '%u', $Hashnum ) ;
  $length = strlen( $HashStr ) ;
  for ( $i = $length - 1; $i >= 0; $i-- ) {
   $Re = $HashStr{$i} ;
   if ( 1 === ( $Flag % 2 ) ) {
    $Re += $Re ;
    $Re = ( int )( $Re / 10 ) + ( $Re % 10 ) ;
   }
   $CheckByte += $Re ;
   $Flag++ ;
  }
  $CheckByte %= 10 ;
  if ( 0 !== $CheckByte ) {
   $CheckByte = 10 - $CheckByte ;
   if ( 1 === ( $Flag % 2 ) ) {
    if ( 1 === ( $CheckByte % 2 ) ) {
     $CheckByte += 9 ;
    }
    $CheckByte >>= 1 ;
   }
  }
  return '7' . $CheckByte . $HashStr ;
 }
 function google_rank( $url ) {
  $data = curl( "http://www.google.com/search?client=navclient-auto&ch=" . CheckHash( HashURL( urlencode( $url ) ) ) . "&features=Rank&q=info:" . urlencode( $url ) ) ;
  $info = strpos( $data, "Rank_" ) ;
  if ( ! $info ) {
   $rank = substr( $data, $info + 9 ) ;
   $rank = trim( $rank ) ;
   return $rank ;
  } else {
  }
 }
 ###################
 function internet_archive( $url ) {
  $data = curl( "http://wayback.archive.org/web/*/" . urlencode( $url ) ) ;
  preg_match( '#crawled\s<strong>([0-9\,]+){1,}\stime#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function w3c_validator( $url ) {
  $data = curl( "http://validator.w3.org/check?uri=" . urlencode( $url ) ) ;
  preg_match( '#valid\">([^\"]*)<\/td>#', $data, $match ) ;
  return $match[1] ;
 }
 ###################
 function whois_domain( $url ) {
  $data = curl( "http://www.who.is/whois/" . urlencode( $url ) ) ;
  preg_match( "#accent1\'>Updated:\s([^\"]*)<\/span><br>#", $data, $match ) ;
  return $match[1] ;
 }
 /*$ext = explode( ".", strtolower( $url ) ) ;
 if ( $ext[1] == "ac" ) {
 $server = "whois.nic.ac" ;
 } else
 if ( $ext[1] == "net.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "gov.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "org.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "mil.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "sch.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "ac.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "pro.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "name.ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "ae" ) {
 $server = "whois.aeda.net.ae" ;
 } else
 if ( $ext[1] == "aero" ) {
 $server = "whois.information.aero" ;
 } else
 if ( $ext[1] == "af" ) {
 $server = "whois.nic.af" ;
 } else
 if ( $ext[1] == "com.ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "edu.ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "gov.ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "net.ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "org.ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "ag" ) {
 $server = "whois.nic.ag" ;
 } else
 if ( $ext[1] == "ai" ) {
 $server = "whois.ai" ;
 } else
 if ( $ext[1] == "am" ) {
 $server = "whois.nic.am" ;
 } else
 if ( $ext[1] == "ar" ) {
 $server = "whois.nic.ar" ;
 } else
 if ( $ext[1] == "arpa" ) {
 $server = "whois.iana.org" ;
 } else
 if ( $ext[1] == "as" ) {
 $server = "whois.nic.as" ;
 } else
 if ( $ext[1] == "asia" ) {
 $server = "whois.nic.asia" ;
 } else
 if ( $ext[1] == "ac.at" ) {
 $server = "whois.nic.at" ;
 } else
 if ( $ext[1] == "co.at" ) {
 $server = "whois.nic.at" ;
 } else
 if ( $ext[1] == "gv.at" ) {
 $server = "whois.nic.at" ;
 } else
 if ( $ext[1] == "or.at" ) {
 $server = "whois.nic.at" ;
 } else
 if ( $ext[1] == "at" ) {
 $server = "whois.nic.at" ;
 } else
 if ( $ext[1] == "asn.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "com.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "edu.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "id.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "net.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "org.au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "au" ) {
 $server = "whois.aunic.net" ;
 } else
 if ( $ext[1] == "be" ) {
 $server = "whois.dns.be" ;
 } else
 if ( $ext[1] == "bg" ) {
 $server = "whois.register.bg" ;
 } else
 if ( $ext[1] == "biz" ) {
 $server = "whois.biz" ;
 } else
 if ( $ext[1] == "bj" ) {
 $server = "whois.nic.bj" ;
 } else
 if ( $ext[1] == "bo" ) {
 $server = "whois.nic.bo" ;
 } else
 if ( $ext[1] == "agr.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "am.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "art.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "com.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "coop.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "esp.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "etc.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "far.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "fm.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "g12.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "gov.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "imb.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ind.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "inf.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "mil.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "net.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "org.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "psi.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "rec.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "srv.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "tmp.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "tur.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "tv.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "edu.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "nom.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "adm.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "adv.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "arq.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ato.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "bio.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "bmd.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "cim.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "cng.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "cnt.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ecn.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "eng.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "eti.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "fnd.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "fot.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "fst.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ggf.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "jor.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "lel.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "mat.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "med.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "mus.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "not.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ntr.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "odo.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "ppg.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "pro.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "psc.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "qsl.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "trd.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "vet.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "zlg.br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "br" ) {
 $server = "whois.registro.br" ;
 } else
 if ( $ext[1] == "com.bz" ) {
 $server = "whois.belizenic.bz" ;
 } else
 if ( $ext[1] == "net.bz" ) {
 $server = "whois.belizenic.bz" ;
 } else
 if ( $ext[1] == "org.bz" ) {
 $server = "whois.belizenic.bz" ;
 } else
 if ( $ext[1] == "bz" ) {
 $server = "whois.belizenic.bz" ;
 } else
 if ( $ext[1] == "bc.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "mb.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "nb.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "nf.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "ns.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "nt.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "on.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "pe.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "qc.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "sk.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "yk.ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "ca" ) {
 $server = "whois.cira.ca" ;
 } else
 if ( $ext[1] == "cat" ) {
 $server = "whois.cat" ;
 } else
 if ( $ext[1] == "cc" ) {
 $server = "ccwhois.verisign-grs.com" ;
 } else
 if ( $ext[1] == "cd" ) {
 $server = "whois.nic.cd" ;
 } else
 if ( $ext[1] == "ch" ) {
 $server = "whois.nic.ch" ;
 } else
 if ( $ext[1] == "ci" ) {
 $server = "whois.nic.ci" ;
 } else
 if ( $ext[1] == "cl" ) {
 $server = "whois.nic.cl" ;
 } else
 if ( $ext[1] == "co.ck" ) {
 $server = "whois.nic.ck" ;
 } else
 if ( $ext[1] == "edu.ck" ) {
 $server = "whois.nic.ck" ;
 } else
 if ( $ext[1] == "gov.ck" ) {
 $server = "whois.nic.ck" ;
 } else
 if ( $ext[1] == "net.ck" ) {
 $server = "whois.nic.ck" ;
 } else
 if ( $ext[1] == "org.ck" ) {
 $server = "whois.nic.ck" ;
 } else
 if ( $ext[1] == "cm" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "edu.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "ac.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "ah.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "bj.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "com.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "cq.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "gd.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "gov.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "gs.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "gx.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "gz.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "hb.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "he.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "hi.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "hk.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "hl.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "hn.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "jl.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "js.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "mo.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "net.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "nm.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "nx.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "ln.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "org.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "qh.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "sc.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "sh.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "sn.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "tj.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "tw.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "yn.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "xj.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "xz.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "zj.cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "cn" ) {
 $server = "whois.cnnic.net.cn" ;
 } else
 if ( $ext[1] == "com" ) {
 $server = "whois.verisign-grs.com" ;
 } else
 if ( $ext[1] == "coop" ) {
 $server = "whois.nic.coop" ;
 } else
 if ( $ext[1] == "cx" ) {
 $server = "whois.nic.cx" ;
 } else
 if ( $ext[1] == "cz" ) {
 $server = "whois.nic.cz" ;
 } else
 if ( $ext[1] == "de" ) {
 $server = "whois.denic.de" ;
 } else
 if ( $ext[1] == "dk" ) {
 $server = "whois.dk-hostmaster.dk" ;
 } else
 if ( $ext[1] == "dm" ) {
 $server = "whois.nic.dm" ;
 } else
 if ( $ext[1] == "ec" ) {
 $server = "whois.nic.ec" ;
 } else
 if ( $ext[1] == "edu" ) {
 $server = "whois.educause.edu" ;
 } else
 if ( $ext[1] == "com.ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "pri.ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "fie.ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "org.ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "med.ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "ee" ) {
 $server = "whois.eenet.ee" ;
 } else
 if ( $ext[1] == "es" ) {
 $server = "whois.nic.es" ;
 } else
 if ( $ext[1] == "eu" ) {
 $server = "whois.eu" ;
 } else
 if ( $ext[1] == "fi" ) {
 $server = "whois.ficora.fi" ;
 } else
 if ( $ext[1] == "ac.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "biz.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "com.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "gov.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "info.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "mil.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "name.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "net.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "org.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "pro.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "school.fj" ) {
 $server = "whois.usp.ac.fj" ;
 } else
 if ( $ext[1] == "fo" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "asso.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "com.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "nom.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "prd.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "presse.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "tm.fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "fr" ) {
 $server = "whois.nic.fr" ;
 } else
 if ( $ext[1] == "gd" ) {
 $server = "whois.adamsnames.tc" ;
 } else
 if ( $ext[1] == "co.gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "gov.gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "net.gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "org.gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "sch.gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "gg" ) {
 $server = "whois.channelisles.net" ;
 } else
 if ( $ext[1] == "gi" ) {
 $server = "whois2.afilias-grs.net" ;
 } else
 if ( $ext[1] == "gl" ) {
 $server = "whois.nic.gl" ;
 } else
 if ( $ext[1] == "gov" ) {
 $server = "whois.dotgov.gov" ;
 } else
 if ( $ext[1] == "gy" ) {
 $server = "whois.registry.gy" ;
 } else
 if ( $ext[1] == "com.hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "edu.hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "gov.hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "net.hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "org.hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "hk" ) {
 $server = "whois.hkdnr.net.hk" ;
 } else
 if ( $ext[1] == "hm" ) {
 $server = "whois.registry.hm" ;
 } else
 if ( $ext[1] == "hn" ) {
 $server = "whois2.afilias-grs.net" ;
 } else
 if ( $ext[1] == "ht" ) {
 $server = "whois.nic.ht" ;
 } else
 if ( $ext[1] == "co.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "info.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "org.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "priv.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "sport.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "tm.hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "hu" ) {
 $server = "whois.nic.hu" ;
 } else
 if ( $ext[1] == "war.net.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "web.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "sch.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "go.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "ac.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "co.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "or.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "net.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "mil.id" ) {
 $server = "whois.netzone.web.id" ;
 } else
 if ( $ext[1] == "ie" ) {
 $server = "whois.domainregistry.ie" ;
 } else
 if ( $ext[1] == "je" ) {
 $server = "whois.je" ;
 } else
 if ( $ext[1] == "ac.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "co.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "gov.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "idf.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "k12.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "muni.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "net.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "org.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "ac.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "co.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "gov.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "idf.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "k12.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "muni.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "net.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "org.il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "il" ) {
 $server = "whois.isoc.org.il" ;
 } else
 if ( $ext[1] == "im" ) {
 $server = "whois.nic.im" ;
 } else
 if ( $ext[1] == "co.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "net.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "org.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "gen.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "firm.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "ind.in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "in" ) {
 $server = "whois.inregistry.net" ;
 } else
 if ( $ext[1] == "info" ) {
 $server = "whois.afilias.net" ;
 } else
 if ( $ext[1] == "int" ) {
 $server = "whois.iana.org" ;
 } else
 if ( $ext[1] == "io" ) {
 $server = "whois.nic.io" ;
 } else
 if ( $ext[1] == "ac.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "co.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "gov.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "id.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "net.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "org.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "sch.ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "ir" ) {
 $server = "whois.nic.ir" ;
 } else
 if ( $ext[1] == "is" ) {
 $server = "whois.isnic.is" ;
 } else
 if ( $ext[1] == "it" ) {
 $server = "whois.nic.it" ;
 } else
 if ( $ext[1] == "jm" ) {
 $server = "whois.nic.jm" ;
 } else
 if ( $ext[1] == "jobs" ) {
 $server = "jobswhois.verisign-grs.com" ;
 } else
 if ( $ext[1] == "ac.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "ad.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "co.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "ed.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "go.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "ne.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "or.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "geo.jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "jp" ) {
 $server = "whois.jprs.jp" ;
 } else
 if ( $ext[1] == "ac.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "co.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "go.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "ne.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "or.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "sc.ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "ke" ) {
 $server = "whois.kenic.or.ke" ;
 } else
 if ( $ext[1] == "kp" ) {
 $server = "whois.kcce.kp" ;
 } else
 if ( $ext[1] == "ac.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "co.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "go.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "ne.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "or.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "pe.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "re.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "seoul.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "kyonggi.kr" ) {
 $server = "whois.krnic.net" ;
 } else
 if ( $ext[1] == "kr" ) {
 $server = "whois.nic.or.kr" ;
 } else
 if ( $ext[1] == "kz" ) {
 $server = "whois.nic.kz" ;
 } else
 if ( $ext[1] == "la" ) {
 $server = "whois.nic.la" ;
 } else
 if ( $ext[1] == "li" ) {
 $server = "whois.nic.li" ;
 } else
 if ( $ext[1] == "lt" ) {
 $server = "whois.domreg.lt" ;
 } else
 if ( $ext[1] == "lu" ) {
 $server = "whois.dns.lu" ;
 } else
 if ( $ext[1] == "asn.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "com.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "conf.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "edu.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "gov.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "id.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "mil.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "net.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "org.lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "lv" ) {
 $server = "whois.nic.lv" ;
 } else
 if ( $ext[1] == "ly" ) {
 $server = "whois.nic.ly" ;
 } else
 if ( $ext[1] == "co.ma" ) {
 $server = "whois.iam.net.ma" ;
 } else
 if ( $ext[1] == "net.ma" ) {
 $server = "whois.iam.net.ma" ;
 } else
 if ( $ext[1] == "org.ma" ) {
 $server = "whois.iam.net.ma" ;
 } else
 if ( $ext[1] == "ac.ma" ) {
 $server = "whois.iam.net.ma" ;
 } else
 if ( $ext[1] == "ma" ) {
 $server = "whois.iam.net.ma" ;
 } else
 if ( $ext[1] == "tm.mc" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "asso.mc" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "mc" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "md" ) {
 $server = "whois.nic.md" ;
 } else
 if ( $ext[1] == "me" ) {
 $server = "whois.nic.me" ;
 } else
 if ( $ext[1] == "mg" ) {
 $server = "whois.nic.mg" ;
 } else
 if ( $ext[1] == "mil" ) {
 $server = "whois.nic.mil" ;
 } else
 if ( $ext[1] == "mn" ) {
 $server = "whois.nic.mn" ;
 } else
 if ( $ext[1] == "mobi" ) {
 $server = "whois.dotmobiregistry.net" ;
 } else
 if ( $ext[1] == "mp" ) {
 $server = "whois.nic.mp" ;
 } else
 if ( $ext[1] == "ms" ) {
 $server = "whois.adamsnames.tc" ;
 } else
 if ( $ext[1] == "com.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "edu.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "net.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "org.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "tm.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "uu.mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "mt" ) {
 $server = "whois.nic.org.mt" ;
 } else
 if ( $ext[1] == "mu" ) {
 $server = "whois.nic.mu" ;
 } else
 if ( $ext[1] == "com.mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "edu.mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "gob.mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "net.mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "org.mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "mx" ) {
 $server = "whois.nic.mx" ;
 } else
 if ( $ext[1] == "com.my" ) {
 $server = "whois.mynic.net.my" ;
 } else
 if ( $ext[1] == "net.my" ) {
 $server = "whois.mynic.net.my" ;
 } else
 if ( $ext[1] == "org.my" ) {
 $server = "whois.mynic.net.my" ;
 } else
 if ( $ext[1] == "gov.my" ) {
 $server = "whois.mynic.net.my" ;
 } else
 if ( $ext[1] == "edu.my" ) {
 $server = "whois.mynic.net.my" ;
 } else
 if ( $ext[1] == "mil.my" ) {
 $server = "whois.mynic.net." ;
 } else
 if ( $ext[1] == "my" ) {
 $server = "whois.mynic.net" ;
 } else
 if ( $ext[1] == "com.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "org.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "alt.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "co.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "edu.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "net.na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "na" ) {
 $server = "whois.na-nic.com.na" ;
 } else
 if ( $ext[1] == "name" ) {
 $server = "whois.nic.name" ;
 } else
 if ( $ext[1] == "net" ) {
 $server = "whois.verisign-grs.com" ;
 } else
 if ( $ext[1] == "nf" ) {
 $server = "whois.nic.cx" ;
 } else
 if ( $ext[1] == "ng" ) {
 $server = "whois.nic.net.ng" ;
 } else
 if ( $ext[1] == "nl" ) {
 $server = "whois.domain-registry.nl" ;
 } else
 if ( $ext[1] == "no" ) {
 $server = "whois.norid.no" ;
 } else
 if ( $ext[1] == "nu" ) {
 $server = "whois.nic.nu" ;
 } else
 if ( $ext[1] == "ac.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "co.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "cri.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "gen.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "govt.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "iwi.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "net.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "org.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "mil.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "school.nz" ) {
 $server = "whois.domainz.net.nz" ;
 } else
 if ( $ext[1] == "nz" ) {
 $server = "whois.srs.net.nz" ;
 } else
 if ( $ext[1] == "org" ) {
 $server = "whois.pir.org" ;
 } else
 if ( $ext[1] == "pe" ) {
 $server = "kero.yachay.pe" ;
 } else
 if ( $ext[1] == "biz.pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "com.pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "net.pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "org.pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "info.pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "pl" ) {
 $server = "whois.dns.pl" ;
 } else
 if ( $ext[1] == "pm" ) {
 $server = "whois.nic.pm" ;
 } else
 if ( $ext[1] == "pr" ) {
 $server = "whois.nic.pr" ;
 } else
 if ( $ext[1] == "cpa.pro" ) {
 $server = "whois.registrypro.pro" ;
 } else
 if ( $ext[1] == "eng.pro" ) {
 $server = "whois.registrypro.pro" ;
 } else
 if ( $ext[1] == "law.pro" ) {
 $server = "whois.registrypro.pro" ;
 } else
 if ( $ext[1] == "med.pro" ) {
 $server = "whois.registrypro.pro" ;
 } else
 if ( $ext[1] == "pro" ) {
 $server = "whois.registrypro.pro" ;
 } else
 if ( $ext[1] == "com.pt" ) {
 $server = "whois.dns.pt" ;
 } else
 if ( $ext[1] == "nome.pt" ) {
 $server = "whois.dns.pt" ;
 } else
 if ( $ext[1] == "pt" ) {
 $server = "whois.dns.pt" ;
 } else
 if ( $ext[1] == "re" ) {
 $server = "whois.nic.re" ;
 } else
 if ( $ext[1] == "arts.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "com.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "firm.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "info.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "nom.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "gov.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "nt.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "org.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "rec.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "store.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "tm.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "www.ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "ro" ) {
 $server = "whois.rotld.ro" ;
 } else
 if ( $ext[1] == "com.ru" ) {
 $server = "whois.ripn.ru" ;
 } else
 if ( $ext[1] == "net.ru" ) {
 $server = "whois.ripn.ru" ;
 } else
 if ( $ext[1] == "org.ru" ) {
 $server = "whois.ripn.ru" ;
 } else
 if ( $ext[1] == "ru" ) {
 $server = "whois.ripn.net" ;
 } else
 if ( $ext[1] == "sa" ) {
 $server = "whois.nic.net.sa" ;
 } else
 if ( $ext[1] == "sb" ) {
 $server = "whois.nic.net.sb" ;
 } else
 if ( $ext[1] == "sc" ) {
 $server = "whois2.afilias-grs.net" ;
 } else
 if ( $ext[1] == "pp.se" ) {
 $server = "whois.nic-se.se" ;
 } else
 if ( $ext[1] == "press.se" ) {
 $server = "whois.nic-se.se" ;
 } else
 if ( $ext[1] == "org.se" ) {
 $server = "whois.nic-se.se" ;
 } else
 if ( $ext[1] == "se" ) {
 $server = "whois.iis.se" ;
 } else
 if ( $ext[1] == "com.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "edu.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "gov.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "net.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "org.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "per.sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "sg" ) {
 $server = "whois.nic.net.sg" ;
 } else
 if ( $ext[1] == "com.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "co.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "net.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "org.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "edu.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "gov.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "mil.sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "sh" ) {
 $server = "whois.nic.sh" ;
 } else
 if ( $ext[1] == "si" ) {
 $server = "whois.arnes.si" ;
 } else
 if ( $ext[1] == "sk" ) {
 $server = "whois.sk-nic.sk" ;
 } else
 if ( $ext[1] == "sm" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "sn" ) {
 $server = "whois.nic.sn" ;
 } else
 if ( $ext[1] == "so" ) {
 $server = "whois.nic.so" ;
 } else
 if ( $ext[1] == "st" ) {
 $server = "whois.nic.st" ;
 } else
 if ( $ext[1] == "su" ) {
 $server = "whois.ripn.net" ;
 } else
 if ( $ext[1] == "tc" ) {
 $server = "whois.adamsnames.tc" ;
 } else
 if ( $ext[1] == "tel" ) {
 $server = "whois.nic.tel" ;
 } else
 if ( $ext[1] == "tf" ) {
 $server = "whois.nic.tf" ;
 } else
 if ( $ext[1] == "ac.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "co.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "go.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "in.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "mi.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "net.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "or.th" ) {
 $server = "whois.thnic.net" ;
 } else
 if ( $ext[1] == "th" ) {
 $server = "whois.thnic.co.th" ;
 } else
 if ( $ext[1] == "tj" ) {
 $server = "whois.nic.tj" ;
 } else
 if ( $ext[1] == "tk" ) {
 $server = "whois.dot.tk" ;
 } else
 if ( $ext[1] == "tl" ) {
 $server = "whois.nic.tl" ;
 } else
 if ( $ext[1] == "tm" ) {
 $server = "whois.nic.tm" ;
 } else
 if ( $ext[1] == "to" ) {
 $server = "whois.tonic.to" ;
 } else
 if ( $ext[1] == "tp" ) {
 $server = "whois.nic.tp" ;
 } else
 if ( $ext[1] == "bbs.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "com.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "edu.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "gen.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "gov.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "k12.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "mil.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "net.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "nom.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "org.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "web.tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "tr" ) {
 $server = "whois.nic.tr" ;
 } else
 if ( $ext[1] == "travel" ) {
 $server = "whois.nic.travel" ;
 } else
 if ( $ext[1] == "tv" ) {
 $server = "tvwhois.nic.tv" ;
 } else
 if ( $ext[1] == "com.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "ebiz.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "club.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "game.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "idv.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "net.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "org.tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "tw" ) {
 $server = "whois.twnic.net.tw" ;
 } else
 if ( $ext[1] == "com.ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "edu.ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "gov.ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "org.ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "net.ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "ua" ) {
 $server = "whois.com.ua" ;
 } else
 if ( $ext[1] == "co.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "or.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "ac.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "sc.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "go.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "ne.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "org.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "mil.ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "ug" ) {
 $server = "whois.co.ug" ;
 } else
 if ( $ext[1] == "co.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "ltd.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "me.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "net.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "org.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "plc.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "sch.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "ac.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "gov.uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "uk" ) {
 $server = "whois.nic.uk" ;
 } else
 if ( $ext[1] == "us" ) {
 $server = "whois.nic.us" ;
 } else
 if ( $ext[1] == "com.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "org.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "net.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "edu.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "gub.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "mil.uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "uy" ) {
 $server = "whois.nic.org.uy" ;
 } else
 if ( $ext[1] == "uz" ) {
 $server = "whois.cctld.uz" ;
 } else
 if ( $ext[1] == "va" ) {
 $server = "whois.ripe.net" ;
 } else
 if ( $ext[1] == "vc" ) {
 $server = "whois2.afilias-grs.net" ;
 } else
 if ( $ext[1] == "co.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "com.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "net.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "web.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "nom.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "firm.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "store.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "rec.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "info.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "org.ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "ve" ) {
 $server = "whois.nic.ve" ;
 } else
 if ( $ext[1] == "vg" ) {
 $server = "whois.adamsnames.tc" ;
 } else
 if ( $ext[1] == "wf" ) {
 $server = "whois.nic.wf" ;
 } else
 if ( $ext[1] == "wales.com" ) {
 $server = "whois.wales.com" ;
 } else
 if ( $ext[1] == "wales.org" ) {
 $server = "whois.wales.com" ;
 } else
 if ( $ext[1] == "wales.net" ) {
 $server = "whois.wales.com" ;
 } else
 if ( $ext[1] == "cymru.org" ) {
 $server = "whois.wales.com" ;
 } else
 if ( $ext[1] == "com.ws" ) {
 $server = "whois.nic.ws" ;
 } else
 if ( $ext[1] == "edu.ws" ) {
 $server = "whois.nic.ws" ;
 } else
 if ( $ext[1] == "gov.ws" ) {
 $server = "whois.nic.ws" ;
 } else
 if ( $ext[1] == "net.ws" ) {
 $server = "whois.nic.ws" ;
 } else
 if ( $ext[1] == "org.ws" ) {
 $server = "whois.nic.ws" ;
 } else
 if ( $ext[1] == "ws" ) {
 $server = "whois.website.ws" ;
 } else
 if ( $ext[1] == "yt" ) {
 $server = "whois.nic.yt" ;
 } else
 if ( $ext[1] == "yu" ) {
 $server = "whois.nic.yu" ;
 } else
 if ( $ext[1] == "au.com" ) {
 $server = "whois.au.com" ;
 } else
 if ( $ext[1] == "br.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "cn.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "de.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "eu.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "eu.org" ) {
 $server = "whois.eu.org" ;
 } else
 if ( $ext[1] == "gb.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "gb.net" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "hu.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "no.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "qc.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "ru.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "sa.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "se.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "se.net" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "uk.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "uk.net" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "us.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "uy.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "uz" ) {
 $server = "whois.cctld.uz" ;
 } else
 if ( $ext[1] == "za.com" ) {
 $server = "whois.centralnic.com" ;
 } else
 if ( $ext[1] == "za.net" ) {
 $server = "whois.za.net" ;
 } else
 if ( $ext[1] == "za.org" ) {
 $server = "whois.za.net" ;
 } else
 if ( $ext[1] == "za" ) {
 $server = "whois.nic.za" ;
 }
 if ( ! $sock = @fsockopen( $server, 43, $errno, $errstr, 30 ) ) {
 $output = "Cannot checking whois of " . $url . "\n" ;
 } else {
 fputs( $sock, $url . "\r\n" ) ;
 while ( ! feof( $sock ) ) $output .= fgets( $sock, 128 ) ;
 @fclose( $sock ) ;
 }
 return "<pre>
 " . $output . "
 </pre>" ;
 }*/
?>