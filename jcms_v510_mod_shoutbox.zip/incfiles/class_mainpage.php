<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                             Content Management System              //
// Di situs resmi dari proyek site:      http://johncms.com                     //
// Tambahan dukungan situs:      http://gazenwagen.com                  //
// Skrip asli
menggunakan bahasa rusia
//
// Translate by : jogerplay
http://skylands13.co.cc
////////////////////////////////////////////////////////////////////////////////
// JohnCMS core team:                                                         //
// Evgeniy Ryabinin alias john77 john77@gazenwagen.com                  //
// Oleg Kasyanov alias AlkatraZ          alkatraz@gazenwagen.com                //
//                                                                            //
// Versi informasi, melihat file terlampir, version.txt              //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Restricted access');

class mainpage {
    public $news;    // Teks berita
    public $newscount;    // Total jumlah berita
    public $lastnewsdate;    // Berita terakhir
    private $settings = array();

    function __construct() {
        global $set;
        global $realtime;
        $this->settings = unserialize($set['news']);
        $this->newscount = $this->newscount() . $this->lastnewscount();
        $this->news = $this->news();
    }

    // meminta berita terbaru di main
    private function news() {
        global $realtime;
        if ($this->settings['view'] > 0) {
            $reqtime = $realtime - ($this->settings['days'] * 86400);
            $req = mysql_query("SELECT * FROM `news` WHERE `time` > '" . $reqtime . "' ORDER BY `time` DESC LIMIT " . $this->settings['quantity']);
            if (mysql_num_rows($req) > 0) {
                $news = '<div class="bmenu">Berita</div>';
                while ($res = mysql_fetch_array($req)) {
                    $text = $res['text'];
$foto = $res['foto'];
                    // Jika teks melebihi batas yang ditentukan akan dipotong
                    if (mb_strlen($text) > $this->settings['size']) {
                        $text = mb_substr($text, 0, $this->settings['size']);
                        $text = htmlentities($text, ENT_QUOTES, 'UTF-8');
                        $text .= ' <a href="str/news.php">Selanjutnya...</a>';
                    }
                    else {
                        $text = htmlentities($text, ENT_QUOTES, 'UTF-8');
                    }
                    // Kita transfer dimasukan,kemudian di proses
                    if ($this->settings['breaks'])
                        $text = str_replace("\r\n", "<br/>", $text);
                    // Parsing smile
                    if ($this->settings['smileys']) {
                        $text = call_user_func('smileys', $text);                        //TODO: Periksa admin smile
                    }
                    // handle Tag
                    if ($this->settings['tags']) {
                        $text = call_user_func('tags', $text);
                    }
                    else {
                        $text = call_user_func('notags', $text);
                    }
                    // Definisikan melihat header - Teks
                    $news .= '<div class="news">';
                    switch ($this->settings['view']) {
                        case 2 :
                            $news .= '<a href="str/news.php">' . $res['name'] . '</a><br/><img src="' . $res['foto'] . '" width="'.$res['w'].'"  height="'.$res['h'].'" alt="foto"/>';
                            break;
                        case 3 :
                            $news .= '<img src="' . $res['foto'] . '" width="'.$res['w'].'"  height="'.$res['h'].'" alt="foto"/><br/>'.$text;
                            break;
                        default :
                            $news .= '<u>' . $res['name'] . '</u><br /><img src="' . $res['foto'] . '" width="'.$res['w'].'"  height="'.$res['h'].'" alt="foto"/><br/>'  . $text;
                    }
                    // Link komentar
                    if (!empty ($res['kom']) && $this->settings['view'] != 2 && $this->settings['kom'] == 1) {
                        $mes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `refid` = '" . $res['kom'] . "'");
                        $komm = mysql_result($mes, 0) - 1;
                        if ($komm >= 0)
                            $news .= '<br /><a href="../forum/?id=' . $res['kom'] . '">Komentar</a> (' . $komm . ')';
                    }
                    $news .= '</div>';
                    ++$i;
                }
                return $news;
            }
            else {
                return false;
            }
        }
    }

    // counter semua berita
    private function newscount() {
        $req = mysql_query("SELECT COUNT(*) FROM `news`");
        $res = mysql_result($req, 0);
        return ($res > 0 ? $res : '0');
    }

    // counter berita baru
    private function lastnewscount() {
        global $realtime;
        $ltime = $realtime - (86400 * 3);
        $req = mysql_query("SELECT COUNT(*) FROM `news` WHERE `time` > '" . $ltime . "'");
        $res = mysql_result($req, 0);
        return ($res > 0 ? '/<font color="#FF0000">+' . $res . '</font>' : false);
    }
}

?>