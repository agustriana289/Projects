<?
{
$roq = mysql_query("SELECT `guest`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");;
while ($res = mysql_fetch_array($roq))
{
$post = $gres['text'];
if(strlen($post) > 260) {
$post = substr($post, 0, 260).'....';
}
$post = functions::checkout($res['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $res['rights'] ? 1 : 0);
if($user_id) {
$post = str_replace ( '[  ]' , 'Good NooN' , $post ) ;
$post = str_replace ( "[   ]" , "Good After NooN" , $post ) ;
$post = str_replace ( "[    ]" , "Good Night" , $post ) ;
$post = str_replace ( "[     ]" , "MiD Night Bro!" , $post ) ;
$post = str_replace('[+]','Good Morning', $post);
$post = str_replace('[++]','Good NooN', $post);
$post = str_replace('[+++]','Good After NooN', $post);
$post = str_replace('[++++]','Good Night', $post);
$post = str_replace('[you]', $login, $post);
} else {
$post = str_replace('[you]', 'Guest', $post);
}
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">' : '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">';
// icon seks
global $set_user, $realtime, $user_id, $admp, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/avatar/' . $res['user_id'] . '.png')))
echo '<img src="' . $set['homeurl'] . '/files/users/avatar/' . $res['user_id'] . '.png" width="20" height="20" alt="' . $user['name'] . '" /> ';
else
echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="20" height="20" alt="' . $user['name'] . '" /> ';
}
if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="'.$home.'/users/'.$res['name'].'"><b>'.functions::nickcolor($res['user_id']).'</b></span></a> ';
}
else {
echo '<b>' . $res['name'] . '</b> ';
}
switch ($res['user_id'])
{
case 1:
echo ' (SV!) ';
break;
}

$ontimes = $res['lastdate'] + 300;
if (time() > $ontimes)
{
echo '<font color="red">[OFF]</font>';
}
else
{
echo '<font color="#00AA00">[ON]</font>';
}
// text
if (mb_strlen($post) >= 500)
{
$post = mb_substr($post, 0, 500);
echo $post.' ';
echo '...<a href="../guestbook/index.php">more</a>';
}
else
{
echo $post;
}
echo '</div>';
$i;
}
}
?>
