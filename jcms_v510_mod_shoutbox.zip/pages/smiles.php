<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
//editing file by http://seupang.Co.Cc http://penceter.co.cc
@$pas=$_GET['pas'];
@$n=$_GET['n'];
$pageName ='Smiles';
$PHP_SELF = basename($_SERVER['PHP_SELF']);
define('_IN_JOHNCMS', 1);
//www.susukan.us
require('../incfiles/core.php');
include('../incfiles/function.php');
$headmod = 'Smiles';
$textl = 'Smiles';
include('../incfiles/head.php');
echo '</div>';
require('../shout/tulis1.php');
echo'</div><div class="nfooter">List smile</div>';
require('../shout/smiles.php');
$cnt=count($sstr);
for($c=0;$c<7;$c++){
if($c+$n>$cnt-1) break;
echo'<div class="menu">';
print $simg[$c+$n].' '.$sstr[$c+$n].'</div>
';
}
print '</div>';
$n=$n+$c;
if($n<$cnt){
print '<div class="menu">&gt;<a href="smiles.php?n='.$n;
if($pas) print '&amp;pas='.$pas;
print '">next</a></div>';
}
require('../incfiles/end.php');
?>
