<?php
$XMLFILE = "http://feeds.bbci.co.uk/news/technology/rss.xml";
$TEMPLATE = "http://susukan.us/pages/sample-template.html";
$MAXITEMS = "1";
include("rss2html.php");
?>