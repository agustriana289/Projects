<?php
$XMLFILE = "http://feeds.bbci.co.uk/news/technology/rss.xml";
$TEMPLATE = "http://susukan.us/pages/sample-templates.html";
$MAXITEMS = "3";
include("rss2html.php");
?>