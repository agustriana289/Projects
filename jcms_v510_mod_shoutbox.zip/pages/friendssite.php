<?php

define('_IN_JOHNCMS', 1);

$textl = 'Friend site';
$headmod = 'friendssite';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$maxsite = 100; //?a?c�?y? ca?�?�
$adddate = 3; //��c?? �?e? ??c?e pe�� �?� �?�a�?e?�� ca?�a
$userssite = 3; //��c?? pa�pe�e??�x ca?�?� ��?� ?�??�? ��epa
switch ($act) {
case 'delete':
// ��a?e?�e ca?�a
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_GET['yes'])) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want to delete site from list..??!<br/><a href="friendssite.php?act=delete&amp;id=' . $id . '&amp;yes">Yes</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'edit':
// ?e�a?��p?�a?�e ca?�a
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 20) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 50) : '';
$count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;
$error = array();
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'All field are required';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Site url not valid..!!';
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=edit&amp;id=' . $id . '">Try again</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("UPDATE `friendssite` SET `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "', `count`='$count' WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
$res = mysql_fetch_array($req);
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Change site</b></div>' .
'<div class="menu"><form action="friendssite.php?act=edit&amp;id=' . $id . '" method="post">' .
'Url&nbsp;-&nbsp;max. 25:<br/><input type="text" size="17" name="adres" maxlength="25" value="' . functions::checkout($res['site']) . '"/><br/> ' .
'nama&nbsp;-&nbsp;max. 20:<br/><input type="text" name="name" maxlength="50" value="' . functions::checkout($res['name']) . '"/><br/>' .
'Description&nbsp;-&nbsp;max. 50:<br/><textarea cols="17" rows="2" name="opis">' . htmlentities($res['opis'], ENT_QUOTES, 'UTF-8') . '</textarea><br/>' .
'Views:<br/><input type="text" size="17" name="count" maxlength="50"  value="' . $res['count'] . '"/><br />' .
'<input name="submit" type="submit" title="click to add site" value="Save"/></form>' .
'</div><div class="nfooter"><a href="' . $_SESSION['prd'] . '">Back</a></div></div></div>';
}
}
break;

case 'redirect':
// ?e��pe?�
$req = mysql_query("SELECT `site` FROM `friendssite` WHERE `id`='$id' AND `type`='1'");
if(mysql_num_rows($req)) {         $res = mysql_fetch_assoc($req);
if (!$_SESSION['fr_site_' . $id]) {
mysql_query("UPDATE `friendssite` SET `count` = (`count`+1) WHERE `id` = '$id' LIMIT 1");
$_SESSION['fr_site_' . $id] = true;
}
header('location:' . $res['site']);
exit;

}
break;

case 'mass_del':
// Macc?�?e y�a?e?�e ca?�?�
if ($rights >= 6) {
if (isset($_GET['yes'])) {
foreach ($_SESSION['dc'] as $delid) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='" . intval($delid) . "';");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
if (empty($_POST['delch'])) {
echo functions::display_error('you not choose for delete', '<a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Back</a>');
require_once ("../incfiles/end.php");
exit;
}
foreach ($_POST['delch'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want delete this site..??!<br/><a href="?act=mass_del&amp;yes">Yes</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'mod_site':
// Ca?�� ?a ??�epa���
if ($rights >= 6) {
if (isset($_GET['pr'])) {
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `id` = '$id' LIMIT 1");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite)
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT 1");
header("location: friendssite.php?act=mod_site");
exit;
} elseif (isset($_GET['vs'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT $total_mod");
}
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `type` = '2'");
header("location: friendssite.php?act=mod_site");
exit;
}
else{

echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b><a href="friendssite.php">Friend site</a></b> | Check site</div>';
$req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='2'");
if(mysql_num_rows($req)) {
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a><br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Add <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '<br/><a href="' . functions::checkout($res['site']) . '">' . functions::checkout($res['site']) . '</a></small>';
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> | <a href="friendssite.php?act=mod_site&amp;id=' . $res["id"] . '&amp;pr">Confirm</a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">Change</a></div></div>';
++$i;
}
echo '<div class="rmenu"><input type="submit" value="delete check it"/></div></form>' .
'<div class="gmenu"><a href="friendssite.php?act=mod_site&amp;vs">Confirm all</a></div>';
}
else
echo '<div class="menu"><p>Empty list</p></div>';
echo '<div class="nfooter"><a href="friendssite.php">Back</a></div></div></div></div>';
}

}
break;

case 'add_site':
// �?�a�?e?�e ca?�a
if ($user_id) {
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
$error = array();
if ($total_site >= $userssite && $rights < 6)
$error[] = 'user only allowed add one ' . $userssite . ' site..!!';
if ((time()  - $datauser['datereg']) < ($adddate * 86400) && $rights < 6)
$error[] = 'user only allowed add site atleast after ' . $adddate . ' day..!!';
$flood = functions::antiflood();
if ($flood)
$error[] = 'antiflood..!! Please,wait ' . $flood . ' ce?.';
if($error) {
echo display_error($error, '<a href="friendssite.php">Please wait..</a>');
require_once ("../incfiles/end.php");
exit;
}
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 20) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 50) : '';
$type = $rights >= 6 ? 2 : 2;
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'All field are Required..!!';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Url site does not valid..!!';
if(!$error) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `name`='" . mysql_real_escape_string($name) . "' OR  `site`='http://" . mysql_real_escape_string($adres) . "'"), 0);
if ($total >= 1)
$error[] = 'This site url already exist..!!';

}
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=add_site">Try again</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("INSERT INTO `friendssite` SET `vr`='" . time() . "', `iduser`='$user_id', `type`='$type', `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Confermation Message</b></div><div class="gmenu">site has been added' . ($rights >= 6 ? '' : ' your site is going to show  on our List after get verification By Admin') . '</div><div class="rmenu">Just copy the html tag from box and past it in your site Homepage. Other wise Your Site will not appear in our List<br/><textarea rows="2" cols="17"><a href="http://susukan.us/">No.1 Wapmaster Forum</a></textarea></div>
<div class="nfooter"><b><a href="http://susukan.us">Back to Home</a></b></div></div></div>';
}
else {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b><a href="friendssite.php">Friend site</a></b> | Add site</div>' .
'<div class="bmenu">Only allowed direct link,else gonna be cut</div><div class="menu">' .
'<form action="friendssite.php?act=add_site" method="post">' .
'Url&nbsp;-&nbsp;max. 25:<br/><input type="text" size="17" name="adres" maxlength="25" value="http://"/><br/> ' .
'Name&nbsp;-&nbsp;max. 20:<br/><input type="text" size="17" name="name" maxlength="50"/><br/>' .
'Description&nbsp;-&nbsp;max. 50:<br/><textarea cols="17" rows="2" name="opis"></textarea><br/>' .
'<input name="submit" type="submit" title="click to add site" value="Add site"/></form>' .
'</div><div class="nfooter"><a href="friendssite.php">Friend site</a></div></div></div>';
}
}
else {
header('location: ../login.php');
exit;
}
break;
default:
// C?�c?? ca?�?�
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Friend site</b></div>';
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 6))
echo '<div class="gmenu"><a href="friendssite.php?act=add_site">Add site</a></div>';
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="friendssite.php?act=mod_site">sites for moderation</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if($total) {          $req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='1' ORDER BY `friendssite`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 6)
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a> (' . $res['count'] . ')<br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Added by <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';
if ($rights >= 6)
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">Change</a></div>';
echo '</div>';
++$i;
}
if ($rights >= 6)
echo '<div class="rmenu"><input type="submit" value="delete check it"/></div></form>';
}
else
echo '<div class="menu"><p>Empty list</p></div>';
echo '<div class="nfooter">Total:&nbsp;' . $total . '</div>';
if ($total > $kmess) {
echo '<p>' . functions::display_pagination('friendssite.php?', $start, $total, $kmess) . '</p>';
echo '<p><form action="friendssite.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="Go to page &gt;&gt;"/></form></p></div></div></div></div>';
}
}
require_once ("../incfiles/end.php");

?>
