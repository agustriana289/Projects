<?php

if ($user_id){
} else {
echo '</div><div class="mainbox"><div class="mainblok"><div class="nfooter">  <b> Welcome Friends</b></div>'; 
echo '<div class="menu"><table><tr><td width="60px"><img src="/images/susukan.us.jpg" width="60" height="60"/></td>'; 
echo '<td><b><u>Selamat Datang di <font color="blue">Susukan ID Community</b></font></u><br />Silakan lakukan <a href="/registration.php"><b>Registrasi</b></a> atau <a href="/login.php"><b>Login</b></a> agar dapat mengakses seluruh fitur wapsite ini. Terima Kasih Atas Kunjungannya.';
echo '</td></tr></table></div></div>'; 

}

?>