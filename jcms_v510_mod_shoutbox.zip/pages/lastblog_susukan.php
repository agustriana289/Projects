<?php
echo '<div class="mainbox"><div class="mainblok">';
if ($user_id) {
echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">
<font size=2><b>Last Blog</b></font></td><td width="auto" align="right"><a href="blogs/new.php"><img src="./images/add.jpg" alt="Add" width="12" height="12"/></a></td></tr></table></div>';}
if (!$user_id) {
echo '<div class="nfooter"><b>Last Blog</b></div>';}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs`"), 0);
$r = mysql_query
("SELECT * FROM `blogs` ORDER BY id DE
start, 1");
if ($total == 0)
echo '<div class="rmenu">No blogs!</div>';
$res = mysql_query("SELECT * FROM `blogs`
ORDER BY id DESC LIMIT 1");
while($req = mysql_fetch_array($res)) {
echo $i % 2 ? '<div class="list1">' : '<div class="">';
$totkom = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE `refid` = '$req[id]'"), 0);
$totlook = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE place_id='$req[id]' AND type='b'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$req[user]'"));
$set_user['avatar'] = 0;
echo '<img src="../images/pt.gif"width="20" height="20" alt=""/>&#160;<a href="blogs/view.php?id='.$req['id'].'">'.($req['name'] ? functions::checkout($req['name']) : 'Untitled').'</a><br/><small>Posted by</small> <a
href="'.$home.'/users/' . $user['name'] . '">' . $user['name'] . '</a><div class="gray">Date:<small>'.date("d F. h:ia", $req['time'] + $set_user['sdvig'] * 3600).'</small><br/>Comments: ' . $totkom . '<br/>';
++$i;
echo '</div></div></div></div></div>';
}
echo '</div></div>';
?>