<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
//editing file by http://seupang.Co.Cc http://penceter.co.cc
define('_IN_JOHNCMS', 1);
//www.susukan.us
require('../incfiles/core.php');
include('../incfiles/function.php');
$headmod = 'Bbcode';
$textl = 'Bbcode';
include('../incfiles/head.php');
echo '</div>';
include '../shout/tulis1.php';
echo "</div><div class='nfooter'>gaya tulisan</div>
<div class='menu'><input type='text' value='[b]Teks anda[/b]'/><br/><strong>Huruf tebal</strong><br />
<input type='text' value='[i]Teks anda[/i]' /><br/><em>Huruf miring</em><br />
<input type='text' value='[das]Teks anda[/das]' /><br/><span style='border:1px dashed;'>muncul kotak</span><br />
<input type='text' value='[youtube]masukan code[/youtube]' /><br/><span style='border:1px dashed;'>muncul youtube</span><br />
<input type='text' value='[marq]Teks anda[/marq]' /><br/><marquee>teks bergerak</marquee>
<input type='text' value='[in]Teks anda[/in]' /><br/>Input teks<br/>
<input type='text' value='[big]Teks anda[/big]' /><br/><big>teks besar</big><br/>
<input type='text' value='[blink]Teks anda[/blink]' /><br/><blink>teks berkedip</blink><br />
<input type='text' value='[url=http://url anda]nama url[/url]' /><br/><b>url situs</b><br /><input type='text' value='[color=red]Teks anda[/color]' /><br/>red bisa diganti dengan warna lain,dalam bahasa inggris<br/>
<input type='text' value='[u]Teks anda[/u]' /><br/><u>teks bergaris bawah</u></div>";
include('../incfiles/end.php');
?>
