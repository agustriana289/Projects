<?php

define('_IN_JOHNCMS', 1);

$textl = 'Staff-Susukan.Us';
$headmod = 'staff';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$maxsite = 100; //?a?c�?y? ca?�?�
$adddate = 3; //��c?? �?e? ??c?e pe�� �?� �?�a�?e?�� ca?�a
$userssite = 3; //��c?? pa�pe�e??�x ca?�?� ��?� ?�??�? ��epa
switch ($act) {
case 'delete':
// ��a?e?�e ca?�a
$req = mysql_query("SELECT * FROM `staff` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_GET['yes'])) {
mysql_query("DELETE FROM `staff`  WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want to delete site from list..??!<br/><a href="staff.php?act=delete&amp;id=' . $id . '&amp;yes">Yes</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'edit':
// ?e�a?��p?�a?�e ca?�a
$req = mysql_query("SELECT * FROM `staff` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 50);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 100) : '';

$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;

$error = array();
if (empty($name) || empty($opis))
$error[] = 'All field are required';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Site url not valid..!!';
if($error) {
echo functions::display_error($error, '<a href="staff.php?act=edit&amp;id=' . $id . '">Try again</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("UPDATE `staff` SET `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "', `count`='$count' WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
$res = mysql_fetch_array($req);
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Change Status</b></div>' .
'<div class="currentpage"><form action="staff.php?act=edit&amp;id=' . $id . '" method="post">' .
'<b>Why do you want to be a staff member ?</b><br/><textarea cols="17" rows="2" name="opis">' . htmlentities($res['opis'], ENT_QUOTES, 'UTF-8') . '</textarea><br/>' .
'<input name="S1" cols="20" size="20" value="[red]Reject[/red]"></p>' .
'<input name="S1" cols="20" size="20" value="[green]Accept[/green]  as a Forum Moderator"></p>' .
'<b>Status</b><br/><input type="text" name="name" maxlength="100" value="' . functions::checkout($res['name']) . '"/><br/>' .
'<input name="submit" type="submit" title="click to add site" value="Save"/></form>' .
'</div><div class="nfooter"><a href="staff.php?act=view_list">Back</a></div></div></div>';
}
}
break;

case 'redirect':
// ?e��pe?�
$req = mysql_query("SELECT `site` FROM `staff` WHERE `id`='$id' AND `type`='1'");
if(mysql_num_rows($req)) {         $res = mysql_fetch_assoc($req);
if (!$_SESSION['fr_site_' . $id]) {
mysql_query("UPDATE `staff` SET `count` = (`count`+1) WHERE `id` = '$id' LIMIT 1");
$_SESSION['fr_site_' . $id] = true;
}
header('location:' . $res['site']);
exit;

}
break;

case 'mass_del':
// Macc?�?e y�a?e?�e ca?�?�
if ($rights >= 6) {
if (isset($_GET['yes'])) {
foreach ($_SESSION['dc'] as $delid) {
mysql_query("DELETE FROM `staff`  WHERE `id`='" . intval($delid) . "';");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
if (empty($_POST['delch'])) {
echo functions::display_error('you not choose for delete', '<a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Back</a>');
require_once ("../incfiles/end.php");
exit;
}
foreach ($_POST['delch'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want delete this Application..??!<br/><a href="?act=mass_del&amp;yes">Yes</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'mod_site':
// Ca?�� ?a ??�epa���
if ($rights >= 6) {
if (isset($_GET['pr'])) {
mysql_query("UPDATE `staff` SET `type` = '1' WHERE `id` = '$id' LIMIT 1");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `type`='1'"), 0);
if ($total > $maxsite)
mysql_query("DELETE FROM `staff` where `type`='1' ORDER BY `vr` ASC LIMIT 1");
header("location: staff.php?act=mod_site");
exit;
} elseif (isset($_GET['vs'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `type`='1'"), 0);
if ($total > $maxsite) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `type`='2'"), 0);
mysql_query("DELETE FROM `staff` where `type`='1' ORDER BY `vr` ASC LIMIT $total_mod");
}
mysql_query("UPDATE `staff` SET `type` = '1' WHERE `type` = '2'");
header("location: staff.php?act=mod_site");
exit;
}
else{

echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Staff Request Panding</b></div>';
$req = mysql_query("SELECT `staff`.*, `users`.`name` AS `nick` FROM `staff` LEFT JOIN `users` ON `staff`.`iduser` = `users`.`id` WHERE `staff`.`type`='2'");
if(mysql_num_rows($req)) {
echo '<form action="staff.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>&nbsp;';
if ($rights >= 9){
echo '<span class="red"><a href="profile.php?act=edit&amp;user=' . $user['id'] . '">edit</b></a></span><br />';
}
echo '' . functions::checkout($res['opis'], 1, 1);
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="staff.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> | <a href="staff.php?act=mod_site&amp;id=' . $res["id"] . '&amp;pr">Confirm</a> | <a href="staff.php?act=edit&amp;id=' . $res["id"] . '">Change</a></div></div>';
++$i;
}
echo '<div class="rmenu"><input type="submit" value="delete check it"/></div></form></div>';
}
else
echo '<div class="rmenu"><p>No More Staff Request Panding</p></div>';
echo '<div class="nfooter"><a href="staff.php">Back</a></div></div></div></div>';
}

}
break;

default:
// �?�a�?e?�e ca?�a
if ($user_id) {
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `iduser`='$user_id'"), 0);
$error = array();
if ($total_site >= $userssite && $rights < 6)
$error[] = 'user only allowed add one ' . $userssite . ' site..!!';
if ((time()  - $datauser['datereg']) < ($adddate * 0))
$error[] = 'user only allowed add site atleast after ' . $adddate . ' day..!!';
$flood = functions::antiflood();
if ($flood)
$error[] = 'antiflood..!! Please,wait ' . $flood . ' ce?.';
if($error) {
echo display_error($error, '<a href="staff.php">Please wait..</a>');
require_once ("../incfiles/end.php");
exit;
}
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 50);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 100) : '';

$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$type = $rights >= 6 ? 2 : 2;
if (empty($adres) || empty($opis))
$error[] = 'All field are Required..!!';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Url site does not valid..!!';
if(!$error) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `name`='" . mysql_real_escape_string($name) . "' OR  `site`='http://" . mysql_real_escape_string($adres) . "'"), 0);
if ($total >= 1)
$error[] = 'This site url already exist..!!';

}
if($error) {
echo functions::display_error($error, '<a href="staff.php">Try again</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("INSERT INTO `staff` SET `vr`='" . time() . "', `iduser`='$user_id', `type`='$type', `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Confermation Message</b></div><div class="gmenu"><b>Thank you for applying </b><br/>Your Application has been Submited' . ($rights >= 6 ? '' : ' your Application is going to Moderate by Admin') . '</div><div class="rmenu"><green>You will shortly notify by pm from admin within 24 hour or you can check your status <a href="staff.php?act=view_list">here</a></green></div>
<div class="nfooter"><b><a href="http://susukan.us">Back to Home</a></b></div></div></div>';
}
else {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Our staff</b></div><div class="currentpage">' .
'<p>We are continuously trying to find talanted people for our staff and also to expand our comunity.<br/>
<b>What do we want ? We want to make the internet better.</b><br/>
And you are invited to join us. You dont know if you will fit in here ? Well its very simple to answer that. If you like any kind of programming we usually like you.
You must note that a staff member needs to have some level of knowledge about programming in order to help other users.
You also need to note that a staff member needs to be active here daily and usually reply to topics if he can help.
Finally the most important thing a staff member has to do is to HAVE FUN.
Do you think you can manage that ? And most importantly do you think that by doing this you can help others ?
If the answrer is yes then we invite you to become a part of our team.
To ancomplish that all you have to do is to submit the form down below and if the current staff members agree that you can become a staff member you will be promoted in just a few hours. Its also possible to receive pms from the staff if they want to get to know you better but it is recommended to submit this form after you do some decent number of posts here and by doing that they we already know you.
That being said we wish you good luck and we hope, staff member or not, that you have a good time here.</p> ' .
'<form action="staff.php?act=add_site" method="post">' .
'<b>You must have a site to apply ?</b> ' .
'<br/><input type="text" size="17" name="adres" maxlength="25" value="http://"/><br/> ' .
'<b>Why do you want to be a staff member ?</b> ' .
'<br/><textarea cols="17" rows="2" name="opis"></textarea><br/>' .
'<input name="submit" type="submit" title="click to add site" value="Apply"/></form>' .
'</div><div class="omenu">If you applyed you can view your status <a href="staff.php?act=view_list">Here</a></div>';
echo '<div class="nfooter"><a href="http://susukan.us"><b>Back To Home</b></a></div></div></div>';
}
}
else {
header('location: ../login.php');
exit;
}
break;
case 'view_list':
// C?�c?? ca?�?�
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Staff Request List</b></div>';
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 1) || $rights >= 6))

if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="staff.php?act=mod_site">Moderation</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `staff` WHERE `type`='1'"), 0);
if($total) {          $req = mysql_query("SELECT `staff`.*, `users`.`name` AS `nick` FROM `staff` LEFT JOIN `users` ON `staff`.`iduser` = `users`.`id` WHERE `staff`.`type`='1' ORDER BY `staff`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 6)
echo '<form action="staff.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

echo '<img src="../images/users.png">&nbsp;<a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a></img><br/>';

echo '' . functions::checkout($res['opis'], 1, 1);
echo '<br/><b>' . bbcode::tags($res['name']) . '</b><br/>';

if ($rights >= 6)
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> | <red><b><a href="staff.php?act=edit&amp;id=' . $res["id"] . '">Dicision</b></a></red></div>';
echo '</div>';
++$i;
}
if ($rights >= 6)
echo '<div class="rmenu"><input type="submit" value="delete check it"/></div></form>';
}
else
echo '<div class="menu"><p>Empty list</p></div>';
echo '<div class="nfooter">Total:&nbsp;' . $total . '</div>';
if ($total > $kmess) {
echo '<p>' . functions::display_pagination('staff.php?act=view_list&', $start, $total, $kmess) . '</p>';
echo '<p><form action="staff.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="Go to page &gt;&gt;"/></form></p></div></div></div></div>';
}
}
require_once ("../incfiles/end.php");

?>
