<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

require('../incfiles/head.php');

/*
-----------------------------------------------------------------
Ð£Ð´Ð°Ð»Ð¸Ñ�Ñ� ÐºÐ°Ñ�Ñ�Ð¸Ð½ÐºÑ�
-----------------------------------------------------------------
*/
if ($img && $user['id'] == $user_id || $rights >= 6) {
    $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `id` = '$img' AND `user_id` = '" . $user['id'] . "' LIMIT 1");
    if (mysql_num_rows($req)) {
        $res = mysql_fetch_assoc($req);
        $album = $res['album_id'];
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="album.php?act=show&amp;al=' . $album . '&amp;user=' . $user['id'] . '"><b>' . $lng['photo_album'] . '</b></a> | ' . $lng_profile['image_delete'] . '</div>';
        //TODO: Ð¡Ð´ÐµÐ»Ð°Ñ�Ñ� Ð¿Ñ�Ð¾Ð²ÐµÑ�ÐºÑ�, Ñ�Ñ�Ð¾Ð± Ð°Ð´Ð¼Ð¸Ð½Ð¸Ñ�Ñ�Ñ�Ð°Ñ�Ð¸Ñ� Ð½Ðµ Ð¼Ð¾Ð³Ð»Ð° Ñ�Ð´Ð°Ð»Ñ�Ñ�Ñ� Ñ�Ð¾Ñ�ÐºÐ¸ Ñ�Ñ�Ð°Ñ�Ñ�Ð¸Ñ� Ð¿Ð¾ Ð´Ð¾Ð»Ð¶Ð½Ð¾Ñ�Ñ�Ð¸
        if (isset($_POST['submit'])) {
            // Ð£Ð´Ð°Ð»Ñ�ÐµÐ¼ Ñ�Ð°Ð¹Ð»Ñ� ÐºÐ°Ñ�Ñ�Ð¸Ð½Ð¾Ðº
            @unlink('../files/users/album/' . $user['id'] . '/' . $res['img_name']);
            @unlink('../files/users/album/' . $user['id'] . '/' . $res['tmb_name']);
            // Ð£Ð´Ð°Ð»Ñ�ÐµÐ¼ Ð·Ð°Ð¿Ð¸Ñ�Ð¸ Ð¸Ð· Ñ�Ð°Ð±Ð»Ð¸Ñ�
            mysql_query("DELETE FROM `cms_album_files` WHERE `id` = '$img'");
            mysql_query("DELETE FROM `cms_album_votes` WHERE `file_id` = '$img'");
            mysql_query("OPTIMIZE TABLE `cms_album_votes`");
            mysql_query("DELETE FROM `cms_album_comments` WHERE `sub_id` = '$img'");
            mysql_query("OPTIMIZE TABLE `cms_album_comments`");
            header('Location: album.php?act=show&al=' . $album . '&user=' . $user['id']);
        } else {
            echo '<div class="rmenu"><form action="album.php?act=image_delete&amp;img=' . $img . '&amp;user=' . $user['id'] . '" method="post">' .
                '<p>' . $lng_profile['image_delete_warning'] . '</p>' .
                '<p><input type="submit" name="submit" value="' . $lng['delete'] . '"/></p>' .
                '</form></div>' .
                '<div class="nfooter"><a href="album.php?act=show&amp;al=' . $album . 'user=' . $user['id'] . '">' . $lng['cancel'] . '</a></div></div>';
        }
    } else {
        echo functions::display_error($lng['error_wrong_data']);
    }
}
?>