<?php 
$sqlhost="sql309.eb2a.com"; //cazOn sa"-a cha"- nA?y 
$username="eb2a_6164559"; //cazOn sa"-a cha"- nA?y 
$password="123gogoteam";//cazOn sa"-a cha"- nA?y 
mysql_connect($sqlhost,$username,$password) or 
die("Cannot connect to SQL"); 
mysql_select_db("eb2a_6164559_admin") or 
die("Cannot select database"); 
?>