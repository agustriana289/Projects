﻿<?php include("connectdb.php"); ?> 
<h2>View My Address Book!!</h2> 
<?php 
$result = mysql_query("select * from addressbook") or 
die (mysql_error()); 
while ($row = mysql_fetch_array($result)) 
{ 
echo "<b>Name:</b>"; 
echo $row["name"]; 
echo "<br>\n"; 
echo "<br>\n"; 
echo "<b>Age:</b>"; 
echo $row["age"]; 
echo "<br>\n"; 
echo "<br>\n"; 
echo "<b>Email:</b>"; 
echo $row["email"]; 
echo "<br>\n"; 
echo "<br>\n"; 
echo "<b>Comments:</b>"; 
echo $row["comments"]; 
echo "<br>\n"; 
echo "<br>\n"; 
echo "<br>\n"; 
} 
mysql_free_result($result); 
?> 
<h2><a href="admin.php">Sign My Guest Book!!</a></h2>