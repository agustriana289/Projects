﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Nguyen Ngoc Thanh Tung - Personal information page of Nguyen Ngoc Thanh Tung</title>
</head>
<body>
<meta name="description" content="Personal information nguyen ngoc thanh tung"/>
<meta name="keywords" content="nguyễn ngọc thanh tùng, nguyen ngoc thanh tung, tungmaster, tungmasterhg, tung ngoc thanh nguyen"/>
</head><body><div><strong><font face="Arial" size="3">Personal Information Page</font></strong></div>
		<div><font size="2" face="Arial">This page displays brief summaries of individual information and you can to easily contact me.</font></div>

<div align="center"><a href="/04022011021.jpg"><img src="../users/04022011021.jpg" alt="Image nguyen ngoc thanh tung" title="Image nguyen ngoc thanh tung" width="128" border="0"/></a></div><div><ul><li><b>Full name:</b> Nguyen Ngoc Thanh Tung</li><li><b>Birthday:</b> 15/05/1991</li><li><b>Location</b>: HaGiang, VietNam</li><li><b>Education</b>: University</li><li><b>Yahoo</b>: nguyentung1505</li><li><b>Email</b>: <a href="#contact">nguyentung1505@yahoo.com.vn</a></li><li><b>The project implementation</b>
		<ul>
		<li><i>In Vietnam</i>: <a href="http://mhagiang.com">MHaGiang.Com</a>; <a href="http://vuinao.com">VuiNao.Com</a>; <a href="http://johncmsvn.tk">JohnCMSVN.Tk</a>; <a href="http://nguyentung.org">NguyenTung,Org</a>;  <a href="http://boygirlvn.com">BoyGirlVN.Com</a>; <a href="http://waphagiang.com">WapHaGiang.Com</a>; <a href="http://upvn.tk">UpVN.Tk</a>; ..</li>
		<li><i>World Wide</i>: <a href="http://quagioihan.com">QuaGioiHan.Com</a>; ..</li>
		</ul></li></ul></div><hr/><div><strong><font size="3" face="Arial">Contact</font></strong></div>
	<div><font size="2" face="Arial">Enter the correct information and full to send contact suggestions, cooperation, ..</font></div>	<table border="0" width="100%" cellspacing="1" id="contact">
	<tr><td> 
		<table border="0">
<form action="create.php" method="POST">
<tr><td width="30%">Full name</td><td><input value="" name="name" type="text"/></td></tr>
			<tr><td>Age</td><td><input value="" name="age" type="text"/></td></tr>
			<tr><td>Email</td><td><input value="" name="email" type="text"/></td></tr>
			<tr><td>Adress</td><td><input value="" name="adress" type="text"/></td></tr>
			<tr><td>Message</td><td><textarea name="comments"></textarea></td></tr>
<tr><td><input value="Send" name="submit" type="submit" /></td></tr>
</form>
</form>
</table></td> 
</tr></table><hr/>
Version: <a href="/vi.php">Vietnamese</a> | English
<br/>
<div align="center"><a href="http://top.vietpro.mobi/click_in.html?46"><img alt="Online MHaGiang" src="http://top.vietpro.mobi/online.gif?46" border="0"></a><br/><img src="http://whos.amung.us/swidget/rs7877pyeq2y/" border="0"/></div>
</body></html>