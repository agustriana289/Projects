<?php

/**
@author FROSTY
@site nadmad.ru
@mail: valik619@inbox.ru
Modul: ���o� c�a��ap��o� �o���!

*/

define('_IN_JOHNCMS', 1);
$textl = 'Mail Viewer';
$rootpath = '../';
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');
if ($datauser['rights'] < 9) {
echo header("Location: http://susukan.us");
require_once ('../incfiles/end.php');
exit;
}

$vsego = mysql_result(mysql_query("SELECT COUNT(*) FROM `privat`;"), 0);
$poshta = mysql_query("SELECT * FROM `privat` ORDER BY `id` DESC LIMIT $start, $kmess ");
//$sms = mysql_fetch_array($vsego);

$id = intval ($_GET['id']) ? $_GET['id'] : '';


$act = isset ($_GET['act']) ? $_GET['act'] : '';
switch ($act) {

case 'deleted' :

if ($rights == 9) {

mysql_query("DELETE FROM `privat` WHERE `id`='" . $id . "'");

header("Location: sms.php");
}else{

header("Location: http://susukan.us");}
break;

default :
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>User Message Viewer</b></div>';


if ($poshta <1){
echo '<div class="rmenu">Coo��e��� �e�y</div>';}
while ($sms = mysql_fetch_assoc($poshta)) {
echo '<div class="menu">';


echo '<b>From: </b>' . $sms['author'] . '<br /><b>To: </b>' . $sms['user'] . '';


echo '<br /><b>Time:</b> ' . date('d.m.o - H:i',$sms['time']) . '';

echo '<br /><b>Text: </b>' . ($sms['text']) . '';

echo ' <a href="sms.php?act=deleted&amp;id=' . $sms['id'] . '"><small>[Delete]</small></a>'; //cc���a �a y�a�e��e �oc�a
echo '</div>';
++$i;
}
$kmess = 30;
$start = 10;
$stranic = $poshta/$kmess;
echo '<div class="nfooter"><b>Page: ' . round($stranic) . '</b></div></div></div>'; //C�o���o �ce�o c�pa��� (��� �o��o�o o�o�pa�e��� �ao�py����ae�)

if ($poshta > $kmess) {

echo '<div class="topmenu">' . functions::display_pagination('sms.php', $start, $total, $kmess) . '</div>';
echo '<form action="sms.php" method="post"><input type="text" name="page" size="3"/><input type="submit" value="submit"/></form>';
}

break;
}

echo '<a href="index.php">Admin Panel</a>';

require_once ('../incfiles/end.php');
?>
