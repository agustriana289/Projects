﻿<?php 
include("connectdb.php"); 
if(isset($_POST['submit'])) { 
  $name     = $_POST['name'] ; 
  $age      = $_POST['age']; 
  $email    = $_POST['email']; 
  $address  = $_POST['address']; 
  $comments = $_POST['comments']; 
  $sql=       "INSERT INTO addressbook (name, age, email, address, comments) 
  VALUES ('".$name."', '".$age."', '".$email."', '".$address."', '".$comments."')"; 
    mysql_query($sql) or 
 die(mysql_error()); 
?> 
<a href="view.php">View my address book</a> 
<?}?>