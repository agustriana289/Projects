<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$id = isset($_POST['id']) ? abs(intval($_POST['id'])) : false;
$act = isset($_POST['act']) ? trim($_POST['act']) : '';
if($act == 'clean')
	header('location: index.php?act=scan_dir&do=clean&id=' . $id);
else
	header('location: index.php?act=' . $act . '&id=' . $id);

?>