<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$title .= ': Deleted File';
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name'])) {
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if ($rights > 6 || $rights == 4) {
    if (isset($_GET['yes'])) {
        if (is_dir($screens_path . '/' . $id)) {
            $dir_clean = opendir($screens_path . '/' . $id);
            while ($file = readdir($dir_clean)) {
                if ($file != '.' && $file != '..') {
                    @unlink($screens_path . '/' . $id . '/' . $file);
                }
            }
            closedir($dir_clean);
            rmdir($screens_path . '/' . $id);
        }
        @unlink('../files/download/java_icons/' . $id . '.png');
        $req_file_more = mysql_query("SELECT * FROM `down_more` WHERE `refid` = '$id'");
        if (mysql_num_rows($req_file_more)) {
            while ($res_file_more = mysql_fetch_assoc($req_file_more)) {
                if (is_file($res_down['dir'] . '/' . $res_file_more['name']))
                    @unlink($res_down['dir'] . '/' . $res_file_more['name']);
            }
            mysql_query("DELETE FROM `down_more` WHERE `refid` = '$id'");
        }
        mysql_query("DELETE FROM `down_comms` WHERE `refid`='$id'");
        @unlink($res_down['dir'] . '/' . $res_down['name']);
        $dirid = $res_down['refid'];
        $sql = '';
        while ($dirid != '0' && $dirid != "") {
            $res = mysql_fetch_assoc(mysql_query("SELECT `refid` FROM `down_files` WHERE `type` = 1 AND `id` = '$dirid' LIMIT 1"));
            if ($i)
                $sql .= ' OR ';
            $sql .= '`id` = \'' . $dirid . '\'';
            $dirid = $res['refid'];
            ++$i;
        }
        mysql_query("UPDATE `down_files` SET `total` = (`total`-1) WHERE $sql");
        mysql_query("DELETE FROM `down_files` WHERE `id` = '$id' LIMIT 1");
        mysql_query("OPTIMIZE TABLE `down_files`");
        header('Location: index.php?id=' . $res_down['refid']);
    } else {
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Deleting a file</b></div><div class="rmenu">Are you sure you want to delete the file?<br /> <a href="index.php?act=del_file&amp;id=' . $id . '&amp;yes">Remove</a></div><div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a></div>';
    }
} else {
    header('Location: ../?err');
}
?>