<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || ($rights < 6 && $rights != 4)) {
    echo functions::display_error('<a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if (isset($_POST['submit'])) {
    $name = isset($_POST['text']) ? trim($_POST['text']) : null;
    $name_link = isset($_POST['name_link']) ? functions::check(mb_substr($_POST['name_link'], 0, 200)) : null;
    if ($name_link && $name) {
        $name = mysql_real_escape_string($name);
        mysql_query("UPDATE `down_files` SET `rus_name`='$name', `text` = '$name_link' WHERE `id` = '$id' LIMIT 1");
        header('Location: index.php?act=view&id=' . $id);
    } else
        echo functions::display_error('All fields are required!<br /><a href="index.php?act=edit_file&amp;id=' . $id . '">Back</a>');
} else {
    $file_name = functions::checkout($res_down['rus_name']);
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $file_name . '</b></div>';
    echo '<div class="list1"><form action="index.php?act=edit_file&amp;id=' . $id . '" method="post">
    File name (Ð¼Ð°Ñ�. 200):<br /><input type="text" name="text" value="' . $file_name . '"/><br />
    Link to download file (Ð¼Ð°Ñ�. 200):<br /><input type="text" name="name_link" value="' . $res_down['text'] . '"/><br />';
    echo '<input type="submit" name="submit" value="Save"/></form></div>';
    echo '<div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a></div>';
}
?>