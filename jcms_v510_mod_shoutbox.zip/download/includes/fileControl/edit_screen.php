<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || ($rights < 6 && $rights != 4)) {
    echo functions::display_error('<a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
$screen = array ();
if ($do && is_file($screens_path . '/' . $id . '/' . $do)) {
    unlink($screens_path . '/' . $id . '/' . $do);
    header('Location: index.php?act=edit_screen&id=' . $id);
    exit;
} else if (isset($_POST['submit'])) {
    require('../incfiles/lib/class.upload.php');
    $handle = new upload($_FILES['screen']);
    if ($handle->uploaded) {
        $handle->file_new_name_body = $id;
        $handle->allowed = array (
            'image/jpeg',
            'image/gif',
            'image/png'
        );
        $handle->file_max_size = 1024 * $set['flsz'];
        if ($set_down['screen_resize']) {
            $handle->image_resize = true;
            $handle->image_x = 240;
            $handle->image_ratio_y = true;
        }
        $handle->process($screens_path . '/' . $id . '/');
        if ($handle->processed) {
            echo '<div class="gmenu"><b>Screenshot is attached</b>';
        } else
            echo '<div class="rmenu"><b>Screenshot not attached: ' . $handle->error . '</b>';
    } else
        echo '<div class="rmenu"><b>No file selected</b>';
    echo '<br /><a href="index.php?act=edit_screen&amp;id=' . $id . '">Back</a><br /><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></div>';
} else {
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Screenshots</b>: ' . functions::checkout($res_down['rus_name']) . '</div>';
    if ($screen)
        echo '<div class="gmenu"><img src="' . $screen . '" alt="screen"/></div>';
    echo '<div class="list1"><form action="index.php?act=edit_screen&amp;id=' . $id . '"  method="post" enctype="multipart/form-data"><input type="file" name="screen"/><br /><input type="submit" name="submit" value="Upload"/>';
    if ($screen)
        echo '&nbsp;<input type="submit" name="delscreen" value="Remove"/>';
    echo '</form></div><div class="phdr"><small>Max. size: ' . $set['flsz'] . ' Kb
        ' . ($set_down['screen_resize'] ? '<br />Screenshot will be automatically resize , of a width not exceeding 240px (height will be automatically resize)' : '') . '
        <br />New file to replace the old</small></div>';
    $screen = array ();
    if (is_dir($screens_path . '/' . $id)) {
        $dir = opendir($screens_path . '/' . $id);
        while ($file = readdir($dir)) {
            if (($file != '.') && ($file != "..") && ($file != "name.dat") && ($file != ".svn") && ($file != "index.php")) {
                $screen[] = $screens_path . '/' . $id . '/' . $file;
            }
        }
        closedir($dir);
    } else {
        if (mkdir($screens_path . '/' . $id, 0777) == true)
            @chmod($screens_path . '/' . $id, 0777);
    }
    if ($screen) {
        $total = count($screen);
        for ($i = $start; $i < $total; $i++) {
            $screen_name = htmlentities($screen[$i], ENT_QUOTES, 'utf-8');
            $file = preg_replace('#^' . $screens_path . '/' . $id . '/(.*?)$#isU', '$1', $screen_name, 1);
            echo (($i % 2) ? '<div class="list2">' : '<div class="list1">') . '
                  <table  width="100%"><tr><td width="40" valign="top"><a href="' . $screen_name . '"><img src="preview.php?type=1&amp;img=' . rawurlencode($screen_name) . '" alt="screen_' . $i . '" /></a></td><td>' . $file . '<div class="sub"><a href="index.php?act=edit_screen&amp;id=' . $id . '&amp;do=' . $file
                . '">Remove</a></div></td></tr></table></div>';
        }
    }
    echo '<div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a></div>';
}
?>