<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name'])) {
    require('../incfiles/head.php');
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
$title_pages = functions::checkout(mb_substr($res_down['rus_name'], 0, 30));
$textl = mb_strlen($res_down['rus_name']) > 30 ? $title_pages . '...' : $title_pages;
require('../incfiles/head.php');
if ($res_down['type'] == 3) {
    echo '<div class="rmenu">Wait to approve</div>';
    if ($rights < 6 && $rights != 4) {
        require('../incfiles/end.php');
        exit;
    }
}
$format_file = functions::format($res_down['name']);
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . functions::checkout($res_down['rus_name']) . '</b></div>';
if($user_id) {
	$bookmark = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_bookmark` WHERE `file_id` = $id  AND `user_id` = $user_id"), 0);
    if(isset($_GET['addBookmark']) && !$bookmark) {
    	mysql_query("INSERT INTO `down_bookmark` SET `file_id`='$id', `user_id`='$user_id' ");
        $bookmark = 1;
    } elseif(isset($_GET['delBookmark']) && $bookmark) {
        mysql_query("DELETE FROM `down_bookmark` WHERE `file_id`='$id' AND `user_id`='$user_id'");
    	$bookmark = 0;
    }
	echo '<div class="topmenu">';
	if(!$bookmark) echo '<a href="index.php?act=view&amp;id=' . $id . '&amp;addBookmark">Add to favorites</a>';
    else echo '<a href="index.php?act=view&amp;id=' . $id . '&amp;delBookmark">Remove from favorites</a>';
	echo '</div>';
}
$text_info = '';
$screen = array ();
if (is_dir($screens_path . '/' . $id)) {
    $dir = opendir($screens_path . '/' . $id);
    while ($file = readdir($dir)) {
        if (($file != '.') && ($file != "..") && ($file != "name.dat") && ($file != ".svn") && ($file != "index.php")) {
            $screen[] = $screens_path . '/' . $id . '/' . $file;
        }
    }
    closedir($dir);
}
if (($format_file == 'mp4' || $format_file == 'flv') && !$is_mobile) {
echo'<div class="menu"><b>Review</b><br />
<div id="mediaplayer">JW Player goes here</div>
    <script type="text/javascript" src="players/mediaplayer-5.7-viral/jwplayer.js"></script>
    <script type="text/javascript">
        jwplayer("mediaplayer").setup({
            flashplayer: "players/mediaplayer-5.7-viral/player.swf",
            file: "'.$res_down['dir'] . '/' . $res_down['name'].'",
            image: "preview.php?type=3&amp;img=' . rawurlencode($screen[0]) . '"
        });
    </script></div>';
}
if ($format_file == 'jpg' || $format_file == 'jpeg' || $format_file == 'gif' || $format_file == 'png') {
    $info_file = getimagesize($res_down['dir'] . '/' . $res_down['name']);
    echo '<div class="gmenu"><img src="preview.php?type=2&amp;img=' . rawurlencode($res_down['dir'] . '/' . $res_down['name']) . '" alt="preview" /></div>';
    $text_info = '<b>Resolution: </b>' . $info_file[0] . 'x' . $info_file[1] . ' px<br />';
}
else if (($format_file == '3gp' || $format_file == 'avi' || $format_file == 'mp4') && !$screen && $set_down['video_screen'])
    $screen[] = screen_auto($res_down['dir'] . '/' . $res_down['name'], $res_down['id'], $format_file);
elseif (($format_file == 'thm' || $format_file == 'nth') && !$screen && $set_down['theme_screen'])
    $screen[] = screen_auto($res_down['dir'] . '/' . $res_down['name'], $res_down['id'], $format_file);
elseif ($format_file == 'mp3') {
	if (!$is_mobile)
    	$text_info ='<object type="application/x-shockwave-flash" data="' . $set['homeurl'] . '/download/players/player.swf" width="240" height="20" id="dewplayer" name="dewplayer">
		<param name="wmode" value="transparent" /><param name="movie" value="' . $set['homeurl'] . '/download/players/player.swf" />
		<param name="flashvars" value="mp3=' . $set['homeurl'] . '/' . str_replace('../', '', $res_down['dir']) . '/' . $res_down['name'] . '" /> </object><br />';
	else $text_info = '';
  	require ('../incfiles/lib/getid3/getid3.php');
	$getID3 = new getID3;
	$getID3->encoding = 'cp1251';
	$getid = $getID3->analyze($res_down['dir'] . '/' . $res_down['name']);
    $mp3info = true;
	if(!empty($getid['tags']['id3v2'])) $tagsArray = $getid['tags']['id3v2'];
	elseif(!empty($getid['tags']['id3v1'])) $tagsArray = $getid['tags']['id3v1'];
	else $mp3info = false;
	$text_info .= '<b>Channels</b>: ' . $getid['audio']['channels'] . ' (' . $getid['audio']['channelmode'] . ')<br/>' .
	'<b>BitRate</b>: ' . ceil($getid['audio']['sample_rate']/1000) . ' KHz<br/>' .
	'<b>Quality</b>: ' . ceil($getid['audio']['bitrate']/1000) . ' Kbit/s<br/>' .
	'<b>Duration</b>: ' . date('i:s', $getid['playtime_seconds']) . '<br />';
	if($mp3info){
		if(isset($tagsArray['artist'][0])) $text_info .= '<b>Artist</b>: ' . mp3tagsOut($tagsArray['artist'][0]) . '<br />';
		if(isset($tagsArray['title'][0])) $text_info .= '<b>Title</b>: ' . mp3tagsOut($tagsArray['title'][0]) . '<br />';
		if(isset($tagsArray['album'][0])) $text_info .= '<b>Album</b>: ' . mp3tagsOut($tagsArray['album'][0]) . '<br />';
		if(isset($tagsArray['genre'][0])) $text_info .= '<b>Genre</b>: ' . mp3tagsOut($tagsArray['genre'][0]) . '<br />';
 		if(intval($tagsArray['year'][0])) $text_info .= '<b>Year</b>: ' . (int) $tagsArray['year'][0] . '<br />';
	}
}
if ($screen) {
    $total = count($screen);
    if ($total > 1) {
        if ($page >= $total) $page = $total;
        echo '<div class="topmenu"> ' . functions::display_pagination('index.php?act=view&amp;id=' . $id . '&amp;', $page-1, $total, 1) . '</div>' .
		'<div class="gmenu"><b>Screenshot (' . $page . '/' . $total . '):</b><br />' .
        '<img src="preview.php?type=3&amp;img=' . rawurlencode($screen[$page-1]) . '" alt="screen" /></div>';
    } else {
        echo '<div class="gmenu"><b>Screenshot:</b><br /><img src="preview.php?type=3&amp;img=' . rawurlencode($screen[0]) . '" alt="screen" /></div>';
    }
}
$user = mysql_fetch_assoc(mysql_query("SELECT `name`, `id` FROM `users` WHERE `id`='" . $res_down['user_id'] . "' LIMIT 1"));
if ($user['id']) $user_up = $user['id'] == $user_id || !$user_id ? $user['name'] : '<a href="../users/profil.php?user=' . $user['id'] . '">' . $user['name'] . '</a>';
else $user_up = 'USER_DEL';
echo '<div class="list1"><b>Name:</b> ' . $res_down['name'] . '<br /><b>Downloads:</b> ' . $res_down['field'] . ' time(s)
<br /><b>Uploaded by:</b> ' . $user_up . '<br />' . $text_info;
if ($res_down['about'])
    echo '<b>Description:</b> ' . functions::checkout($res_down['about'], 1, 1);
echo '<div class="sub"></div>';
$file_rate = explode('|', $res_down['rate']);
if ((isset($_GET['plus']) || isset($_GET['minus'])) && !$_SESSION['rate_file_' . $id]) {
    if (isset($_GET['plus']))
        $file_rate[0] = $file_rate[0] + 1;
    else
        $file_rate[1] = $file_rate[1] + 1;
    mysql_query("UPDATE `down_files` SET `rate`='" . $file_rate[0] . '|' . $file_rate[1] . "' WHERE `id`='$id'");
    echo '<b><span class="green">Your vote</span></b><br />';
    $_SESSION['rate_file_' . $id] = 1;
}
$sum = ($file_rate[1] + $file_rate[0]) ? round(100 / ($file_rate[1] + $file_rate[0]) * $file_rate[0]) : 50;
echo '<b>Rate File</b>' . (!$_SESSION['rate_file_' . $id] ? '(<a href="index.php?act=view&amp;id=' . $id . '&amp;plus">+</a>/<a href="index.php?act=view&amp;id=' . $id . '&amp;minus">-</a>)' : '(+/-)') . ': <b><span class="green">' . $file_rate[0] .
    '</span>/<span class="red">' . $file_rate[1] . '</span></b>
<br /><img src="vote_img.php?img=' . $sum . '" alt="Rating" /></div>';
if ($format_file == 'jpg' || $format_file == 'jpeg' || $format_file == 'gif' || $format_file == 'png') {
    $array = array (
        '101x80',
        '128x128',
        '128x160',
        '176x176',
        '176x208',
        '176x220',
        '208x208',
        '208x320',
        '240x266',
        '240x320',
        '240x432',
        '352x416',
        '480x800'
    );
    echo '<form action="created_img.php" method="get"><div class="list1">Custom size:
    <input name="id" type="hidden" value="' . $id . '" /><select name="img_size">';
    $img = 0;
    foreach ($array as $v) {
        echo '<option value="' . $img . '">' . $v . '</option>';
        ++$img;
    }
    echo '</select><br />Quality: <select name="val">' .
        '<option value="100">100</option>' .
        '<option value="90">90</option>' .
        '<option value="80">80</option>' .
        '<option value="70">70</option>' .
        '<option value="60">60</option>' .
        '<option value="50">50</option>' .
        '</select><br />' .
        '<input name="proportion" type="checkbox" value="1" />&nbsp;Keep aspect ratio<br /><input type="submit" value="Download" /></div></form>';
}
echo '<div class="list2"><table  width="100%"><tr><td width="16" valign="top">';
if ($format_file == 'jar' && $set_down['icon_java'])
    echo java_icon($res_down['dir'] . '/' . $res_down['name'], $res_down['id']);
else
    echo '<img src="' . $filesroot . '/images/download/' . (file_exists($filesroot . '/images/download/' . $format_file . '.png') ? $format_file . '.png' : 'file.gif') . '" alt="file" />';
echo '</td><td><a href="index.php?act=load_file&amp;id=' . $id . '">' . $res_down['text'] . '</a> (' .  formatsize(filesize($res_down['dir'] . '/' . $res_down['name'])) . ') <div class="sub">Added: ' . date("d.m.y в H:i", $res_down['time'] + $set_user['timeshift'] * 3600);
if ($format_file == 'jar')
    echo ', <a href="index.php?act=jad_file&amp;id=' . $id . '">Download as JAD</a>';
elseif ($format_file == 'txt') {
    echo ', Convert to <a href="index.php?act=txt_in_zip&amp;id=' . $id . '">ZIP</a> / <a href="index.php?act=txt_in_jar&amp;id=' . $id . '">JAR</a> file.';
}
else if ($format_file == 'zip')
    echo ', <a href="index.php?act=open_zip&amp;id=' . $id . '">Open Archives</a><br /><a href="http://myroot.7ko.in/installer/?package='.rawurlencode($set['homeurl'].'/'.substr($res_down['dir'],3).'/'.$res_down['name']).'">FTP Archive</a>';
echo '</div></td></tr></table></div>';
$req_file_more = mysql_query("SELECT * FROM `down_more` WHERE `refid` = '$id'");
if (mysql_num_rows($req_file_more)) {
    while ($res_file_more = mysql_fetch_assoc($req_file_more)) {
        echo ($k % 2) ? '<div class="list2">' : '<div class="list1">';
        $format = explode('.', $res_file_more['name']);
        $format_file = strtolower($format[count($format) - 1]);
        echo '<table  width="100%"><tr><td width="16" valign="top">';
        if ($format_file == 'jar' && $set_down['icon_java'])
            echo java_icon($res_down['dir'] . '/' . $res_file_more['name'], 'more_' . $res_file_more['id']);
        else
            echo '<img src="' . $filesroot . '/images/download/' . (file_exists($filesroot . '/images/download/' . $format_file . '.png') ? $format_file . '.png' : 'file.gif') . '" alt="file" />';
        echo '</td><td><a href="index.php?act=load_file&amp;id=' . $id . '&amp;more=' . $res_file_more['id'] . '">' . $res_file_more['rus_name'] . '</a> (' .  formatsize($res_file_more['size']) . ')';
        if ($res_file_more['time'] > $old)
            echo ' <span class="red">(NEW)</span>';
        echo '<div class="sub"> Added: ' . date("d.m.y в H:i", $res_file_more['time'] + $set_user['timeshift'] * 3600);
        if ($format_file == 'jar')
            echo ', <a href="index.php?act=jad_file&amp;id=' . $id . '&amp;more=' . $res_file_more['id'] . '">Download as JAD</a>';elseif ($format_file == 'txt') {
            echo ', Convert to <a href="index.php?act=txt_in_zip&amp;id=' . $id . '&amp;more=' . $res_file_more['id'] . '">ZIP</a> / <a href="index.php?act=txt_in_jar&amp;id=' . $id . '&amp;more=' . $res_file_more['id'] . '">JAR</a> file.';
        }
        else if ($format_file == 'zip')
            echo ', <a href="index.php?act=open_zip&amp;id=' . $id . '&amp;more=' . $res_file_more['id'] . '">Open Archive</a><br /><a href="http://myroot.7ko.in/installer/?package='.rawurlencode($set['homeurl'].'/'.substr($res_file_more['dir'],3).'/'.$res_file_more['name']).'">FTP Archive</a>';
        echo '</div></td></tr></table></div>';
        ++$k;
    }
}
echo '<div class="gmenu"><a href="index.php?act=comms&amp;id=' . $res_down['id'] . '">Comment</a> (' . $res_down['total'] . ')</div>';
echo '<div class="rmenu"><input type="text" value="' . $set['homeurl'] . '/download/index.php?act=view&amp;id=' . $id . '" /></div>';
$tree = array ();
$dirid = $res_down['refid'];
while ($dirid != '0' && $dirid != "") {
    $req = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$dirid' LIMIT 1");
    $res = mysql_fetch_assoc($req);
    $tree[] = '<a href="index.php?id=' . $dirid . '">' . functions::checkout($res['rus_name']) . '</a>';
    $dirid = $res['refid'];
}
krsort($tree);
$cdir = array_pop($tree);
echo '<div class="nfooter"><a href="index.php?">Downloads</a> &raquo; ';
foreach ($tree as $value) {
    echo $value . ' &raquo; ';
}
echo '<a href="index.php?id=' . $res_down['refid'] . '">' . strip_tags($cdir) . '</a></div>';
if ($rights > 6 || $rights == 4) {
    echo '<p><div class="func"><a href="index.php?act=edit_file&amp;id=' . $id . '">Edit File</a><br />' .
    '<a href="index.php?act=edit_about&amp;id=' . $id . '">Edit Description</a><br />' .
    '<a href="index.php?act=edit_screen&amp;id=' . $id . '">Manage Screenshots</a><br />' .
    '<a href="index.php?act=file_more&amp;id=' . $id . '">Additional Files</a><br />' .
    '<a href="index.php?act=del_file&amp;id=' . $id . '">Delete</a>';
    if($rights > 6) {
    	echo '<br /><a href="index.php?act=transfer_file&amp;id=' . $id . '">Move file</a>';
    	if ($format_file == 'mp3') echo '<br /><a href="index.php?act=mp3tags&amp;id=' . $id . '">Edit mp3 tags</a>';
    }
    echo '</div></p>';
}
?>