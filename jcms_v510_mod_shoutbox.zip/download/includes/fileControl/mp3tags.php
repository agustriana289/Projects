<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || functions::format($res_down['name']) != 'mp3' || $rights < 6) {
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Mp3 Tag:</b> ' . functions::checkout($res_down['rus_name']) . '</div>';

require ('../incfiles/lib/getid3/getid3.php');
$getID3 = new getID3;
$getID3->encoding = 'cp1251';
$getid = $getID3->analyze($res_down['dir'] . '/' . $res_down['name']);
 if(!empty($getid['tags']['id3v2'])) $tagsArray = $getid['tags']['id3v2'];
elseif(!empty($getid['tags']['id3v1'])) $tagsArray = $getid['tags']['id3v1'];

if (isset($_POST['submit'])) {
	$tagsArray['artist'][0] = isset($_POST['artist']) ? mp3tagsOut($_POST['artist'], 1) : '';
	$tagsArray['title'][0] = isset($_POST['title']) ? mp3tagsOut($_POST['title'],1) : '';
	$tagsArray['album'][0] = isset($_POST['album']) ? mp3tagsOut($_POST['album'], 1) : '';
	$tagsArray['genre'][0] = isset($_POST['genre']) ? mp3tagsOut($_POST['genre'], 1) : '';
	$tagsArray['year'][0] = isset($_POST['year']) ?  (int) $_POST['year'] : 0;
	require('../incfiles/lib/getid3/write.php');
	$tagsWriter = new getid3_writetags;
	$tagsWriter->filename = $res_down['dir'] . '/' . $res_down['name'];
	$tagsWriter->tagformats = array('id3v1', 'id3v2.3');
	$tagsWriter->tag_encoding = 'cp1251';
	$tagsWriter->tag_data = $tagsArray;
	$tagsWriter->WriteTags();
    echo '<div class="gmenu">Done</div>';


 }

 echo '<div class="list1"><form action="index.php?act=mp3tags&amp;id=' . $id . '" method="post">' .
'<b>Artist</b>:<br /> <input name="artist" type="text" value="' . mp3tagsOut($tagsArray['artist'][0]) . '"><br />' .
'<b>Title</b>:<br /> <input name="title" type="text" value="' . mp3tagsOut($tagsArray['title'][0]) . '"><br />' .
'<b>Album</b>:<br /> <input name="album" type="text" value="' . mp3tagsOut($tagsArray['album'][0]) . '"><br />' .
'<b>Genre</b>: <br /><input name="genre" type="text" value="' . mp3tagsOut($tagsArray['genre'][0]) . '"><br />' .
'<b>Year</b>:<br /> <input name="year" type="text" value="' . (int) $tagsArray['year'][0] . '"><br />' .
'<br /><input type="submit" name="submit" value="Save"/></form></div>' .
'<div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a></div>';

?>