<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$dir_clean = opendir('../files/download/temp/created_zip');
while ($file = readdir($dir_clean)) {
    if ($file != 'index.php' && $file != '.htaccess' && $file != '.' && $file != '..') {
        $time_file = filemtime('../files/download/temp/created_zip/' . $file);
        if ($time_file < ($realtime - 300))
            @unlink('../files/download/temp/created_zip/' . $file);
    }
}
closedir($dir_clean);
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || functions::format($res_down['name']) != 'txt' || ($res_down['type'] == 3 && $rights < 6 && $rights != 4)) {
    require('../incfiles/head.php');
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if (isset($_GET['more'])) {
    $more = abs(intval($_GET['more']));
    $req_more = mysql_query("SELECT * FROM `down_more` WHERE `id` = '$more' LIMIT 1");
    $res_more = mysql_fetch_assoc($req_more);
    if (!mysql_num_rows($req_more) || !is_file($res_down['dir'] . '/' . $res_more['name']) || functions::format($res_more['name']) != 'txt') {
        require('../incfiles/head.php');
        echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
        require('../incfiles/end.php');
        exit;
    }
    $down_file = $res_down['dir'] . '/' . $res_more['name'];
    $title_pages = $res_more['rus_name'];
    $txt_file = $res_more['name'];
} else {
    $down_file = $res_down['dir'] . '/' . $res_down['name'];
    $title_pages = $res_down['rus_name'];
    $txt_file = $res_down['name'];
}
if (!$_SESSION['down_' . $id]) {
    mysql_query("UPDATE `down_files` SET `field`=`field`+1 WHERE `id`='$id'");
    $_SESSION['down_' . $id] = 1;
}
$file = '../files/download/temp/created_zip/' . $txt_file . '.zip';
if (!file_exists($file)) {
    require('../incfiles/lib/pclzip.lib.php');
    $zip = new PclZip($file);
    function w($event, &$header) {
        $header['stored_filename'] = basename($header['filename']);
        return 1;
    }
    $zip->create($down_file, PCLZIP_CB_PRE_ADD, 'w');
    chmod($file, 0644);
}

require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . functions::checkout($title_pages) . '</b></div>';
echo '<div class="menu"><a href="' . functions::checkout($file) . '">Download as ZIP</a></div>';
echo '<div class="rmenu"><input type="text" value="' . $set['homeurl'] . '/' . $dir_load . '/' . functions::checkout($file) . '"/><b></b></div>';
echo '<div class="omenu">The file will be available for download within 5 minutes</div>';
echo '<p><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></p>';
?>