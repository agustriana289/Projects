<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights == 4 || $rights >= 6) {
	$req_down = mysql_query("SELECT `dir`, `name`, `id` FROM `down_files` WHERE `type` = 1");
	while ($res_down = mysql_fetch_assoc($req_down)) {
		$dir_files = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2' AND `dir` LIKE '" . ($res_down['dir'] . '/' . $res_down['name']) . "%'"), 0);
		mysql_query("UPDATE `down_files` SET `total` = '$dir_files' WHERE `id` = '" . $res_down['id'] . "'");
	}
}
header('location: index.php?id=' . $id);

?>