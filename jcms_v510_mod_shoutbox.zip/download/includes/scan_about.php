<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    set_time_limit(99999);
    $dir = glob($down_path . '/about/*.txt');
    foreach ($dir as $val) {
        if (isset($_GET['clean'])) {
            @unlink($val);
        } else {
            $file_id = abs(intval(preg_replace('#' . $down_path . '/about/([0-9]+)\.txt#si', '\1', $val, 1)));
            if ($file_id) {
                $text = mysql_real_escape_string(file_get_contents($val));
                mysql_query("UPDATE `down_files` SET `about` = '$text' WHERE `id` = '$file_id' LIMIT 1");
            }
        }
    }
    mysql_query("OPTIMIZE TABLE `down_files`");
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Updating descriptions</b></div>';
    if (isset($_GET['clean'])) {
        echo '<div class="menu">Folder is cleared!</div>';
    } else {
        echo '<div class="menu">Descriptions updated</div>';
        echo '<div class="rmenu"><a href="index.php?act=scan_about&amp;clean">Empty folder</a></div>';
    }
    echo '<div class="nfooter"><a href="index.php?id=' . $id . '">Back</a></div>';
} else {
    echo functions::display_error('Access denied<br /><a href="index.php">Back to category</a>');
}
?>