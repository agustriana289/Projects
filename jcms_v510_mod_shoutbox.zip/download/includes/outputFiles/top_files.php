<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if($id == 2) $textl = 'Most Commented';
elseif($id == 1) $textl = 'Most Downloaded';
else $textl = 'Top Downloads';
require('../incfiles/head.php');
echo '<div class="phdr"><b>' . $textl . '</b> (' . $set_down['top'] . ')</div>';
if($id == 2) {
	echo '<div class="gmenu"><a href="index.php?act=top_files&amp;id=0">Top Downloads</a><br />
	<a href="index.php?act=top_files&amp;id=1">Most Downloaded</a></div>';
	$sql = '`total`';
} elseif($id == 1) {
	echo '<div class="gmenu"><a href="index.php?act=top_files&amp;id=0">Top Downloads</a><br />
	<a href="index.php?act=top_files&amp;id=2">Most Commented</a></div>';
	$sql = '`field`';
} else {
	echo '<div class="gmenu"><a href="index.php?act=top_files&amp;id=1">Most Downloaded</a><br />
	<a href="index.php?act=top_files&amp;id=2">Most Commented</a></div>';
	$sql = '`rate`';
}
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `type` = 2 ORDER BY $sql DESC LIMIT " . $set_down['top']);
while ($res_down = mysql_fetch_assoc($req_down)) {
    echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
    echo display_file($res_down, 1);
    echo '</div>';
    ++$i;
}
echo '<div class="nfooter"><br /></div><a href="index.php">Back</a>';
?>