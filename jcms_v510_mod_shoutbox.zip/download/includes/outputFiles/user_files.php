<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Files user';
require('../incfiles/head.php');
$user = functions::get_user($id);
if (!$user) {
    echo functions::display_error('User not found');
    require('../incfiles/end.php');
    exit;
}
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="../users/profile.php?user=' . $id . '">Profile</a> | <b>Files</b></div>' .
'<div class="user"><p>' . functions::display_user($user, array('iphide' => 0)) . '</p></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2'  AND `user_id` = $id"), 0);

if ($total) {
    $req_down = mysql_query("SELECT * FROM `down_files` WHERE `type` = '2'  AND `user_id` = $id ORDER BY `time` DESC LIMIT $start, $kmess");
    while ($res_down = mysql_fetch_assoc($req_down)) {
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        echo display_file($res_down);
        echo '</div>';
        ++$i;
    }
} else {
    echo '<div class="menu">The list is empty!</div>';
}
echo '<div class="nfooter">Total: ' . $total . '</div>';
if ($total > $kmess) {
    echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;act=user_files&amp;', $start, $total, $kmess) . '</div>';
    echo '<form action="index.php" method="get"><input type="hidden" value="user_files" name="act" /><input type="hidden" name="id" value="' . $id . '"/><input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form><br />';
}
echo '<p><a href="index.php">Back to category</a></p>';
?>