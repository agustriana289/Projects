<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    set_time_limit(99999);
    switch ($do) {
        case 'clean':
            $query = mysql_query("SELECT `id`, `dir`, `name`, `type` FROM `down_files`");
            while ($result = mysql_fetch_assoc($query)) {
                if (!file_exists($result['dir'] . '/' . $result['name'])) {
                    if ($result['type'] == 1) {
                        $arrayClean = array();
                        $req = mysql_query("SELECT `id` FROM `down_files` WHERE `refid` = '" . $result['id'] . "'");
                        while ($res = mysql_fetch_assoc($req)) {
                            $arrayClean = $res['id'];
                        }
                        $idClean = implode(',', $arrayClean);
						mysql_query("DELETE FROM `down_comms` WHERE `refid` IN (" . $idClean . ")");
						mysql_query("DELETE FROM `down_more` WHERE `refid` IN (" . $idClean . ")");
                      	mysql_query("DELETE FROM `down_files` WHERE `id` = '" . $result['id'] . "' OR  `refid` = '" . $result['id'] . "'");
                    } else {
                        $req = mysql_query("SELECT `id` FROM `down_more` WHERE `refid` = '" . $result['id'] . "'");
                        while ($res = mysql_fetch_assoc($req)) {
                            @unlink($result['dir'] . '/' . $res['name']);
                        }
                        mysql_query("DELETE FROM `down_more` WHERE `refid` = '" . $result['id'] . "'");
                        mysql_query("DELETE FROM `down_comms` WHERE `refid`='" . $result['id'] . "'");
                        mysql_query("DELETE FROM `down_files` WHERE `id` = '" . $result['id'] . "' LIMIT 1");
                    }
                }
            }
            $req_down = mysql_query("SELECT `dir`, `name`, `id` FROM `down_files` WHERE `type` = 1");
            while ($res_down = mysql_fetch_assoc($req_down)) {
                $dir_files = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2' AND `dir` LIKE '" . ($res_down['dir'] . '/' . $res_down['name']) . "%'"), 0);
                mysql_query("UPDATE `down_files` SET `total` = '$dir_files' WHERE `id` = '" . $res_down['id'] . "'");
            }
            mysql_query("OPTIMIZE TABLE `down_files`");
            mysql_query("OPTIMIZE TABLE `down_comms`");
            mysql_query("OPTIMIZE TABLE `down_more`");
            echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Remove missing files</b></div>';
            echo '<div class="menu">The database has been updated successfully</div>';
            echo '<div class="nfooter"><a href="index.php?id=' . $id . '">Back</a></div>';
            break;

        default:
            if ($id) {
                $cat = mysql_query("SELECT `dir`, `name`, `rus_name` FROM `down_files` WHERE `type` = 1 AND `id` = '$id' LIMIT 1");
                $res_down_cat = mysql_fetch_assoc($cat);
                $scan_dir = $res_down_cat['dir'] . '/' . $res_down_cat['name'];
                if (mysql_num_rows($cat) == 0 || !is_dir($scan_dir)) {
                    require('../incfiles/head.php');
                    echo functions::display_error('Directory does not exist<br /><a href="index.php">Back</a>');
                    require('../incfiles/end.php');
                    exit;
                }
            } else {
                $scan_dir = $files_path;
            }
            echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Update</b>' . ($id ? ': ' . functions::checkout($res_down_cat['rus_name']) : '') . '</div>';
            if (isset($_GET['yes'])) {
                $array_dowm = array ();
                $array_id = array ();
                $array_more = array ();
                $query = mysql_query("SELECT `dir`, `name`, `id` FROM `down_files`");
                while ($result = mysql_fetch_assoc($query)) {
                    $array_dowm[] = $result['dir'] . '/' . $result['name'];
                    $array_id[$result['dir'] . '/' . $result['name']] = $result['id'];
                }
                $query_more = mysql_query("SELECT `name` FROM `down_more`");
                while ($result_more = mysql_fetch_assoc($query_more)) {
                    $array_more[] = $result_more['name'];
                }
                $array_scan = array ();
                function scan_dir($dir = '') {
                    static $array_scan;
                    global $mod;
                    $arr_dir = glob($dir . '/*');

                    foreach ($arr_dir as $val) {
                        if (is_dir($val)) {
                            $array_scan[] = $val;
                            if (!$mod)
                                scan_dir($val);
                        } else {
                            $file_name = basename($val);
                            if ($file_name != '.' && $file_name != '..' && $file_name != 'index.php' && $file_name != '.htaccess' && $file_name != '.svn')
                                $array_scan[] = $val;
                        }
                    }
                    return $array_scan;
                }
                $arr_scan_dir = scan_dir($scan_dir);
                if ($arr_scan_dir) {
                    $i_three = $i_two = $i = 0;
                    foreach ($arr_scan_dir as $val) {
                        if (!in_array($val, $array_dowm)) {
                            if (is_dir($val)) {
                                $name = mysql_real_escape_string(basename($val));
                                $dir = mysql_real_escape_string(dirname($val));
                                $refid = (int)$array_id[$dir];
                                mysql_query("INSERT INTO `down_files` SET `refid`='$refid', `dir`='$dir', `time`='$realtime', `name`='$name', `type` = '1', `field`='0', `rus_name`='$name'");
                                $array_id[$val] = mysql_insert_id();
                                ++$i;
                            } else {
                                $name = basename($val);
                                if (preg_match("/^file([0-9]+)_/", $name)) {
                                    if (!in_array($name, $array_more)) {
                                        $refid = (int)str_replace('file', '', $name);
                                        $name_link = functions::check(mb_substr(str_replace('file' . $refid . '_', 'Скачать ', $name), 0, 200));
                                        $name = mysql_real_escape_string($name);
                                        $size = filesize($val);
                                        mysql_query("INSERT INTO `down_more` SET `refid`='$refid', `time`='$realtime',`name`='$name', `rus_name` = '$name_link',`size`='$size'");
                                        ++$i_two;
                                    }
                                } else {
                                    $name = mysql_real_escape_string($name);
                                    $dir = mysql_real_escape_string(dirname($val));
                                    $refid = (int)$array_id[$dir];
                                    mysql_query("INSERT INTO `down_files` SET `refid`='$refid', `dir`='$dir', `time`='$realtime',`name`='$name', `text` = 'Download file',`rus_name`='$name', `type` = '2',`user_id`='$user_id'");
                                    ++$i_three;
                                }
                            }
                        }
                    }
                }
                if ($id) {
                    $dir_files = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2' AND `dir` LIKE '" . ($res_down_cat['dir'] . '/' . $res_down_cat['name']) . "%'"), 0);
                    mysql_query("UPDATE `down_files` SET `total` = '$dir_files' WHERE `id` = '$id'");
                } else {
                    $req_down = mysql_query("SELECT `dir`, `name`, `id` FROM `down_files` WHERE `type` = 1");
                    while ($res_down = mysql_fetch_assoc($req_down)) {
                        $dir_files = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2' AND `dir` LIKE '" . ($res_down['dir'] . '/' . $res_down['name']) . "%'"), 0);
                        mysql_query("UPDATE `down_files` SET `total` = '$dir_files' WHERE `id` = '" . $res_down['id'] . "'");
                    }
                }
                echo '<div class="menu"><b>Posted:</b><br />Categories: ' . $i . '<br />Files: ' . $i_three . '<br />Extras. files: ' . $i_two . '</div>';
                echo '<div class="rmenu"><a href="index.php?act=scan_dir&amp;do=clean&amp;id=' . $id . '">Remove missing files</a></div>';
            } else  {
                echo '<div class="menu">Update ' . ($id ? 'folder' : 'all') . '? - <a href="index.php?act=scan_dir&amp;yes&amp;id=' . $id . '">Yes</a> ' . ($id ? ' | <a href="index.php?act=scan_dir&amp;yes&amp;id=' . $id . '&amp;mod=1">Only this current folder</a>' : '') .
                '</div><div class="rmenu">';
                if($id)
                    echo '<a href="index.php?act=scan_dir&amp;yes">Update all folders</a><br />';
                echo '<a href="index.php?act=scan_dir&amp;do=clean&amp;id=' . $id . '">Remove missing files</a></div>';


            }
            echo '<div class="nfooter"><a href="index.php?id=' . $id . '">Back</a></div>';
    }
} else {
    echo functions::display_error('Access denied<br /><a href="index.php">Back to category</a>');
}
?>