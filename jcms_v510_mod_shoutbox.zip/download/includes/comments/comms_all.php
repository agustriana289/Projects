<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Browse comments';
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Browse comments</b></div>';
$colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_comms`"), 0);
if ($colmes) {
    $req = mysql_query("SELECT `down_comms`.*, `down_comms`.`id` AS `cid`, `users`.`rights`, `users`.`name`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`, `down_files`.`rus_name`
FROM `down_comms` LEFT JOIN `users` ON `down_comms`.`user_id` = `users`.`id` LEFT JOIN `down_files` ON `down_comms`.`refid` = `down_files`.`id` ORDER BY `down_comms`.`time` DESC LIMIT $start, $kmess");
    while ($res = mysql_fetch_assoc($req)) {
        $text = '';
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        $text = ' <span class="gray">(' . date("d.m.y / H:i", $res['time'] + $set_user['timeshift'] * 3600) . ')</span>';
        $post = functions::checkout($res['text'], 1, 1);
        if ($set_user['smileys'])
            $post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
        $subtext = '<a href="index.php?act=view&amp;id=' . $res['refid'] . '">' . functions::checkout($res['rus_name']) . '</a> | <a href="index.php?act=comms&amp;id=' . $res['refid'] . '">Browse comments</a>';
        $arg = array (
            'header' => $text,
            'body' => $post,
            'sub' => $subtext
        );
        echo functions::display_user($res, $arg) . '</div>';
        ++$i;
    }
} else {
    echo '<div class="list1">List is empty!</div>';
}
echo '<div class="nfooter">Total: ' . $colmes . '</div>';
if ($colmes > $kmess) {
    echo '<p>' . functions::display_pagination('index.php?act=comm_all&amp;', $start, $colmes, $kmess) . '</p>';
    echo '<p><form action="index.php" method="get"><input type="text" name="page" size="2"/><input type="hidden" name="act" value="comm_all"/><input type="submit" value="Jump &gt;&gt;"/></form></p>';
}
echo '<a href="index.php">Category</a>';
?>