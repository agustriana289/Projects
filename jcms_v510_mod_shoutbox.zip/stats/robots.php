<?php

/**
 * @author simba
 * @copyright 2011
 */
defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="phdr">Statistics for robots</div>';
$count = mysql_result(mysql_query("SELECT COUNT(DISTINCT `robot`) FROM `counter` WHERE `robot` != '';"), 0);
if($count > 0){
    $req = mysql_query("SELECT * FROM `counter` WHERE `robot` != '' GROUP BY `robot` LIMIT ".$start.",".$kmess);
    $i = 0;
    while($arr = mysql_fetch_array($req)){
        echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';
        ++$i;
        $count_view = mysql_result(mysql_query("SELECT COUNT(*) FROM `counter` WHERE `robot` = '".$arr['robot']."'") , 0);
        
        echo '<img src="icons/robot.png" alt="."/> <a href="index.php?act=robot_types&amp;robot='.$arr['robot'].'">'.$arr['robot'].'</a>
        <div class="sub">Total conversions: '.$count_view.'</div>';
        
        echo '</div>';    
        }
    
    echo '<div class="phdr">Total robots: '.$count.'</div>';
    
}else{
 echo '<div class="rmenu">No robots for today!</div>';   
}
?>