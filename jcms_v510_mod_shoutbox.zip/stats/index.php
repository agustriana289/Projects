<?php
//////////////////////////////////////////
//   Модуль статистики для JohnCMS      //
//////////////////////////////////////////
//  Автор: Максим (Simba)               //
//  Wap site - http://symbos.su         //
//////////////////////////////////////////

@ini_set('max_execution_time', 5);
@set_time_limit(5);

define('_IN_JOHNCMS', 1);
$headmod = 'statistik';
$textl = 'Site Stats';
require_once '../incfiles/core.php';
require_once '../incfiles/head.php';
$act = isset($_GET['act']) ? $_GET['act'] : '';
$model = isset($_GET['model']) ? functions::check($_GET['model']) : '';

// Дополнительные страницы //
$do = array('robots', 'robot_types', 'hosts', 'point_in', 'opsos', 'allstat',
 'country', 'users', 'referer', 'siteadr', 'pop', 'phones', 'phone', 'os');
if (in_array($act, $do)){
$back_links = '';
include_once ($act . '.php');
echo '<div class="gmenu">'.$back_links.'<a href="index.php">Statistics</a></div>';
include '../incfiles/end.php';
exit;
}


// Главная статистики //

$begin_day = strtotime(date("d F y", statistic::$system_time));
$my_url = parse_url($home);
$sql = "
(SELECT COUNT(*) FROM `counter` WHERE `robot` != '') UNION ALL
(SELECT COUNT(DISTINCT `pop`) FROM `counter` WHERE `robot` = '') UNION ALL
(SELECT COUNT(*) FROM `stat_robots` WHERE `date` > '".$begin_day."') UNION ALL
(SELECT COUNT(DISTINCT `country`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `operator`, `country`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `robot`) FROM `counter` WHERE `robot` != '') UNION ALL
(SELECT COUNT(DISTINCT `user`) FROM `counter`) UNION ALL
(SELECT COUNT(DISTINCT `site`) FROM `counter` WHERE `site` NOT LIKE '%".$my_url['host']."')
";

$query = mysql_query($sql);
$count_stat = array();
while($result_array = mysql_fetch_array($query)) {
        $count_stat[] = $result_array[0];
        }


$hitnorob = statistic::$hity - $count_stat[0];

echo '<div class="phdr">Statistics</div>
<div class="gmenu"><h3><img src="icons/statistic.png" alt="."/> General Information</h3>
<li>Hits today: '.statistic::$hity.'</li>
<li>Hosts today: '.statistic::$hosty.'</li>
<li>Hits from robots: '.$count_stat[0].'</li>
<li>Hits without robots: '.$hitnorob.'</li>';


//////// Максимум хостов //////
$maxhost = mysql_query("SELECT `date`, `host` FROM `countersall` ORDER BY `countersall`.`host` DESC LIMIT 0 , 1");
if(mysql_num_rows($maxhost) > 0){
$maxhost = mysql_fetch_array($maxhost);
/////// Максимум хитов ////////
$maxhits = mysql_fetch_array(mysql_query("SELECT `date`, `hits` FROM `countersall` ORDER BY `countersall`.`hits` DESC LIMIT 0 , 1"));
$max_host_time = date("d M Y", $maxhost['date']);
$max_hits_time = date("d M Y", $maxhits['date']);
echo '<li>Record host (<b>'.$maxhost['host'].'</b>) was <b>'.statistic::month($max_host_time).'.</b></li>
<li>Record hits (<b>'.$maxhits['hits'].'</b>) was <b>'.statistic::month($max_hits_time).'.</b></li>';
}

echo '<li>Average number of hits per visitor: '.round($hitnorob/statistic::$hosty).'</li></div>';

$percent = statistic::$hosty/100; // 1%
$searchpercent = $count_stat[2]/$percent; // % поисковиков
echo '<div class="menu"><h3><img src="icons/stats.png" alt="."/> Detailed statistics</h3>';

echo'<li><a href="index.php?act=hosts">Hosts</a> ('.statistic::$hosty.')</li>
<li><a href="index.php?act=opsos">Operators</a> ('.$count_stat[4].')</li>
<li><a href="index.php?act=country">Countries</a> ('.$count_stat[3].')</li>
<li><a href="index.php?act=robots">Robots</a> ('.$count_stat[5].')</li>
<li><a href="index.php?act=users">Members</a> ('.$count_stat[6].')</li>
<li><a href="stat_search.php">Referrals from search engine</a> ('.$count_stat[2].' | '.round($searchpercent, 2).'%)</li>
<li><a href="index.php?act=phones">Telephones / Browsers</a></li>
<li><a href="index.php?act=os">Operating Systems</a></li>
<li><a href="index.php?act=referer">Where come</a> ('.$count_stat[7].')</li>';

echo'<li><a href="index.php?act=point_in">Entry Points</a></li>';
echo'<li><a href="index.php?act=pop">Popular sections</a> ('.$count_stat[1].')</li>';
echo'<li><a href="http://www.cy-pr.com/analysis/'.$my_url['host'].'">SEO Site Analysis</a></li>';
echo'<li><a href="index.php?act=allstat">Daily Statistics</a></li></div>';

if ($rights >= 9)
echo'<div class="bmenu"><a href="ip_base.php?act=base">Database management IP</a></div>';


//echo'<div class="phdr">Версия модуля: 6.3</div>';


require_once '../incfiles/end.php';
?>