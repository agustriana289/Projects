<?php

/**
 * @author simba
 * @copyright 2011
 */
 
defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="phdr">Popular sections</div>';
$count = mysql_result(mysql_query("SELECT COUNT(DISTINCT `pop`) FROM `counter` WHERE `robot` = '';"), 0);
if($count > 0){
    $req = mysql_query("SELECT * FROM `counter` WHERE `robot` = '' GROUP BY `pop` ORDER BY COUNT(`pop`) DESC LIMIT ".$start.",".$kmess);
    $i = 0;
    while($arr = mysql_fetch_array($req)){
        echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';
        ++$i;
        $count_view = mysql_result(mysql_query("SELECT COUNT(*) FROM `counter` WHERE `robot` = '' AND `pop` = '" . $arr['pop'] . "'") , 0);
        
		$time = date("H:i", $arr['date']);
        
        if($arr['pop'] !== '/'){
        echo '<b>'.$time.'</b> | Title: '.($arr['head'] == '' ? 'No title' : $arr['head']);
        echo '<div class="sub">Page: <a href="'.$arr['pop'].'">'.$arr['pop'].'</a><br/>';
        }else{
        echo'<b>'.$time.'</b> | <a href="'.$arr['pop'].'">Home</a><div class="sub">'; 
        }
        
        echo 'In: '.$count_view.'</div>';
        
        echo '</div>';    
        }
    
    echo '<div class="phdr">Total: '.$count.'</div>';
    if ($count > $kmess){
    	echo '<div class="topmenu">';
    	echo functions::display_pagination('index.php?act=pop&amp;', $start, $count, $kmess) . '</div>';
    	echo '<p><form action="index.php" method="get"><input type="hidden" name="act" value="pop"/><input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form></p>';}
    
}else{
 echo '<div class="rmenu">There are no data for display!</div>';   
}
?>