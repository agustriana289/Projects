<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights == 3 || $rights >= 6) {
if (empty ($_GET['id'])) {
require_once ("../incfiles/head.php");
echo "Lỗi!<br/><a href='?'>Quay lại</a><br/>";
require_once ("../incfiles/end.php");
exit;
}
$time = time()+10;
$req = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `id` = '" . $id . "' AND `type` = 't'");
if (mysql_result($req, 0) > 0) {
mysql_query("UPDATE `forum` SET  `kiemduyet` = '" . (isset ($_GET['kiemduyet']) ? '1' : '0') . "', `time` = '" .$time. "', `kiemduyet_who` = '$login' WHERE `id` = '" . $id . "'");
//kiem duyet
$men = mysql_query("SELECT * FROM `forum` WHERE `id` ='".$id."'");
if(mysql_num_rows($men)) {
$okmen = mysql_fetch_array($men);
//				'Xem chủ đề tại link: <a href="/forum/index.php?id='.$rid.'">'.$th.'</a>'
$msg = 'Thread <a href="/forum/index.php?id='.$id.'">'.$okmen['text'].'</a> has been <font color="red">' .$login. '</font> fault finding';
mysql_query("insert into `privat` values(0,'" . $okmen['from'] . "','".$msg."','" .$time. "','BOT','in','no','Censoring posts','0','','','','" . mysql_real_escape_string($fname) . "');");
}
header('Location: index.php?id=' . $id);

}
}
else {
require_once ("../incfiles/head.php");
echo '<p>ERROR!<br/><a href="index.php">Back</a></p>';
require_once ("../incfiles/end.php");
exit;
}

?>
