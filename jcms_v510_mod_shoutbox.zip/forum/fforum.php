<?php
/*
Author: Pavel
Web site: http://mtuner.tk
*/
define('_IN_JOHNCMS', 1);
$headmod = 'forum';
require('../incfiles/core.php');
$textl = 'Forum - Susukan.Us - [ID]';
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>'.$textl.'</b></div>';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
if ($user_id) {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Unread</a><font color="red">&nbsp;(<b>' . counters::forum_new() . '</b>)</font> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div></div></div>'; }
if (!$user_id) {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Last Activity</a> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div></div></div>'; }
$bonguyen = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while (($dd = mysql_fetch_array($bonguyen)) !== false) {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>'.$dd['text'].'</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`='" . $dd['id'] . "' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
$chude = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' and `refid`='" . $res['id'] . "'"), 0);
echo '<div class="'.(++$j%2==0 ? "list1" : "list2").'">&bull; <a href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a>        Topics : '.$chude.'<br/>';
if ($user_id) {
echo '<a class="omenu" href="/forum/index.php?act=nt&id=' . $res['id'] . '">Add Post</a>'; }
echo '</div>';
if ($rights >= 9) { echo '<div class="rmenu"><a href="/panel/index.php?act=forum&mod=edit&id=' . $res['id'] . '">Edit</a> | <a href="/panel/index.php?act=forum&mod=del&id=' . $res['id'] . '">Delete</a></div>'; }
}
echo '</div></div>';
++$j;
}
require('../incfiles/end.php');
?>
