<?php
////////////////////////////////////////////////////////////
//                 Komentar forum v3.x.x                  //
//                   by vitagame                          //
//                   ICQ 233-615                          //
//                 http://smartfonam.ru                   //
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
//                 Last Mod for v4.4.0                    //
//                 By jitozclub.com                       //
//                 Email : jitozclub@gmail.com            //
//                 http://jitozclub.com                   //
//                     INDONESIA                          //
////////////////////////////////////////////////////////////

define('_IN_JOHNCMS', 1);
$textl = 'menghapus komentar di post forum';
$headmod = "forum";
$pembuat = '<a href="http://jitozclub.com">Jitozclub</a>';  // Don't change this sites
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if($rights==9)
{
require_once('../incfiles/head.php');
if (empty ($_GET['id']))
{
echo '<div class="rmenu">Kesalahan!</div>';
require_once ("../incfiles/end.php");
exit;
}
$req = mysql_query("SELECT * FROM `forum_komm` WHERE `id`='" . $id . "' ;");
if (mysql_num_rows($req) == 0)
{
echo '<div class="rmenu">Kesalahan!</div>';
require_once ("../incfiles/end.php");
exit;
}
$res = mysql_fetch_assoc($req);
mysql_query("DELETE FROM `forum_komm` WHERE `id` = '" . $id . "' LIMIT 1 ");
echo '<div class="menu">Komentar berhasil di hapus</div>';
$copyright = $pembuat;  // copyright
echo '<div class="phdr">Last Mod v4.0.0 By '.$copyright.'</div>';

}

else{
header('Location: ../?err');
exit;
}
require_once ("../incfiles/end.php");

?>
