<?php
////////////////////////////////////////////////////////////
//                 Komentar forum v3.x.x                  //
//                   by vitagame                          //
//                   ICQ 233-615                          //
//                 http://smartfonam.ru                   //
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
//                 Last Mod for v4.4.0                    //
//                 By jitozclub.com                       //
//                 Email : jitozclub@gmail.com            //
//                 http://jitozclub.com                   //
//                     INDONESIA                          //
////////////////////////////////////////////////////////////

define('_IN_JOHNCMS', 1);
$textl = 'post forum comments';
$headmod = "komforum";
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$counts = @ mysql_result(mysql_query('SELECT COUNT(*) FROM `forum` WHERE `id`=' . $id . ';'), 0);
if($counts==0) {
$textl = 'post forum comments';
require_once('../incfiles/head.php');
echo '<div class="menu">Error! Message does not exist!</div>';
require_once ('../incfiles/end.php');
exit;
}
$res = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id`='" . $id . "';"));
$textl = 'post forum comments';
require_once('../incfiles/head.php');
echo '<div class="phdr">'.$textl.'</div>';
if($res['kom']!=1) {
if($user_id) {
if(!isset($_POST['submit'])) {
echo '<form name="form2" action="komm.php?id=' . $id . '" method="post">';
echo 'Pesan: <b>max. 1000</b><br />';
echo bbcode::auto_bb('form2', 'text');
echo'<textarea name="text" value=""></textarea><br />';
echo '<input type="submit" name="submit" value="Comments"/></form>';
}
else
{
$text = functions::check(trim($_POST['text']));
$flood = functions::antiflood();

if ($flood)
$error = 'You can not send messages over and over again<br />Please wait ' . $flood . ' ???.';

if (empty($text))
$error = $error . 'There are no comments!<br />';
elseif (mb_strlen($text) < 2 || mb_strlen($text) > 1000)
$error = $error . 'error message is too long!<br />';
if (empty($error))
{
mysql_query("INSERT INTO `forum_komm` SET
`ref`='" . $id . "',
`text`='" . mysql_real_escape_string($text) . "',
`uid`='" . $user_id . "',
`ip`='" . $ipl . "',
`ua`='" . mysql_real_escape_string($agn) . "',
`time`='" . $realtime . "';");
mysql_query("UPDATE `users` SET `lastpost` = '$realtime' WHERE `id` = '$user_id'");
header('Location: komm.php?id=' . $id);
}
else
{
echo functions::display_error($error);
}
}
}
}

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_komm` WHERE `ref`='" . $id . "';"), 0);
if($count>0)
{
$res1 = mysql_query("SELECT * FROM `forum_komm` WHERE `ref`='" . $id . "' ORDER BY `time` DESC LIMIT " . $start . "," . $kmess);
while ($row = mysql_fetch_assoc($res1))
{
$req = mysql_fetch_assoc(mysql_query("SELECT `id`, `name`,`sex`, `lastdate`, `datereg`, `status`,`rights`,`browser`,`ip`,`podpis`,`skype`,`jabber`,`www` FROM `users` WHERE `id`='" . $row['uid'] . "';"));
$text = $row['text'];
$text = htmlentities($text, ENT_QUOTES, 'UTF-8');
$text = str_replace("\r\n", "<br/>", $text);
$text = functions::checkout($text, 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] ? 1 : 0);
echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
echo functions::display_user($req,1,NULL,NULL,$row['text']);
echo $text;
echo'<br/>';
if($rights==9)echo '<a href="delete_komm.php?id=' . $row['id'] . '">Delete</a>';
echo '</div>';
++$i;
}
if ($count > $kmess)
{
echo '<p class="menu">' . functions::display_pagination('komm.php?id='.$id.'&amp;', $start, $count, $kmess) . '<br/>';
echo '<form action="" method="POST">
<input type="text" name="page" size="2"/> <input type="submit" value="GO"/></form></p>';
}
}
else
{
echo '<div class="menu">There are no comments</div>';
}

$copyright = $pembuat;  // copyright
$error = 'You can not send messages over and over again<br />Please wait ' . $flood . ' ???.';
$page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" . $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">=" : "<=") . " '$id'"), 0) / $kmess);
echo '<div class="phdr"><a href="index.php?id=' . $res['refid'] . '&amp;page=' . $page . '">In Forum</a></div>';

require_once ("../incfiles/end.php");
?>
