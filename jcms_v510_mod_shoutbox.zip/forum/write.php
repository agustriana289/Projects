<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
require('../incfiles/head.php');
$lng_forum = core::load_lng('forum');
if (isset($_POST['submit'])) {
$error = array();
$name = isset($_POST['name']) ? functions::check($_POST['name']) : false;
$text = isset($_POST['text']) ? trim($_POST['text']) : false;
$pf = intval($_POST['pf']);
$tiento = $_POST['tiento'];
if (!$name)
$error[] = 'Header is not crazy ';
if (!$user_id)
$error[] = 'You need to be logged in';
if (!$pf)
$error[] = 'No Selected Category!';
if (!$text)
$error[] = $lng_news['error_text'];
$flood = functions::antiflood();
if ($flood)
$error[] = $lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'];
if (!$error) {
$rid = 0;
if (!empty($_POST['pf']) && ($_POST['pf'] != '0')) {
$pf = intval($_POST['pf']);
$rz = $_POST['rz'];
$pr = mysql_query("SELECT * FROM `forum` WHERE `refid` = '$pf' AND `type` = 'r'");
while ($pr1 = mysql_fetch_array($pr)) {
$arr[] = $pr1['id'];
}
foreach ($rz as $v) {
if (in_array($v, $arr)) {
mysql_query("INSERT INTO `forum` SET
`refid` = '$v',
`type` = 't',
`time` = '" . time() . "',
`user_id` = '$user_id',
`from` = '$login',
`text` = '$name'
");
$rid = mysql_insert_id();
mysql_query("INSERT INTO `forum` SET
`refid` = '$rid',
`type` = 'm',
`time` = '" . time() . "',
`user_id` = '$user_id',
`from` = '$login',
`ip` = '" . long2ip($ip) . "',
`soft` = '" . mysql_real_escape_string($agn) . "',
`text` = '" . mysql_real_escape_string($text) . "'
");
$postid = mysql_insert_id();
}
}
}
echo '<p>Messages posted successfully!<br /><a href="index.php">To forum</a></p>';

// �?������N?N?�2���u�? N?N?�uN?N?���� ���?N?N?�?�2 N?�.�uN?��
$fpst = $datauser['postforum'] + 1;
mysql_query("UPDATE `users` SET
`postforum` = `postforum`+1,
`balans` = `balans`+500,
`lastpost` = '$realtime'
WHERE `id` = '$user_id'
");
// ��N?���2���? �?�uN?��N? �? ��N?�?N?N?�u�?����
if ($tiento>0) {
mysql_query("UPDATE `forum` SET
`tiento` = '$tiento'
WHERE `id` = '$rid'");
}
mysql_query("INSERT INTO `cms_forum_rdm` SET
`topic_id`='$rid',
`user_id`='$user_id',
`time`='$realtime'
");
mysql_query("INSERT INTO `guest` SET
`adm` = '0',
`time` = '" . time() . "',
`user_id` = '2',
`name` = 'Satpam',
`text` = '@$login just created a new topic: $name',
`ip` = '087876222261',
`browser` = 'Susukan.Us'
");
if($rights >= 3) {
mysql_query("UPDATE forum SET `kiemduyet`='1' WHERE `id`='$rid'");
mysql_query("UPDATE forum SET `kiemduyet_who`='$login' WHERE `id`='$rid'");
}
if ($_POST['addfiles'] == 1)
header("Location: index.php?id=$postid&act=addfile");
else
header("Location: index.php?id=$rid");
} else {
echo functions::display_error($error, '<a href="write.php">Back To Write</a>');
}
} else {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter">Creat Topic</div>';
echo '<form name="form2" action="write.php" method="post"><div class="currentpage">' .
'<p>Topic Name<br></p>' .
'<input type="text" name="name"/><br/><br/>';

if (!$is_mobile)
echo bbcode::auto_bb('form2', 'text');
echo '<textarea rows="' . $set_user['field_h'] . '" name="text"></textarea></p></div><div class="nfooter"><b>Forum Option</b></div><div class="forumb">';
$fr = mysql_query("SELECT * FROM `forum` WHERE `type` = 'f'");
while ($fr1 = mysql_fetch_array($fr)) {
echo '<input type="radio" name="pf" value="' . $fr1['id'] . '"/><b>' . $fr1['text'] . '</b><br><select name="rz[]">';
$pr = mysql_query("SELECT * FROM `forum` WHERE `type` = 'r' AND `refid` = '" . $fr1['id'] . "'");
while ($pr1 = mysql_fetch_array($pr)) {
echo '<option value="' . $pr1['id'] . '">' . $pr1['text'] . '</option>';
}
echo '</select><br/>';
}
//Ti?n t? bAi vi?t
/*
echo '</div><div class="nfooter"><b>Forum Type</b></div>';
echo'
<input type="radio" value="0" name="tiento" checked="checked" />&nbsp;No
<br/><input type="radio" value="1" name="tiento" />&nbsp;<font color="pink">Mod</font>
<br/><input type="radio" value="2" name="tiento" />&nbsp;<font color="lime">Discusion</font>
<br/><input type="radio" value="3" name="tiento" />&nbsp;<font color="red">HOT</font>
<br/><input type="radio" value="4" name="tiento" />&nbsp;<font color="navy">Notice</font>
<br/><input type="radio" value="5" name="tiento" />&nbsp;<font color="olive">Share</font>
<br/><input type="radio" value="6" name="tiento" />&nbsp;<font color="red">Script</font>
<br/><input type="radio" value="7" name="tiento" />&nbsp;<font color="blue">Help</font>';
*/
echo '<div class="nfooter"><b>Forum Type</b></div>';
echo'<input type="radio" value="0" name="tiento" checked="checked" />&nbsp;<b>Defaut<br/>
<input type="radio" value="1" name="tiento" />&nbsp;<font color="purple">Discusion:</font><br/>
<input type="radio" value="2" name="tiento" />&nbsp;<font color="red">HOT:</font><br/>
<input type="radio" value="3" name="tiento" />&nbsp;<font color="green">Notice:</font><br/>
<input type="radio" value="4" name="tiento" />&nbsp;<font color="red">Share:</font><br/>
<input type="radio" value="5" name="tiento" />&nbsp;<font color="green">Script:</font><br/>
<input type="radio" value="6" name="tiento" />&nbsp;<font color="blue">Help:</font>';
echo '</p></div><div class="mainblok"><div class="forumb">' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'] . '</p></div>'.
'<div class="nfooter"><input type="submit" name="submit" value="Submit"/>' .
'</form></div></div></div>' .
'<p><a href="index.php">' . $lng_news['to_news'] . '</a></p>';
}
require('../incfiles/end.php');
?>
