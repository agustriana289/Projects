<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
require('shout.php');
$perf = new perf;
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
include('bcheck.php');
ob_start();
$headmod = 'chatbook';
$text = 'chatbook';if(isset($_SESSION['sgb_admp'])){
echo'<div class="rmenu">
Keterangan utk: D-B-E<br />
D: Delete pesan<br/>
B: Banned user<br />
E: Edit nama, pesan, dan admin jawab pesan<br />
</div>';
}

if(isset($_SESSION['sgb_avatar'])){ include "tulis2.php"; } else { echo '</div>';
include "tulis1.php"; }
//menyimpan data pesan
// Membuka data gb
$arr=file('motto.dat');
$cnt=count($arr);
for($i=0;$i<$CONF['ns'];$i++){
if($c==$cnt) break;
$post=unserialize($arr[$c]);
// Hasil post pesan
$urutan=$cnt-$c;

$nama = $post['nick'];
$rhs = $post['rhs'];
$pesan = $post['text'];
include'pesan.php';
$avatar = $post['avatar'];
$url = $post['url'];
$url = str_replace("\r\n","",$url);
$ip = $post['ip'];
$ip = strtok($ip, ',');
$ip = substr($ip,0,15);
$hape = $post['hape'];
$versi = $post['br'];
$jamshout = $post['time'];
$ali = explode(" ",$jamshout);
$jam ="$ali[1] - $ali[2]";

$time = $ali[3];
$periods=array("detik","menit","jam","hari","minggu","bulan","tahun","dekade");
$lengths=array("60","60","24","7","4","35","12","10");
$now=gmdate(time()+(7*3600));
$difference=$now-$time;
$tense="yang lalu";
for($j=0; $difference>=$lengths[$j]&&$j<count($lengths)-1; $j++) {
$difference/=$lengths[$j]; }
$difference=round($difference); if($difference!=1) { $periods[$j].=""; } $jame="$difference $periods[$j] $tense";

$jamnya ="$ali[0], $jame";

if(isset($_SESSION['sgb_admp'])) print('</div></div><div class="mainbox"><div class="mainblok"><div class="rmenu"><center><small> [<a href="del.php?n='.$c.'&amp;'.SID.'">D</a>-<a href="ban.php?n='.$c.'&amp;'.SID.'">B</a>-<a href="edit.php?n='.$c.'&amp;'.SID.'">E</a>]</small></center></div>');
include'nama.php';
echo ceil(ceil($c / 2) - ($c / 2)) == 0 ? '</div><div class="list2">' : '</div><div class="list2">';
if($rhs == "oke"){
if(isset($_SESSION['sgb_admp'])){
echo'<b>@'.$urutan.'</b> '.$aran.' <font color="red">Penting...!</font><br/> '.$pesan.'</div><div class="nfooter"><img src="http://chodot.yn.lt/shout/clock.png" width="16" hieght="16" alt="clock"> '.$jamnya.'<br/>';
}
if (trim($post[url])<>"" and trim($post[url])<>"http://") { if (ereg("^", trim($post[url]))) echo'<img src="http://chodot.yn.lt/shout/home.png" alt="&bull;"></a> <a href="'.$url.'">'.$url.'</a><br/>'; }
if(isset($_SESSION['sgb_name'])){
echo'Situs: <a href="'.$url.'">'.$url.'</a></div>';
}else{
echo'</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="http://chodot.yn.lt/shout/private.png" alt="*"/> <b>RAHASIA</b></div><div class="menu" style="background-image:url('.$avatar.');background-repeat:no-repeat;background-position:right bottom;min-height:60px;"><div style="float:right">'.$urutan.'</span></div><form action="/shout/admin.php" method="get">
<input type="password" name="p" size="6" value="*******" /><input type="submit" value="Buka" /></form><marquee behavior=alternate loop=is>'.$jamnya.'</marquee></div>';
}
}
else
{
echo'</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter"><b><t style="text-shadow:-1px 0 black, 0 1px black, 1px 0 black, 0 -1px black"><b>@'.$urutan.'</b> '.$aran.' &trade;</t></b></div><div style="float:left">'.$jamnya.'</div></div><div class="menu" style="background-image:url('.$avatar.');background-repeat:no-repeat;background-position:right bottom;min-height:60px;"><div style="text-align:right"></div><t style="text-shadow:-1px 0 black, 0 1px black, 1px 0 black, 0 -1px black"><font color="red"><b>Pesan</b> :</font></t> '.$pesan.'';
// Jika admin menjawab, yg tertampil sbb:
if(isset($post['answ']))
print'</div><div style="background:#FFFF00;color:#F70000;" align="left"><font color="green"><b>ADMIN:</font></b> ';
echo'<font color="fuchsia">'.$post['answ'].'</font></div></div>';
echo'</div><div class="weng">';
if($nama == "sss"){ echo'</div>'; }else{echo' </b></font></span> <a href="/shout/index.php?a=quote&m='.$nama.'"><img src="http://chodot.yn.lt/shout/quota.png" alt="Quote" style="float:right;" /></a>';
}
if (trim($post[url])<>"" and trim($post[url])<>"http://") { if (ereg("^", trim($post[url]))) echo'<div class="mainbox"><div class="topmenu"><img src="http://chodot.yn.lt/shout/sm/home.png" alt="&bull;"></a> <a href="'.$url.'">'.$url.'</a><br/>'; }
if(isset($_SESSION['sgb_name'])){
echo'IP: '.$ip.'<br/>
Browser: '.$versi.'<br/>';
if($hape!= '') { echo 'Mobile: '.$hape.'</div>';
}
}
}
$c++;
echo'</div>';
}
echo'<div class="omenu"><center>';
if($c>$CONF['ns']){
print('[<a href="index.php?c='.($c-$CONF['ns']-$i).'&amp;'.SID.'">&#171;</a>]|');
}else{
print'[&#171;]|';
}
echo $cnt;
if($c<$cnt){
print('|[<a href="index.php?c='.$c.'&amp;'.SID.'">&#187;</a>]<br />');
}else{
print'|[&#187;]<br />';
}
echo'</center></div>';
function logout(){
session_destroy();
header("Location: /");
}
$a = $_GET['a'];
switch ($a){
case "keluar":
logout();
break;
default:
}
function refresh(){
session_destroy();
header("Location: /");
}
$a = $_GET['a'];
switch ($a){
case "refresh":
refresh();
break;
case "quote":
$m = $_GET['m'];
$_SESSION['sgb_quote']=true;
$_SESSION['sgb_quote']="[quote=$m] ";
if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL){
$balik=$_SERVER['HTTP_REFERER'];
} elseif (ereg("&pass=", $_SERVER['HTTP_REFERER'])){
$balik='/';
} else { $balik='/';
}
header('Location: '.$balik.'');
break;
default:
}
if(isset($_SESSION['sgb_admp'])){
print('<div class="nfooter">
<a href="banlist.php'.psid().'">Banlist</a> |
<a href="del.php?clear&amp;'.SID.'">Clear GB</a> | <a href="index.php?a=keluar">Log out</a></center></div>');
}
echo'<div class="menu">';
print'Total pesan: '.$cnt.' [<a href="admin.php'.psid().'">Panel</a>]</div>';
/* di edit lagi oleh http://sangguna.net
*/
ob_end_flush();
include 'foot.php';
?>
