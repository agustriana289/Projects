<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
//editing file by http://seupang.Co.Cc http://penceter.co.cc
$pesan=preg_replace("#\[youtube\](.*?)\[\/youtube\]#","<center><b>Nonton Pidio Brow</b><br><object style=\"width: 200px;\"><param name=\"movie\" value=\"http://www.youtube.com/v/$1?version=3\"><param name=\"allowFullScreen\" value=\"true\"><param name=\"allowScriptAccess\" value=\"always\"><embed height=\"200\" width=\"200\" src=\"http://www.youtube.com/v/$1?version=3\" type=\"application/x-shockwave-flash\" allowfullscreen=\"true\" allowscriptaccess=\"always\"></object></center>", $pesan);
$pesan = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\">\\2</a>", $pesan); $pesan = preg_replace("#(^|[\n ])((www|wap)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\">\\2</a>", $pesan);
$pesan=preg_replace("#\[b\](.*?)\[/b\]#","<b>\\1</b>",$pesan);
$pesan=preg_replace("#\[marq\](.*?)\[/marq\]#","<marquee>\\1</marquee>",$pesan);
$pesan=preg_replace("#\[marq\](.*?)\[/marq\]#","<marquee>\\1</marquee>",$pesan);
$pesan=preg_replace("#\[big\](.*?)\[/big\]#","<span style='font-size:large;'>\\1</span>",$pesan);
$pesan=preg_replace("#\[das\](.*?)\[/das\]#","<span style='border:1px dashed;'>\\1</span>",$pesan);
$pesan=preg_replace("#\[in\](.*?)\[/in\]#","<input type='text' value='\\1'/>",$pesan);
$pesan=preg_replace("#\[kode\](.*?)\[/kode\]#",htmlentities("\\1"),$pesan);
$pesan=preg_replace("#\[u\](.*?)\[/u\]#", "<u>\\1</u>", $pesan);
$pesan=preg_replace("#\[i\](.*?)\[/i\]#", "<i>\\1</i>",$pesan);
$pesan=preg_replace("#\[blink\](.*?)\[/blink\]#","<blink>\\1</blink>",$pesan);
$pesan=str_replace("[br/]","<br/>", $pesan);
$pesan=preg_replace("#\[color=(.*?)\](.*?)\[/color\]#","<font color=\\1>\\2</font>",$pesan);
$pesan=preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#","\\1<a href=\"\\2\" target=\"_blank\">\\2</a>", $pesan);
$pesan=preg_replace("#\[url=(.*?)\](.*?)\[/url\]#","<a href=\"\\1\">\\2</a>", $pesan);
$pesan=preg_replace("#\[spoiler\](.*?)\[\/spoiler\]#","<div style=\"margin: 1px 1px 1px;\"> <div class=\"weng\" align=\"center\"><input  class=\"p_t\" value=\"buka\" onclick=\"if (this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display = ''; this.innerText = ''; this.value = 'tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display = 'none'; this.innerText = ''; this.value = 'buka'; }\" type=\"button\"> </div> <div class=\"weng\" align=\"center\"><div style=\"display: none;\">$1</div></div></div>", $pesan);
$pesan=preg_replace("#\[quote=(.*?)\]#","<small>Balasan:</small> <b>\\1</b>\\2,<br/><div style='background:#FFFF00;color:#F70000;' align='left'>",$pesan);
$pesan = str_replace("abiw","<a href=\"http://penceter.co.cc\"><font color=\"red\">abiw</font></a>", $pesan);
$pesan = str_replace("anjing","*", $pesan);
$pesan = str_replace("bego","*", $pesan);
$pesan = str_replace("babi","*", $pesan);
$pesan = str_replace("kunyuk","*", $pesan);
$pesan = str_replace("ngentot","*", $pesan);
$pesan = str_replace("ngewe","*", $pesan);
$pesan = str_replace("itil","*", $pesan);
$pesan = str_replace("tumbung","*", $pesan);
$pesan = str_replace("bangsat","*", $pesan);
$pesan = str_replace("luh","*", $pesan);
$pesan = str_replace("tai","*", $pesan);
$pesan = str_replace("ketek","*", $pesan);
$pesan = str_replace("@","<font color=\"fuchsia\">@</font>", $pesan);
$pesan = str_replace("~","<font color=\"fuchsia\">~</font>", $pesan);
$pesan = str_replace("sob","<a href=\"http://click.buzzcity.net/click.php?cid=241&partnerid=70909\"/><font color=\"#ff0000\">s</font><font color=\"#ff3300\">o</font><font color=\"#ff6600\">b</font></a>", $pesan);
$pesan = str_replace("kang","<a href=\"http://click.buzzcity.net/click.php?cid=241&partnerid=70909\"/><font color=\"#ff0000\">k</font><font color=\"#ff3300\">a</font><font color=\"#ff6600\">n</font><font color=\"#ff9900\">g</font></a>", $pesan);
$pesan = str_replace("mbah","<a href=\"http://gendeng.net/abg/mulus.jpg\"/><font color=\"#ff0000\">m</font><font color=\"#ff3300\">b</font><font color=\"#ff6600\">a</font><font color=\"#ff9900\">h</font></a>", $pesan);
$pesan = str_replace("shob","<a href=\"http://click.buzzcity.net/click.php?partnerid=70909\"/><font color=\"#ff0000\">s</font><font color=\"#ff3300\">h</font><font color=\"#ff6600\">o</font><font color=\"#ff9900\">b</font></a>", $pesan);
$pesan = str_replace("gan","<a href=\"http://click.buzzcity.net/click.php?partnerid=70909\"/><font color=\"#ff0000\">g</font><font color=\"#ff3300\">a</font><font color=\"#ff6600\">n</font></a>", $pesan);
$pesan = str_replace("brow","<a href=\"http://click.buzzcity.net/click.php?partnerid=70909\"/><font color=\"#ff0000\">b</font><font color=\"#ff3300\">r</font><font color=\"#ff6600\">o</font><font color=\"#ff9900\">w</font></a>", $pesan);
$pesan = str_replace("kancel","<a href=\"http://sangguna.net\"/>ORANGNYA LAGI BOBOK</a>", $pesan);
$pesan = str_replace("master","newbie", $pesan);
$pesan = str_replace("masta","newbie",
$pesan);
$pesan=preg_replace("#\[img\](.*?)\[\/img\]#","<center><b><font color='green'>PESAN DI HAPUS OTOMATIS</font></b></center>", $pesan);
/* di edit http://malang.wapsite.me
*/
/* di edit lagi oleh http://sangguna.net
*/
?>
