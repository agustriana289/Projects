<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
echo '</div><div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="http://chodot.yn.lt/shout/shout.png" alt="&bull;" style="float:right;" /><t style="text-shadow:-1px 0 gray, 0 1px gray, 1px 0 gray, 0 -1px gray"><font
color="white"size="5"> <b>NGOBROL</b></font></div></form></div>';
print('<div class="list2"><form action="http://'.$_SERVER['HTTP_HOST'].'/shout/say.php".psid()."" method="post">
<table><tr>
<td><input name="nick" type="text" style="width:90%" ');
/* di edit lagi oleh http://sangguna.net
*/
if(isset($_SESSION['sgb_name'])) print('value="'.$_SESSION['sgb_name'].'"');
else print('value="nama"onfocus="if(this.value=nama) this,value"" ');
print(' /></td><td><input name="url" type="text" style="width:90%" ');
if(isset($_SESSION['sgb_url'])) print('value="'.$_SESSION['sgb_url'].'"');
else print('value="http://" ');
print(' /></td></tr>
<tr><td><input name="text" style="width:90%" ');
if(isset($_SESSION['sgb_quote'])){ print('value="'.$_SESSION['sgb_quote'].'" ');
unset($_SESSION['sgb_quote']); }else{
print('value="pesan"onfocus="if(this.value=pesan) this,value"" '); }
print(' /></td><td>');
$anu=mt_rand(10,99);$key=$anu;
$_SESSION['sgb_kode']=$key;
include'ikon.php';
print('</table><input type="checkbox" name="rhs" value="oke"> Pesan pribadi');
if(isset($_GET['n']) && isset($arr[$_GET['n']])){
$_GET['n']=intval($_GET['n']);
$post=unserialize($arr[$_GET['n']]);
print($post['nick'].', ');
}
$anu=rand(1,9);
$nganu=rand(1,9);
echo '<input type="hidden" name="kode" readonly value="'.$key.'"> <input name="hasil" type="hidden" mini:hint="phone" value="'.$key.'"/><div class="rmenu"><input type="submit" value="K I R I M" /> </form> <a href="/pages/smiles.php"><font color="blue"> SMILE</a></font> <small><font color="blue">&spades;</font></small> <a href="/pages/bb-code.php"><font color="blue">CODE</a></font></div>';
if(isset($_SESSION['sgb_err'])){
print'<div class="err"><center>'.$_SESSION['sgb_err'].'</div>'; unset($_SESSION['sgb_err']);
}
/*
* http://malang.wapsite.me *
* di edit lg oleh http://sangguna.net *
*/
?>
