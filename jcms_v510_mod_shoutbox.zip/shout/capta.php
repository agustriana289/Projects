<?php
session_start();
if($_SESSION['hasil']) {
$text = $_SESSION['hasil'];
$width = strlen($text)*9;
if($im = imagecreatetruecolor($width, 16)) {
$black = imagecolorallocate($im, 0, 0, 0);
imagecolortransparent($im, $black);
$color = imagecolorallocate($im, 255, 0, 0); //#999999
imagestring($im, 5, 0, 0, $text, $color);
header("Content-type: image/png");
imagepng($im);
imagedestroy($im);
}
}
?>
