<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
require('shout.php');
$perf = new perf;
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
include('bcheck.php');
ob_start();
$headmod = 'Banlist';
$text = 'Banlist';

if(!isset($_SESSION['sgb_admp'])){ header('Location: index.php'.psid()); exit; }
$bf=file('ban.dat');
if(isset($_GET['n'])){
$n=intval($_GET['n']);
unset($bf[$n]);
$f=fopen('./ban.dat','w');
$d=implode('',$bf);
fputs($f,$d);
fclose($f);
Header('Location: banlist.php'.psid());
exit;
}
if(empty($bf[0])) die('Daftar user yg di banned kosong.<hr />[<a href="index.php'.psid().'">Back</a>]</div>');
print('<div class="gmenu"><i>(Method :: Delet)</i><hr />');
$cnt=count($bf);
for($i=0;$i<$cnt;$i++){
$a=explode('|:|',$bf[$i]);
print('[<a href="banlist.php?n='.$i.'&amp;'.SID.'">X</a>] ');
switch($a[0]){
case 0:
print('IP+Br');
break;
case 1:
print('Br');
break;
case 2:
print('IP');
break;
case 3:
print('C. ip+br');
break;
case 4:
print('C. br');
break;
case 5:
print('C. ip');
break;
case 6:
print('Total Ban');
break;
}
print(' :: '.$a[1].'<hr />');
}
echo('[<a href="index.php?'.psid().'">Shout</a>]</div>');
if ($k_page>1)str('index.php?',$k_page,$page); // B??o? c?pa???
include 'foot.php';
/* di edit oleh http://malang.wapsite.me
*/
/* di edit lagi oleh http://purwodadi.biz
*/
?>
