<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
$headmod = 'Kesalahan';
$text = 'Kesalahan';
//editing file by http://seupang.Co.Cc http://penceter.co.cc
require('shout.php');
if(!isset($_SESSION['sgb_admp'])) include('bcheck.php');
$arr=file('motto.dat');
if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL){
$mulih=$_SERVER['HTTP_REFERER'];
} else { $mulih='http://'.$CONF['url'].'';
}
if(isset($_POST['nick']) && isset($_POST['text'])){
function shit_happened($shit='Unknown error'){
global $admin, $mulih;
$_SESSION['sgb_err']=$shit;
if(strtolower($_POST['nick'])==$admin){
unset($_SESSION['sgb_err']);
}else{
unset($_SESSION['sgb_avatar']);
}
Header('Location: /');
exit;
}
$data['nick']=safe_var(strtolower($_POST['nick']));
$data['text']=safe_var(strtolower($_POST['text']),true);
$data['rhs']=safe_var($_POST['rhs']);
include'pasar.php';
$data['time']=$wib;
$data['br']=safe_var($_SERVER['HTTP_USER_AGENT']);
$data['hape']=safe_var($_SERVER['HTTP_X_OPERAMINI_PHONE_UA']);
$data['ip']=safe_var($_SERVER['REMOTE_ADDR']);
$data['avatar']=safe_var($_POST['avatar']);
$data['url']=safe_var($_POST['url']);
$data['hasil']=safe_var($_POST['hasil']);
if(!isset($_SESSION['sgb_name']) or $_SESSION['sgb_name']!=$data['nick']) $_SESSION['sgb_name']=$data['nick'];
if($CONF['captcha'] && (!isset($_POST['kode']) || $_POST['kode']!=$_SESSION['sgb_kode'])) shit_happened('Kalau mau posteng yg bener bos...! <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(!isset($_SESSION['sgb_url']) or $_SESSION['sgb_url']!=$data['url']) $_SESSION['sgb_url']=$data['url'];
if(!isset($_SESSION['sgb_avatar']) or $_SESSION['sgb_avatar']!=$data['avatar']) $_SESSION['sgb_avatar']=$data['avatar'];
if(empty($data['nick']) || empty($data['text'])) shit_happened('Hayo!! Nama atau Pesan kudu di isi! <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(substr_count($data['text'],'')>10)
shit_happened('Sabar2.,! smile jgn terlalu banyak bos,,gak boleh lebih dari 10 <img src="http://chodot.yn.lt/shout/sm/pentung.png" alt="">');
if(strtolower($data['nick'])==$admin){ $_SESSION['sgb_admp']=true; }
if(trim($data['nick']) == '' || trim($data['nick']) == 'nama' || trim($data['nick']) == 'name' || trim($data['nick']) == 'admin' ||
trim($data['nick']) == 'robot' ||
trim($data['nick']) == 'xanax' ||
trim($data['nick']) == 'valium' ||
trim($data['nick']) == 'accutane' ||
trim($data['nick']) == 'tramadol' ||
trim($data['nick']) == 'ambien' ||
trim($data['nick']) == 'cialis' ||
trim($data['nick']) == 'phentermine' ||
trim($data['nick']) == '' )
shit_happened('harap pergunakan nama lain <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(trim($data['text']) == '' ||
trim($data['text']) == 'pesan' || trim($data['text']) == 'message' || trim($data['text']) == 'pesan kamu' || trim($data['text']) == '' )
shit_happened('harap ulangi dengan pesan lain <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(strlen($data['nick'])>10) shit_happened('Nama gak blh lebih dari 10 karakter <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(strlen($data['nick'])<3) shit_happened('Nama gak blh kurang dari 3 karakter <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(!preg_match("/^[a-zA-Z]*$/", $data['nick'])) shit_happened('<img src="http://chodot.yn.lt/shout/sm/maaf.gif" alt="maaf"> Nama hanya a-z A-Z yg di perbolehkan');
if(strlen($data['text'])<3) shit_happened('Maaf, pesannya gak boleh kurang dari 3 karakter gan... <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(strlen($data['text'])>$CONF['shout'])
shit_happened('Sabar... pesan shout gak boleh lebih dari '.$CONF['shout'].' karakter..');
require('./smiles.php');
$data['text']=str_replace($sstr,$simg,$data['text']);
if(strlen($data['url'])>30) shit_happened('Sites gak boleh lebih dari 30 karakter...<img src="http://chodot.yn.lt/shout/sm/ckaka.png" alt="ckaka">');
if(empty($data['avatar'])) shit_happened('ikon belum ada yang dipilih... Silahkan pilih ikon dulu <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
if(empty($data['hasil'])) shit_happened('<img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung"> Sign up kode  kok masih kosong?');
if($_POST['kode']!=$_POST['hasil']) shit_happened('Nulisnya yg bener donk! <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung"> Sign up kode salah tuwh!');
$cnt=count($arr);
if($cnt>0){
$post=unserialize($arr[0]);
if($data['text']==$post['text'])shit_happened('Wew, mau ngeplud ya... Pesan kamu doble tuh <img src="http://chodot.yn.lt/shout/sm/pentung.gif" alt="pentung">');
}
$datarank="".$rank."/".$data['nick'].".txt";
if(!file_exists($datarank)){
$drank=1;
file_put_contents($datarank,$drank);
}else{
$frank=file_get_contents($datarank);
$drank=$frank+1;
file_put_contents($datarank,$drank);
}
$data['rank']=safe_var($drank);
if(!isset($_SESSION['sgb_rank']) or $_SESSION['sgb_rank']!=$data['rank']) $_SESSION['sgb_rank']=$data['rank'];
if($cnt>$CONF['np']) unset($arr[$cnt-1]);
$f=fopen('motto.dat','w');
fputs($f,serialize($data)."\n".implode('',$arr));
fclose($f);
header('Location: '.$mulih.''.psid());
}else{
if($CONF['captcha']){
# CAPTCHA string length
$length = mt_rand(5,6);
# symbols used to draw CAPTCHA
$allowed_sym = '23456789abcdeghkmnpqsuvxyz'; #alphabet without similar symbols (o=0, 1=l, i=j, t=f)
while(true){
$keystr='';
for($i=0;$i<$length;$i++){
$keystr.=$allowed_sym{mt_rand(0,strlen($allowed_sym)-1)};
}
if(!preg_match('/cp|cb|ck|c6|c9|rn|rm|mm|co|do|cl|db|qp|qb|dp/', $keystr)) break;
}
$_SESSION['sgb_code']=$keystr;
}
if(isset($_SESSION['sgb_err'])){
print'<div class="rmenu"><center>'.$_SESSION['sgb_err'].'</center></div>'; unset($_SESSION['sgb_err']);
}else print'<div class="gmenu"><center>Silahkan <a href="/"> kembali</a></center></div>';
}
include 'foot.php';

/*
* di edit oleh elank *
* http://malang.wapsite.me *
*/
?>