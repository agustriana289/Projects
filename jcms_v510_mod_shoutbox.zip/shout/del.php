<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
require('shout.php');
$perf = new perf;
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
include('bcheck.php');
ob_start();
$headmod = 'Delete';
$text = 'Delete';

if(isset($_SESSION['sgb_admp']) && isset($_GET['clear'])){
$f=fopen('motto.dat','w');
fclose($f);
echo('Message has been deleted.');
}elseif(isset($_SESSION['sgb_admp']) && isset($_GET['n'])){
$n=intval($_GET['n']);
$arr=file('motto.dat');
unset($arr[$n]);
$f=fopen('motto.dat','w');
$d=implode('',$arr);
fputs($f,$d);
fclose($f);
echo('<div class="rmenu">Pesan telah di hapus.');
}else echo('Login dulu utk mengakses halaman ini!');
print('<br />[<a href="index.php'.psid().'">Shout</a>]</div>');
if ($k_page>1)str('index.php?',$k_page,$page); // B??o? c?pa???
include 'foot.php';
?>
