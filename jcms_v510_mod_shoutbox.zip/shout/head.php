<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
require('../incfiles/function.php');
include('../incfiles/head.php');
?>
