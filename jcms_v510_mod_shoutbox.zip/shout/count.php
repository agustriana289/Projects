<?
$s_p=mysql_result(mysql_query("SELECT COUNT(*) FROM `shout`",$db), 0);
$s_n= mysql_result(mysql_query("SELECT COUNT(*) FROM `shout` WHERE `time` > '".(time()-86400)."'",$db), 0);
if ($s_n==0)$k_n=NULL;
else $s_n='|<font color=\"#ff0000\">+'.$s_n.'</font>';
echo "$s_p$s_n";
?>
