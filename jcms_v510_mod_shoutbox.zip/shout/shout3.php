<?php
$set_lokasi='./shout/';
$CONF['ns'] = 3;
$CONF['ns3'] = 3;
$block=''.$set_lokasi.'band.dat';
$data_shout= ''.$set_lokasi.'motto.dat';
$link_pesan=''.$set_lokasi.'pesan.php';
?>
