<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
require('shout.php');
$perf = new perf;
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
include('bcheck.php');
ob_start();
$headmod = 'Admin';
$text = 'Admin';
print('
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru"><head><title>Admin Area</title>
<link rel="stylesheet" type="text/css" href="../theme/default/style.css" /></head><body>');
/*
// echo'<div class="title"><center>';
// include'header.php';
echo'</center></div>';
*/
if(isset($_GET['p'])){
if($_GET['p']==$CONF['admp']){
$_SESSION['sgb_admp']=true;
print('<div class="gmenu"><center>Login success!<br /><small>Click</small><br />[<a href="index.php'.psid().'">Here</a>]</center></div>');
}else print('<div class="rmenu"><center>Password salah!<br />[<a href="admin.php'.psid().'">Ulangi</a>]</center></div>');
}else print('<div class="menu"><center>
<form action="admin.php'.psid().'" method="get">
Enter Password:<br />
<input type="password" name="p" size="12" /><br />
<input type="submit" value="OK" />
</form>
</center></div>');
if ($k_page>1)str('index.php?',$k_page,$page); // B??o? c?pa???
include 'foot.php';
?>
