<?php 
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
//editing scrip dari http://mymotto.110mb.com
//di edit lagi oleh http://seupang.Co.Cc
//modif by http://malang.wapsite.me
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
ob_start();
// Membuka data gb
$arr=file(''.$data_shout.'');
$cnt=count($arr);
for($i=0;$i<$CONF['ns'];$i++){
if($c==$cnt) break;
$post=unserialize($arr[$c]);
// Hasil post pesan
// Post rahasia
$rhs = $post['rhs'];
$nama = $post['nick'];
$nama=strtolower($nama);
$avatar = $post['avatar'];
$pesan = $post['text'];
$reply = $post['reply'];
include'pesan.php';
$ip = $post['ip'];$hape = $post['hape'];
$hape = strtok($hape,'/');
$hape = str_replace('/',' ',$hape);
$hape = str_replace('Opera','Oplet',$hape);
$hape = str_replace('Mozilla','Gorila',$hape);
$hape = str_replace('Nokia','NOK ',$hape);
$hape = str_replace('SonyEricsson','SE ',$hape);
$hape = str_replace('Siemens','SIE ',$hape);
$hape = str_replace('Motorola','MOT ',$hape);
$hape = substr($hape, 0, 30);
$versi = $post['br'];
$versi = explode(' ',$versi);
$versi = $versi[3];
$versi = str_replace("Mini","OpMin",$versi);
$versi = str_replace("/"," ",$versi);
$versi = substr($versi, 0, 9);
$hape = $post['hape'];
$hape = strtok($hape,'/');
$hape = str_replace('/',' ',$hape);
$hape = str_replace('Mozilla','Moz ',$hape);
$hape = str_replace('Nokia','NOK ',$hape);
$hape = str_replace('SonyEricsson','SE ',$hape);
$hape = str_replace('Siemens','SIE ',$hape);
$hape = str_replace('Motorola','MOT ',$hape);
$hape = $post['hape'];
$hape2 = explode(' ',$hape);
if(substr_count($hape2[3], 'Series60/3')){ $hape = $hape2[4]; }elseif(substr_count($hape2[2], 'Series60/3')){ $hape = $hape2[3]; }
$hape = strtok($hape,'/');
$hape = str_replace('/',' ',$hape);
$hape = str_replace('Mozilla','Gorilla',$hape);
$hape = str_replace('Nokia','Nokia ',$hape);
$hape = str_replace('SonyEricsson','Soner ',$hape);
$hape = str_replace('Siemens','SIE ',$hape);
$hape = str_replace('Motorola','MOT ',$hape);
$hape = str_replace('BlackBerry','BeBe ',$hape);
$url = $post['url'];
$ip = $post['ip'];
$url = str_replace("\r\n","",$url);
$jamshout = $post['time'];
$waktu = explode(" ",$jamshout);
$time = $waktu[3];
$periods=array("detik","menit","jam","hari","minggu","bulan","tahun","dekade");
$lengths=array("60","60","24","7","4","35","12","10");
$now=gmdate(time()+(7*3600));
$difference=$now-$time;
$tense="yang lalu";
for($j=0; $difference>=$lengths[$j]&&$j<count($lengths)-1; $j++) {
$difference/=$lengths[$j]; }
$difference=round($difference); if($difference!=1) { $periods[$j].=""; } $jam="$waktu[0], $difference $periods[$j] $tense";
if(isset($_SESSION['sgb_admp']))
include''.$link_pesan.'';
include'nama.php';
if($rhs == "oke"){
if(isset($_SESSION['sgb_admp'])){
echo'</div><div class="mainboox"><div class="mainblok"><div class="nfooter"><img src="http://chodot.yn.lt/shout/clock.png" width="16" hieght="16" alt="clock"> '.$jam.'</span></div> <img src="http://chodot.yn.lt/shout/friends.png"> '.$aran.' <font color="red">Penting...!</font><hr/> '.$pesan.'</div>';
if(trim($url)<>"" and trim($url)<>"http://"){ if (ereg("^", trim($url)))
echo'Markas: <a href="'.$url.'">'.$url.'</a></div>'; }
}else{
echo'</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="http://chodot.yn.lt/shout/private.png" alt="*"/> <b>RAHASIA</b><br/></div><div class="list2" style="background-image:url(http://chodot.yn.lt/shout/naruto/'.$avatar.');background-repeat:no-repeat;background-position:right bottom;min-height:60px;"><div style="float:right">'.$urutan.'</span></div><form action="/shout/admin.php" method="get">
<input type="password" name="p" size="6" value="*******" /><input type="submit" value="Buka" /></form><marquee behavior=alternate loop=is>'.$jam.'</marquee></div>';
}
}
else
{
print'</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter"style="text-align:left"><img src="http://chodot.yn.lt/shout/clock.png" width="16" hieght="16" alt="clock"> '.$jam.'</span></div><table width="100%"><tr><td width="5%">';
if (trim($post[url])<>"" and trim($post[url])<>"http://") {
if (ereg("^", trim($post[url])))
echo'</div><div class="topmenu"><div class="list"><img src="'.$avatar.'" width="30" height="30" alt="*"/><div><div></td><td width="95%"><div><div class="topmenu"><div class="list"><b>Nama : <font color="blue"><span style="text-shadow:black 0.10em 0.10em 0.10em" valign="_top"><a href="'.$url.'">'.$aran.'</a></span>&trade;</font></b><br/>Kartu : ';
}
else echo'</div><div class="topmenu"><div class="list"><img src="'.$avatar.'" width="30" height="30" alt="*"/><div><div></td><td width="95%"><div class="topmenu"><div class="list"><b>Nama : <font color="blue"><span style="text-shadow:black 0.10em 0.10em 0.10em" valign="_top">'.$aran.'</span>&trade;</font></b><br/>Kartu : ';
include'provider.php';
print'<div></div></td></table><div class="mainbox"><div class="list2"><b><font color="red">Pesan: </font><img src="http://chodot.yn.lt/shout/suka.gif"></b> '.$pesan.'';
// Jika admin mejawab, yg tertampil sbb:
if(isset($post['answ']))
print'</div></div><div style="background:#FFFF00;color:#F70000;" align="left"><font color="green"><b>ADMIN:</font></b> ';
echo'<font color="fuchsia">'.$post['answ'].'</font><div></div>';
echo'</div></div><div class="list2">';
if($nama == "sss"){ echo'</div>'; }else{echo' </b></font></span> <a href="/shout/index.php?a=quote&m='.$nama.'"><img src="http://chodot.yn.lt/shout/quota.png" alt="Quote" style="float:right;" /></a>';
}
if($nama!=$admin){
}
if($nama!="sss"){ echo'<div class="rmenu"><div style="text-align:left">&bull;</b><input ="text" value="Melalui, '.$versi.' '.$hape.'" size="12" /><br/>&bull; IP: '.$ip.'</a> '; }
if (trim($post[url])<>"" and trim($post[url])<>"http://") { if (ereg("^", trim($post[url]))) echo'<br/>&bull; <img src="http://chodot.yn.lt/shout/sm/home.png" alt="" /> <a href="'.$url.'" target="_blank">'.$url.'</a></div></div>'; }
echo'</form></div></div></div>';
}
$c++;
}
//Main page
echo '</div></div></div></div><div class="mainbox"><table class="gmenu" cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><a href="'.$set['home'].'/pages/smiles.php">Smiley</a></div></td><td width="auto" align="center">';
if($c>$CONF['ns']){
print('[<a href="?c='.($c-$CONF['ns']-$i).''.SID.'">&#171;</a>]|');
}else{
print'[&#171;]|';
}
echo $cnt;
if($c<$cnt){
print('|[<a href="?c='.$c.''.SID.'">&#187;</a>]<br />');
}else{
print'|[&#187;]<br />';
}
echo'</td><td width="auto" align="right"><a href="'.$set['home'].'/pages/bb-code.php">Bbcode</a>';
echo '</td></tr></table>';

?>
