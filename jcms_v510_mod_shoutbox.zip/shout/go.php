<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
 include'head.php';
 require('shout.php');
/*
silahkan di edit sesuai selera anda
*/
$url=htmlspecialchars(rawurldecode(@$_SERVER['QUERY_STRING']));
echo '<html><head><title>External Url</title></head><body>';
echo '<div><div class="rmenu"><font color="red">PERHATIAN...!</font><br/>Anda akan pergi menuju link teman saya<font color="blue">'.$url.'</font>dan akan meninggalkan situs ini, terima kasih atas kunjunganya<br/><a href="'.$url.'" target="_blank"></font><font color="bluee"><b>LANJUTKAN</b></font></a> | <a href="/" target="_blank"><font color="red"><b>KEMBALE</b></font></a></div>';
include 'foot.php';
?>
