<?
echo'<select name="avatar" style="width:95%">
<option value="">Harap Pilih</option>
<option value="http://chodot.yn.lt/shout/naruto/asuma.gif">Asuma</option>
<option value="http://chodot.yn.lt/shout/naruto/baki.gif">Baki</option>
<option value="http://chodot.yn.lt/shout/naruto/choji.gif">Choji</option>
<option value="http://chodot.yn.lt/shout/naruto/ebisu.gif">Ebisu</option>
<option value="http://chodot.yn.lt/shout/naruto/gaara.gif">Gaara</option>
<option value="http://chodot.yn.lt/shout/naruto/gai.gif">Gai</option>
<option value="http://chodot.yn.lt/shout/naruto/gamabunta.gif">Gamabunta</option>
<option value="http://chodot.yn.lt/shout/naruto/genma.gif">Genma</option>
<option value="http://chodot.yn.lt/shout/naruto/hayate.gif">Hayate</option>
<option value="http://chodot.yn.lt/shout/naruto/hinata.gif">Hinata</option>
<option value="http://chodot.yn.lt/shout/naruto/hokage.gif">Hokage</option>
<option value="http://chodot.yn.lt/shout/naruto/ibiki.gif">Ibiki</option>
<option value="http://chodot.yn.lt/shout/naruto/ino.gif">Ino</option>
<option value="http://chodot.yn.lt/shout/naruto/iruka.gif">Iruka</option>
<option value="http://chodot.yn.lt/shout/naruto/itachi.gif">Itachi</option>
<option value="http://chodot.yn.lt/shout/naruto/jiraiya.gif">Jiraiya</option>
<option value="http://chodot.yn.lt/shout/naruto/kabuto.gif">Kabuto</option>
<option value="http://chodot.yn.lt/shout/naruto/kakashi.gif">Kakashi</option>
<option value="http://chodot.yn.lt/shout/naruto/kankuro.gif">Kankuro</option>
<option value="http://chodot.yn.lt/shout/naruto/kiba.gif">Kiba</option>
<option value="http://chodot.yn.lt/shout/naruto/kizame.gif">Kizame</option>
<option value="http://chodot.yn.lt/shout/naruto/konohamaru.gif">Konohamaru</option>
<option value="http://chodot.yn.lt/shout/naruto/kurenai.gif">Kurenai</option>
<option value="http://chodot.yn.lt/shout/naruto/kyubi.gif">Kyubi</option>
<option value="http://chodot.yn.lt/shout/naruto/moegi.gif">Moegi</option>
<option value="http://chodot.yn.lt/shout/naruto/naruto.gif">Naruto</option>
<option value="http://chodot.yn.lt/shout/naruto/naji.gif">Naji</option>
<option value="http://chodot.yn.lt/shout/naruto/nidaime.gif">Nidaime</option>
<option value="http://chodot.yn.lt/shout/naruto/orochimaru.gif">Orochimaru</option>
<option value="http://chodot.yn.lt/shout/naruto/rock_lee.gif">Rock_lee</option>
<option value="http://chodot.yn.lt/shout/naruto/sakura.gif">Sakura</option>
<option value="http://chodot.yn.lt/shout/naruto/sasuke.gif">Sasuke</option>
<option value="http://chodot.yn.lt/shout/naruto/shikamura.gif">Shikamura</option>
<option value="http://chodot.yn.lt/shout/naruto/shino.gif">Shino</option>
<option value="http://chodot.yn.lt/shout/naruto/shodai.gif">Shodai</option>
<option value="http://chodot.yn.lt/shout/naruto/shukaku.gif">Shukaku</option>
<option value="http://chodot.yn.lt/shout/naruto/temari.gif">Temari</option>
<option value="http://chodot.yn.lt/shout/naruto/tenten.gif">Tenten</option>
<option value="http://chodot.yn.lt/shout/naruto/tsunade.gif">Tsunade</option>
<option value="http://chodot.yn.lt/shout/susu.png">Susu</option>
<option value="http://chodot.yn.lt/shout/naruto/yondaime.gif">Yondaime</option>
<option value="http://chodot.yn.lt/shout/naruto/zabuza.gif">Zabuza</option>
</select>';

?>