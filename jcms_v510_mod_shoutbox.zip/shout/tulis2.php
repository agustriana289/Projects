<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
$tank=array("http://chodot.yn.lt/shout/tank/amx-50-heavy-tank.png", "http://chodot.yn.lt/shout/tank/amx56-leclerc-mbt.png", "http://chodot.yn.lt/shout/tank/carro-armato-p26-40.png", "http://chodot.yn.lt/shout/tank/challenger-a30.png", "http://chodot.yn.lt/shout/tank/fv214-conqueror-heavy-tank.png", "http://chodot.yn.lt/shout/tank/fv432.png", "http://chodot.yn.lt/shout/tank/is1-joseph-stalin.png", "http://chodot.yn.lt/shout/tank/m3-lee.png", "http://chodot.yn.lt/shout/tank/object-279.png", "http://chodot.yn.lt/shout/tank/panzer-8-pzkpfw-viii-maus.png", "http://chodot.yn.lt/shout/tank/t28-super-heavy-tank.png", "http://chodot.yn.lt/shout/tank/t29-heavy-tank.png", "http://chodot.yn.lt/shout/tank/t35-heavy-tank.png", "http://chodot.yn.lt/shout/tank/tank-heavy-assault-tortoise-a39.png", "http://chodot.yn.lt/shout/tank/type-120-oi-super-heavy-tank.png");
print'</div><div class="mainbox"><div class="mainblok"><div class="nfooter"><div style="float:right"> <a href="/shout/index.php?a=keluar"><font color="gold">Logout</a></font></div><img src="http://chodot.yn.lt/shout/suka.gif"> <b><font style="text-shadow:black 0.3mm 0.3mm 0.3mm; font-family: Tahoma, sans-serif;"> <font style="text-shadow:-1px 0 black, 0 1px red, 1px 0 red, 0 -1px red">'.$_SESSION['sgb_name'].'</font> logged on ! </font></b></span></div><div class="list2" style="background-image:url('.$_SESSION['sgb_avatar'].');background-repeat:no-repeat;background-position:right bottom;"><form action="http://'.$_SERVER['HTTP_HOST'].'/shout/say.php".psid()."" method="post"><table><td><textarea name="text"  class="of" id="msg" value="pesan" style="background-image:url('.$tank[rand(0,count($tank)-1)].');background-repeat:no-repeat;background-position:right;margin-top:1px;margin-bottom:1px;height:50px;width:95%;text-align:center;">';
if(isset($_SESSION['sgb_quote'])){ echo $_SESSION['sgb_quote'];
unset($_SESSION['sgb_quote']); }
echo'</textarea></td><td valign="_top"><input type="submit" style="font-family: Tahoma;" value="Shout"/></td></table></div><div class="rmenu"><select name="rhs"><option value="">Publik</option><option value="oke">Pribadi</option></select> | <small><a href="/pages/smiles.php"><font color="blue">SMILE</font></a><font color="blue"> |</font> <a href="/pages/bb-code.php"><font color="blue">CODE</font></a></small></div><input name="nick" type="hidden" value="'.$_SESSION['sgb_name'].'" /><input name="avatar" type="hidden" value="'.$_SESSION['sgb_avatar'].'" /><input name="url" type="hidden" value="'.$_SESSION['sgb_url'].'" />';
$anumu=rand(1,9);
$nganu=rand(1,9);
$sianu=$anumu.'+'.$nganu;
$anu=$anumu+$nganu;
$_SESSION['sgb_kode']=$anu;
$key=$_SESSION['sgb_kode'];
print'<input type="hidden" name="kode" readonly value="'.$key.'"><input type="hidden" name="hasil" size="8" class="number" maxlength="5" value="'.$key.'"></form></div>';
if(isset($_SESSION['sgb_err'])){
print'<div class="err"><center>'.$_SESSION['sgb_err'].'</div>'; unset($_SESSION['sgb_err']);
}
/*
* di edit oleh http://malang.wapsite.me *
*/
?>
