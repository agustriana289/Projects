<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2009 - 2014 JohnCMS Community
* @author      http://johncms.com/about
* @mod shoutbox      http://www.chapink.com
* @forum      http://www.susukan.us
* @freehosting      http://www.indomob.net
**/
include 'head.php';
require('shout.php');
$perf = new perf;
$c=intval(@$_GET['c']);
if(!isset($_SESSION['sgb_admp']))
include('bcheck.php');
ob_start();
$headmod = 'Ban';
$text = 'Ban';

if(!isset($_SESSION['sgb_admp'])) die('<div class="rmenu">Kamu tidak dapat mengakses page ini,silahkan login dulu.</div>');
elseif(!isset($_GET['n'])) die('O?@a.</div>');
elseif(isset($_POST['method'])){
$n=intval($_GET['n']);
$arr=file('motto.dat');
$a=unserialize($arr[$n]);
$_POST['method']=intval($_POST['method']);
switch($_POST['method']){
case 0:
$str='0|:|'.$a['br'].' IP:'.$a['ip'];
break;
case 1:
$str='1|:|'.$a['br'];
break;
case 2:
$str='2|:|'.$a['ip'];
break;
case 3:
$str='3|:|'.$a['br'].' IP:'.$a['ip'];break;
case 4:
$str='4|:|'.$a['br'];
break;
case 5:
$str='5|:|'.$a['ip'];
break;
case 6:
$str='6|:|';
break;
}
$f=fopen('ban.dat','a');
fwrite($f,$str."\n");
fclose($f);
print('A?? A@?e? ?@??c?<hr />');
if($_POST['method']>2 && $_POST['method']<6) print('<small>B?pa???A@? c ????cookies,<br />
cpo?A??? ??p? ???e??pe?7 cy??<br />
Ka???? ?????? ????cookie A?? @A?yA?? ? ?c?</small><hr />');
}else{
$n=intval($_GET['n']);
print('<form action="ban.php?n='.$n.'&amp;'.SID.'" method="post">
<div class="gmenu">Select banned:<br /><select name="method" title="method">
<option value="0">IP+Browser</option>
<option value="1">Browser</option>
<option value="2">IP</option>
<option value="3">Cookie(IP+Browser)</option>
<option value="4">Cookie(Browser)</option>
<option value="5">Cookie(IP)</option>
<option value="6">Banned All</option>
</select><br />
<input type="submit" value="Ban user" />
</form></div>');
}
print('<div class="rmenu">[<a href="index.php?'.psid().'">shotbook</a>]</div>');
if ($k_page>1)str('index.php?',$k_page,$page); // B??o? c?pa???
include 'foot.php';
/* di edit oleh http://malang.wapsite.me
*/
/* di edit lagi oleh http://purwodadi.biz
*/
?>
