<?php
ob_start();
include "shout3.php";
if(isset($_SESSION['sgb_avatar'])){ include "tulis2.php"; include "sht.php"; } else { include "tulis1.php"; include "sht.php"; }
/*
* di edit oleh elank *
* http://malang.wapsite.me *
*/
ob_end_flush();
?>
