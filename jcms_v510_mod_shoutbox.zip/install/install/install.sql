-- Wap PhpMyAdmin 2.1 Beta
-- http://master-land.net/phpmyadmin 
-- Generation Time: 2014-01-23 08:40
-- MySQL Server Version: 5.1.61
-- PHP Version: 5.3.24

-- Database: `susukan_jcms`


-- --------------------------------------------------------
-- 
-- Table structure for table `apply_staff`
-- 

CREATE TABLE `apply_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `blogs`
-- 

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` text NOT NULL,
  `text` text NOT NULL,
  `time` int(11) NOT NULL,
  `count` int(10) NOT NULL,
  `close` int(3) NOT NULL,
  `file` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`user`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `blogs`
-- 

INSERT INTO `blogs` VALUES ('1','1','JohnCMS 5.1.0 Mod Shoutbox','[b]JohnCMS v5.1.0 Full Mod[/b] [url=http://susukan.us] Susukan.Us [/url]\r\n\r\n[b]Fitur-fitur mod:[/b]\r\n- My blogs\r\n- Mod rewrite Url fix\r\n- Mod rewrite profile fix\r\n- Mod shoutbox untuk tamu buat posting tanpa harus login\r\n- Mod wall\r\n- Mod chat\r\n- Mod subforum index\r\n- Mod bot panel\r\n- Mod guestbook chat\r\n- Mod forum thanks\r\n- Mod jurnal forum\r\n- Import file forum\r\n- Extra attach forum\r\n- Stats google\r\n- Robots editor\r\n- Add bookmark forum\r\n- TOS dan FAQ\r\n- Tags forum\r\n- Facebook dan twitter link di profile\r\n- Friendssite\r\n- Mod apply staf\r\n- dan masih banyak lagi :cape\r\n\r\n[b]Cara installasi:[/b]\r\n- Extrack file di root atau public_html\r\n- Lalu chmod file-file yang di haruskan untuk di chmod. Agar chmodnya lebih mudah sudah tersedia auto chmod, caranya klik [red]http://situsmu.com/chmod.php[/red] lalu lanjutkan "Go to installation step"\r\n- Langkah terakhir isi kolom-kolom seperti, host, database, user, dan password sesuai hostingmu.\r\n- Jika sudah terinstall klik [red]http://situsmu/chmod2.php[/red] untuk menonaktifkan folder [b]INSTALL[/b]dan merubah chmod file "db.php" ke 644\r\n- Selesai..\r\n\r\nUntuk downloadnya silahkan [big][b][green][url=http://www.chapink.com]Masuk Sini[/url][/green][/b][/big] atau download file dibawah ini :','1390478881','1','0','');

-- --------------------------------------------------------
-- 
-- Table structure for table `blogs_komm`
-- 

CREATE TABLE `blogs_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` text NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`user`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `blogs_komm`
-- 

INSERT INTO `blogs_komm` VALUES ('1','1','2','Lanjutkan mbuahahahaha :D','1390484158');
INSERT INTO `blogs_komm` VALUES ('2','1','1','Yang penting mau mumet itu sudah afdol :D','1390484235');

-- --------------------------------------------------------
-- 
-- Table structure for table `bot`
-- 

CREATE TABLE `bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `key` varchar(100) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `txt1` varchar(500) NOT NULL,
  `txt2` varchar(500) NOT NULL,
  `txt3` varchar(500) NOT NULL,
  `txt4` varchar(500) NOT NULL,
  `txt5` varchar(500) NOT NULL,
  `time` int(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_bot`
-- 

CREATE TABLE `chat_bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tip` int(3) NOT NULL,
  `mass_bot` text NOT NULL,
  `mass_author` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_bot`
-- 

INSERT INTO `chat_bot` VALUES ('1','Chodot','4','a:18:{s:6:"status";s:18:"Waper banjarnegara";s:3:"sex";s:1:"m";s:2:"av";s:6:"Chodot";s:8:"time_off";i:5;s:6:"vopros";s:6:"Chodot";s:7:"time_on";i:0;s:6:"time_1";i:60;s:6:"time_2";i:0;s:7:"nev_vop";s:36:"Selamat datang dan selamat bergabung";s:6:"pods_1";s:36:"Selamat datang dan selamat bergabung";s:6:"pods_2";s:0:"";s:6:"no_otv";s:36:"Selamat datang dan selamat bergabung";s:5:"otv_0";s:0:"";s:5:"otv_1";s:0:"";s:5:"otv_2";s:0:"";s:8:"pods_0_n";i:0;s:8:"pods_1_n";i:0;s:8:"pods_2_n";i:0;}','a:6:{s:6:"author";s:5:"admin";s:12:"author_email";s:16:"admin@susukan.us";s:10:"author_url";s:23:"http://test.indoboox.us";s:11:"description";s:26:"Hanya seorang waper newbie";s:7:"version";s:1:"1";s:3:"iso";s:2:"en";}');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_room_1`
-- 

CREATE TABLE `chat_room_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_u` int(11) NOT NULL,
  `id_s` int(11) NOT NULL,
  `id_bot` int(11) NOT NULL,
  `time` int(15) NOT NULL,
  `text` text NOT NULL,
  `author` text NOT NULL,
  `tip` int(1) NOT NULL,
  `pas` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_room_1`
-- 

INSERT INTO `chat_room_1` VALUES ('8','1','0','1','1388414790','Selamat datang dan selamat bergabung','a:10:{s:2:"av";s:6:"Chodot";s:3:"sex";s:1:"m";s:6:"status";s:18:"Waper banjarnegara";s:4:"name";s:6:"Chodot";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','8','');
INSERT INTO `chat_room_1` VALUES ('9','1','0','1','1388465590','Selamat datang dan selamat bergabung','a:10:{s:2:"av";s:6:"Chodot";s:3:"sex";s:1:"m";s:6:"status";s:18:"Waper banjarnegara";s:4:"name";s:6:"Chodot";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','9','');
INSERT INTO `chat_room_1` VALUES ('10','0','0','2','1388465588','Mobile wap forum Susukan.Us - [ID]','a:10:{s:2:"av";s:0:"";s:3:"sex";s:1:"m";s:6:"status";s:0:"";s:4:"name";s:8:"Informer";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','2','0');
INSERT INTO `chat_room_1` VALUES ('11','0','0','2','1390403642','Mobile wap forum Susukan.Us - [ID]','a:10:{s:2:"av";s:0:"";s:3:"sex";s:1:"m";s:6:"status";s:0:"";s:4:"name";s:8:"Informer";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','2','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_rooms`
-- 

CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `op` varchar(500) NOT NULL,
  `tip` varchar(3) NOT NULL,
  `bot` text NOT NULL,
  `nev` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_rooms`
-- 

INSERT INTO `chat_rooms` VALUES ('1','Susukan.Us - [ID]','Mobile wap forum','','a:1:{i:0;i:1;}','Mobile wap forum Susukan.Us - [ID]');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_settings`
-- 

CREATE TABLE `chat_settings` (
  `key` tinytext NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`key`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_settings`
-- 

INSERT INTO `chat_settings` VALUES ('access','1');
INSERT INTO `chat_settings` VALUES ('balls','0');
INSERT INTO `chat_settings` VALUES ('color_nik','0');
INSERT INTO `chat_settings` VALUES ('color_nik_text','0');
INSERT INTO `chat_settings` VALUES ('color_text','0');
INSERT INTO `chat_settings` VALUES ('auto_delete','0');
INSERT INTO `chat_settings` VALUES ('faq','1');
INSERT INTO `chat_settings` VALUES ('time','0');
INSERT INTO `chat_settings` VALUES ('leave_post','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_users`
-- 

CREATE TABLE `chat_users` (
  `id_u` int(11) NOT NULL,
  `ban_naz_time` int(11) NOT NULL,
  `ban_time` int(11) NOT NULL,
  `ban_text` text NOT NULL,
  `postchat` int(10) NOT NULL DEFAULT '0',
  `otvetov` int(11) NOT NULL DEFAULT '0',
  `rights` tinyint(1) NOT NULL DEFAULT '0',
  `balans` int(11) NOT NULL DEFAULT '0',
  `set_chat` text NOT NULL,
  PRIMARY KEY (`id_u`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_users`
-- 

INSERT INTO `chat_users` VALUES ('3','0','0','','0','0','0','0','');
INSERT INTO `chat_users` VALUES ('4','0','0','','2','0','0','0','');
INSERT INTO `chat_users` VALUES ('1','0','0','','0','0','0','0','');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_vop`
-- 

CREATE TABLE `chat_vop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `vopros` text NOT NULL,
  `otvet` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bot` (`id_bot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ads`
-- 

CREATE TABLE `cms_ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(2) NOT NULL,
  `view` int(2) NOT NULL,
  `layout` int(2) NOT NULL,
  `count` int(11) NOT NULL,
  `count_link` int(11) NOT NULL,
  `name` text NOT NULL,
  `link` text NOT NULL,
  `to` int(10) NOT NULL DEFAULT '0',
  `color` varchar(10) NOT NULL,
  `time` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `mesto` int(2) NOT NULL,
  `bold` tinyint(1) NOT NULL DEFAULT '0',
  `italic` tinyint(1) NOT NULL DEFAULT '0',
  `underline` tinyint(1) NOT NULL DEFAULT '0',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_cat`
-- 

CREATE TABLE `cms_album_cat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `name` varchar(40) NOT NULL,
  `description` text NOT NULL,
  `password` varchar(20) NOT NULL,
  `access` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `access` (`access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_comments`
-- 

CREATE TABLE `cms_album_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  `attributes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_downloads`
-- 

CREATE TABLE `cms_album_downloads` (
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_files`
-- 

CREATE TABLE `cms_album_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `album_id` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `img_name` varchar(100) NOT NULL,
  `tmb_name` varchar(100) NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `comments` tinyint(1) NOT NULL DEFAULT '1',
  `comm_count` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vote_plus` int(11) NOT NULL,
  `vote_minus` int(11) NOT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `unread_comments` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `album_id` (`album_id`),
  KEY `access` (`access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_views`
-- 

CREATE TABLE `cms_album_views` (
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_votes`
-- 

CREATE TABLE `cms_album_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `vote` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `file_id` (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ban_ip`
-- 

CREATE TABLE `cms_ban_ip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip1` bigint(11) NOT NULL DEFAULT '0',
  `ip2` bigint(11) NOT NULL DEFAULT '0',
  `ban_type` tinyint(4) NOT NULL DEFAULT '0',
  `link` varchar(100) NOT NULL,
  `who` varchar(25) NOT NULL,
  `reason` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip1` (`ip1`),
  UNIQUE KEY `ip2` (`ip2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ban_users`
-- 

CREATE TABLE `cms_ban_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `ban_time` int(11) NOT NULL DEFAULT '0',
  `ban_while` int(11) NOT NULL DEFAULT '0',
  `ban_type` tinyint(4) NOT NULL DEFAULT '1',
  `ban_who` varchar(30) NOT NULL DEFAULT '',
  `ban_ref` int(11) NOT NULL DEFAULT '0',
  `ban_reason` text NOT NULL,
  `ban_raz` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ban_time` (`ban_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_contact`
-- 

CREATE TABLE `cms_contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `from_id` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `friends` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ban` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `man` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`user_id`,`from_id`),
  KEY `time` (`time`),
  KEY `ban` (`ban`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_counters`
-- 

CREATE TABLE `cms_counters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) NOT NULL DEFAULT '1',
  `name` varchar(30) NOT NULL,
  `link1` text NOT NULL,
  `link2` text NOT NULL,
  `mode` tinyint(4) NOT NULL DEFAULT '1',
  `switch` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_files`
-- 

CREATE TABLE `cms_forum_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat` int(10) NOT NULL,
  `subcat` int(10) NOT NULL,
  `topic` int(10) NOT NULL,
  `post` int(10) NOT NULL,
  `time` int(11) NOT NULL,
  `filename` text NOT NULL,
  `filetype` tinyint(4) NOT NULL,
  `dlcount` int(10) NOT NULL,
  `del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `subcat` (`subcat`),
  KEY `topic` (`topic`),
  KEY `post` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_rdm`
-- 

CREATE TABLE `cms_forum_rdm` (
  `topic_id` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`,`user_id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_forum_rdm`
-- 

INSERT INTO `cms_forum_rdm` VALUES ('3','1','1390475826');
INSERT INTO `cms_forum_rdm` VALUES ('5','1','1390480222');
INSERT INTO `cms_forum_rdm` VALUES ('8','1','1390483998');
INSERT INTO `cms_forum_rdm` VALUES ('8','2','1390483951');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_vote`
-- 

CREATE TABLE `cms_forum_vote` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(2) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_vote_users`
-- 

CREATE TABLE `cms_forum_vote_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_mail`
-- 

CREATE TABLE `cms_mail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `from_id` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `delete` int(10) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(100) NOT NULL DEFAULT '',
  `count` int(10) NOT NULL DEFAULT '0',
  `size` int(10) NOT NULL DEFAULT '0',
  `them` varchar(100) NOT NULL DEFAULT '',
  `spam` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `from_id` (`from_id`),
  KEY `time` (`time`),
  KEY `read` (`read`),
  KEY `sys` (`sys`),
  KEY `delete` (`delete`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_online`
-- 

CREATE TABLE `cms_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_online`
-- 

INSERT INTO `cms_online` VALUES ('1','user','2','admin, BOT','1362973309');
INSERT INTO `cms_online` VALUES ('2','guest','0','@','1362973309');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_sessions`
-- 

CREATE TABLE `cms_sessions` (
  `session_id` char(32) NOT NULL DEFAULT '',
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sestime` int(10) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `movings` smallint(5) unsigned NOT NULL DEFAULT '0',
  `place` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `lastdate` (`lastdate`),
  KEY `place` (`place`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_sessions`
-- 

INSERT INTO `cms_sessions` VALUES ('f5d942a4bcc4df7a133406c03e397c2e','1123633944','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1390466826','1390466826','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('5de855819bc0bb9b7dd40c99114a5ba0','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.926; U; en) Presto/2.8.119 Version/11.10','1390467288','1390467187','0','3','friendssite');
INSERT INTO `cms_sessions` VALUES ('86290da688d88a80e958abe925c5ed08','1123633574','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1390479045','1390479045','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('6d77ea60a4b5e9ed172af2117ac62aad','531276770','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.926; U; en) Presto/2.8.119 Version/11.10','1390480379','1390480223','0','0','forum,5');
INSERT INTO `cms_sessions` VALUES ('8ce7ae1fd9ac22c4153bb4fc8a70c0df','531276770','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1390482495','1390482495','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('aa2e399edcfffdf6414e3aeb8a5f355b','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.1000; U; en) Presto/2.8.119 Version/11.10','1390483714','1390483666','0','1','');
INSERT INTO `cms_sessions` VALUES ('36521a59a2fd66e02081ae39f6b20d1b','531276770','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.1000; U; en) Presto/2.8.119 Version/11.10','1390484204','1390483918','0','0','forum,8');
INSERT INTO `cms_sessions` VALUES ('4f7ddb30eef3b196aed37efe17a31a55','1123633524','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1390484263','1390484263','0','0','mainpage');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_settings`
-- 

CREATE TABLE `cms_settings` (
  `key` tinytext NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`key`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_settings`
-- 

INSERT INTO `cms_settings` VALUES ('active','0');
INSERT INTO `cms_settings` VALUES ('admp','panel');
INSERT INTO `cms_settings` VALUES ('antiflood','a:5:{s:4:"mode";i:2;s:3:"day";i:10;s:5:"night";i:30;s:7:"dayfrom";i:10;s:5:"dayto";i:22;}');
INSERT INTO `cms_settings` VALUES ('clean_time','1390403480');
INSERT INTO `cms_settings` VALUES ('copyright','Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('email','admin@susukan.us');
INSERT INTO `cms_settings` VALUES ('flsz','10000');
INSERT INTO `cms_settings` VALUES ('gzip','1');
INSERT INTO `cms_settings` VALUES ('homeurl','http://blogs.indoboox.us');
INSERT INTO `cms_settings` VALUES ('karma','a:6:{s:12:"karma_points";i:5;s:10:"karma_time";i:86400;s:5:"forum";i:20;s:4:"time";i:0;s:2:"on";i:1;s:3:"adm";i:0;}');
INSERT INTO `cms_settings` VALUES ('lng','en');
INSERT INTO `cms_settings` VALUES ('mod_reg','2');
INSERT INTO `cms_settings` VALUES ('mod_forum','2');
INSERT INTO `cms_settings` VALUES ('mod_guest','1');
INSERT INTO `cms_settings` VALUES ('mod_lib','1');
INSERT INTO `cms_settings` VALUES ('mod_gal','1');
INSERT INTO `cms_settings` VALUES ('mod_down_comm','1');
INSERT INTO `cms_settings` VALUES ('mod_down','1');
INSERT INTO `cms_settings` VALUES ('mod_lib_comm','1');
INSERT INTO `cms_settings` VALUES ('mod_gal_comm','1');
INSERT INTO `cms_settings` VALUES ('meta_desc','Susukan wap forum, mod Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('meta_key','Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('news','a:8:{s:4:"view";i:1;s:4:"size";i:200;s:8:"quantity";i:5;s:4:"days";i:3;s:6:"breaks";i:1;s:7:"smileys";i:1;s:4:"tags";i:1;s:3:"kom";i:1;}');
INSERT INTO `cms_settings` VALUES ('reg_message','Selamat Datang di [green](WWW.Susukan.Us)[/green] !!Selamat bergabung bersama kami, jangan lupa untuk mengisi data lengkap diri anda di [b][blue]Profile[/blue][/b] dan jangan segan-segan untuk ikut serta (dalam forum, shout dan lainnya) bersama member [b][green]Susukan.Us[/green][/b] yang lain. Jangan sungkan-sungkan share ataupun sekedar bersalam sapa antar sesama member [b][green]Susukan.Us[/green][/b] demi mempererat tali persaudaraan dengan kami disini.\r\n[size=xx-large][red]Peraturan Umum[/red][/size]\r\n#1. - Member yang tidak melakukan aktifititas apapun selama 1 bulan setelah pendaftaran maka dengan sangat terpaksa kami akan menghapus akun dari situs\r\n#2. - Member yang membuat kekacauan yang menimbulkan keributan antar member di Forum, Shoutbox, Chat, Blog dll akan kami beri sangsi hukuman\r\n#3. - Jika sangsi yang kami berikan masih tetap di hiraukan maka kami tidak akan segan-segan menghapus data akun dari situs\r\n#4. - Member dilarang Post di Forum berupa:\r\n- Posting OOT, Junk, Sara, SPAM, dll yang tidak tepat dari topik situs\r\n- Posting yang melecehkan member lain\r\n- Posting yang berbau pornografi yg disengaja (Sensor / Fulgar)\r\n[red]NB: Jika masih di hiraukan akan kami beri sangsi tegas berupa hukuman banned dengan waktu yg lama atau penghapusan akun[/red]\r\nHarap agar dibaca dengan teliti semua informasi diatas demi terjalinnya hubungan yg akur, rukun, nyaman dan tentram antar sesama member !!\r\nHormat Kami:\r\n[b][blue]Staff Susukan.us[/blue][/b]');
INSERT INTO `cms_settings` VALUES ('setting_mail','a:2:{s:11:"cat_friends";i:1;s:15:"message_include";i:1;}');
INSERT INTO `cms_settings` VALUES ('skindef','default');
INSERT INTO `cms_settings` VALUES ('them_message','Welcome!');
INSERT INTO `cms_settings` VALUES ('timeshift','7');
INSERT INTO `cms_settings` VALUES ('site_access','2');
INSERT INTO `cms_settings` VALUES ('lng_list','a:1:{s:2:"en";s:7:"English";}');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_data`
-- 

CREATE TABLE `cms_users_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `key` varchar(30) NOT NULL DEFAULT '',
  `val` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_guestbook`
-- 

CREATE TABLE `cms_users_guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  `attributes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_iphistory`
-- 

CREATE TABLE `cms_users_iphistory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cons`
-- 

CREATE TABLE `cons` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `number` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  `up` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cons`
-- 

INSERT INTO `cons` VALUES ('1','2','tulung tulung','tulung tulung mbaeh ki njajal','1387032592','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `cons_komm`
-- 

CREATE TABLE `cons_komm` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  `author` int(8) NOT NULL,
  `folder` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cons_komm`
-- 

INSERT INTO `cons_komm` VALUES ('1','tulung pentung hahaha','1387032617','4','1');

-- --------------------------------------------------------
-- 
-- Table structure for table `counter_ip_base`
-- 

CREATE TABLE `counter_ip_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` bigint(11) NOT NULL,
  `stop` bigint(11) NOT NULL,
  `operator` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------
-- 
-- Table structure for table `countersall`
-- 

CREATE TABLE `countersall` (
  `date` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `host` int(11) NOT NULL,
  `yandex` int(11) NOT NULL,
  `rambler` int(11) NOT NULL,
  `google` int(11) NOT NULL,
  `mail` int(11) NOT NULL,
  `gogo` int(11) NOT NULL,
  `yahoo` int(11) NOT NULL,
  `bing` int(11) NOT NULL,
  `nigma` int(11) NOT NULL,
  `qip` int(11) NOT NULL,
  `aport` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `countersall`
-- 

INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `download`
-- 

CREATE TABLE `download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `adres` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `ip` text NOT NULL,
  `soft` text NOT NULL,
  `text` text NOT NULL,
  `screen` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `refid` (`refid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `forum`
-- 

CREATE TABLE `forum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `type` char(1) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `from` varchar(25) NOT NULL DEFAULT '',
  `realid` int(3) NOT NULL DEFAULT '0',
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `soft` text NOT NULL,
  `text` text NOT NULL,
  `close` tinyint(1) NOT NULL DEFAULT '0',
  `close_who` varchar(25) NOT NULL,
  `vip` tinyint(1) NOT NULL DEFAULT '0',
  `edit` text NOT NULL,
  `tedit` int(11) NOT NULL DEFAULT '0',
  `kedit` int(2) NOT NULL DEFAULT '0',
  `curators` text NOT NULL,
  `min_post` int(11) NOT NULL DEFAULT '0',
  `tiento` varchar(50) NOT NULL,
  `minim` tinyint(1) NOT NULL,
  `kiemduyet_who` varchar(40) NOT NULL,
  `closed_who` varchar(40) NOT NULL,
  `kiemduyet` int(1) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refid` (`refid`),
  KEY `type` (`type`),
  KEY `time` (`time`),
  KEY `close` (`close`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `forum`
-- 

INSERT INTO `forum` VALUES ('1','0','f','0','0','','1','0','0','','Script update - [ID]','0','','0','0','0','0','','0','','0','','','0','');
INSERT INTO `forum` VALUES ('2','1','r','0','0','','1','0','0','','JohnCMS - [ID]','0','','0','0','0','0','','0','','0','','','0','');
INSERT INTO `forum` VALUES ('8','2','t','1390483951','1','Chodot','0','0','0','','JohnCMS 5.1.0 Mod Shoutbox','0','','0','','0','0','','0','5','0','','','0','Johncms,Shoutbox,Susukan');
INSERT INTO `forum` VALUES ('9','8','m','1390483797','1','Chodot','0','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.926; U; en) Presto/2.8.119 Version/11.10','[b]JohnCMS v5.1.0 Full Mod[/b] [url=http://susukan.us] Susukan.Us [/url]\r\n\r\n[b]Fitur-fitur mod:[/b]\r\n- My blogs\r\n- Mod rewrite Url fix\r\n- Mod rewrite profile fix\r\n- Mod shoutbox untuk tamu buat posting tanpa harus login\r\n- Mod wall\r\n- Mod chat\r\n- Mod subforum index\r\n- Mod bot panel\r\n- Mod guestbook chat\r\n- Mod forum thanks\r\n- Mod jurnal forum\r\n- Import file forum\r\n- Extra attach forum\r\n- Stats google\r\n- Robots editor\r\n- Add bookmark forum\r\n- TOS dan FAQ\r\n- Tags forum\r\n- Facebook dan twitter link di profile\r\n- Friendssite\r\n- Mod apply staf\r\n- dan masih banyak lagi :cape\r\n\r\n[b]Cara installasi:[/b]\r\n- Extrack file di root atau public_html\r\n- Lalu chmod file-file yang di haruskan untuk di chmod. Agar chmodnya lebih mudah sudah tersedia auto chmod, caranya klik [red]http://situsmu.com/chmod.php[/red] lalu lanjutkan "Go to installation step"\r\n- Langkah terakhir isi kolom-kolom seperti, host, database, user, dan password sesuai hostingmu.\r\n- Jika sudah terinstall klik [red]http://situsmu/chmod2.php[/red] untuk menonaktifkan folder [b]INSTALL[/b]dan merubah chmod file "db.php" ke 644\r\n- Selesai..\r\n\r\nUntuk downloadnya silahkan [big][b][green][url=http://www.chapink.com]Masuk Sini[/url][/green][/b][/big] atau download file dibawah ini :','0','','0','','0','0','','0','','0','','','0','Johncms,Shoutbox,Susukan');
INSERT INTO `forum` VALUES ('11','8','m','1390483951','2','Bot','0','2344760023','0','Opera/9.80','Lanjutkan wak broo :D','0','','0','Chodot','1390484031','1','','0','','0','','','0','');

-- --------------------------------------------------------
-- 
-- Table structure for table `forum_thank`
-- 

CREATE TABLE `forum_thank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `userthank` int(11) NOT NULL,
  `chude` int(11) NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `forum_thank`
-- 

INSERT INTO `forum_thank` VALUES ('1','2','11','1','8','');
INSERT INTO `forum_thank` VALUES ('2','1','9','2','8','');

-- --------------------------------------------------------
-- 
-- Table structure for table `friendssite`
-- 

CREATE TABLE `friendssite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` text NOT NULL,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `friendssite`
-- 

INSERT INTO `friendssite` VALUES ('1','http://www.susukan.us','Susukan.Us - [ID]','Susukan wap forum','1','15','1','1387678074');

-- --------------------------------------------------------
-- 
-- Table structure for table `gallery`
-- 

CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `type` varchar(2) NOT NULL DEFAULT '',
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `name` text NOT NULL,
  `user` binary(1) NOT NULL DEFAULT '\0',
  `ip` text NOT NULL,
  `soft` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refid` (`refid`),
  KEY `type` (`type`),
  KEY `time` (`time`),
  KEY `avtor` (`avtor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `guest`
-- 

CREATE TABLE `guest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adm` tinyint(1) NOT NULL DEFAULT '0',
  `time` int(15) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `browser` tinytext NOT NULL,
  `admin` varchar(25) NOT NULL DEFAULT '',
  `otvet` text NOT NULL,
  `otime` int(15) NOT NULL DEFAULT '0',
  `edit_who` varchar(20) NOT NULL DEFAULT '',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `edit_count` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `ip` (`ip`),
  KEY `adm` (`adm`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `guest`
-- 

INSERT INTO `guest` VALUES ('13','0','1390483706','2','Chodot','Hai @Bot Thank you for Registering at the Susukan.Us ID Community, please complited your profile :salaman','0','Susukan.Us','','','0','','0','0');
INSERT INTO `guest` VALUES ('14','0','1390483797','2','Satpam','Chodot newly posted topic http://blogs.indoboox.us/forum/index.php?id=8] if you want to see [you] :ngacir','0','Auto Bot','','','0','','0','0');
INSERT INTO `guest` VALUES ('15','0','1390484158','2','Satpam','@Bot comment on blog: Lanjutkan mbuahahahaha :D','1778585865','Susukan.Us','','','0','','0','0');
INSERT INTO `guest` VALUES ('16','0','1390484235','2','Satpam','@Chodot comment on blog: Yang penting mau mumet itu sudah afdol :D','1778585865','Susukan.Us','','','0','','0','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `karma_users`
-- 

CREATE TABLE `karma_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `karma_user` int(11) NOT NULL,
  `points` int(2) NOT NULL,
  `type` int(1) NOT NULL,
  `time` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `karma_user` (`karma_user`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `lib`
-- 

CREATE TABLE `lib` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `type` varchar(4) NOT NULL DEFAULT '',
  `name` tinytext NOT NULL,
  `announce` text NOT NULL,
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `text` mediumtext NOT NULL,
  `ip` int(11) NOT NULL DEFAULT '0',
  `soft` text NOT NULL,
  `moder` tinyint(1) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `moder` (`moder`),
  KEY `time` (`time`),
  KEY `refid` (`refid`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `look`
-- 

CREATE TABLE `look` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user` int(20) NOT NULL,
  `place_id` int(20) NOT NULL,
  `type` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `look`
-- 

INSERT INTO `look` VALUES ('1','0','7','b');
INSERT INTO `look` VALUES ('2','2','1','b');

-- --------------------------------------------------------
-- 
-- Table structure for table `news`
-- 

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL DEFAULT '0',
  `avt` varchar(25) NOT NULL DEFAULT '',
  `name` text NOT NULL,
  `text` text NOT NULL,
  `kom` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `privat`
-- 

CREATE TABLE `privat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `time` varchar(25) NOT NULL DEFAULT '',
  `author` varchar(25) NOT NULL DEFAULT '',
  `type` char(3) NOT NULL DEFAULT '',
  `chit` char(3) NOT NULL DEFAULT '',
  `temka` text NOT NULL,
  `otvet` binary(1) NOT NULL DEFAULT '\0',
  `me` varchar(25) NOT NULL DEFAULT '',
  `cont` varchar(25) NOT NULL DEFAULT '',
  `ignor` varchar(25) NOT NULL DEFAULT '',
  `attach` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `me` (`me`),
  KEY `ignor` (`ignor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `qchat`
-- 

CREATE TABLE `qchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `staff`
-- 

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` text NOT NULL,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `stat_robots`
-- 

CREATE TABLE `stat_robots` (
  `engine` text NOT NULL,
  `date` int(11) NOT NULL,
  `url` text NOT NULL,
  `query` text NOT NULL,
  `ua` text NOT NULL,
  `ip` bigint(11) NOT NULL,
  `count` int(11) NOT NULL,
  `today` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `name_lat` varchar(40) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `rights` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `failed_login` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `imname` varchar(50) NOT NULL,
  `sex` varchar(2) NOT NULL DEFAULT '',
  `komm` int(10) NOT NULL DEFAULT '0',
  `postforum` int(10) NOT NULL DEFAULT '0',
  `postguest` int(11) NOT NULL DEFAULT '0',
  `yearofbirth` int(4) NOT NULL DEFAULT '0',
  `datereg` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(11) NOT NULL DEFAULT '0',
  `mail` varchar(50) NOT NULL DEFAULT '',
  `icq` int(9) NOT NULL DEFAULT '0',
  `skype` varchar(50) NOT NULL,
  `jabber` varchar(50) NOT NULL,
  `www` varchar(50) NOT NULL DEFAULT '',
  `about` text NOT NULL,
  `live` varchar(100) NOT NULL,
  `mibile` varchar(50) NOT NULL DEFAULT '',
  `status` varchar(100) NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `browser` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `preg` tinyint(1) NOT NULL DEFAULT '0',
  `regadm` varchar(25) NOT NULL DEFAULT '',
  `mailvis` tinyint(1) NOT NULL DEFAULT '0',
  `dayb` int(2) NOT NULL DEFAULT '0',
  `monthb` int(2) NOT NULL DEFAULT '0',
  `sestime` int(10) unsigned NOT NULL DEFAULT '0',
  `total_on_site` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL,
  `rest_code` varchar(32) NOT NULL,
  `rest_time` int(11) NOT NULL,
  `movings` int(11) NOT NULL DEFAULT '0',
  `place` varchar(30) NOT NULL,
  `set_user` text NOT NULL,
  `set_forum` text NOT NULL,
  `karma_plus` int(11) NOT NULL DEFAULT '0',
  `karma_minus` int(11) NOT NULL DEFAULT '0',
  `karma_time` int(11) NOT NULL DEFAULT '0',
  `karma_off` tinyint(1) unsigned NOT NULL,
  `comm_count` int(10) unsigned NOT NULL,
  `comm_old` int(10) unsigned NOT NULL DEFAULT '0',
  `smileys` text NOT NULL,
  `podpis` varchar(100) NOT NULL,
  `pangkat` text NOT NULL,
  `journal_forum` int(11) NOT NULL DEFAULT '0',
  `twitter` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `set_mail` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name_lat` (`name_lat`),
  KEY `lastdate` (`lastdate`),
  KEY `place` (`place`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
