<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);
$day = date("d");
$month = date("m");
$year = date("y");
$h=date("H");
if (preg_match("|http://|",$msg) ||preg_match("|Http://|",$msg) || preg_match("|Http://www.|",$msg) ||preg_match("|http://www.|",$msg) || preg_match("|www.|",$msg) || preg_match("|I in You|",$msg) || preg_match("|invite anyone to visit|",$msg)) {
$botvip = array			(
1  => "Wap advertising ban all forms!!",
2  => "$login try again to see what. :ha:",
3  => "$login want the island to ROBINSON k? :ban:",
4  => "Got the wonderful Bot on wap firewood!",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|đi cf|",$msg) ||preg_match("|đi cafe|",$msg) || preg_match("|di cafe|",$msg) ||preg_match("|cafe di|",$msg) || preg_match("|CAFE đi|",$msg) || preg_match("|cafe không bot|",$msg) || preg_match("|cafe nào|",$msg)) {
$botvip = array			(
1  => "$login can not but invite!Boy's favorite cafe girls hug it: haha:",
2  => "$login rounded up to the :ban:",
3  => "Go, go 1 Bot not going anywhere",
4  => "Cafe embrace not brothers!",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|territory|",$msg) ||preg_match("|more|",$msg) || preg_match("|more|",$msg) ||preg_match("|more|",$msg) || preg_match("|bit|",$msg) || preg_match("|bik|",$msg) || preg_match("|Bik|",$msg)) {
$botvip = array			(
1  => "Bot know only!",
2  => "ROBOT know bot call away here tomorrow for new installation",
3  => "BOT shall be asked whether he spoke.",

);
srand ((double) microtime() * 100000);
$randnum = rand(1,3);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|help me|",$msg) ||preg_match("|heo|",$msg) || preg_match("|Help|",$msg) ||preg_match("|help|",$msg) || preg_match("|help with|",$msg) || preg_match("|help|",$msg) || preg_match("|HELP|",$msg)) {
$botvip = array			(
1  => "$login with bot help :haha:",
2  => "$login bot know but help! :chemgio:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,2);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|bot|",$msg) || preg_match("|Bot|",$msg) || preg_match("|BOt|",$msg) || preg_match("|BOT|",$msg) || preg_match("|b0t|",$msg)) {
$botvip = array			(
1  => "Here anyone named bot $login asked what this?",
2  => "You just called subscriber is currently flirting would you please call back later!",
3  => "$login called bot huh what not?",
4  => "BOT is flirting pm slightly.",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|time|",$msg) || preg_match("|TIME|",$msg) || preg_match("|Time|",$msg) || preg_match("|may gio|",$msg) || preg_match("|what time|",$msg) || preg_match("|now bot|",$msg)) {
$day = date("d");
$month = date("m");
$year = date("y");
$h=date("H");
$botvip = array			(
1  => "The time now is $h+7 hours on $day months $month year $year!",
2  => "Hours today with yesterday!",
3  => "$login this Bot can not speak!",
4  => "Go ask other people what time it is, the bot tell :ha:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|Admin|",$msg) || preg_match("|admin|",$msg) || preg_match("|ADMIN|",$msg) || preg_match("|SlVr|",$msg) || preg_match("|Hộ|",$msg) || preg_match("|dùm|",$msg) || preg_match("|Sadmin|",$msg)) {
$botvip = array			(
1  => "admin Busy flirting!",
2  => "admin This most handsome wap isnt it.",
3  => "$login What is the admin is busy learning",
4  => "Finnish back begging huh or what they own pm's!",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|good|",$msg) || preg_match("|Buồn|",$msg) || preg_match("|Good|",$msg) || preg_match("|gOOD|",$msg) || preg_match("|BUON|",$msg) || preg_match("|BOT Good too|",$msg) || preg_match("|GOOD|",$msg)) {
$botvip = array			(
1  => "$login sad game here to play with you for support",
2  => "Sad, sleep here do?",
3  => "$login What is the admin is busy learning",
4  => "So sad ah! Share bot home. :ha:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|test|",$msg) ||preg_match("|Test|",$msg) || preg_match("|TEST|",$msg) ||preg_match("|thu nghiem|",$msg) || preg_match("|test|",$msg) || preg_match("|TEst|",$msg) || preg_match("|TESt|",$msg)) {
$botvip = array			(
1  => "$login Oh successful it is!",
2  => "Oh Hello :haha:",
3  => "$login school burned",
4  => "Test something?!",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|bot mad|",$msg) ||preg_match("|bot dien|",$msg) || preg_match("|Bot điên|",$msg) ||preg_match("|Bot MaD|",$msg) || preg_match("|BOT MAd|",$msg) || preg_match("|BOT MAD|",$msg) || preg_match("|bOt Mad|",$msg)) {
$botvip = array			(
1  => " Insult someone says to watch no.hừm",
2  => "Verbally do like the street fight lun",
3  => "$login want to eat or blow",
4  => "Mad without culture, without education",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|Bot sleep|",$msg) || preg_match("|bot Sleep|",$msg) ||preg_match("|Bot SLeep|",$msg) || preg_match("|BOT SLEEP|",$msg) ||preg_match("|BOT ngu|",$msg) || preg_match("|BOT SLEEP|",$msg) || preg_match("|BOT sleep|",$msg) || preg_match("|bOt dan|",$msg)) {
$botvip = array			(
1  => "Insult someone says to watch sleep.hum",
2  => "Verbally do like the street fight lun",
3  => "$login Like and out Island",
4  => "More than one guy as $login is!",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|bot ngu qua|",$msg) ||preg_match("|thằng bot ngu|",$msg) || preg_match("|bot ngu vl|",$msg) ||preg_match("|bot khon vai|",$msg)) {
$botvip = array			(
1  => "BOT chỉ thế thôi $login khôn thì nói xem hum nay đề vào bao nhiu! :haha:",
2  => "$login mún ăn gạch không :bannhau:",
3  => "Hơn 1 số thằng như $login là được! ",
4  => "Ngu nhưng chém gió giỏi hơn $login đấy :chemgio:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,4);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|Im đi|",$msg) ||preg_match("|im đi|",$msg) || preg_match("|BOT IM ĐI|",$msg) ||preg_match("|bot im đi|",$msg)) {
$botvip = array			(
1  => "BOT chỉ thế thôi $login đi chỗ khác mà chơi :bunngu:",
2  => "$login mún ăn gạch không :bannhau:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,2);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|XIN|",$msg) ||preg_match("|Xin|",$msg) || preg_match("|SHARE|",$msg) ||preg_match("|Share|",$msg)) {
$botvip = array			(
1  => "Throughout the day for sick people through!",
2  => "$login cần gì Bot cho :haha:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,2);
$bot =''. $botvip[$randnum].'';
}
if (preg_match("|share|",$msg) ||preg_match("|Share|",$msg)) {
$botvip = array			(
1  => "Share hả. share gì thế. Share cho tớ luôn!",
2  => "$login share kìa. Thank đi anh em :haha:",
);
srand ((double) microtime() * 100000);
$randnum = rand(1,2);
$bot =''. $botvip[$randnum].'';
}
?>
