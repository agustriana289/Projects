<?php
define('_IN_JOHNCMS', 1);
$time = time();
if(preg_match('|Quay|',$msg) ||preg_match('|quay|',$msg) ||preg_match('|QUAY|',$msg)) {
if($datauser['balans'] < 5000) {
$quay = '[b]'.$login.'[/b] ko đủ tiền để quay đâu nhé!';
} else {
$rand = rand(1000, 9999);
$card = rand(1111111111111, 9999999999999);
$quay = 'ÉO [b]'.$login.'[/b] quay được số '.$rand.' chúc may mắn lần sau! BOT đã lấy của [b]'.$login.'[/b] 5.000xu làm chi phí duy trì dịch vụ nhé. Hôhô';
mysql_query("UPDATE users SET balans=balans+5000 WHERE id=1584 LIMIT 1");
mysql_query("UPDATE users SET balans=balans-5000 WHERE id='$user_id' LIMIT 1");
if(preg_match('|9999|',$rand)) {
$quay = '[b]'.$login.'[/b] quay đc số '.$rand.'! Xin chúc mừng đã quay đc giải biệt của chương trình quay số may mắn! Mở hộp thư nhận thưởng nhé!';
$msg = 'Xin chúc mừng bạn đã quay đc giải biệt của chương trình quay số may mắn! Giải thưởng 500.000xu cùng 5000% năng lượng! Xin chân thành cảm ơn bạn đã ủng hộ wap!';
mysql_query("UPDATE users SET balans=balans+505000 WHERE id='$user_id' LIMIT 1");;

mysql_query("UPDATE users SET power=power+5000 WHERE id='$user_id' LIMIT 1");
mysql_query("insert into `privat` values(0,'" . $login . "','".$msg."','" . $realtime . "','BOT','in','no','Giải thưởng quay số','0','','','',0);");
$sent = '[b]'.$login.'[/b] đã trúng 500.000xu do tham gia chương trình quay số may mắn vào ngày '.date('d/m', time()).'! BOT đã thanh toán!';
$time = time();
mysql_query("INSERT INTO `forum` SET
`refid`='1584',
`type` = 'm',
`time` = '$realtime',
`user_id` = '2',
`from` = 'BOT [Quay Số]',
`ip` = '0.0.0.0',
`soft` = 'iphone 4Gs',
`text` = '" . mysql_real_escape_string($sent) . "'") or die('BOT ko thể xử lý');
// Обновляем время топика
mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '1584' LIMIT 1") or die('Không thể cập nhật');
// Обновляем статистику юзера
mysql_query("UPDATE `users` SET
`postforum`=`postforum`+1,
`balans`=`balans`+100,
`lastpost` = '$time'
WHERE `id` = '1584'
");
} else {
if(preg_match('|999|',$rand)) {
$quay = 'zeze [b]'.$login.'[/b] đã quay đc số '.$rand.'! Xin chúc mừng [b]'.$login.'[/b] đã quay đc giải nhất của chương trình quay số may mắn! Giải thưởng gồm 300.000xu và 3000% năng lượng. Cảm ơn!';
$sent = '[b]'.$login.'[/b] đã trúng 300.000xu do tham gia chương trình quay số may mắn vào ngày '.date('d/m', time()).'! BOT đã thanh toán!';
$time = time();
mysql_query("UPDATE users SET balans=balans+305000 WHERE id='$user_id' LIMIT 1");;
mysql_query("UPDATE users SET power=power+3000 WHERE id='$user_id' LIMIT 1");
mysql_query("UPDATE users SET postforum=postforum+1 WHERE id='$user_id' LIMIT 1");
mysql_query("INSERT INTO `forum` SET
`refid`='1584',
`type` = 'm',
`refid`='1584',
`type` = 'm',
`time` = '$realtime',
`user_id` = '2',
`from` = 'BOT [Quay Số]',
`ip` = '0.0.0.0',
`soft` = 'BOT [Quay Số] ',
`text` = '" . mysql_real_escape_string($sent) . "'") or die('BOT ko thể xử lý');
// Обновляем время топика
mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '1584' LIMIT 1") or die('Không thể cập nhật');
// Обновляем статистику юзера
mysql_query("UPDATE `users` SET
`postforum`=`postforum`+1,
`balans`=`balans`+100,
`lastpost` = '$time'
WHERE `id` = '1584'
");
} else {
if(preg_match('|99|',$rand)) {
$quay = 'ồ. [b]'.$login.'[/b] quay đc số '.$rand.'! Xin chúc mừng [b]'.$login.'[/b] đã quay đc giải nhì của chương trình quay số may mắn! Giải thưởng trị giá 100.000xu và 500% năng lượng. Cảm ơn bạn đã tham gia!';
$sent = '[b]'.$login.'[/b] đã trúng 100.000xu do tham gia chương trình quay số may mắn vào ngày '.date('d/m', time()).'! BOT đã thanh toán!';
$time = time();
mysql_query("UPDATE users SET balans=balans+105000 WHERE id='$user_id' LIMIT 1");
mysql_query("UPDATE users SET power=power+500 WHERE id='$user_id' LIMIT 1");
mysql_query("UPDATE users SET postforum=postforum+1 WHERE id='$user_id' LIMIT 1");
mysql_query("INSERT INTO `forum` SET
`refid`='1584',
`type` = 'm',
`time` = '$realtime',
`user_id` = '2',
`from` = 'BOT [Quay Số]',
`ip` = '0.0.0.0',
`soft` = 'iphone 4Gs',
`text` = '" . mysql_real_escape_string($sent) . "'") or die('BOT ko thể xử lý');
// Обновляем время топика
mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '1584' LIMIT 1") or die('Không thể cập nhật');
// Обновляем статистику юзера
mysql_query("UPDATE `users` SET
`postforum`=`postforum`+1,
`balans`=`balans`+100,
`lastpost` = '$time'
WHERE `id` = '1584'
");
} else {
if(preg_match('|00|',$rand) ||preg_match('|11|',$rand) ||preg_match('|22|',$rand) ||preg_match('|33|',$rand) ||preg_match('|44|',$rand) ||preg_match('|55|',$rand) ||preg_match('|66|',$rand) ||preg_match('|77|',$rand) ||preg_match('|25|',$rand) ||preg_match('|88|',$rand)) {
$quay = 'à zí ạ zị. [b]'.$login.'[/b] quay đc số '.$rand.'! Xin chúc mừng [b]'.$login.'[/b] đã quay đc giải ba của chương trình quay số may mắn! BOT đã send 50.000xu và 100% năng lượng rồi đấy!';
mysql_query("UPDATE users SET balans=balans+55000
WHERE id='$user_id' LIMIT 1");
mysql_query("UPDATE users SET power=power+100 WHERE id='$user_id' LIMIT 1");
mysql_query("UPDATE users SET postforum=postforum+1 WHERE id='$user_id' LIMIT 1");
$sent = '[b]'.$login.'[/b] đã trúng 50.000xu do tham gia chương trình quay số may mắn vào ngày '.date('d/m', time()).'! BOT đã thanh toán!';
$time = time();
mysql_query("INSERT INTO `forum` SET
`refid`='1584',
`type` = 'm',
`time` = '$realtime',
`user_id` = '2',
`from` = 'BOT [Quay Số]',
`ip` = '0.0.0.0',
`soft` = 'iphone 4Gs',
`text` = '" . mysql_real_escape_string($sent) . "'") or die('BOT ko thể xử lý');
// Обновляем время топика
mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '1584' LIMIT 1") or die('Không thể cập nhật');
// Обновляем статистику юзера
mysql_query("UPDATE `users` SET
`postforum`=`postforum`+1,
`balans`=`balans`+100,
`lastpost` = '$time'
WHERE `id` = '1584'
");
}
}
}
}
}
}
if($quay) {
mysql_query("INSERT INTO `guest` SET
`adm` = '$admset',
`time` = '$time',
`user_id` = '2',
`name` = 'BOT [Quay Số]',
`text` = '" . mysql_real_escape_string($quay) . "',
`ip` = '60543201',
`browser` = 'iphone 4Gs'
");
}
?>
