<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Blogs';
require('../incfiles/head.php');
if (!$user_id) {
echo functions::display_error('&#1058;&#1086;&#1083;&#1100;&#1082;&#1086; &#1076;&#1083;&#1103; &#1072;&#1074;&#1090;&#1086;&#1088;&#1080;&#1079;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1099;&#1093;!');
require('../incfiles/end.php');
exit;
}
$sql = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE id='$id'"), 0);
if (!$sql && $id && $user_id) {
echo functions::display_error('&#1058;&#1072;&#1082;&#1086;&#1075;&#1086; &#1073;&#1083;&#1086;&#1075;&#1072; &#1085;&#1077; &#1089;&#1091;&#1097;&#1077;&#1089;&#1090;&#1074;&#1091;&#1077;&#1090;!');
require('../incfiles/end.php');
exit;
}
if (!$id && $user_id)
$id = $user_id;
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$id'"));
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter">'.$textl.' '.$user['name'].'</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs` WHERE user='$id' ".($user['id'] == $user_id || $rights > 6 ? "" : "AND close!=1 AND close!=3").""), 0);
if ($total > $kmess)
echo '<div class="topmenu">' . functions::display_pagination('user.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
if ($user['id'] == $user_id)
echo '<div class="gmenu"><a href="new.php">Create New Blog</a></div>';
if (!$total)
echo '<div class="rmenu">No blog</div>';
$req = mysql_query("SELECT * FROM `blogs` WHERE user='$id' ORDER BY `id` DESC LIMIT $start, $kmess");
while ($res = mysql_fetch_array($req)) {
$avtor = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$res[user]'"));
if (!$res['close'] == 1 || !$res['close'] == 3 || ($avtor['id'] == $user_id || $rights == 9)) {
if ($res['close'] == 1 || $res['close'] == 3)
echo '<div class="rmenu">';
else
echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
$text = $res['text'];
$text = mb_substr($text, 0, 100);
$text = functions::checkout($text, 0, 1);
echo '<a href="../users/profile.php?act=guestbook&amp;user='.$avtor['id'].'">'.functions::checkout($avtor['name']).'</a> ('.date("F h:ia", $res['time'] + $set_user['sdvig'] * 3600).')<br />';
if ($res['name'])
echo '<b>'.functions::checkout($res['name']).'</b><br />';
echo $text;
echo '&nbsp;<a href="view.php?id='.$res['id'].'">&gt;&gt;</a>';
echo '<br /><small>Hits: '.$res['count'].' '.($user['id'] == $user_id || $rights > 6 ? '[<a href="edit.php?id='.$res['id'].'">Edit</a> | <a href="edit.php?id='.$res['id'].'&amp;del">Delete</a>]' : '').'</small>';
++$i;
echo '</div>';
}
}

if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('user.php?id=' . $id . '&amp;', $start, $total, $kmess) . '<form action="user.php?id=' . $id . '" method="post"><input type="text" name="page" size="2"/><input type="submit" value="GO"/></form></div>';
}
echo '<div class="nfooter">Total: '.$total.'</div>';
echo '</div></div></div></div>';
require('../incfiles/end.php');
?>
