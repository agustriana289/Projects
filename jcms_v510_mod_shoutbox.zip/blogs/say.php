<?
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Blogs - Balas komentar';
require('../incfiles/head.php');
$empty = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs` WHERE id='$id'"), 0);
if (!$empty) {
echo functions::display_error('Ta�o� �a��c� �e cy�ec��ye�!');
echo '<div class="menu"><a href="index.php">Blogs</a></div>';
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array(mysql_query("SELECT * FROM `blogs` WHERE id='$id'"));
if ($rights <= 6 && ($user_id != $blog['user']) && $blog['close'] >= 1) {
echo functions::display_error('�a��c� �oc�y��a �o���o a��opy ��� a��op �a�pe��� �o��e��ap��!');
echo '<div class="menu"><a href="'.htmlspecialchars(getenv("HTTP_REFERER")).'">Back</a></div>';
require('../incfiles/end.php');
exit;
}
echo '<div class="phdr">Blogs - '.$blog['name'].'</div>';
if (isset($_POST['submit'])) {
if ((!$user_id || $blog['close'] == 2) && $rights < 8 && $blog['user'] != $user_id)
$error = 'Komentar ditutup!';
$flood = functions::antiflood();
if ($flood) {
echo functions::display_error('Silakan tunggu '.$flood.' lagi untuk memposting komentar <br />');
echo '<div class="menu"><a href="view.php?id='.$id.'">Back</a></div>';
require('../incfiles/end.php');
exit;
}
$datetime = time();
$text = mb_substr(trim($_POST['text']), 0, 5000);
$trans = isset($_POST['msgtrans']) ? 1 : 0;
if ($trans)
$text = functions::trans($text);
$error = array();
if (empty($text))
$error[] .= 'Anda belum menulis pesan!';
// �po�ep�e�, �e �o��op�e�c� �� coo��e��e?
$req = mysql_query("SELECT * FROM `blogs_komm` WHERE user='$user_id' ORDER BY `time` DESC");
if (mysql_num_rows($req)) {
$res = mysql_fetch_array($req);
if ($text == $res['text'])
$error[] .= 'Ta�oe coo��e��e y�e ���o!';
}
if ($error)
echo functions::display_error($error);
if (empty($error)) {
mysql_query("INSERT INTO `blogs_komm` SET user='$user_id', refid='$id', text='".($do ? "[b]".$do."[/b], " : "")."$text', time='$datetime'");
$kol = 1;
mysql_query("UPDATE `users` SET komm=komm+".$kol." WHERE id='$user_id'");
mysql_query("UPDATE `users` SET
`lastpost` = 'datetime'
WHERE `id` = '$user_id'
");

      mysql_query("INSERT INTO `guest` SET
`adm` = '0',
`time` = '" . time() . "',
`user_id` = '2',
`name` = 'Satpam',
`text` = '@$login comment on blog: $text',
`ip` = '01778585865',
`browser` = 'Susukan.Us'
");
$page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE `refid` = '$id'"), 0) / $kmess);
header('Location: view.php?id='.$id.'&page='.$page.'');
}
}
if (($user_id && !$blog['close']) || ($blog['user'] == $user_id || $rights > 6)) {
echo '<form method="POST" name="form1"><div class="gmenu">Comments:<br /><textarea cols="'.$set_user['field_w'].'" rows="'.$set_user['field_h'].'" name="text"></textarea><br />';
if ($set_user['translit'])
echo '<input type="checkbox" name="msgtrans" value="1" />&nbsp;' . $lng['translit'] . '<br/>';
echo '<input type="submit" name="submit" value="Kirim"/></div></form>';
echo '<div class="menu"><a href="view.php?id='.$blog['id'].'">Back</a> | <a href="index.php">Ke Blogs</a></div>';
require('../incfiles/end.php');
}
?>