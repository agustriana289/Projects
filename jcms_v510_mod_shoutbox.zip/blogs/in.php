<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');

echo '<div class="phdr">Last Blog</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs`"), 0);
if ($total == 0)
echo '<div class="rmenu">No blogs!</div>';
$res = mysql_query("SELECT * FROM `blogs` ORDER BY id DESC LIMIT $start, $kmess");
while($req = mysql_fetch_array($res)) {
echo $i % 2 ? '<div class="currentpage">' : '<div class="clip">';
$totkom = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE `refid` = '$req[id]'"), 0);
$totlook = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE place_id='$req[id]' AND type='b'"), 0);

$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$req[user]'"));
$set_user['avatar'] = 0;
echo '<img src="../images/pt.gif" alt=""/>&#160;<a href="view.php?id='.$req['id'].'">'.$req['name'].'</a><br/><small>Posted by</small> <a href="../users/profile.php?act=guestbook&amp;user=' . $user['id'] . '">' . $user['name'] . '</a><div class="gray">Date:<small>'.date("d.m.Y / H:i", $req['time'] + $set_user['sdvig'] * 3600).'</small></div>Comments: ' . $totkom . '<br/>';
++$i;
echo '</div>';
}

?>
