<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Popular Blogs';
require('../incfiles/head.php');
echo '<div class="phdr">'.$textl.'</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs` WHERE count>='1'"), 0);
echo '<div class="menu"><a href="user.php">My Blog</a><br /><a href="index.php">Latest</a> | Popular</div>';
if ($total == 0)
echo '<div class="rmenu">Blog List is empty!</div>';
$res = mysql_query("SELECT * FROM `blogs` WHERE count>='1' ORDER BY count DESC LIMIT $start, $kmess");
while($req = mysql_fetch_array($res)) {
echo $i % 2 ? '<div class="currentpage">' : '<div class="clip">';
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$req[user]'"));
$set_user['avatar'] = 0;
$look = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE place_id='$req[id]' AND type='b'"), 0);
$body = '<a href="view.php?id='.$req['id'].'">'.$req['name'].'</a>';
$sub = 'Created: <font color="gray">(' . date("d.m.Y / H:i", $req['time'] + $set_user['sdvig'] * 3600) . ')</font> | Hits: '.$look.'';
$arg = array(
'iphide' => 1,
'stshide' => 1,
'body' => $body,
'sub' => $sub
);
echo functions::display_user($user, $arg);
++$i;
echo '</div>';
}
echo '<div class="phdr">Total: '.$total.'</div>';
if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div>' .
'<p><form action="index.php" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="GO!"/>' .
'</form></p>';
}
require('../incfiles/end.php');
?>
