<?php
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');

$empty = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs` WHERE id='$id'"), 0);
if (!$empty) {require('../incfiles/head.php');
echo functions::display_error('This record does not exist!');
echo '<div class="menu"><a href="index.php">Blogs</a></div>';
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array(mysql_query("SELECT * FROM `blogs` WHERE id='$id'"));
if ($rights <= 6 && $user_id != $blog['user'] && ($blog['close'] == 1 || $blog['close'] == 3)) {
require('../incfiles/head.php');
echo functions::display_error('Recording is only available to the author!');
echo '<div class="menu"><a href="'.htmlspecialchars(getenv("HTTP_REFERER")).'">Back</a></div>';
require('../incfiles/end.php');
exit;
}
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='".$blog['user']."'"));
if (($blog['user'] != $user_id) && $user_id)
$look = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE user='$user_id' AND place_id='$blog[id]' AND type='b'"), 0);
$total_look = mysql_result(mysql_query("SELECT COUNT(*) FROM `look` WHERE place_id='$blog[id]' AND type='b'"), 0);
if ($look <= 0 && $blog['user'] != $user_id)
mysql_query("INSERT INTO `look` SET user='$user_id', place_id='$blog[id]', type='b'");
$textl = 'Blog - '.$blog['name'].'';
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="index.php">Blogs</a> - '.($blog['name'] ? functions::checkout($blog['name']) : 'Untitled').'</div>';
mysql_query("UPDATE `blogs` SET count='$total_look' WHERE id='$id'");
$head = '<span class="gray">(' . date("F h:ia", $blog['time'] + $set_user['sdvig'] * 3600) . ')</span>';$body = $blog['text'];
$body = functions::checkout($body, 1, 1);
if ($set_user['smileys'])
$body = functions::smileys($body, $user['rights'] ? 1 : 0);
if ($blog['user'] == $user_id || $rights >= 7)
$body .= '<br />[<a href="edit.php?id='.$blog['id'].'">Edit</a> | <a href="edit.php?id='.$blog['id'].'&amp;del">Delete</a>]';
$format_file = functions::format($blog['file']);
switch ($format_file) {
case 'png':
$file = '<a href="files/'.$blog['file'].'"><img src="files/'.$blog['file'].'" width="60" height="60" /></a>';
break;
case 'gif':
$file = '<a href="files/'.$blog['file'].'"><img src="files/'.$blog['file'].'" width="60" height="60" /></a>';
break;
case 'jpeg':
$file = '<a href="files/'.$blog['file'].'"><img src="files/'.$blog['file'].'" width="60" height="60" /></a>';
break;
case 'jpg':
$file = '<a href="files/'.$blog['file'].'"><img src="files/'.$blog['file'].'" width="60" height="60" /></a>';
break;
$file = '<a href="files/'.$blog['file'].'">'.$blog['file'].'</a>';
}
if ($file)
$sub1 = 'The attached file:<br />'.$file.'';
$arg = array (
'iphide' => 1,
'header' => $head,
'body' => $body,
'sub' => $sub1
);
echo '<div class="list2">';
echo functions::display_user($user, $arg);
echo '</div>';
echo '<div class="nfooter">';
$total_komm = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE refid='$id'"), 0);
echo 'Comments: '.$total_komm.' | Hits: '.$total_look.'';
echo '</div></div></div>';
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Comments</b></div>';
$req = mysql_query("SELECT * FROM `blogs_komm` WHERE refid='$id' ORDER BY `time` ASC LIMIT $start, $kmess");
while ($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE id='$res[user]'"));
$text = functions::checkout($res['text'], 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $user['rights'] >= 1 ? 1 : 0);
$arg = array(
'iphide' => 1,
'sub' => $sub,
'body' => $text,
'header' => '<span class="gray">(' . date("F h:ia", $res['time'] + $set_user['sdvig'] * 3600) . ')</span><br/>'
);
echo functions::display_user($user, $arg);
if ($user_id)
{
echo '<div class="sub">';
echo '<a href="say.php?id='.$blog['id'].'&amp;do='.$user['name'].'">Bullets</a>';
if ($rights > 6 || ($user['id'] == $user_id && $res['time'] > $realtime - 300))
echo ' | <a href="edit_post.php?id='.$res['id'].'">Edit</a>';
if ($rights > 6 || $blog['user'] == $user_id || ($user['id'] == $user_id && $res['time'] > $realtime - 300))
echo ' | <a href="edit_post.php?id='.$res['id'].'&amp;del">Delete</a>';
echo '</div>';
}
echo '</div>';
++$i;
}
if ($blog['close'] >= 2 && $user_id)
echo '<div class="rmenu">Comments are closed!</div>';
if (($user_id && !$blog['close']) || ($blog['user'] == $user_id || $rights > 6)) {
echo '<form action="say.php?id='.$id.'" name="form1" method="POST"><div class="currentpage">Comments:<br /><textarea cols="'.$set_user['field_w'].'" rows="'.$set_user['field_h'].'" name="text"></textarea><br />';
if ($set_user['translit'])
echo '<input type="checkbox" name="msgtrans" value="1" />&nbsp;' . $lng['translit'] . '<br/>';
echo '<input type="submit" name="submit" value="Post"/></div></form>';
}
else
{
echo '<div class="rmenu">To post comments please <a href="http://' . $_SERVER['HTTP_HOST'] . '/login.php">Login</a> or <a href="http://' . $_SERVER['HTTP_HOST'] . '/registration.php">Register</a> First</div>';
}
if ($total_komm > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('show.php?id='.$id.'&amp;', $start, $total_komm, $kmess) . '<form action="show.php?id='.$id.'" method="post"><input type="text" name="page" size="2"/><input type="submit" value="GO"/></form></div>';
}
echo '</div></div></div>';
echo '<div class="mainbox"><div class="nfooter">';
if ($user_id)
{
echo '<a href="user.php?id='.$blog['user'].'">My Blog</a> | ';
}
echo '<a href="index.php">Blogs</a></div></div>';
require('../incfiles/end.php');
?>
