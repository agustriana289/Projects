<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Blogs - Create New Blog';
require('../incfiles/head.php');
if (!$user_id) {
echo functions::display_error('Only to member sites!');
require('../incfiles/end.php');
exit;
}
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter">'.$textl.'</div>';
if (isset($_POST['submit'])) {
if (!$user_id) {
echo functions::display_error('Only to member sites!');
require('../incfiles/end.php');
exit;
}
$flood = functions::antiflood();
if ($flood) {
echo functions::display_error('Please wait '.$flood.' seconds. <a href="user.php">Back</a>');
require('../incfiles/end.php');
exit;
}
$datetime = time();
$name = isset($_POST['name_blog']) ? trim($_POST['name_blog']) : '';
$text = isset($_POST['text_blog']) ? trim($_POST['text_blog']) : '';
$close = isset($_POST['close']) ? trim($_POST['close']) : '';
if (empty($text) || empty($name))
$error .= 'You have not inserted the title or text';
if (mb_strlen($name) >= 101)
$error .= '' . (empty($text) || empty($name) >= 101 ? '<br/>' : '') . 'The name of the blog should not be greater than 100 characters'.mb_strlen($name).'!';
if (mb_strlen($text) >= 100001)
$error .= '' . (mb_strlen($name) >= 100000 ? '<br/>' : '') . 'The text of the blog should not be more than 100000 characters '.mb_strlen($text).'!';
echo '<div class="rmenu">'.$error.'</div>';
if (empty($error)) {
mysql_query("UPDATE `users` SET
`lastpost` = '$datetime'
WHERE `id` = '$user_id'
");
mysql_query("INSERT INTO `blogs` SET user='$user_id', name='$name', text='" . mysql_real_escape_string($text) . "', time='$datetime', close='$close'");
mysql_query("INSERT INTO `guest` SET
`adm` = '0',
`time` = '" . time() . "',
`user_id` = '2',
`name` = 'Satpam',
`text` = '@$login just created a new blog: $text',
`ip` = '01737235248',
`browser` = 'Susukan.Us'
");
$res = mysql_fetch_array(mysql_query("SELECT * FROM `blogs` WHERE user='$user_id' ORDER BY `time` DESC LIMIT 1;"));
echo '<div class="currentpage">Blog is established!<br/>ID: <b>' . $res['id'] . '</b><br/>Blog Title: <b>' . functions::checkout($res['name']) . '</b><br/><br/><a href="view.php?id=' . $res['id'] . '">View Blog</a><br/><a href="user.php">My Blog</a></div>';
require('../incfiles/end.php');
exit;
}
}
$flood = functions::antiflood();
if ($flood) {
echo functions::display_error('Error, Please wait '.$flood.' seconds to make a new blog.<br /><a href="user.php">Back</a>');
require('../incfiles/end.php');
exit;
}
echo '<form action="new.php" name="form1" method="POST"><div class="currentpage"><h3>Blog Title:</h3><input name="name_blog" ' . (mb_strlen($name) >= 101 ? '' : 'value="'.$name.'"') . ' /><br /><br /><h3>Blog Text:</h3><textarea cols="'.$set_user['field_w'].'" rows="'.$set_user['field_h'].'" name="text_blog">' . (mb_strlen($text) >= 100001 ? '' : $text) . '</textarea><br /><input type="checkbox" name="close" value="1" /> Disable comments<br /><input type="submit" name="submit" value="Create Blog"/></div></form>';
echo '<div class="nfooter"><a href="user.php">Back</a></div></div></div>';
require('../incfiles/end.php');
?>
