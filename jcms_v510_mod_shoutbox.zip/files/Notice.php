<?php
echo '<div class="mainbox"><div class="mainblok">';
if ($rights == 9) {
echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">
<font size=2><b>Users Notice</b></font></td><td width="auto" align="right"><a href="/panel/realdon.php?act=edit&file=Notice&type=php"><img src="./images/add.jpg" alt="Edit Notice" width="12" height="12"/></a></td></tr></table></div>';
} else {
echo '<div class="nfooter"><b>Notice</b></div>'; }


echo '<div class="list1"><center>Dear ' . ($user_id ? '<b>' . $login . '</b>' : $lng['guest'] . '!') . ' We Are Updating Our Site. After Updating We Will Take A TLD Domain .So Enjoy Your Programming With Us</center></div></div></div>';
?>