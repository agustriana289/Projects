<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/
define('_IN_JOHNCMS', 1);
$rootpath = '';
$textl = "MOD Gửi tin nhắn";
$realtime = time();
require_once ("incfiles/core.php");
require_once ("incfiles/head.php");
if (!$user_id && $rights < 9) {
echo '<div class="phdr" style="font-weight:bold;">Thất bại!</div>';
echo 'Truy cập vào trang này được giới hạn trong phần Quản trị!';
require_once ("incfiles/end.php");
exit;
}
switch($_GET['act']) {
default:
echo '<div class="phdr" style="font-weight:bold;">Gửi tin nhắn</div>' . "\n";
echo '<div class="list1"><p><form action="sendsms.php?act=start" method="POST"><br />';
echo '<b>Gửi thư cho:</b><br />';
echo '<select name="sel"><option value="all">Tất cả</option><option value="admin">Admin</option><option value="smdadm">Sadmin trở lên</option><option value="adm">Mod</option><option value="m">Tất cả TV Nam</option><option value="zh">Tất cả TV Nữ</option></select><br />' . "\n";
echo '<br /><b>Nội dung: </b><br />';
echo '<textarea name="message" rows="5"></textarea><br />';
echo '<p>[<a href="' .$home. '/pages/faq.php?act=smileys">Smiles</a>] [<a href="' .$home. '/pages/faq.php?act=forumfaq">FAQ</a>]</p>';
echo '<input type="submit" value="Gửi!" />' . "\n";
echo '</form></p></div>';
break;
case 'start':
if (empty($_POST['message'])) {
echo '<b>Lỗi!</b>Bạn chưa nhập nội dung cần gửi!<br />&raquo; <a href="sendsms.php">Quay lại</a>';
require_once ("incfiles/end.php");
exit;
}
echo '<div class="phdr" style="font-weight:bold;">Kết quả danh sách</div>' . "\n";
echo '<div class="b">';
$soob = functions::check(trim($_POST['message']));

//Tin nhắn đến thành viên
if ($_POST['sel'] == 'all') {
$colus = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`;"), 0);
$asp = mysql_query("SELECT `name` FROM `users` ORDER BY `id` DESC LIMIT $colus;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; }
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT ','0','','','','');");
$wx++;
}
echo '<b>Gửi thông báo thành công rồi!</b><br />
Gửi<b>' .$wx. '</b> Thông báo Tất cả người dùng!';
$type_r = 1;
}

//Phần quản trị admin

elseif ($_POST['sel'] == 'adm') {
$colad = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights`>= 1;"), 0);
$asp = mysql_query("SELECT `name` FROM `users` WHERE `rights`>=1 ORDER BY `id` DESC LIMIT $colad;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; } 
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT ','0','','','','');");
$wx++;
}
echo '<b>Gửi thư thành công!!</b><br />
Gửi <b>' .$wx. '</b> thông báo cho tất cả các quản trị viên và Mod!';
$type_r = 2;
}

//Gửi cho mod

elseif ($_POST['sel'] == 'smdadm') {
$coladm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights`>=7;"), 0);
$asp = mysql_query("SELECT `name` FROM `users` WHERE `rights`>=7 ORDER BY `id` DESC LIMIT $coladm;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; } 
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT','0','','','','');");
$wx++;
}
echo '<b>Gửi thư thành công!!</b><br />
Gửi <b>' .$wx. '</b> thông báo cho tất cả các cấp cao và hiện đại hóa hành chính!';
$type_r = 3;
}

//Gửi cho tv nam
if ($_POST['sel'] == 'm') {
$colm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex`='m';"), 0);
$asp = mysql_query("SELECT `name` FROM `users` WHERE `sex`='m' ORDER BY `id` DESC LIMIT $colm;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; } 
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT','0','','','','');");
$wx++;
}
echo '<b>Gửi thư thành công!!</b><br />
Gửi <b>' .$wx. '</b> Thông báo cho tất cả các TV NAM!'; 
$type_r = 4;
}

//Gửi riêng phái nữ tui mình :D
elseif ($_POST['sel'] == 'zh') {
$colzh = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `sex`='zh';"), 0);
$asp = mysql_query("SELECT `name` FROM `users` WHERE `sex`='zh' ORDER BY `id` DESC LIMIT $colzh;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; } 
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT ','0','','','','');");
$wx++;
}
echo '<b>Gửi thư thành công!!</b><br />
Gửi <b>' .$wx. '</b> thông báo đến tất cả các TV NỮ!';
$type_r = 5;
}
//Gửi cho admin

elseif ($_POST['sel'] == 'admin') {
$coladm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights`=9;"), 0);
$asp = mysql_query("SELECT `name` FROM `users` WHERE `rights`=9 ORDER BY `id` DESC LIMIT $coladm;");
$wx = 0;
while ($res = mysql_fetch_assoc($asp)) {
$usname = $res['name'];
if ($usname == $login) { continue; } 
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .$realtime. "','" .$login. "','in','no','Thông báo từ BQT ','0','','','','');");
$wx++;
}
echo '<b>Gửi thư thành công!!</b><br />
Gửi <b>' .$wx. '</b> thông báo cho Admin!';
$type_r = 6;
}
echo '<br /></div><div class="menu">&raquo; <a href="sendsms.php">Quay lại</a><br />&raquo; <a href="sendsms.php?act=stat">Thống kê thư</a></div>';
break;
}
require_once ("incfiles/end.php");
?>
