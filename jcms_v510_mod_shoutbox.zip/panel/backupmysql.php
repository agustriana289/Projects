<?php
@ini_set("max_execution_time", "600");
define('_IN_JOHNCMS', 1);
define('_IN_JOHNADM', 1);

require('../incfiles/core.php');

$lng = array_merge($lng, core::load_lng('admin'));


if (core::$user_rights < 1) {
    header('Location: /?err');
    exit;
}
 if (!is_dir($rootpath.'files/mysql/'))mkdir($rootpath.'files/mysql');
 
$headmod = 'admin';
$textl = $lng['admin_panel'];
require('../incfiles/head.php');
require('../incfiles/db.php');
echo "<div class='mainbox'><div class='mainblok'><div class='nfooter'>Download your backups via ftp ($_SERVER[SERVER_NAME]/files/mysql/) and remove!</div>";
if(!empty($_POST['table'])){
foreach ( $_POST['table'] as $value)
{
$table= $_POST['table'];
}
$c=count($table);
for($i=0;$i<$c;$i++)
{
$sql=NULL;
$sql.="DROP TABLE IF EXISTS `$table[$i]`;\r\n";
$res=mysql_query("SHOW CREATE TABLE `$table[$i]`");
$row=mysql_fetch_row($res);
$sql.=$row[1].";\r\n\r\n\r\n";
$res = mysql_query("SELECT * FROM `$table[$i]`");
if (count($res) > 0) {
while (($row = mysql_fetch_assoc($res))) {
$keys = implode("`, `", array_keys($row));
$values = array_values($row);
foreach($values as $k=>$v) {

$values[$k] = mysql_real_escape_string($v);
$values[$k]=preg_replace("#(\n|\r){1,}#", '\n', $values[$k]);

}
$values2 = implode("', '", $values);
$values2 = "'".$values2."'";

$sql .= "INSERT INTO `$table[$i]` (`$keys`) VALUES ($values2);\r\n";
}

$sql .= "\r\n\r\n";
}
}
$fopen_mysql=fopen($rootpath.'files/mysql/backup__'.date("d_m_y___").rand(99,999).'__.sql','a');
fwrite($fopen_mysql, $sql);
fclose($fopen_mysql);
echo '<div class="omenu">Backup successfully created!</div>';
}
if (isset($_GET['copy']))echo 'Tadochi'; // не трогаем )) ведь это вам не мешает ))
echo '<div class="rmenu"><a href="index.php">' . $lng['admin_panel'] . '</a> | ';
echo (isset($_GET['get'])?'<a href="?">unmark</a>':'<a href="?get">Mark</a>').'</div>';
$tab=mysql_query("SHOW TABLES from $db_name;");
echo '<form action="?backup" method="post">';
for($i=0;$i<mysql_num_rows($tab);$i++)
{
echo '<input type="checkbox" '.(isset($_GET['get'])?'checked="checked"':'').' name="table[]" value="'.mysql_tablename($tab, $i).'"/> '.mysql_tablename($tab,$i).'<br />';
}
echo '<div class="list2"><input class="omenu" type="submit"/></form></div>';
echo "
<div class='nfooter'><b>list of backups</b>:</div>";
$open=glob($rootpath.'files/mysql/*.sql');
foreach ($open as $file) {
    echo "<hr/><b><a href='$file'>".$file."</a></b><br />
	size: " . round(filesize($file)/1024) . " kb/" . round(filesize($file)/1024000,1) . " mb<br />
	</div></div><hr/>";
}
require('../incfiles/end.php');
?>
