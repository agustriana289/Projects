<?php
header('Location: /files.php');
?>
