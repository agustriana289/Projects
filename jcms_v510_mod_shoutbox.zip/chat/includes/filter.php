<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:5.3 для JohnCMS v.:4.2.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверяем наличие идентификатора комнаты
if (!$id) {
  header("Location: index.php");
 exit;
}
// Получаем данные комнаты
$k_d = mysql_fetch_assoc(mysql_query("SELECT `name`, `tip` FROM `chat_rooms` WHERE `id` = '".$id."'"));
if ($k_d['tip'] == 'an' || $k_d['tip'] == 'in') {
  header("Location: index.php");
 exit;
} 
switch ($do) {

  case 'unset' :
    unset ($_SESSION['chat_id']);
    unset ($_SESSION['chat_k']);
    header("Location: index.php?id=$id");
  break;

  case 'set' :
    if (empty ($_POST['users'])) {
      echo '<div class="rmenu"><p>'.$lng_chat['error_no_authors'].'<br /><a href="index.php?act=filter&amp;id=' . $id . '">'.$lng['back'].'</a></p></div>';
      require('../incfiles/end.php');
     exit;
    }
    $users = isset($_POST['users']) ? $_POST['users'] : '';
    $array = array();
    foreach ($users as $val) {
      $array [] = functions::check($val);
    }
    $_SESSION['chat_id'] = serialize($array);
    $_SESSION['chat_k'] = $id;
    header("Location: index.php?id=$id");
  break;

  default :
    /*
    -----------------------------------------------------------------
    Отображаем сгруппированный список юзеров
    -----------------------------------------------------------------
    */ 
    $req = mysql_query("SELECT *, COUNT(`id_u`) AS `count` FROM `chat_room_".$id."` WHERE `tip` != '1' AND `id_bot` = '0' GROUP BY `id_u` ORDER BY `id_u`");
    if (mysql_num_rows($req)) {
      echo '<form action="index.php?act=filter&amp;do=set&amp;id='.$id.'" method="post">';
      echo '<div class="phdr"><a href="index.php"><b>'.$lng_chat['chat'].'</b></a> | <a href="index.php?id='.$id.'">'.$k_d['name'].'</a> | '.$lng_chat['filter_messages'].'</div>';
      $i = 0;
      while ($res = mysql_fetch_array($req)) {
        $us_d = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $res['id_u'] . "'"));
        echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
        echo '<input type="checkbox" name="users[]" value="' . $res['id_u'] . '"/>&#160;';
        echo $user_id != $res['id_u'] ? '<a href="../str/anketa.php?id=' . $res['id_u'] . '">' . $us_d['name'] . '</a>' : $us_d['name'];
        echo time() > $us_d['lastdate'] + 300 ? '<span class="red"> [Off]</span> ' : '<span class="green"> [ON]</span> ';
        echo '<span class="gray">[' . $res['count'] . ']</span></div>';
       ++$i;
      }
      echo '<div class="gmenu"><input type="submit" value="'.$lng_chat['filter'].'" name="submit" /></div></form>';
      echo '<div class="phdr"><small>'.$lng_chat['filter_help'].'</small></div>';
      echo '<p><a href="index.php?id=' . $id . '">'.$lng['back'].'</a></p>';
    } else {
      echo '<div class="rmenu"><p>'.$lng['error'].'<br /><a href="index.php?id=' . $id . '">'.$lng['back'].'</a></p></div>';
    }
}

?>