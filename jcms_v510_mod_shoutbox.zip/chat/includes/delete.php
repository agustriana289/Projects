<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$id || !$id_k || !$user_id || $rights != 9) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Удаление сообщения
-----------------------------------------------------------------
*/ 
// Получаем данные сообщения
$soob = mysql_query("SELECT `id_u`, `tip` FROM `chat_room_".$id_k."` WHERE `id` = '" . $id . "'");
// Проверяем существование сообщения
if (!mysql_num_rows($soob)) {
  header("Location: index.php");
 exit;
}
$soob_d = mysql_fetch_assoc($soob);
// Получаем количество сообщений автора
$us_d = mysql_fetch_assoc(mysql_query("SELECT `postchat` FROM `chat_users` WHERE `id_u` = '" . $soob_d['id_u'] . "'"));
if ($mod == 'yes') {
  // Удаляем сообщение
  mysql_query("DELETE FROM `chat_room_".$id_k."` WHERE `id` = '" . $id . "'");
  // Если сообщение не скрыто, то вычитаем один балл из счетчика постов юзера
  if ($soob_d['tip'] != 1) {
    $postchat = $us_d['postchat'] > 0 ? $us_d['postchat'] - 1 : 0;
    mysql_query("UPDATE `chat_users` SET `postchat` = '" . $postchat . "' WHERE `id_u` = '" . $soob_d['id_u'] . "'");
  }
  header("Location: $home/chat/index.php?id=$id_k");
 exit;
} else {
  // Подтверждение удаления сообщения
  echo '<div class="phdr"><a href="index.php"><b>'.$lng_chat['chat'].'</b></a> | '.$lng['delete'].'</div>';
  echo '<div class="rmenu"><p>'.$lng_chat['really_delete_post'].'<br /><a href="index.php?act=delete&amp;id=' . $id . '&amp;id_k='.$id_k.'&amp;mod=yes">Да</a> | <a href="index.php?id=' . $id_k . '">Нет</a></p></div>';
  echo '<div class="phdr"><a href="index.php?id='.$id_k.'">'.$lng['back'].'</a></div>';
}

?>