<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($id) {
  /*
  -----------------------------------------------------------------
  Отображение Онлайн комнаты
  -----------------------------------------------------------------
  */ 
  // Получаем данные комнаты
  $k_d = mysql_fetch_assoc(mysql_query("SELECT `name`, `tip` FROM `chat_rooms` WHERE `id` = '" . $id . "'"));
  echo '<div class="phdr"><b>'.$lng_chat['who_s_room'].':</b> <a href="index.php?id=' . $id . '">' . $k_d['name'] . '</a></div>';
  // Получаем общее количество пользоватей в комнате
  $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` >= '" . (time() - 300) . "' AND `place` = 'chat," . $id . "'"), 0);
  if ($total) {
    // Получаем список пользователей в комнате
    $q = mysql_query("SELECT * FROM `users` WHERE `lastdate` >= '" . (time() - 300) . "' AND `place` = 'chat," . $id . "' LIMIT $start, $kmess"); 
    while ($arr = mysql_fetch_array($q)) {
      echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
      // Выбираем тип отображения данных, пользователь или аноним
      if ($k_d['tip'] != 'an' || $k_d['tip'] == 'an' && ($chat_us_d['rights'] == 1 || $rights >= 6)) {
        echo functions::display_user($arr) . '</div>';
      } else {
        // Открываем таблицу с данными анонима
        if ($set_user['avatar']) {
          echo '<table cellpadding="0" cellspacing="0"><tr><td>';
          echo '<img src="../images/empty.png" width="32" height="32" alt=""/>&#160;';
          echo '</td><td>';
        }
        echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($arr['sex'] == 'm' ? 'm' : 'w') . ($arr['datereg'] > time() - 86400 ? '_new' : '') . '.png" width="16" height="16" align="middle" />&#160;';
        echo '<b>Аноним</b>&#160;';
        // Метка Онлайн
        echo '<span class="green">[ON]</span>';
        // Закрываем таблицу с данными
        if ($set_user['avatar'])
          echo '</td></tr></table>';
        echo '</div>';
      }
     ++$i;
    }
  } else {
    echo '<div class="menu"><p>'.$lng_chat['the_list_is_empty'].'</p></div>';
  }
} else {
  /*
  -----------------------------------------------------------------
  Отображение Онлайн чата
  -----------------------------------------------------------------
  */ 
  echo '<div class="phdr"><a href="index.php"><b>' . $lng_chat['chat'] . '</b></a> | ' . $lng_chat['who_s_chatting'] . '</div>';
  // Получаем общее количество пользоватей в чате
  $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` >= '" . (time() - 300) . "' AND `place` LIKE 'chat%'"), 0);
  if ($total) {
    // Получаем список пользователей в чате
    $q1 = mysql_query("SELECT * FROM `users` WHERE `lastdate` >= '" . (time() - 300) . "' AND `place` LIKE 'chat%' LIMIT $start, $kmess");
    $i = 0;
    while ($arr1 = mysql_fetch_array($q1)) {
      // Вычисляем местоположение
      $place = '';
      $tip = '';
      switch ($arr1['place']) {
        case 'chat':
          $place = '<a href="index.php">'.$lng_chat['in_the_hallway'].'</a>';
        break;

        case 'chatwho':
          $place = $lng_chat['where_here'];
        break;

        case 'chatfaq':
          $place = '<a href="index.php?act=faq">'.$lng_chat['where_rules'].'</a>';
        break;

        case 'chatmoders':
          $place = '<a href="index.php?act=moders">'.$lng_chat['where_moders'].'</a>';
        break;

        case 'chatset':
          $place = '<a href="index.php?act=my_set">'.$lng_chat['where_settings'].'</a>';
        break;

        case 'chattop':
          $place = '<a href="top.php">'.$lng_chat['where_top'].'</a>';
        break;

        default:
          $where = explode(",", $arr1['place']);
          if ($where[0] == 'chat' && intval($where[1])) {                       
            // Получаем данные комнаты по её идентификатору
            $room = mysql_fetch_array(mysql_query("SELECT * FROM `chat_rooms` WHERE `id` = '" . $where[1] . "'")); 
            $place = ''.$lng_chat['in_room'].' &quot;<a href="index.php?id='.$where[1].'">' .  $room['name'] . '</a>&quot;';      
            $tip = $room['tip'];
          }
        }
        echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
        // Выбираем тип отображения данных, пользователь или аноним
        if ($tip != 'an' || $tip == 'an' && ($chat_us_d['rights'] == 1 || $rights >= 6)) {
          $arg = array (
            'stshide' => 1,
            'header' => ('<br /><img src="../images/info.png" width="16" height="16" align="middle" />&#160;' . $place)
          );
          echo functions::display_user($arr1, $arg);
          echo '</div>';
        } else {
          // Открываем таблицу с данными анонима
          if ($set_user['avatar']) {
            echo '<table cellpadding="0" cellspacing="0"><tr><td>';
            echo '<img src="../images/empty.png" width="32" height="32" alt="" />&#160;';
            echo '</td><td>';
          }
          // Метка пола
          echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($arr1['sex'] == 'm' ? 'm' : 'w') . ($arr1['datereg'] > time() - 86400 ? '_new' : '') . '.png" width="16" height="16" align="middle" />&#160;';
          echo '<b>'.$lng_chat['anonymous'].'</b>&#160;';
          // Метка Онлайн
          echo '<span class="green">[ON]</span>';
          echo '<br /><img src="../images/info.png" width="16" height="16" align="middle"/>&#160;' . $place;
          // Закрываем таблицу с данными
          if ($set_user['avatar'])
            echo '</td></tr></table>';
          echo '</div>';
        }   
       ++$i;
    }
  } else {
    echo '<div class="menu"><p>'.$lng_chat['the_list_is_empty'].'</p></div>';
  }
}
echo '<div class="phdr">'.$lng_chat['all'].': <b>'.$total.'</b></div>';
// Постраничная навигация
if ($total > $kmess) {
  echo '<div class="topmenu">' . functions::display_pagination('index.php?act=who&amp;'.($id ? 'id='.$id.'&amp;' : ''), $start, $total, $kmess) . '</div>';
  echo '<p><form action="index.php?act=who'.($id ? '&amp;id='.$id.'' : '').'" method="post">
<input type="text" name="page" size="2"/>
<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
}
echo '<p><a href="index.php">'.$lng_chat['to_chat'].'</a></p>';

?>