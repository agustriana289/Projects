<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.2.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$id || !$user_id || $rights != 9) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Очистка комнаты
-----------------------------------------------------------------
*/ 
switch ($mod) {

  case 'yes' :
    /*
    -----------------------------------------------------------------
    Полная очистка комнаты
    -----------------------------------------------------------------
    */ 
    mysql_query("DELETE FROM `chat_room_".$id."`");
    mysql_query("OPTIMIZE TABLE `chat_room_".$id."`");
    echo '<div class="phdr"><b>'.$lng['clear_param'].':</b></div>';
    echo '<div class="gmenu"><b>'.$lng_chat['room_emptied_completely'].'</b></div>';
    echo '<div class="phdr"><b><a href="index.php?id='.$id.'">'.$lng_chat['to_room'].'</a></b></div>';
 break;

  case '1d' :
    /*
    -----------------------------------------------------------------
    Очистка комнаты от сообщений старше 1 дня
    -----------------------------------------------------------------
    */ 
    mysql_query("DELETE FROM `chat_room_".$id."` WHERE `time` <= '" . (time() - 86400) . "'");
    mysql_query("OPTIMIZE TABLE `chat_room_".$id."`");
    echo '<div class="phdr"><b>'.$lng['clear_param'].':</b></div>';
    echo '<div class="gmenu"><b>'.$lng_chat['remove_posts_1_day_yes'].'</b></div>';    
    echo '<div class="phdr"><b><a href="index.php?id='.$id.'">'.$lng_chat['to_room'].'</a></b></div>';
 break;

  case 'skr' :
    /*
    -----------------------------------------------------------------
    очистка комнаты от скрытых сообщений
    -----------------------------------------------------------------
    */ 
    mysql_query("DELETE FROM `chat_room_".$id."` WHERE `tip` = '1'");
    mysql_query("OPTIMIZE TABLE `chat_room_".$id."`");
    echo '<div class="phdr"><b>'.$lng['clear_param'].':</b></div>';
    echo '<div class="gmenu"><b>'.$lng_chat['room_free_of_hidden_messages'].'</b></div>';
    echo '<div class="phdr"><b><a href="index.php?id='.$id.'">'.$lng_chat['to_room'].'</a></b></div>';
 break;

  default:
    /*
    -----------------------------------------------------------------
    Меню вариантов очистки комнаты
    -----------------------------------------------------------------
    */ 
    $soob = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$id."`"), 0);
    $soob_s = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$id."` WHERE `tip` = '1'"), 0);
    $soob_1d = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$id."` WHERE `time` <= '" . (time() - 86400) . "'"), 0);
    echo '<div class="phdr"><b>'.$lng['clear_param'].':</b></div><div class="menu"><p><a href="index.php?act=dell&amp;mod=yes&amp;id=' . $id . '">'.$lng['clear_param_all'].'</a> <span class="gray"><small>(' . $soob . ')</small></span></p>';
    echo '<p><a href="index.php?act=dell&amp;mod=skr&amp;id=' . $id . '">'.$lng_chat['remove_posts_hidden'].'</a> <span class="gray"><small>(<span class="red">' . $soob_s . '</span>)</small></span></p>';
    echo '<p><a href="index.php?act=dell&amp;mod=1d&amp;id=' . $id . '">'.$lng_chat['remove_posts_1_day'].'</a> <span class="gray"><small>(<span class="red">' . $soob_1d . '</span>)</small></span></p></div>';
    echo '<div class="phdr"><b><a href="index.php?id='.$id.'">'.$lng['back'].'</a></b></div>';
}

?>