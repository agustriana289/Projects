<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверяем права доступа
if ($rights < 9) {
  header("Location: $home?err");
 exit;
}

echo '<div class="phdr"><b><a href="../' . $set['admp'] . '/index.php">' . $lng['admin_panel'] . '</a></b> | '.$lng_chat['cleaning'].'</div>';

switch ($mod) {

  case 'delete':
    /*
    -----------------------------------------------------------------
    Полная очистка всех комнат
    -----------------------------------------------------------------
    */
    if (isset ($_GET['yes'])) {
      $i = 0;
      $room = mysql_query("SELECT * FROM `chat_rooms`");
      while ($room_d = mysql_fetch_assoc($room)) {
        mysql_query("DELETE FROM `chat_room_".$room_d['id']."`");
        mysql_query("OPTIMIZE TABLE `chat_room_".$room_d['id']."`");
       ++$i;
      }
      header("location: ?act=mod_messages&do=del");
     exit;
    } else {
      echo '<div class="rmenu"><p>'.$lng_chat['remove_all_chat_messages'].'</p>';
      echo '<p><a href="?act=mod_messages&amp;mod=delete&amp;yes">'.$lng_chat['action_yes'].'</a> | <a href="?act=mod_messages">'.$lng_chat['action_no'].'</a></p></div>';
    }
 break;

  case 'delete_s':
    /*
    -----------------------------------------------------------------
    Полная очистка всех комнат от скрытых сообщений
    -----------------------------------------------------------------
    */
    if (isset ($_GET['yes'])) {
      $i = 0;
      $room = mysql_query("SELECT * FROM `chat_rooms`");
      while ($room_d = mysql_fetch_assoc($room)) {
        mysql_query("DELETE FROM `chat_room_".$room_d['id']."` WHERE `tip` = '1'");
        mysql_query("OPTIMIZE TABLE `chat_room_".$room_d['id']."`");
       ++$i;
      }
      header("location: ?act=mod_messages&do=del_s");
     exit;
    } else {
      echo '<div class="rmenu"><p>'.$lng_chat['remove_hidden_chat_messages'].'</p>';
      echo '<p><a href="?act=mod_messages&amp;mod=delete_s&amp;yes">'.$lng_chat['action_yes'].'</a> | <a href="?act=mod_messages">'.$lng_chat['action_no'].'</a></p></div>';
    }
 break;

  case 'delete_k':
    /*
    -----------------------------------------------------------------
    Очистка определённой комнаты
    -----------------------------------------------------------------
    */
    if (isset ($_GET['yes'])) {
      if (isset ($_GET['skr'])) {
        // Очистка комнаты от скрытых сообщений
        mysql_query("DELETE FROM `chat_room_".$id."` WHERE `tip` = '1'");
        mysql_query("OPTIMIZE TABLE `chat_room_".$id."`");
        header("location: ?act=mod_messages&do=del_k_s");
       exit;
      } else {
        // Полная очистка комнаты
        mysql_query("DELETE FROM `chat_room_".$id."`");
        mysql_query("OPTIMIZE TABLE `chat_room_".$id."`");
        header("location: ?act=mod_messages&do=del_k");
       exit;
      }
    } else {
      // Выбор комнаты для очистки
      $i = 0;
      $req = mysql_query("SELECT `id`, `name` FROM `chat_rooms`");
      while ($res = mysql_fetch_assoc($req)) {
        $soob = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$res['id']."`"), 0);
        $soob_s = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$res['id']."` WHERE `tip` = '1'"), 0);
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        echo '<b>' . $res['name'] . '</b> <small>(' . $soob . '/<span class="red">' . $soob_s . '</span>)</small><br />';
        if ($soob) {
          echo '<div class="sub"><a href="?act=mod_messages&amp;mod=delete_k&amp;id=' . $res['id'] . '&amp;yes">'.$lng_chat['completely'].'</a>';
          if ($soob_s)
            echo ' | <a href="?act=mod_messages&amp;mod=delete_k&amp;id=' . $res['id'] . '&amp;skr&amp;yes">'.$lng_chat['hidden'].'</a>';
          echo '</div>';
        }
        echo '</div>';
       ++$i;
      }
    }
 break;

  default :
    /*
    -----------------------------------------------------------------
    Меню управления сообщениями
    -----------------------------------------------------------------
    */  
    switch ($do) {

      case 'del':
        echo '<div class="gmenu"><b>'.$lng_chat['chat_cleared'].'</b></div>';
     break;
    
      case 'del_s':
        echo '<div class="gmenu"><b>'.$lng_chat['hidden_messages_are_deleted'].'</b></div>';
     break;
    
      case 'del_k_s':
        echo '<div class="gmenu"><b>'.$lng_chat['room_free_of_hidden_messages'].'</b></div>';
     break;
    
      case 'del_k':
        echo '<div class="gmenu"><b>'.$lng_chat['room_emptied_completely'].'</b></div>';
     break;
    
      default :
        echo '';
    }    
    $i = 0;
    $soob = 0;
    $soob_s = 0;
    $room = mysql_query("SELECT * FROM `chat_rooms`");
    while ($room_d = mysql_fetch_assoc($room)) {
      $soob = $soob + mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$room_d['id']."`"), 0);
      $soob_s = $soob_s + mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_".$room_d['id']."` WHERE `tip` = '1'"), 0);
     ++$i;
    }
    echo '<div class="menu"><p><h3><img src="img/messages_delete.png" width="16" height="16" class="left" />&#160;'.$lng_chat['cleaning'].'</h3><ul>';
    echo '<li><a href="?act=mod_messages&amp;mod=delete_k">'.$lng_chat['clear_some_room'].'</a> <small>(' . $i . ')</small></li>';
    if ($soob_s)
      echo'<li><a href="?act=mod_messages&amp;mod=delete_s">'.$lng_chat['remove_the_hidden_message'].'</a> <small>(<span class="red">' . $soob_s . '</span>)</small></li>';
    echo '<li><a href="?act=mod_messages&amp;mod=delete">'.$lng_chat['delete_all_messages'].'</a> <small>(' . $soob . ')</small></li>';
    echo '</ul></p></div>';
}

if ($mod) {
  echo '<div class="phdr"><a href="?act=mod_messages">'.$lng['back'].'</a></div>';
  echo '<p><a href="menu.php">'.$lng_chat['menu'].'</a>';
} else {
  echo '<div class="phdr"><a href="menu.php">'.$lng_chat['menu'].'</a></div>';
  echo '<p><a href="index.php">'.$lng_chat['to_chat'].'</a>';
}
echo '<br /><a href="../' . $set['admp'] . '/index.php">' . $lng['admin_panel'] . '</a></p>';

?>