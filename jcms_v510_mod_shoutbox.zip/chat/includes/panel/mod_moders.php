<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверяем права доступа
if ($rights < 9) {
  header("Location: $home?err");
 exit;
}

echo '<div class="phdr"><a href="../' . $set['admp'] . '/index.php"><b>' . $lng['admin_panel'] . '</b></a> | '.$lng_chat['control_moderators'].'</div>';
switch ($mod) {

  case 'user':
    /*
    -----------------------------------------------------------------
    Список претендентов на пост Модератора чата
    -----------------------------------------------------------------
    */
    $us_m = mysql_query("SELECT `id` FROM `users` WHERE `preg` = '1' AND `rights` < '6'");
    while ($us_m_d = mysql_fetch_assoc($us_m)) {
      $usery = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `id_u` = '".$us_m_d['id']."'"), 0);
      if (!$usery)
        mysql_query("INSERT INTO `chat_users` SET `id_u` = '".$us_m_d['id']."'");
    }
    $total = mysql_num_rows(mysql_query("SELECT `users`.*, `chat_users`.*
      FROM `users` LEFT JOIN `chat_users` ON `users`.`id` = `chat_users`.`id_u`
      WHERE `users`.`rights` < '6' AND `chat_users`.`rights` != '1'
      ORDER BY `users`.`id`
    "));
    echo '<div class="topmenu"><a href="?act=mod_moders">'.$lng['moders'].'</a> | <b>'.$lng_chat['users_off_moders'].'</b></div>';
    if ($total) {
      $userreq = mysql_query("SELECT `users`.*, `chat_users`.*
        FROM `users` LEFT JOIN `chat_users` ON `users`.`id` = `chat_users`.`id_u`
        WHERE `users`.`rights` < '6' AND `chat_users`.`rights` != '1'
        ORDER BY `users`.`id` LIMIT $start, $kmess
      ");
      while ($res = mysql_fetch_assoc($userreq)) {
        $col_vo = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `rights` != '1' AND `id_u` = '".$res['id']."'"), 0); 
        if ($col_vo) {
          echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
          $arg = array (
            'stshide' => 1,
            'sub' => '<a href="?act=mod_moders&amp;mod=nazn&amp;id='.$res['id'].'">'.$lng_chat['appoint'].'</a>'
          );
          echo functions::display_user($res, $arg).'</div>';
         ++$i;
        }
      }
      echo '<div class="phdr">'.$lng_chat['all'].': ' . $total . '</div>';
    } else {
      echo '<div class="rmenu"><p><b>'.$lng_chat['not_bidders'].'</b></p></div>';
      echo '<div class="phdr"><a href="menu.php">'.$lng_chat['menu'].'</a></div>';
    }
    // Постраничная навигация
    if ($total > $kmess) {
      echo '<div class="topmenu">' . functions::display_pagination('?act=mod_moders&amp;mod=user&amp;', $start, $total, $kmess) . '</div>';
      echo '<p><form action="?act=mod_moders&amp;mod=user" method="post">';
      echo '<input type="text" name="page" size="2"/>';
      echo '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
    }
    echo '<p><a href="?act=mod_moders">'.$lng['back'].'</a><br />';
    echo '<a href="../' . $set['admp'] . '/index.php">' . $lng['admin_panel'] . '</a></p>';
 break;

  case 'nazn':
    /*
    -----------------------------------------------------------------
    Назначение Модератора чата
    -----------------------------------------------------------------
    */
    $us = mysql_query("SELECT COUNT(*) FROM `users` WHERE `id` = '$id'");
    if (mysql_result($us, 0) || !$id) {
      $chat_us = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `id_u` = '$id'");
      if (mysql_result($chat_us, 0)) {
        mysql_query("UPDATE `chat_users` SET `rights` = '1' WHERE `id_u` = '" . $id . "'");
      } else {
        mysql_query("INSERT INTO `chat_users` SET `id_u` = '".$id."', `rights` = '1'");
      }  
    } else {
      // Пользователь ненайден
      header("Location: ?act=mod_moders&do=us_no");
     exit;
    }
    // Упешно
    header("Location: ?act=mod_moders&do=us_nazn"); 
   exit; 
 break;

  case 'del':
    /*
    -----------------------------------------------------------------
    Снятие с должности Модератора чата
    -----------------------------------------------------------------
    */
    $us = mysql_query("SELECT COUNT(*) FROM `users` WHERE `id` = '$id'");
    if (mysql_result($us, 0) || !$id) {
      mysql_query("UPDATE `chat_users` SET `rights` = '0' WHERE `id_u` = '" . $id . "'");
    } else {
      // Пользователь ненайден
      header("Location: ?act=mod_moders&do=us_no");
     exit;
    }
    // Упешно 
    header("Location: ?act=mod_moders&do=us_del"); 
   exit;  
 break;

  default :
    /*
    -----------------------------------------------------------------
    Список Модераторов чата
    -----------------------------------------------------------------
    */
    echo '<div class="topmenu"><b>'.$lng['moders'].'</b> | <a href="?act=mod_moders&amp;mod=user">'.$lng_chat['users_off_moders'].'</a></div>';
    switch ($do) {

      case 'us_no':
        echo '<div class="rmenu"><b>'.$lng_chat['user_not_found'].'</b></div>';
     break;
    
      case 'us_nazn':
        echo '<div class="gmenu"><b>'.$lng_chat['moderator_appointed'].'</b></div>';
     break;
    
      case 'us_del':
        echo '<div class="gmenu">'.$lng_chat['moderator_dismissed'].'</div>';
     break;

      default :
        echo '';
    }
    $req = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `rights` = '1'");
    $total = mysql_result($req, 0);
    $chat_us = mysql_query("SELECT `id_u` FROM `chat_users` WHERE `rights` = '1' LIMIT $start, $kmess");
    while ($chat_us_d = mysql_fetch_assoc($chat_us)) {
      $req = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser`, `rights` FROM `users` WHERE `id` = '".$chat_us_d['id_u']."'");
      $res = mysql_fetch_assoc($req);
      echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
      $arg = array (
        'stshide' => 1,
        'sub' => '<a href="?act=mod_moders&amp;mod=del&amp;id='.$chat_us_d['id_u'].'">'.$lng_chat['dismiss'].'</a>'
      );
      echo functions::display_user($res, $arg). '</div>';
     ++$i;
    }
    if ($total) {
      echo '<div class="gmenu"><form action="?act=mod_moders&amp;mod=user" method="post"><input type="submit" value="'.$lng_chat['appoint'].'"/></form></div>';
      echo '<div class="phdr">Всего: <b>' . $total . '</b></div>';
    } else {
      echo '<div class="rmenu"><p><b>'.$lng_chat['not_appointed'].'</b></p></div>';
      echo '<div class="gmenu"><form action="?act=mod_moders&amp;mod=user" method="post"><input type="submit" value="'.$lng_chat['appoint'].'"/></form></div>';
      echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
    }
    // Постраничная навигация
    if ($total > $kmess) {
      echo '<div class="topmenu">' . functions::display_pagination('?act=mod_moders&amp;', $start, $total, $kmess) . '</div>';
      echo '<p><form action="?act=mod_moders" method="post">';
      echo '<input type="text" name="page" size="2"/>';
      echo '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
    }
    echo '<p><a href="menu.php">'.$lng_chat['menu'].'</a><br />';
    echo '<a href="../' . $set['admp'] . '/index.php">' . $lng['admin_panel'] . '</a></p>';
}

?>