<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);
$headmod = 'profile';
require('../incfiles/core.php');
$lng_profile = core::load_lng('profile');
$lng_chat_faq = core::load_lng('chat_faq');

/*
-----------------------------------------------------------------
Закрываем от неавторизованных юзеров
-----------------------------------------------------------------
*/
if (!$user_id) {
  require('../incfiles/head.php');
  echo functions::display_error($lng['access_guest_forbidden']);
  require('../incfiles/end.php');
 exit;
}

/*
-----------------------------------------------------------------
Получаем данные бота
-----------------------------------------------------------------
*/
if (!$user) {
  header("Location: $home/users/profile.php");
 exit;
}
$bot = mysql_query("SELECT `name`, `tip`, `mass_bot`, `mass_author` FROM `chat_bot` WHERE `id` = '" . $user . "' LIMIT 1");
$bot_d = mysql_fetch_assoc($bot);
$mass_bot = unserialize($bot_d['mass_bot']);
$mass_author = unserialize($bot_d['mass_author']);
if (!mysql_num_rows($bot) || empty($mass_bot)) {
  header("Location: $home/users/profile.php");
 exit;
}

switch ($act) {
  case 'bot_info':
    $textl = htmlspecialchars($bot_d['name']) . ': ' . $lng['information'];
    require('../incfiles/head.php');
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="profile.php?user=' . $user . '"><b>' . $lng['profile'] . '</b></a> | ' . $lng['information'] . '</div>';
    echo '<div class="gmenu"><b>' . $lng_chat_faq['bot_no_func'] . '</b></div>';
    echo '<div class="nfooter"><a href="profile.php?user=' . $user . '">' . $lng['back'] . '</a></div>';
  break;
      
  case 'info':
    /*
    -----------------------------------------------------------------
    Ð�Ð¾Ð´Ñ�Ð¾Ð±Ð½Ð°Ñ� Ð¸Ð½Ñ�Ð¾Ñ�Ð¼Ð°Ñ�Ð¸Ñ�, ÐºÐ¾Ð½Ñ�Ð°ÐºÑ�Ð½Ñ�Ðµ Ð´Ð°Ð½Ð½Ñ�Ðµ
    -----------------------------------------------------------------
    */
    $textl = htmlspecialchars($bot_d['name']) . ': ' . $lng['information'];
    require('../incfiles/head.php');
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="profile.php?user=' . $user . '"><b>' . $lng['profile'] . '</b></a> | ' . $lng['information'] . '</div>';
    if ($rights == 9)
      echo '<div class="topmenu"><a href="menu.php?act=mod_bots&amp;mod=edit&amp;id=' . $user . '">' . $lng['edit'] . '</a></div>';
    // Ð�Ð½Ñ�Ð¾Ñ�Ð¼Ð°Ñ�Ð¸Ñ� Ð¾ Ð±Ð¾Ñ�Ðµ    
    echo '<div class="user"><p>';    
    if ($set_user['avatar']) {
      echo '<table cellpadding="0" cellspacing="0"><tr><td>';
      if (file_exists(('img/' . $mass_bot['av']) . '.png'))
        echo '<img src="img/' . $mass_bot['av'] . '.png" width="32" height="32" alt="" />&#160;';
      else
        echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="32" height="32" alt="" />&#160;';
      echo '</td><td>';
    }
    if ($mass_bot['sex'])
      echo '<img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/' . ($mass_bot['sex'] == 'm' ? 'm' : 'w') . '.png" width="16" height="16" align="middle" alt="' . ($mass_bot['sex'] == 'm' ? 'Ð�' : 'Ð�') . '"/>&#160;';
    else
      echo '<img src="' . $set['homeurl'] . '/images/del.png" width="12" height="12" align="middle" />&#160;';
    echo  '<a href="' . $set['homeurl'] . '/chat/profile.php?user=' . $user . '"><b>' . $bot_d['name'] . '</b></a>';
    echo '<span class="green"> [ON]</span>';
    if (!empty($mass_bot['status']))
      echo '<div class="status"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/label.png" alt="" align="middle" />&#160;' . $mass_bot['status'] . '</div>';
    if ($set_user['avatar'])
      echo '</td></tr></table>';
    echo '</p></div>';   
    echo '<div class="list2"><p><h3><img src="../images/contacts.png" width="16" height="16" class="left" />&#160;' . $lng_profile['personal_data'] . '</h3><ul>';
    echo '<li><span class="gray">' . $lng_profile['about'] . ':</span> ' . (empty($mass_author['description']) ? '' : '<br />' . functions::smileys(bbcode::tags($mass_author['description']))) . '</li></ul></p><p>';
    if (($mass_author['author_email'] || $mass_author['author_url']) && $rights >= 7) {
      echo '<h3><img src="../images/mail.png" width="16" height="16" class="left" />&#160;' . $lng_chat_faq['communication_author'] . '</h3><ul>';
      if ($mass_author['author_email'])
        echo '<li><span class="gray">E-mail:</span> ' . $mass_author['author_email'] . '<span class="gray"> [' . $lng_profile['hidden'] . ']</span></li>';
      if ($mass_author['author_url'])
        echo '<li><span class="gray">' . $lng_profile['site'] . ':</span> ' . bbcode::tags($mass_author['author_url']) . '</li>';
      echo '</ul>';
    }
    echo '</p></div><div class="nfooter"><a href="profile.php?user=' . $user . '">' . $lng['back'] . '</a></div>';
  break;

  default :
    /*
    -----------------------------------------------------------------
    Ð�Ð½ÐºÐµÑ�Ð° Ð±Ð¾Ñ�Ð°
    -----------------------------------------------------------------
    */
    $textl = $lng['profile'] . ': ' . htmlspecialchars($bot_d['name']);
    require('../incfiles/head.php');
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $lng_profile['user_profile'] . '</b></div>';
    // Ð�ÐµÐ½Ñ� Ð°Ð½ÐºÐµÑ�Ñ�
    if ($rights == 9)
      echo '<div class="topmenu"><a href="menu.php?act=mod_bots&amp;mod=edit&amp;id=' . $user . '">' . $lng['edit'] . '</a></div>';
    // Ð�Ð½Ñ�Ð¾Ñ�Ð¼Ð°Ñ�Ð¸Ñ� Ð¾ Ð±Ð¾Ñ�Ðµ    
    echo '<div class="user"><p>';    
    if ($set_user['avatar']) {
      echo '<table cellpadding="0" cellspacing="0"><tr><td>';
      if (file_exists(('img/' . $mass_bot['av'] . '.png')))
        echo '<img src="img/' . $mass_bot['av'] . '.png" width="32" height="32" alt="" />&#160;';
      else
        echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="32" height="32" alt="" />&#160;';
      echo '</td><td>';
    }
    if ($mass_bot['sex'])
      echo '<img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/' . ($mass_bot['sex'] == 'm' ? 'm' : 'w') . '.png" width="16" height="16" align="middle" alt="' . ($mass_bot['sex'] == 'm' ? 'Ð�' : 'Ð�') . '"/>&#160;';
    else
      echo '<img src="' . $set['homeurl'] . '/images/del.png" width="12" height="12" align="middle" />&#160;';
    echo '<a href="' . $set['homeurl'] . '/chat/profile.php?user=' . $user . '"><b>' . $bot_d['name'] . '</b></a>';
    echo '<span class="green"> [ON]</span>';
    if (!empty($mass_bot['status']))
      echo '<div class="status"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/label.png" alt="" align="middle" />&#160;' . $mass_bot['status'] . '</div>';
    if ($set_user['avatar'])
      echo '</td></tr></table>';
    echo '</p></div>';    
    // Ð�Ð°Ñ�Ð¼Ð°
    if ($set_karma['on']) {
      echo '<div class="menu">';
      echo '<table  width="100%"><tr><td width="22" valign="top"><img src="' . $set['homeurl'] . '/images/k_0.gif"/></td><td>' .
        '<b>' . $lng['karma'] . ' (0)</b>' .
        '<div class="sub">' .
        '<span class="green"><a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['vote_for'] . ' (0)</a></span> | ' .
        '<span class="red"><a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['vote_against'] . ' (0)</a></span>';
      echo '</div></td></tr></table></div>';
    }
    // Ð�ÐµÐ½Ñ� Ð²Ñ�Ð±Ð¾Ñ�Ð°
    echo '<div class="list2"><p>' .
      '<div><img src="../images/contacts.png" width="16" height="16"/>&#160;<a href="profile.php?act=info&amp;user=' . $user . '">' . $lng['information'] . '</a></div>' .
      '<div><img src="../images/activity.gif" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng_profile['activity'] . '</a></div>' .
      '<div><img src="../images/rate.gif" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['statistics'] . '</a></div>';
    echo '<br />' .
      '<div><img src="../images/photo.gif" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['photo_album'] . '</a>&#160;(0)</div>' .
      '<div><img src="../images/guestbook.gif" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['guestbook'] . '</a>&#160;(0)</div>';
    echo '<br /><div><img src="../images/users.png" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '">' . $lng['contacts_in'] . '</a></div>';
    echo '<div><img src="../images/write.gif" width="16" height="16"/>&#160;<a href="profile.php?act=bot_info&amp;user=' . $user . '"><b>' . $lng['write'] . '</b></a></div>';
    echo '</p></div>';
    echo '<div class="nfooter"><a href="../users/index.php">' . $lng['users'] . '</a></div>';
}
require_once('../incfiles/end.php');

?>