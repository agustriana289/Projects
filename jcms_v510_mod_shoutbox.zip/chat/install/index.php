<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

define('INSTALL', 1);
define('_IN_JOHNCMS', 1);
// Служебные переменные
$rootpath = '../../';
$install = false;
$delete = false;
require('../../incfiles/core.php');

/*
-----------------------------------------------------------------
Проверка, проинсталлирован чат, или нет
-----------------------------------------------------------------
*/
$array = array ('chat_bot', 'chat_vop', 'chat_rooms', 'chat_users', 'chat_settings');
foreach ($array as $val) {  
  $table = mysql_query("SELECT * FROM `".$val."`");
  if ($table == true) { 
    $delete = true;
  } else {
    $install = true;
  }
}

/*
-----------------------------------------------------------------
Получаем список доступных языков
-----------------------------------------------------------------
*/
$i = 1;
foreach (glob('languages/*.ini') as $file) {
    $ini = parse_ini_file($file, true);
    $lng_key[$ini['description']['iso']] = $i;
    $lng_set[$i] = $ini['description'];
    $lng_phrases[$i] = $ini['install'];
    unset($ini);
    ++$i;
}
//if (!count($lng_key))
//    die('ERROR: there are no languages for installation');

// Используем  язык системы
$lng_id = $lng_key[core::$lng_iso];
$chat_lng = $lng_phrases[$lng_id];

if (!count($chat_lng))
    die('ERROR: there are no languages for installation');

/*
-----------------------------------------------------------------
Получаем список доступных ботов и их данные
-----------------------------------------------------------------
*/
$i = 1;
foreach (glob('bot/*.txt') as $file) {
  $ini = file($file);
  for ($b=0; $b<34; ++$b) {
    $str = explode("=", $ini[$b]);
    $str2 = explode("'", $str[1]);
    $bot[$i][$b] = $str2[1];
  }  
  unset($ini);
 ++$i;
}

/*
-----------------------------------------------------------------
HTML Пролог
-----------------------------------------------------------------
*/
ob_start();
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' .
  '<html xmlns="http://www.w3.org/1999/xhtml">' .
  '<title>chat k_2 6.0.0 - '.$chat_lng['install'].'</title>' .
  '<style type="text/css">' .
  'body {font-family: Arial, Helvetica, sans-serif; font-size: small; color: #000000; background-color: #FFFFFF}' .
  'h2{margin: 0; padding: 0; padding-bottom: 4px;}' .
  'h3{margin: 0; padding: 0; padding-bottom: 2px;}' .
  'ul{margin:0; padding-left:20px; }' .
  'li{padding-bottom: 6px; }' .
  '.red{color: #FF0000;}' .
  '.green{color: #009933;}' .
  '.blue{color: #0000EE;}' .
  '.gray{color: #888888;}' .
  '.small{font-size: x-small}' .
  '</style>' .
  '</head><body>' .
  '<h2 class="green">chat k_2 6.0.0</h2><h3 class="gray">for JohnCMS 4.3.x</h3><hr />';

/*
-----------------------------------------------------------------
Переключаем режимы работы
-----------------------------------------------------------------
*/
$act = isset($_REQUEST['act']) ? trim($_REQUEST['act']) : '';
$mod = isset($_REQUEST['mod']) ? trim($_REQUEST['mod']) : '';
$actions = array (
  'install',
  'bot',
  'delete'
);
if (in_array($act, $actions) && file_exists('includes/' . $act . '.php')) {
  require_once('includes/' . $act . '.php');
} else {
  /*
  -----------------------------------------------------------------
  Главное меню инсталлятора
  -----------------------------------------------------------------
  */
  echo '<form action="index.php" method="post">';
  echo '<table>';
  echo '<tr><td valign="top"><input type="radio" name="act" value="install" ' . ($install ? 'checked="checked"' : 'disabled="disabled"') . '/></td><td style="padding-bottom:6px"><h3 class="' . ($install ? 'blue' : 'gray') . '">'.$chat_lng['install'].'</h3><small>';
  echo ($install ? $chat_lng['install_no'] : '<span class="gray">'.$chat_lng['install_yes'].'</span>') . '</small></td></tr>';
  echo '<tr><td valign="top"><input type="radio" name="act" value="bot" ' . (!$install ? 'checked="checked"' : 'disabled="disabled"') . '/>';
  echo '</td><td style="padding-bottom:6px"><h3 class="'. (!$install ? 'blue' : 'gray') . '">'.$chat_lng['install_bot'].'</h3><small>';
  echo (!$install ? $chat_lng['install_bot_yes'] : '<span class="gray">'.$chat_lng['install_bot_no'].'</span>') . '</small></td></tr>';
  echo '<tr><td valign="top"><input type="radio" name="act" value="delete" ' . ($delete ? '' : 'disabled="disabled"') . '/>';
  echo '</td><td style="padding-bottom:6px"><h3 class="'. ($delete ? 'blue' : 'gray') . '">'.$chat_lng['install_table_and_lng'].'</h3><small>';
  echo ($delete ? $chat_lng['install_table_and_lng_yes'] : '<span class="gray">'.$chat_lng['install_table_and_lng_no'].'</span>') . '</small></td></tr>';
  echo '<tr><td>&#160;</td><td><input type="submit" name="submit" value="'.$chat_lng['continue'].'" /></td></tr>';
  echo '</table>';
  echo '</form><hr />';
  echo '<a href="../../index.php">'.$chat_lng['on_site'].'</a><br /><a href="../menu.php">'.$chat_lng['admin_panel'].'</a>';
}
echo '<hr /><p>';
echo '&copy;&#160;Powered by <a href="http://johncms.com">JohnCMS</a></body></html>';
echo '</p>';
?>