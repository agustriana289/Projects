<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                            Автор: k_2 (k202)                               //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('INSTALL') or die('Error: restricted access');

switch ($_GET['mod']) {
  case 'final':
    /*
    -----------------------------------------------------------------
    Удаление завершено
    -----------------------------------------------------------------
    */
    echo '<h2 class="blue">'.$chat_lng['delete'].'</h2><br />';

    echo $chat_lng['delete_completed'];  
    echo '<hr /><p><a href="index.php">'.$chat_lng['home'].'</a><br />';
    echo '<a href="../../index.php">'.$chat_lng['on_site'].'</a><br />';
    echo '<a href="../../panel">'.$chat_lng['admin_panel'].'</a></p>';
  break;

  case 'set':
    /*
    -----------------------------------------------------------------
    Удаление таблиц чата из базы данных
    -----------------------------------------------------------------
    */
    $i = 0;
    $room = mysql_query("SELECT * FROM `chat_rooms`");
    while ($room_d = mysql_fetch_assoc($room)) {
      mysql_query("DROP TABLE IF EXISTS `chat_room_".$room_d['id']."`;");
     ++$i;
    }
    mysql_query("DROP TABLE IF EXISTS `chat_bot`;");
    mysql_query("DROP TABLE IF EXISTS `chat_rooms`;");
    mysql_query("DROP TABLE IF EXISTS `chat_vop`;");
    mysql_query("DROP TABLE IF EXISTS `chat_users`;");
    mysql_query("DROP TABLE IF EXISTS `chat_settings`;");
    header("location: index.php?act=delete&mod=final");
  break;

  default:
    /*
    -----------------------------------------------------------------
    Предупреждение о удалении таблиц чата
    -----------------------------------------------------------------
    */
    echo '<big><span class="red">'.$chat_lng['warning'].'</span></big>';
    echo '<ul><li>'.$chat_lng['delete_table'].'</li></ul>';
    echo '<ul><li>'.$chat_lng['delete_table_2'].'</li></ul>';
    echo '<hr />'.$chat_lng['are_you_sure'].'<br /><a href="index.php?act=delete&mod=set">'.$chat_lng['continue'].'</a><br /><a href="?">'.$chat_lng['home'].'</a>'; 
  break;
}

?>