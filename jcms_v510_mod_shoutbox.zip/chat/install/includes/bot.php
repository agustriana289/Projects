<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('INSTALL') or die('Error: restricted access');
if ($install)
  die('ERROR: installation of bot is impossible</body></html>');
switch ($_GET['mod']) {
  case 'install':
    /*
    -----------------------------------------------------------------
    Добавляем бота в базу
    -----------------------------------------------------------------
   */
    $select = isset($_POST['select']) ? $_POST['select'] : false;
    if ($select) {
      echo '<h3 class="blue">'.$chat_lng['install_bot'].'</h3>';
      foreach ($select as $var) {
        $req = mysql_query("SELECT * FROM `chat_bot` WHERE `name` = '" . $bot[$var][4] . "' LIMIT 1");
        if ($bot[$var][5] == 600) {
        if (mysql_num_rows($req)) {
          $res = mysql_fetch_assoc($req);
          // Удаляем выбранного бота
          mysql_query("DELETE FROM `chat_bot` WHERE `id` = '" . $res['id'] . "'");
          mysql_query("DELETE FROM `chat_vop` WHERE `id_bot` = '" . $res['id'] . "'");
          mysql_query("OPTIMIZE TABLE `chat_bot` , `chat_vop`");
          $bot_setup = '<span class="green">'.$chat_lng['updated'].'</span>';
        } else {
          $bot_setup = '<span class="green">'.$chat_lng['installed'].'</span>';
        }

        //Создаём массивы с данными и заносим их в б.д.
        $mass_bot = serialize(array (
          'time_off' => $bot[$var][15],
          'time_on' => $bot[$var][16],
          'time_1' => $bot[$var][17],                    
          'time_2' => $bot[$var][18],
          'pods_1' => $bot[$var][20],
          'pods_2' => $bot[$var][21],                    
          'vopros' => $bot[$var][22],
          'nev_vop' => $bot[$var][23],
          'no_otv' => $bot[$var][24],
          'otv_0' => $bot[$var][25],                    
          'otv_1' => $bot[$var][26],
          'otv_2' => $bot[$var][27],
          'pods_0_n' => $bot[$var][28],                    
          'pods_1_n' => $bot[$var][29],
          'pods_2_n' => $bot[$var][30],
          'av' => $bot[$var][31],
          'sex' => $bot[$var][32],
          'status' => $bot[$var][33],
        ));

        $mass_author = serialize(array (
          'author' => $bot[$var][8],
          'author_email' => $bot[$var][9],
          'author_url' => $bot[$var][10],
          'description' => $bot[$var][11],
          'version' => $bot[$var][6],
          'iso' => $bot[$var][7]
        ));

        mysql_query("INSERT INTO `chat_bot` SET
          `name` = '" . $bot[$var][4] . "',
          `tip` = '" . $bot[$var][19] . "',
          `mass_bot` = '" . mysql_real_escape_string($mass_bot) . "',
          `mass_author` = '" . mysql_real_escape_string($mass_author) . "'
        ");
        $bot_id = mysql_insert_id();
        // Добавляем фразы
        $file = file('bot/' . $bot[$var][3] . '.txt');
        $count = count($file);
        for ($i = 37; $i < ($count); $i++) {
          if (trim($file[$i])) {
            $text = explode("||", $file[$i]);
            mysql_query("INSERT INTO `chat_vop` SET
              `id_bot`='" . $bot_id . "',
              `vopros`='" . trim($text[0]) . "',
              `otvet`='" . trim($text[1]) . "'
            ");
          }
        }  
        } else
          $bot_setup = '<span class="red">'.$chat_lng['no_install'].'</span>';
        echo '<div>&#160;<b>' . $bot_setup . '&#160;' . $bot[$var][4] . '</b></div>';
      }
      echo '<hr /><a href="index.php?act=bot">'.$chat_lng['back'].'</a><br /><a href="?">'.$chat_lng['home'].'</a><br /><a href="../../index.php">'.$chat_lng['on_site'].'</a>';
    } else {
      echo '<span class="red"><b>'.$chat_lng['error'].'</b><br /><a href="index.php?act=bot">'.$chat_lng['back'].'</a></span><hr />';
    }
  break;

  default:
    /*
    -----------------------------------------------------------------
    Проверка на установленность
    -----------------------------------------------------------------
    */
    $req = mysql_query("SELECT * FROM `chat_bot`");
    $bot_array = array ();
    $b = 1;
    while ($res = mysql_fetch_assoc($req)) {
      $bot_array[$b] = $res['name'];
     ++$b;
    }
    echo '<form action="?act=bot&amp;mod=install" method="post"><table>';
    echo '<tr><td>&#160;</td><td style="padding-bottom:4px"><h3 class="blue">'.$chat_lng['install_bot'].'</h3><small>'.$chat_lng['select_bot_install'].'</small></td></tr>';
    $c = 1;
    $bot_tip = array (
      0 => $chat_lng['frazy'],
      1 => $chat_lng['vopros'],
      2 => $chat_lng['vopros_1'],
      3 => $chat_lng['vopros_2'],
      4 => $chat_lng['dialog']
    );
    foreach ($bot as $mass) {
      $versia = $mass[5] != 600 ? '<span class="red">['.$chat_lng['bot_no_install'].']</span>' : false;
      $inst_status = in_array($mass[4], $bot_array) ? '<span class="green">['.$chat_lng['yes_install_bot'].']</span>' : false;
      $bot_menu = array (
        ($inst_status || $versia ? '<span class="gray">' . $chat_lng['status'] . ':</span>' . ($inst_status ? ' '.$inst_status : '') . ($versia ? ' '.$versia : '') : ''),
        ('<span class="gray">' . $chat_lng['type'] . ':</span> ' . $bot_tip[$mass[19]]),
        (!empty($mass[6]) ? '<span class="gray">'.$chat_lng['version'].':</span> ' . $mass[6] : ''),
        (!empty($mass[8]) ? '<span class="gray">' . $chat_lng['author'] . ':</span> ' . $mass[8] : ''),
        (!empty($mass[9]) ? '<span class="gray">E-mail:</span> ' . $mass[9] : ''),
        (!empty($mass[10]) ? '<span class="gray">URL:</span> ' . $mass[10] : ''),
        (!empty($mass[11]) ? '<span class="gray">' . $chat_lng['description'] . ':</span> ' . $mass[11] : '')
      ); 
      echo '<tr>';
      echo '<td valign="top"><input type="checkbox" name="select[]" value="' . $c . '"' . (!$versia ? '' : 'disabled="disabled"') . '/></td>';
      echo '<td style="padding-bottom:6px"><b>' . $mass[4] . '</b>&#160;<span class="blue">['.$mass[7].']';
      echo '</span>' . (!empty($bot_menu) ? '<br /><small>' . functions::display_menu($bot_menu, '<br />') . '</small>' : '') . '</td>';
      echo '</tr>';
     ++$c;
    }
    echo '<tr><td>&#160;</td><td style="padding-top:6px"><input type="submit" name="submit" value="'.$chat_lng['install'].'" /></td></tr>';
    echo '</table>';
    echo '<hr /><a href="../../index.php">' . $chat_lng['on_site'] . '</a><br /><a href="index.php">' . $chat_lng['home'] . '</a>';
}
?>