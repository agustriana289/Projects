<?php
define('_IN_JOHNCMS', 1);
$textl = 'Meta Free SMS';
$headmod = 'Free SMS';
require_once("../incfiles/core.php");
require_once("../incfiles/head.php");

echo '<div class="mainblok"><div class="phdr"><b>Free SMS</b></div>';
echo '<div class="gmenu">';
echo '<font color="ff0000"> Nomor tujuan gunakan 085xxx jangan +6285xx atau 6285xx</font>';

echo '<div style="background-color:#E1E9EA">
<hr><iframe name="I2"src="http://sms-online.web.id/widget"width="168"height="68">Not support..!! Gunakan Operamini v4xx keatas..</iframe><hr></div>';

echo '<font color="ff0000">www.waptok.asia</font>';

echo '</div></div>';
require_once("../incfiles/end.php");
?>