<?php
/** 
* moduls grab Jcms by whiznoe
* http://waptok.asia

*/

define('_IN_JOHNCMS', 1);

$headmod = 'rainbow';
$textl = 'Rainbow';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo "<div class=\"mainblok\"><div class=\"phdr\"><center><b>KAMU TINGGAL COPY PASTE KODE DI DALAM KOTAK</b></div>";

if ($_POST['submit']) {
//array warna
$pelangi = array('#ff0000', '#ff3300', '#ff6600', '#ff9900', '#ffcc00',
'#ffff00', '#ccff00', '#99ff00', '#66ff00', '#33ff00', '#00ff00', '#00ff33',
'#00ff66', '#00ff99', '#00ffcc', '#00ffff', '#00ccff', '#0099ff', '#0066ff',
'#0033ff', '#0000ff', '#3300ff', '#6600ff', '#9900ff', '#cc00ff', '#ff00ff',
'#ff00cc', '#ff0099', '#ff0066', '#ff0033');


//proses mewarnai

$teks = strip_tags($_POST['teks']);
if (empty($teks)) {
echo("Masukkan dulu teks yang mau diwarnai!");
} else {
$arrwarna = $pelangi;

//pisahkan teks atau kalimat menjadi array huruf
$arrteks = str_split($teks);

$i = 0;
$max = count($arrwarna);
foreach ($arrteks as $huruf) {

if ($huruf != " ") {
$tekspelangi .= "<font color=\"".$arrwarna[$i]."\">$huruf</font>";
}

else { $tekspelangi .= " "; }
$i++;
if ($i == $max) { $i = 0; }
}
echo "<div class=\"gmenu\">";
echo("Hasilnya: $tekspelangi<br><br>
Copy paste :<br>
<textarea rows=\"2\" cols=\"20\">$tekspelangi
</textarea></form><br /><br /></div>");
echo "<div class=\"gmenu\">&laquo; <a href=\"javascript:history.go(-1)\">Go back</a></div>";
}
}
echo "<div class=\"gmenu\"><form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\">
Masukkan teks: <br>
<textarea rows=\"2\" cols=\"20\" name=\"teks\"></textarea> <br>
<input type=\"submit\" name=\"submit\" value=\"Warnai\">
</form>";

echo "</div></div>";
require_once ("../incfiles/end.php");
?>
