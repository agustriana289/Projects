This file downloaded from

*******************
*   http://4alka.TK   *
*******************

FOR MORE COOL SCRIPT PLEASE VISIT AND SUPPORT US

Albas Alka
Edit config.php
