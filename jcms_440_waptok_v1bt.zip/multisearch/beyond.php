<?
$link = $_GET['url'];
$name = $_GET['name'];
$name = str_replace(' ', '_', $name); 
header("Content-Disposition: attachment; filename=$name");
header("Content-type: audio/mpeg;\r\n");
readfile(str_replace(' ', '_', $link));

?>