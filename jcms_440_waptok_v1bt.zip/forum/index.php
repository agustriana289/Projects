<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * @mod      http://waptok.asia
 */

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
$lng_forum = core::load_lng('forum');
if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);

/*
-----------------------------------------------------------------
StSzN?N,NESlSaSaSl N"SlNEN?SLSz
---------------------------------------
*/
$set_forum = $user_id && !empty($datauser['set_forum']) ? unserialize($datauser['set_forum']) : array(
    'farea' => 0,
    'upfp' => 0,
    'preview' => 1,
    'postclip' => 1,
    'postcut' => 2
);

/*
-----------------------------------------------------------------
S?SzSlN?SlSa NESzN?N^SlNESuS?SlSa N"SzSaS"SlS2, NESzS.NESuN^SuS?S?N<Na Sa S2N<S"NEN?S.SaSu
-----------------------------------------------------------------
*/
// SRSzSaS"N< SzNENaSlS2SlS2
$ext_arch = array(
    'zip',
    'rar',
    '7z',
    'tar',
    'gz'
);
// S-S2N?SaSlS2N<Su N"SzSaS"N<
$ext_audio = array(
    'mp3',
    'amr'
);
// SRSzSaS"N< S'SlSaN?SLSuS?N,SlS2 Sl N,SuSaN?N,N<
$ext_doc = array(
    'txt',
    'pdf',
    'doc',
    'rtf',
    'djvu',
    'xls'
);
// SRSzSaS"N< Java
$ext_java = array(
    'jar',
    'jad'
);
// SRSzSaS"N< SaSzNEN,SlS?SlSa
$ext_pic = array(
    'jpg',
    'jpeg',
    'gif',
    'png',
    'bmp'
);
// SRSzSaS"N< SIS
$ext_sis = array(
    'sis',
    'sisx'
);
// SRSzSaS"N< S2SlS'SuSl
$ext_video = array(
    '3gp',
    'avi',
    'flv',
    'mpeg',
    'mp4'
);
// SRSzSaS"N< Windows
$ext_win = array(
    'exe',
    'msi'
);
// S"NEN?S"SlSu N,SlSzN< N"SzSaS"SlS2 (N?N,Sl S?Su SzSuNESuN?SlN?S"SuS?N< S2N<N^Su)
$ext_other = array('wmf');

/*
-----------------------------------------------------------------
SzS"NESzS?SlN?SlS2SzSuSL S'SlN?N,N?Sz Sa SRSlNEN?SLN?
-----------------------------------------------------------------
*/
$error = '';
if (!$set['mod_forum'] && $rights < 7)
    $error = $lng_forum['forum_closed'];
elseif ($set['mod_forum'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error) {
    require('../incfiles/head.php');
    echo '<div class="rmenu"><p>' . $error . '</p></div>';
    require('../incfiles/end.php');
    exit;
}

$headmod = $id ? 'forum,' . $id : 'forum';

/*
-----------------------------------------------------------------
Mod Prefix waptok
-----------------------------------------------------------------
*/
switch ($res['waptok']){
case 0 :
$prefix='[DEFAULT]';
break;
case 1 :
$prefix='[SHARE]';
break;
case 2 :
$prefix='[MODD]';
break;
case 3 :
$prefix='[FIX]';
break;
case 4 :
$prefix='[ASK]';
break;
case 5 :
$prefix='[HELP]';
break;
case 6 :
$prefix='[HOT]';
break;
case 7 :
$prefix='[DISCUSS]';
break;
case 8 :
$prefix='[INFO]';
break;
case 9 :
$prefix='[NOTIFE]';
break;
default:
$prefix='';
break;
}
$textl=$prefix.' '.$titlex;


/*
-----------------------------------------------------------------
S-SzS"SlS"SlS2SaSl N?N,NESzS?SlN? N"SlNEN?SLSz
-----------------------------------------------------------------
*/
if (empty($id)) {
    $textl = '' . $lng['forum'] . '';
} else {
    $trangvip = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");  // TAGS MOD
    $trangvip1 = mysql_fetch_assoc($trangvip);  // waptok tags
    $req = mysql_query("SELECT `text` FROM `forum` WHERE `id`= '" . $id . "'");
    $res = mysql_fetch_assoc($req);
    $hdr = strtr($res['text'], array(
        '&quot;' => '',
        '&amp;' => '',
        '&lt;' => '',
        '&gt;' => '',
        '&#039;' => ''
    ));
    $hdr = mb_substr($hdr, 0, 30);
    $hdr = functions::checkout($hdr);
    $hdr = html_entity_decode($hdr,ENT_QUOTES,'UTF-8');
    $textl = mb_strlen($res['text']) > 30 ? $hdr . '...' : $hdr;
    //$textl = ''.bbcode::notags($res['text']).'...'.$trangvip1['tags'].'';
}

                      
/*
-----------------------------------------------------------------
SzSuNESuSaS"NZN?SzSuSL NESuS?SlSLN< NESzS+SlN,N<
-----------------------------------------------------------------
*/
$mods = array(
    'addfile',
    'addvote',
    'close',
    'delfile',
    'deltema',
    'delvote',
    'editpost',
    'editvote',
    'file',
    'files',
    'filter',
    'import',
    'loadtem',
    'massdel',
    'moders',
    'new',
    'nt',
    'per',
    'post',
    'ren',
    'restore',
    'say',
    'tema',
    'users',
    'vip',
    'vote',
    'who',
    'curators'
);
                              
if ($act && ($key = array_search($act, $mods)) !== false && file_exists('includes/' . $mods[$key] . '.php')) {
    require('includes/' . $mods[$key] . '.php');
} else {
    require('../incfiles/head.php');

    /*
----------------------------------------------------------------
    SRN?S"Sl N"SlNEN?SL S.SzSaNEN<N,, N,Sl S'S"NZ S?S'SLSlS?SlS2 S2N<S2SlS'SlSL S?SzSzSlSLSlS?SzS?SlSu
    -----------------------------------------------------------------
    */
    if (!$set['mod_forum']) echo '<div class="alarm">' . $lng_forum['forum_closed'] . '</div>';
    elseif ($set['mod_forum'] == 3) echo '<div class="rmenu">' . $lng['read_only'] . '</div>';
    if (!$user_id) {
        if (isset($_GET['newup']))
            $_SESSION['uppost'] = 1;
        if (isset($_GET['newdown']))
            $_SESSION['uppost'] = 0;
    }
    if ($id) {
        /*
        -----------------------------------------------------------------
        SzSzNESuS'SuS"NZSuSL N,SlSz S.SzSzNESlN?Sz (SaSzN,SzS"SlS", SlS"Sl N,SuSLSz)
        -----------------------------------------------------------------
        */
        $type = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");
        if (!mysql_num_rows($type)) {
            // SRN?S"Sl N,SuSLN< S?Su N?N?NeSuN?N,S2N?SuN,, SzSlSaSzS.N<S2SzSuSL SlN^SlS+SaN?
            echo functions::display_error($lng_forum['error_topic_deleted'], '<a href="index.php">' . $lng['to_forum'] . '</a>');
            require('../incfiles/end.php');
            exit;
        }
        $type1 = mysql_fetch_assoc($type);

        /*
        -----------------------------------------------------------------
        SRSlSaN?SzN?SlNZ N"SzSaN,Sz SzNESlN?N,SuS?SlNZ ScSlSzSlSaSz
        -----------------------------------------------------------------
        */
        if ($user_id && $type1['type'] == 't') {
            $req_r = mysql_query("SELECT * FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            if (mysql_num_rows($req_r)) {
                $res_r = mysql_fetch_assoc($req_r);
                if ($type1['time'] > $res_r['time'])
                    mysql_query("UPDATE `cms_forum_rdm` SET `time` = '" . time() . "' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            } else {
                mysql_query("INSERT INTO `cms_forum_rdm` SET `topic_id` = '$id', `user_id` = '$user_id', `time` = '" . time() . "'");
            }
        }

        /*
        -----------------------------------------------------------------
        SzSlS"N?N?SzSuSL N?N,NEN?SaN,N?NEN? N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
        $res = true;
        $parent = $type1['refid'];
        while ($parent != '0' && $res != false) {
            $req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$parent' LIMIT 1");
            $res = mysql_fetch_assoc($req);
            if ($res['type'] == 'f' || $res['type'] == 'r')
                $tree[] = '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $parent . '.html">' . $res['text'] . '</a>';
            $parent = $res['refid'];
        }
        $tree[] = '<a href="index.php">' . $lng['forum'] . '</a>';
        krsort($tree);
        if ($type1['type'] != 't' && $type1['type'] != 'm')
            $tree[] = '<b>' . $type1['text'] . '</b>';

        /*
        -----------------------------------------------------------------
        S?N?SuN,N?SlSa N"SzSaS"SlS2 Sl N?N?N<S"SaSz S?Sz S?SlNa
        -----------------------------------------------------------------
        */
        $sql = ($rights == 9) ? "" : " AND `del` != '1'";
        if ($type1['type'] == 'f') {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `cat` = '$id'" . $sql), 0);
            if ($count > 0)
                $filelink = '<a href="index.php?act=files&amp;c=' . $id . '">' . $lng_forum['files_category'] . '</a>';
        } elseif ($type1['type'] == 'r') {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `subcat` = '$id'" . $sql), 0);
            if ($count > 0)
                $filelink = '<a href="index.php?act=files&amp;s=' . $id . '">' . $lng_forum['files_section'] . '</a>';
        } elseif ($type1['type'] == 't') {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `topic` = '$id'" . $sql), 0);
            if ($count > 0)
                $filelink = '<a href="index.php?act=files&amp;t=' . $id . '">' . $lng_forum['files_topic'] . '</a>';
        }
        $filelink = isset($filelink) ? $filelink . '&#160;<span class="red">(' . $count . ')</span>' : false;

        /*
        -----------------------------------------------------------------
        S?N?SuN,N?SlSa "SsN,Sl S2 N,SuSLSu?"
        -----------------------------------------------------------------
        */
        $wholink = false;
        if ($user_id && $type1['type'] == 't') {
            $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $wholink = '<a href="index.php?act=who&amp;id=' . $id . '">' . $lng_forum['who_here'] . '?</a>&#160;<span class="red">(' . $online_u . '&#160;/&#160;' . $online_g . ')</span><br/>';
        }

        /*
        -----------------------------------------------------------------
        S'N<S2SlS'SlSL S2SuNENaS?NZNZ SzSzS?SuS"NS S?SzS2SlS"SzN?SlSl
        -----------------------------------------------------------------
        */
        echo '<p>' . counters::forum_new(1) . '</p>' .
             '<div class="mainblok"><div class="phdr">' . functions::display_menu($tree) . '</div>' .
             '<div class="topmenu"><a href="search.php?id=' . $id . '">' . $lng['search'] . '</a>' . ($filelink ? ' | ' . $filelink : '') . ($wholink ? ' | ' . $wholink : '') . '</div></div>';

        /*
        -----------------------------------------------------------------
        SzN,NES+NESzS?SzSuSL N?SlS'SuNES?SlSLSlSu N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
        switch ($type1['type']) {
            case 'f':
                /*
                -----------------------------------------------------------------
                S?SzSlN?SlSa NESzS.S'SuS"SlS2 N"SlNEN?SLSz
                -----------------------------------------------------------------
                */
                echo '<div class="mainblok">';
                $req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='r' AND `refid`='$id' ORDER BY `realid`");
                $total = mysql_num_rows($req);
                if ($total) {
                    $i = 0;
                    while (($res = mysql_fetch_assoc($req)) !== false) {
                        echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
                        $coltem = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '" . $res['id'] . "'"), 0);
                        echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_'.$res['id'].'.html">' . $res['text'] . '</a>';
                        if ($coltem)
                            echo " [$coltem]";
                        if (!empty($res['soft']))
                            echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
                        echo '</div>';
                        ++$i;
                    }
                   echo '</div>';
                   unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                } else {
                    echo '<div class="menu"><p>' . $lng_forum['section_list_empty'] . '</p></div></div>';
                }
                echo '<div class="mainblok"><div class="phdr">' . $lng['total'] . ': ' . $total . '</div></div>';
                break;

            case 'r':
                /*
                -----------------------------------------------------------------
                S?SzSlN?SlSa N,SlSzSlSaSlS2
                -----------------------------------------------------------------
                */
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close`!='1'")), 0);
                if (($user_id && !isset($ban['1']) && !isset($ban['11']) && $set['mod_forum'] != 3) || core::$user_rights) {
                    // SsS?SlSzSaSz N?SlS.S'SzS?SlNZ S?SlS2SlSa N,SuSLN<
                    echo '<div class="rmenu"><form action="index.php?act=nt&amp;id=' . $id . '" method="post"><input type="submit" value="' . $lng_forum['new_topic'] . '" /></form></div>';
                }
                echo '<div class="mainblok">';
                if ($total) {
                    $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t'" . ($rights >= 7 ? '' : " AND `close`!='1'") . " AND `refid`='$id' ORDER BY `vip` DESC, `time` DESC LIMIT $start, $kmess");
                    $i = 0;
                    while (($res = mysql_fetch_assoc($req)) !== false) {
                        if ($res['close'])
                            echo '<div class="rmenu">';
                        else
                            echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
                        $nikuser = mysql_query("SELECT `from` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $res['id'] . "' ORDER BY `time` DESC LIMIT 1");
                        $nam = mysql_fetch_assoc($nikuser);
                        $colmes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m' AND `refid`='" . $res['id'] . "'" . ($rights >= 7 ? '' : " AND `close` != '1'"));
                        $colmes1 = mysql_result($colmes, 0);
                        $cpg = ceil($colmes1 / $kmess);
                        $np = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `time` >= '" . $res['time'] . "' AND `topic_id` = '" . $res['id'] . "' AND `user_id`='$user_id'"), 0);
                        // S-S?SzN?SaSl
                        $icons = array(
                            ($np ? (!$res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/op.gif" alt=""/>' : '') : '<img src="../theme/' . $set_user['skin'] . '/images/np.gif" alt=""/>'),
                            ($res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/pt.gif" alt=""/>' : ''),
                            ($res['realid'] ? '<img src="../theme/' . $set_user['skin'] . '/images/rate.gif" alt=""/>' : ''),
                            ($res['edit'] ? '<img src="../theme/' . $set_user['skin'] . '/images/tz.gif" alt=""/>' : '')
                        );
                        echo functions::display_menu($icons, '&#160;', '&#160;');
/*
-----------------------------------------------------------------
Mod Prefix waptok
-----------------------------------------------------------------
*/
            echo '<b>';
switch ($res['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;
default:
break;
}
echo '</b>';
                        echo '&nbsp;<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a> [' . $colmes1 . ']';
                        if ($cpg > 1) {
                            echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html">&#160;&gt;&gt;</a>';
                        }
                        echo '<div class="sub">';
                        echo $res['from'];
                        if (!empty($nam['from'])) {
                            echo '&nbsp;&asymp;&nbsp;' . $nam['from'];
                        }
                        echo ' <span class="gray">' . counters::update_time($res['time']) . '</span></div></div>';
                        ++$i;
                    }  
                    echo '</div>';
                    unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                } else {
                    echo '<div class="menu"><p>' . $lng_forum['topic_list_empty'] . '</p></div></div>';
                }
                echo '<div class="mainblok"><div class="phdr">' . $lng['total'] . ': ' . $total . '</div></div>';
                if ($total > $kmess) {
                    echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div>' .
                         '<p><form action="index.php?id=' . $id . '" method="post">' .
                         '<input type="text" name="page" size="2"/>' .
                         '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
                         '</form></p>';
                }
                break;

            case 't':
                /*
                -----------------------------------------------------------------
                SNSlN,SzSuSL N,SlSzSlSa
                -----------------------------------------------------------------
                */
                $filter = isset($_SESSION['fsort_id']) && $_SESSION['fsort_id'] == $id ? 1 : 0;
                $sql = '';
                if ($filter && !empty($_SESSION['fsort_users'])) {
                    // SzSlS'S"SlN,SzS2S"SlS2SzSuSL S.SzSzNESlN? S?Sz N"SlS"NSN,NESzN?SlNZ NZS.SuNESlS2
                    $sw = 0;
                    $sql = ' AND (';
                    $fsort_users = unserialize($_SESSION['fsort_users']);
                    foreach ($fsort_users as $val) {
                        if ($sw)
                            $sql .= ' OR ';
                        $sortid = intval($val);
                        $sql .= "`forum`.`user_id` = '$sortid'";
                        $sw = 1;
                    }
                    $sql .= ')';
                }
                if ($user_id && !$filter) {
                    // SRSlSaN?SzN?SlNZ N"SzSaN,Sz SzNESlN?N,SuS?SlNZ N,SlSzSlSaSz
                }
                if ($rights < 7 && $type1['close'] == 1) {
                    echo '<div class="rmenu"><p>' . $lng_forum['topic_deleted'] . '<br/><a href="?id=' . $type1['refid'] . '">' . $lng_forum['to_section'] . '</a></p></div>';
                    require('../incfiles/end.php');
                    exit;
                }
                // S?N?SuN,N?SlSa SzSlN?N,SlS2 N,SuSLN<
                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'$sql AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
                if ($start > $colmes) $start = $colmes - $kmess;
                // S'N<S2SlS'SlSL S?SzS.S2SzS?SlSu N,SlSzSlSaSz
                echo '<div class="mainblok"><div class="phdr"><a name="up" id="up"></a><a href="#down"><img src="../theme/' . $set_user['skin'] . '/images/down.png" alt="waptok" width="20" height="10" border="0"/></a>';
/*
--------------------------------------------------------
Mod Prefix waptok
--------------------------------------------------------
*/
echo ' <b>';
switch ($type1['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #0000ff">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;
default:
break;
}
echo '</b> ';
                echo '<b>' . $type1['text'] . '</b></div>';
                if ($colmes > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div>';
                    //echo '</div>';

/*
-----------------------------------------------------------------
Mod thank waptok
-----------------------------------------------------------------
*/
include 'prus_mod/like_dislike.php';

                // SsSuN,SaSl N?S'SzS"SuS?SlNZ N,SuSLN<
                if ($type1['close'])
                    echo '<div class="rmenu">' . $lng_forum['topic_delete_who'] . ': <b>' . $type1['close_who'] . '</b></div>';
                elseif (!empty($type1['close_who']) && $rights >= 7)
                    echo '<div class="gmenu"><small>' . $lng_forum['topic_delete_whocancel'] . ': <b>' . $type1['close_who'] . '</b></small></div>';
                // SsSuN,SaSl S.SzSaNEN<N,SlNZ N,SuSLN<
                if ($type1['edit'])
                    echo '<div class="rmenu">' . $lng_forum['topic_closed'] . '</div>';

      // Tags forum
      echo '<div class="gmenu"><b>Tags:</b> ';
      echo $type1['tags'];
      echo '</div>';
            //echo '</div>';

        // bookmark
        /*
        -----------------------------------------------------------------
        S-SzSaS"SzS'SaSl N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
                                                  
      if ($type1['type'] == 't' && $user_id) {
           if(!$res_r['bookmark'] && isset($_GET['addBookmark'])) {
              mysql_query("UPDATE `cms_forum_rdm` SET `bookmark` = '1' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
               $res_r['bookmark'] = 1;
         } elseif($res_r['bookmark'] && isset($_GET['delBookmark'])) {
              mysql_query("UPDATE `cms_forum_rdm` SET `bookmark` = '0' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            $res_r['bookmark'] = 0;
           }
         echo '<div class="menu">';
         echo $res_r['bookmark'] ? '<a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;delBookmark">Delete Bookmark</a>' :
           '<a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;addBookmark">Add Bookmark</a>';
      echo ' | <a href="bookmark.php">Panel Bookmark</a>';  
        

      $usersBookmark = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `bookmark` = '1'"), 0);
        if($usersBookmark && !isset($_GET['usersBookmark']))
           echo '<br /><a href="index.php?id=' . $id . '&amp;usersBookmark">' . $usersBookmark . ' Users Bookmark this thread.</a>';
       
       echo '</div></div>';
       } else {
       echo '</div>';
     }
      if(isset($_GET['usersBookmark']) && $usersBookmark) {
         echo '<div class="mainblok"><div class="phdr"><a href="index.php?id=' . $id . '">' . $type1['text'] . '</a> | Cuplikan...</div>';
            $req = mysql_query("SELECT `cms_forum_rdm`.*, `users`.`rights`, `users`.`lastdate`, `users`.`name`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
          FROM `cms_forum_rdm` LEFT JOIN `users` ON `cms_forum_rdm`.`user_id` = `users`.`id`
          WHERE `cms_forum_rdm`.`topic_id`='$id' AND `cms_forum_rdm`.`bookmark` = '1' ORDER BY `id` DESC LIMIT $start,$kmess");
            $i = 0;
          while ($res = mysql_fetch_array($req)) {
              echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
              echo functions::display_user($res, array ('iphide' => 1));
              echo '</div>';
              ++$i;
          }
            echo '<div class="phdr">Total: ' . $usersBookmark . '</div>';
         if ($usersBookmark > $kmess) {
              echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;usersBookmark&amp;', $start, $usersBookmark, $kmess) . '</div>' .
               '<p><form action="index.php?id=' . $id . '&amp;usersBookmark" method="post">' .
               '<input type="text" name="page" size="2"/>' .
               '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
          }
            echo '</div>';
            echo '<p><a href="index.php?id=' . $id . '">To Thread</a></p>';
         require_once('../incfiles/end.php');
            exit;
         }
                          
       // simple vip forum
            include 'vip_waptok.php';
                  /*
     -----------------------------------------------------------------
                S'S"SlSa S"SlS"SlN?SlS2SzS?SlSa
                -----------------------------------------------------------------
                */
                if ($type1['realid']) {
                    $clip_forum = isset($_GET['clip']) ? '&amp;clip' : '';
                    $vote_user = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote_users` WHERE `user`='$user_id' AND `topic`='$id'"), 0);
                    $topic_vote = mysql_fetch_assoc(mysql_query("SELECT `name`, `time`, `count` FROM `cms_forum_vote` WHERE `type`='1' AND `topic`='$id' LIMIT 1"));
                    echo '<div class="mainblok"><div  class="gmenu"><b>' . functions::checkout($topic_vote['name']) . '</b><br />';
                    $vote_result = mysql_query("SELECT `id`, `name`, `count` FROM `cms_forum_vote` WHERE `type`='2' AND `topic`='" . $id . "' ORDER BY `id` ASC");
                    if (!$type1['edit'] && !isset($_GET['vote_result']) && $user_id && $vote_user == 0) {
                        // S'N<S2SlS'SlSL N"SlNESLN? N? SlSzNESlN?SzSLSl
                        echo '<form action="index.php?act=vote&amp;id=' . $id . '" method="post">';
                        while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
                            echo '<input type="radio" value="' . $vote['id'] . '" name="vote"/> ' . functions::checkout($vote['name'], 0, 1) . '<br />';
                        }
                        echo '<p><input type="submit" name="submit" value="' . $lng['vote'] . '"/><br /><a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;vote_result' . $clip_forum .
                             '">' . $lng_forum['results'] . '</a></p></form></div>';
                    } else {
                        // S'N<S2SlS'SlSL NESuS.N?S"NSN,SzN,N< S"SlS"SlN?SlS2SzS?SlNZ
                        echo '<small>';
                        while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
                            $count_vote = $topic_vote['count'] ? round(100 / $topic_vote['count'] * $vote['count']) : 0;
                            echo functions::checkout($vote['name'], 0, 1) . ' [' . $vote['count'] . ']<br />';
                            echo '<img src="vote_img.php?img=' . $count_vote . '" alt="' . $lng_forum['rating'] . ': ' . $count_vote . '%" /><br />';
                        }
                        echo '</small></div><div class="phdrblack">' . $lng_forum['total_votes'] . ': ';
                        if ($datauser['rights'] > 6)
                            echo '<a href="index.php?act=users&amp;id=' . $id . '">' . $topic_vote['count'] . '</a>';
                        else
                            echo $topic_vote['count'];
                        echo '</div>';
                        if ($user_id && $vote_user == 0)
                            echo '<div class="bmenu"><a href="index.php?id=' . $id . '&amp;start=' . $start . $clip_forum . '">' . $lng['vote'] . '</a></div>';
                    }
  echo'</div>';
                }
                $curators = !empty($type1['curators']) ? unserialize($type1['curators']) : array();
                $curator = false;
                if ($rights < 6 && $rights != 3 && $user_id) {
                    if (array_key_exists($user_id, $curators)) $curator = true;
                }
                /*
                -----------------------------------------------------------------
                SRSlSaN?SzN?SlNZ SzSuNES2SlS"Sl SzSlN?N,Sz S2 N,SuSLSu
                -----------------------------------------------------------------
                */
                if (($set_forum['postclip'] == 2 && ($set_forum['upfp'] ? $start < (ceil($colmes - $kmess)) : $start > 0)) || isset($_GET['clip'])) {
                    $postreq = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
                    FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                    WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
                    ORDER BY `forum`.`id` LIMIT 1");
                    $postres = mysql_fetch_assoc($postreq);
                    echo '<div class="topmenu"><p>';
                    if ($postres['sex'])
                        echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($postres['sex'] == 'm' ? 'm' : 'w') . ($postres['datereg'] > time() - 86400 ? '_new.png" width="14"' : '.png" width="10"') . ' height="10"/>&#160;';
                    else
                        echo '<img src="../images/del.png" width="10" height="10" alt=""/>&#160;';
                    if ($user_id && $user_id != $postres['user_id']) {
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$postres['user_id']. "' LIMIT 1;"), 0);
echo '<a href="../' .$name_lat. '/?fid=' . $postres['id'] . '"><b>' . $postres['from'] . '</b></a> ' .
'<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '"> ' . $lng_forum['reply_btn'] . '</a> ' .
'<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '&amp;cyt"> ' . $lng_forum['cytate_btn'] . '</a> ';
} else {
echo '<b>' . $postres['from'] . '</b> ';
}

/*
-----------------------------------------------------------------
Mod Pangkat waptok
-----------------------------------------------------------------
*/
if ($res['postforum'] != 0) {
$arank = $res['postforum'];
if ($arank <= 75)
$arank = 'Newbie';
elseif ($arank <= 200)
$arank = ''.$set['copyright'].' User';
elseif ($arank <= 400)
$arank = ''.$set['copyright'].' Activist';
elseif ($arank <= 600)
$arank = ''.$set['copyright'].' Holic';
elseif ($arank <= 850)
$arank = ''.$set['copyright'].' Addict';
elseif ($arank <= 1200)
$arank = ''.$set['copyright'].' Maniac';
elseif ($arank <= 3200)
$arank = ''.$set['copyright'].' Geek';
elseif ($arank <= 4500)
$arank = ''.$set['copyright'].' Freak';
elseif ($arank >= 5000)
$arank = 'Made in '.$set['copyright'].'';
}
if (!empty($res['pangkat'])){
$jenenge = '' . bbcode::tags($res['pangkat']). '';
}else{
$jenenge = ''.$arank.'';
}
$user_rights = array(
0 => '' . $jenenge . '',
3 => 'Moderator',
6 => 'Staff',
7 => 'Admin',
9 => '<font color="#CC6600">Head Admin</font>'
);

echo @$user_rights[$postres['rights']];
echo (time() > $postres['lastdate'] + 300 ? '<span class="red"> &bull;</span>' : '<span class="green"> &bull;</span>');
echo ' <span class="gray">(' . functions::display_date($postres['time']) . ')</span><br/>';
                    if ($postres['close']) {
                        echo '<span class="red">' . $lng_forum['post_deleted'] . '</span><br/>';
                    }
                    echo functions::checkout(mb_substr($postres['text'], 0, 500), 0, 2);
                    if (mb_strlen($postres['text']) > 500)
                        echo '...<a href="index.php?act=post&amp;id=' . $postres['id'] . '">' . $lng_forum['read_all'] . '</a>';
                    echo '</p></div>';
                }
                if ($filter)
                    echo '<div class="rmenu">' . $lng_forum['filter_on'] . '</div>';
                // S-SzS'SzSuSL SzNESzS2SlS"Sz N?SlNEN,SlNESlS2SaSl (S?SlS2N<Su S2S?SlS.N? / S2S2SuNENaN?)
                if ($user_id)
                    $order = $set_forum['upfp'] ? 'DESC' : 'ASC';
                else
                    $order = ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) ? 'ASC' : 'DESC';
                // S-SzSzNESlN? S2 S+SzS.N?
                $req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`postforum`, `users`.`podpis`, `users`.`pangkat`, `users`.`datereg`
                FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'"
                                   . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "$sql ORDER BY `forum`.`id` $order LIMIT $start, $kmess");
                // S'SuNENaS?SuSu SzSlS"Su "StSzSzSlN?SzN,NS"
                if (($user_id && !$type1['edit'] && $set_forum['upfp'] && $set['mod_forum'] != 3) || ($rights >= 7 && $set_forum['upfp'])) {
echo '<div class="phdr">Quick Reply</div><div class="gmenu"><form name="form1" action="index.php?act=say&amp;id=' . $id . '" method="post">';
if ($set_forum['farea']) {
echo '<p>' .
(!$is_mobile ? bbcode::auto_bb('form1', 'msg') : '') .
'<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea></p>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'] .
($set_user['translit'] ? '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'] : '') .
'</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div>';
} else {
echo '<p><input type="submit" name="submit" value="' . $lng['write'] . '"/></p></form></div>';
}
}
if ($rights == 3 || $rights >= 6)
echo '<form action="index.php?act=massdel" method="post">';
$i = 1;
$nomer = $page ? $page * 10 + 1 : 1;
                while (($res = mysql_fetch_assoc($req)) !== false) {
                    if ($res['close'])
                        echo '<div class="rmenu">';
                    else
                        echo $i % 2 ? '<div class="mainblok">' : '<div class="mainblok">';
echo '<div class="phdr"><table width="100%" cellpadding="0" cellspacing="0"><tr>' .
'<td width="auto"><img src="../images/op.gif">&nbsp;' . functions::display_date($res['time']) . '</td>' .
'<td width="auto" align="right">#<a href="'.$home.'/forum/' . functions::gantiurl($type1['text']) . '_p' . $res['id'] . '.html">'.($nomer - 10).'</a></td></tr></table></div>';
echo '<div class="newsx">';
if ($set_user['avatar']) {
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td width="32" align="left" valign="top">';
if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
echo '<span class="avatar"><img src="../files/users/avatar/' . $res['user_id'] . '.png" width="32" height="32" alt="' . $res['from'] . '" /></span>';
else
echo '<span class="avatar"><img src="../images/empty.png" width="32" height="32" alt="' . $res['from'] . '" /></span> ';
}

echo '</td><td width="auto" align="left" valign="top">';
if (!empty($user_id) && ($user_id != $res['user_id'])) {
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$res['user_id']. "' LIMIT 1;"), 0);
echo '&nbsp;<a href="../' .$name_lat. '"><b>' . $res['from'] . '</b></a> ';
} else {
echo '&nbsp;<b>' . $res['from'] . '</b>&nbsp;';
}
echo (time() > $res['lastdate'] + 300 ? '<span class="red"> &bull;</span>':'<span class="green"> &bull;</span>');
echo '<br />&nbsp;';

/*
-----------------------------------------------------------------
Mod Pangkat waptok
-----------------------------------------------------------------
*/
if ($res['postforum'] != 0) {
$arank = $res['postforum'];
if ($arank <= 75)
$arank = 'Newbie';
elseif ($arank <= 200)
$arank = ''.$set['copyright'].' User';
elseif ($arank <= 400)
$arank = ''.$set['copyright'].' Activist';
elseif ($arank <= 600)
$arank = ''.$set['copyright'].' Holic';
elseif ($arank <= 850)
$arank = ''.$set['copyright'].' Addict';
elseif ($arank <= 1200)
$arank = ''.$set['copyright'].' Maniac';
elseif ($arank <= 3200)
$arank = ''.$set['copyright'].' Geek';
elseif ($arank <= 4500)
$arank = ''.$set['copyright'].' Freak';
elseif ($arank >= 5000)
$arank = 'Made in '.$set['copyright'].'';
}
if (!empty($res['pangkat'])){
$jenenge = '' . bbcode::tags($res['pangkat']). '';
}else{
$jenenge = ''.$arank.'';
}

/*
-----------------------------------------------------------------
Mod pangkat ori
-----------------------------------------------------------------
*/
$user_rights = array(
0 => '' . $jenenge . '',
3 => 'Moderator',
6 => 'Staff',
7 => 'Admin',
9 => '<font color="#CC6600">Head Admin</font>'
);

 
echo @$user_rights[$res['rights']];
echo '</td><td width="auto" align="right" valign="top">';
                                           
/*
-------------------------------------------------
Mod Total Post waptok
-----------------------------------------------------------------
*/
if ($user_id && $user_id != $res['user_id'])
echo '<a href="../users/pradd.php?act=write&amp;adr=' . $res['user_id'] . '"><b>PM <img src="../images/pm.png"></b></a><br/>';
echo 'Post: <a href="/users/profile.php?act=activity&amp;user=' . $res['user_id'] . '">' . $res['postforum'] . '</a>';

//if (!empty($res['status']))
// Mod total thanks
$waptok = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_thank` WHERE `user` = " . $res['user_id'] . ";"), 0);
echo '<br/><img src="jempol.gif" width="14" height="14" alt="waptokthank"/> ' . $waptok . '';

//echo '<br/>' . $res['status'] . '';
if ($set_user['avatar'])
echo '</td></tr></table>';
include 'rank.php';
echo '</div>';

if ($res['close'])
echo '<div class="forum_del_txt">';
else
echo '<div class="forumtxt">';

/*
-----------------------------------------------------------------
Mod thank waptok
-----------------------------------------------------------------
*/
                                               
// include ('prus_mod/ngusere_seneng.php');
include ('prus_mod/ngusere.php');

                    /*
                    -----------------------------------------------------------------
                    S'N<S2SlS' N,SuSaN?N,Sz SzSlN?N,Sz
                    -----------------------------------------------------------------
                    */
                    $text = $res['text'];
                    if ($set_forum['postcut']) {
                        // SRN?S"Sl N,SuSaN?N, S'S"SlS?S?N<Sa, SlS+NESuS.SzSuSL Sl S'SzSuSL N?N?N<S"SaN? S?Sz SzSlS"S?N<Sa S2SzNESlSzS?N,
                        switch ($set_forum['postcut']) {
                            case 2:
                                $cut = 1000000;
                                break;

                            case 3:
                                $cut = 3000000;
                                break;
                            default :
                                $cut = 15000000;
                        }
                    }
                    if ($set_forum['postcut'] && mb_strlen($text) > $cut) {
                        $text = mb_substr($text, 0, $cut);
                        $text = functions::checkout($text, 1, 1);
                        $text = preg_replace('#\[c\](.*?)\[/c\]#si', '<div class="quote">\1</div>', $text);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 : 0);
                        echo bbcode::notags($text) . '...<br /><a href="'.$home.'/forum/' . functions::gantiurl($type1['text']) . '_p' . $res['id'] . '.html">' . $lng_forum['read_all'] . ' &gt;&gt;</a>';
                    } else {
                        // S~S"Sl, SlS+NESzS+SzN,N<S2SzSuSL N,NTS"Sl Sl S2N<S2SlS'SlSL S2SuN?NS N,SuSaN?N,
                        $text = functions::checkout($text, 1, 1);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 : 0);
if($user_id) {
$text = str_replace('[you]', $login, $text);
}
else {
$text = str_replace('[you]', 'Guest', $text);
}
$checkthank = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $res['id'] . '" and `user` = "' . $res['user_id'] . '"');
$thankcheck = mysql_result($checkthank, 0);
if($thankcheck < 1 && $user_id != $res['user_id']) {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '<div class="rmenu"><center><b>Hidden content</b></center></div><div class="rmenu"><center>Please Thank this article to be considered hidden content</center></div>', $text);
} else {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '\1', $text);
}
                        echo $text;
if (($start + $i) == 1){
echo '<br>';
//echo '<p><a href="http://api.idhostinger.com/redir/453842"> FREE @Webhosting for all !</a></p>';                
                                       
}
                    }
                    if ($res['kedit']) {
echo '<br/><span class="gray"><small>Edited</small>&nbsp;<b>' . $res['edit'] . '</b>&nbsp;(' . functions::display_date($res['tedit']). ') <b>[' . $res['kedit'] . ']</b></span>';
}
                    // SRN?S"Sl SuN?N,NS SzNESlSaNESuSzS"SuS?S?N<Sa N"SzSaS", S2N<S2SlS'SlSL SuS"Sl SlSzSlN?SzS?SlSu
$freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] . "'");
                    if (mysql_num_rows($freq) > 0) {
                        $fres = mysql_fetch_assoc($freq);
                        $fls = round(@filesize('../files/forum/attach/' . $fres['filename']) / 1024, 2);
                        echo '<div class="func"><span class="gray">' . $lng_forum['attached_file'] . ':';
                        // SzNESuS'SzNESlN?SLSlN,NE SlS.SlS+NESzS?SuS?SlSa
                        $att_ext = strtolower(functions::format('./files/forum/attach/' . $fres['filename']));
                        $pic_ext = array(
                            'gif',
                            'jpg',
                            'jpeg',
                            'png'
                        );
if (in_array($att_ext, $pic_ext)) {
echo '<div><a href="index.php?act=file&amp;id=' . $fres['id'] . '">';
echo '<img src="thumbinal.php?file=' . (urlencode($fres['filename'])) . '" alt="' . $lng_forum['click_to_view'] . '" /></a></div>';
                        } else {
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3){
echo '<br /><b>File Locked <img src="../images/lock.gif"/></b><p><span class="red">Min 3 Posts, To Download This File</span></p>';
} else {
echo '<br /><a href="index.php?act=file&amp;id=' . $fres['id'] . '">' . $fres['filename'] . '</a>';
echo ' (' . $fls . ' kb)<br/>';
echo $lng_forum['downloads'] . ': ' . $fres['dlcount'] . ' ' . $lng_forum['time'] . '</span>';
$file_id = $fres['id'];
     if ($rights >= 6)
echo' <a href="index.php?act=delfile&amp;id=' . $fres['id'] . '">Delete attachment</a>';
if ($fls == 0) {
echo'<br/><span style="color : #ff0000">File has been deleted</span>';
}                    
}
                    }
echo '</div>';
}
include ('prus_mod/ngusere_seneng.php');
            
echo '</div>';

/*
-----------------------------------------------------------------
Mod signature waptok
-----------------------------------------------------------------
*/
if(!empty($res['podpis']))
echo '<div class="nonex">&#160;<small>' . functions::smileys(bbcode::tags($res['podpis'])) . '</small></div>';
echo '<div class="forumb"><table width="100%" cellspacing="0" cellpadding="0"><tr><td width="auto" align="left">';
if (($start + $i) == 1){
if ($user_id && $user_id != $res['user_id']) {
if (!$datauser['karma_off'] && (!$user['rights'] || ($user['rights'] && !$set_karma['adm'])) && $user['ip'] != $datauser['ip']) {
$sum = mysql_result(mysql_query("SELECT SUM(`points`) FROM `karma_users` WHERE `user_id` = '$user_id' AND `time` >= '" . $datauser['karma_time'] . "'"), 0);
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `karma_users` WHERE `user_id` = '$user_id' AND `karma_user` = '" .$res['user_id']. "' AND `time` > '" . (time() - 86400) . "'"), 0);
if (!$ban && $datauser['postforum'] >= $set_karma['forum'] && $datauser['total_on_site'] >= $set_karma['karma_time'] && ($set_karma['karma_points'] - $sum) > 0 && !$count) {
echo '<a href="/users/profile.php?act=karma&amp;mod=vote&amp;user=' .$res['user_id']. '"><b><span class="green">Cendol</span></b></a>&nbsp;';
}
}
}
}

/*
----------------------------------------------------------------------------------------------------------------------------------
Mod thanks waptok
----------------------------------------------------------------------------------------------------------------------------------
*/
if ($user_id && $user_id != $res['user_id']) {
include ('prus_mod/ngusere_prus.php');
}

echo '&nbsp;';
echo '</td><td width="auto" align="right">';
if ($user_id && $user_id != $res['user_id']) {
echo ' <a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '"><img src="../images/reply.png" alt="Reply" /></a>&#160;' .'<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '&amp;cyt"><img src="../images/fquote.png" alt="Quote" /></a>';
} else {
                                           
  
if ( $user_id == $res [ 'user_id' ])
echo '<b>Follow:</b> <a href="http://www.facebook.com/sharer.php?u=http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><img src="/images/social/facebook.png" align="middle" border="0" width="16" height="16" title="Share on Facebook" alt="Facebook"/></a><a href="http://twitter.com/home?status=http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><img src="/images/social/twitter.png" align="middle" border="0" width="16" height="16" title="Share on Twitter" alt="Twitter"/></a> ';
           
if ( $user_id == $res [ 'user_id' ])
echo '<a href="index.php?id=' . $res [ 'id' ]. '&act=addfile"><font color="blue">Upload</font></a>';
if ( $user_id == $res [ 'user_id' ])
echo ' | <a href="index.php?id=' . $res[ 'id' ]. '&act=import"><font color="blue">Import</font></a>';

                                                     
}

                       
echo '</td></tr></table></div>';

                    if ((($rights == 3 || $rights >= 6 || $curator) && $rights >= $res['rights']) || ($res['user_id'] == $user_id && !$set_forum['upfp'] && ($start + $i) == $colmes && $res['time'] > time() - 999999999) || ($res['user_id'] == $user_id && $set_forum['upfp'] && $start == 0 && $i == 1 && $res['time'] > time() - 999999999)) {
                        // S?N?N<S"SaSl S?Sz NESuS'SzSaN,SlNESlS2SzS?SlSu / N?S'SzS"SuS?SlSu SzSlN?N,SlS2
                        $menu = array(
                            '<a href="index.php?act=editpost&amp;id=' . $res['id'] . '">' . $lng['edit'] . '</a>',
                            ($rights >= 7 && $res['close'] == 1 ? '<a href="index.php?act=editpost&amp;do=restore&amp;id=' . $res['id'] . '">' . $lng_forum['restore'] . '</a>' : ''),
                            ($res['close'] == 1 ? '' : '<a href="index.php?act=editpost&amp;do=del&amp;id=' . $res['id'] . '">' . $lng['delete'] . '</a>')
                        );
                        echo '<div class="sub">';
                        if ($rights == 3 || $rights >= 6)
                            echo '<input type="checkbox" name="delch[]" value="' . $res['id'] . '"/>&#160;';
                        echo functions::display_menu($menu);
                        if ($res['close']) {
                            echo '<div class="red">' . $lng_forum['who_delete_post'] . ': <b>' . $res['close_who'] . '</b></div>';
                        } elseif (!empty($res['close_who'])) {
                            echo '<div class="green">' . $lng_forum['who_restore_post'] . ': <b>' . $res['close_who'] . '</b></div>';
                        }
                        if ($rights == 3 || $rights >= 6) {
                            if ($res['ip_via_proxy']) {
                                echo '<div class="gray"><b class="red"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip']) . '">' . long2ip($res['ip']) . '</a></b> - ' .
                                     '<a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip_via_proxy']) . '">' . long2ip($res['ip_via_proxy']) . '</a>' .
                                     ' - ' . $res['soft'] . '</div>';
                            } else {
                                echo '<div class="gray"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($res['ip']) . '">' . long2ip($res['ip']) . '</a> - ' . $res['soft'] . '</div>';
                                  }
                        }
                        echo '</div>';
                    }
                    echo '</div>';
                    ++$nomer;
                    ++$i;
                }
                if ($rights == 3 || $rights >= 6) {
                    echo '<div class="rmenu"><input type="submit" value=" ' . $lng['delete'] . ' "/></div>';
                    echo '</form>';
                }

/*
-----------------------------------------------------------------
Mod quick posting waptok
-----------------------------------------------------------------
*/
 if (($user_id && !$type1['edit'] && !$set_forum['upfp'] && $set['mod_forum'] != 3) || ($rights >= 7 && !$set_forum['upfp'])) {
echo '<div class="mainblok"><div class="phdr">Quick Reply</div><div class="newsx"><form name="form2" action="index.php?act=say&amp;id=' . $id . '" method="post">';
if ($set_forum['farea']) {
echo bbcode::auto_bb('form2', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'];
if ($set_user['translit'])
echo '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'];
echo '</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div></div>';
} else {
echo bbcode::auto_bb('form2', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea>
</p>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'];
if ($set_user['translit'])
echo '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'];
echo '</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 107px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
'</p></form></div></div>';
}
}

echo '<div class="mainblok">';
echo '<div class="phdr"><a name="down" id="down"></a><a href="#up">' .
'<img src="../theme/' . $set_user['skin'] . '/images/up.png" alt="' . $lng['up'] . '" width="20" height="10" border="0"/></a>' .
'&#160;&#160;' . $lng['total'] . ': ' . $colmes . '</div>';
if ($colmes > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination2(''.$home.'/forum/'.functions::gantiurl($type1["text"]).'_' . $id, $start, $colmes, $kmess) . '</div></div>' .
'<form action="index.php?id=' . $id . '" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
'</form>';
}else{
echo '</div>';
}
                                       
include 'last_forum_upload.php';

echo '<div class="mainblok"><div class="phdr"><b>Share this article</b></div>';
echo '<div class="menu">';
include '../share.php';
echo '<br/>';
echo '<b>BB Code:</b><br/><input type="text" size="18" value="[url='.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html]'.$type1["text"].'[/url]"/><br/><b>Link:</b><br/><input type="text" size="18" value="'.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html"/>';
echo '</div></div>';
                                      

/*
-----------------------------------------------------------------
Mod similar topic waptok
-----------------------------------------------------------------
*/
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `refid`='$type1[refid]' AND `id`!='$id' ORDER BY `vip` DESC, `time` DESC LIMIT 5");
$total = mysql_num_rows($req);
if($total!=0){
echo '<div class="mainblok"><div class="phdrblack">Similar topics</div><div>';
while ($res = mysql_fetch_assoc($req)) {
echo ($i % 2) ? '<div class="menub">' : '<div class="menub">';
echo '<b>';

/*
-----------------------------------------------------------------
Mod Prefix waptok
-----------------------------------------------------------------
*/
switch ($res['waptok']){
case 0 :
echo '<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '<span style="color: #0000ff">[NOTIFE]</span>';
break;
default:
break;
}
echo '</b>';
echo '&nbsp;<a href="'.$home.'/forum/'.functions::gantiurl($res['text']).'_' . $res['id'] . '.html">' . $res['text'] . '</a>';
echo '</div>';
++$i;
}
echo '</div>';
echo '<div class="phdrblack">';
if ($filter)
echo '<div><a href="index.php?act=filter&amp;id=' . $id . '&amp;do=unset">' . $lng_forum['filter_cancel'] . '</a></div>';
else
echo '<a href="index.php?act=filter&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['filter_on_author'] . '</a> ' .
'| <a href="index.php?act=tema&amp;id=' . $id . '">' . $lng_forum['download_topic'] . '</a>';
echo '</div></div>';
}
                /*
                -----------------------------------------------------------------
                S?N?N<S"SaSl S?Sz SLSlS'SuNESzN,SlNEN?SaSlSu N"N?S?SaN?SlSl
                -----------------------------------------------------------------
                */
                if ($curators) {
                    $array = array();
                    foreach ($curators as $key => $value)
                        $array[] = '<a href="../users/profile.php?user=' . $key . '">' . $value . '</a>';
                    echo '<p><div class="func">' . $lng_forum['curators'] . ': ' . implode(', ', $array) . '</div></p>';
                }
                if ($rights == 3 || $rights >= 6) {
                    echo '<p><div class="func">';
                    if ($rights >= 7)
                        echo '<a href="index.php?act=curators&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['curators_of_the_topic'] . '</a><br />';
                    echo isset($topic_vote) && $topic_vote > 0
                            ? '<a href="index.php?act=editvote&amp;id=' . $id . '">' . $lng_forum['edit_vote'] . '</a><br/><a href="index.php?act=delvote&amp;id=' . $id . '">' . $lng_forum['delete_vote'] . '</a><br/>'
                            : '<a href="index.php?act=addvote&amp;id=' . $id . '">' . $lng_forum['add_vote'] . '</a><br/>';
                    echo '<a href="index.php?act=ren&amp;id=' . $id . '">' . $lng_forum['topic_rename'] . '</a><br/>';
                    // S-SzSaNEN<N,NS - SlN,SaNEN<N,NS N,SuSLN?
                    if ($type1['edit'] == 1)
                        echo '<a href="index.php?act=close&amp;id=' . $id . '">' . $lng_forum['topic_open'] . '</a><br/>';
                    else
                        echo '<a href="index.php?act=close&amp;id=' . $id . '&amp;closed">' . $lng_forum['topic_close'] . '</a><br/>';
                    // S<S'SzS"SlN,NS - S2SlN?N?N,SzS?SlS2SlN,NS N,SuSLN?
                    if ($type1['close'] == 1)
                        echo '<a href="index.php?act=restore&amp;id=' . $id . '">' . $lng_forum['topic_restore'] . '</a><br/>';
                    echo '<a href="index.php?act=deltema&amp;id=' . $id . '">' . $lng_forum['topic_delete'] . '</a><br/>';
                    if ($type1['vip'] == 1)
                        echo '<a href="index.php?act=vip&amp;id=' . $id . '">' . $lng_forum['topic_unfix'] . '</a>';
                    else
                        echo '<a href="index.php?act=vip&amp;id=' . $id . '&amp;vip">' . $lng_forum['topic_fix'] . '</a>';
                    echo '<br/><a href="index.php?act=per&amp;id=' . $id . '">' . $lng_forum['topic_move'] . '</a></div></p>';
                }
                //if ($wholink)
                    //echo '<div>' . $wholink . '</div>';
                //if ($filter)
                    //echo '<div><a href="index.php?act=filter&amp;id=' . $id . '&amp;do=unset">' . $lng_forum['filter_cancel'] . '</a></div>';
                //else
                    //echo '<div><a href="index.php?act=filter&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['filter_on_author'] . '</a></div>';
                //echo '<a href="index.php?act=tema&amp;id=' . $id . '">' . $lng_forum['download_topic'] . '</a>';
                break;

            default:
                /*
                -----------------------------------------------------------------
                SRN?S"Sl S?SuS2SuNES?N<Su S'SzS?S?N<Su, SzSlSaSzS.N<S2SzSuSL SlN^SlS+SaN?
                -----------------------------------------------------------------
                */
                echo functions::display_error($lng['error_wrong_data']);
                break;
        }
    } else {
        /*
  -----------------------------------------------------------------
        S?SzSlN?SlSa SsSzN,SuS"SlNESlSa N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
        echo '<p>' . counters::forum_new(1) . '</p>' .
             '<div class="mainblok"><div class="phdr"><b>' . $lng['forum'] . '</b></div>' .
             '<div class="topmenu"><a href="search.php">' . $lng['search'] . '</a> | <a href="index.php?act=files">' . $lng_forum['files_forum'] . '</a> <span class="red">(' . $count . ')</span></div>';
        $req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        while (($res = mysql_fetch_array($req)) !== false) {
            echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
            echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a> [' . $count . ']';
            if (!empty($res['soft']))
                echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
            echo '</div>';
            ++$i;
        }
        $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        echo '<div class="phdr">' . ($user_id ? '<a href="index.php?act=who">' . $lng_forum['who_in_forum'] . '</a>' : $lng_forum['who_in_forum']) . '&#160;(' . $online_u . '&#160;/&#160;' . $online_g . ')</div></div>';
        unset($_SESSION['fsort_id']);
        unset($_SESSION['fsort_users']);
    }

    // StSzS2SlS"SzN?SlNZ S2S?SlS.N? N?N,NESzS?SlN?N<
    echo '<p>' . ($id ? '<a href="index.php">' . $lng['to_forum'] . '</a><br />' : '');
    if (!$id) {
        echo '<a href="../pages/faq.php?act=forum">' . $lng_forum['forum_rules'] . '</a><br/>';
        echo '<a href="index.php?act=moders">' . $lng['moders'] . '</a>';
    }
    echo '</p>';
    if (!$user_id) {
        if ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) {
              echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newup">' . $lng_forum['new_on_top'] . '</a>';
        } else {
              echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newdown">' . $lng_forum['new_on_bottom'] . '</a>';
        }
    }
}
                                                                                                  
require_once('../incfiles/end.php');

?>