<?php
define('_IN_JOHNCMS', 1);
$headmod = 'bookmark';
require ('../incfiles/core.php');
$textl = 'Bookmark forum';
require ('../incfiles/head.php');

if (!$user_id) {
    echo 'You are not logged in';
    require ('../incfiles/end.php');
    exit;
}

echo '<div class="mainblok"><div class="phdr"><b>Bookmark forum</b></div>';

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum`
LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
WHERE `forum`.`type`='t'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . " AND `cms_forum_rdm`.`bookmark` = '1'"), 0);

if ($total) {   $req = mysql_query("SELECT * FROM `forum`
   LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
   WHERE `forum`.`type`='t'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
   AND `cms_forum_rdm`.`bookmark` = '1' ORDER BY `forum`.`time` DESC LIMIT $start, $kmess");
   while (($res = mysql_fetch_assoc($req)) !== false) {
        if ($res['close']) echo '<div class="rmenu">';
        else echo $i++ % 2 ? '<div class="list2">' : '<div class="list1">';
        $post = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $res['id'] . "' ORDER BY `time` DESC LIMIT 1"));
        $totalPost = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m' AND `refid`='" . $res['id'] . "'" . ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
        $pagesEnd = ceil($totalPost / $kmess);
      if(!$res['vip']) echo  '<img src="../theme/' . $set_user['skin'] . '/images/np.gif" alt=""/>&nbsp;';
      if($res['vip']) echo  '<img src="../theme/' . $set_user['skin'] . '/images/pt.gif" alt=""/>&nbsp;';
        if($res['realid']) echo  '<img src="../theme/' . $set_user['skin'] . '/images/rate.gif" alt=""/>&nbsp;';
        if($res['edit']) echo '<img src="../theme/' . $set_user['skin'] . '/images/tz.gif" alt=""/>&nbsp;';
        echo $res['from'] . ' <span class="gray">(' . functions::display_date($res['time']) . ')</span><br />' .
      '<a href="index.php?id=' . $res['id'] . '">' . $res['text'] . '</a> [' . $totalPost . ']';
        if ($pagesEnd > 1) echo '<a href="index.php?id=' . $res['id'] . '&amp;page=' . $pagesEnd . '">&#160;&gt;&gt;</a>';
        if($post['text']) {
           $text = bbcode::tags(functions::checkout(mb_substr($post['text'], 0, 150), 1, 1));
            if(mb_strlen($post['text']) > 150) $text .= ' <a href="index.php?act=post&amp;id=' . $post['id'] . '"> &gt;&gt;</a>';
         echo '<div class="sub">' . $post['from'] . ' <span class="gray">(' . functions::display_date($post['time']) . ')</span><br />' . $text . '</div>';

          }
      echo '</div>';
   }
} else
   echo '<div class="menu"><p>Empty!</p></div>';
echo '<div class="phdr">Total: ' . $total . '</div>';

if ($total > $kmess) {
   echo '<div class="topmenu">' . functions::display_pagination('bookmark.php?', $start, $total, $kmess) . '</div>' .
   '<p><form action="bookmark.php" method="post"><input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';

}
   echo '</div>';

echo '<p><a href="profile.php?act=office">My Profile</a><br /><a href="index.php">Forum</a></p>';

require_once ('../incfiles/end.php');

?>
