<?php
// last blog with preview image
// jika ingin memakai last blog dengan preview image ini rename menjadi last_blog.php

echo '<div class="mainblok"><div class="phdr"><b>Last Blog</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog`"), 0);
      if($total) {
         $req = mysql_query("SELECT `id`,`user_id`, `name`, `count`, `text`, `time` FROM `blog` ORDER BY `id` DESC LIMIT 3");
         $i = 1;
         while (($row = mysql_fetch_assoc($req)) !== false) {
            echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
            if(file_exists('files/blog/small_news_' . $row['id'] . '.jpg') !== false) {
               echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="48">';
               echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../files/blog/small_news_' . $row['id'] . '.jpg" alt="" width="48" height="48"/>&#160;';
               echo '</td><td>';
               echo '<a href="../blog/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '</a><br/>(' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/>';
               echo '</td></tr></table>';
            } else {
               echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="48">';
               echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../blog/default.png" alt="" title="no images" width="48" height="48"/>&#160;';
               echo '</td><td>';
               echo '<a href="../blog/' . functions::gantiurl($row['name']) . '_' . $row['id'] . '.html">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '</a><br/> (' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/>';
               echo '</td></tr></table>';
            }
            echo '<div class="sub"></div>';
            $text = $row['text'];
            if(mb_strlen($text) > 100) {
               $str = mb_substr($text, 0, 100);
               $text = mb_substr($str, 0, mb_strrpos($str, ' ')) . '...';
            }
            echo functions::checkout($text, 2, 1);
            
            $us = mysql_query("SELECT `id`, `name` FROM `users` WHERE `id` = '".$row['user_id']."'");         
              if (mysql_num_rows($us)) {
         $rowuse = mysql_fetch_assoc($us);
         $name_use = $user_id ? '<a href="../users/profile.php?id=' . $rowuse['id'] . '">' . $rowuse['name'] . '</a>' : $rowuse['name'];
      } else {
         $name_use = $lng['guest'];
      }
             
               echo '</div>';
            
             
           echo '<div class="gmenu" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><a href="../blog/comments.php?id=' . $row['id'] . '">Komentar:</a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `refid`= '".$row['id']."' "), 0) . ')';
              echo '</td><td width="auto" align="right">Dilihat: '.$row['count'].' kali ';
echo '</td></tr></table>';
              echo '<div align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">Penulis:<a href="../users/profile.php?user=' . $rowuse['id'] . '"> ' . $rowuse['name'] . '</a>';
            echo '</td><td width="auto" align="right">' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . '';
echo '</td></tr></table></div></div>';
            
            ++$i;
         }
}
              echo '<div class="bmenu" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">' . $lng['total'] . ': ' . $total . '';

              echo '</td><td width="auto" align="right"><a href="/blog">More...</a>';
echo '</td></tr></table></div>';
   
         
echo '</div>';
         


?>
