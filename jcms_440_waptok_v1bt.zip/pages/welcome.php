<?php

if ($user_id){
} else {
echo '<div class="mainblok"><div class="phdr"><b>Welcome Friends</b></div>';
echo '<table><tr><td><img style="float": left; margin: 5px 6px 2px 2px; border: 0px src="/images/rumah.png" width="50" height="50"></td>';
echo '<td><b><u>Selamat Datang di <font color="blue">Waptok ID Community</b></font></u><br />Silakan lakukan <a href="/registration.php"><b>Registrasi</b></a> atau <a href="/login.php"><b>Login</b></a> agar dapat mengakses seluruh fitur wapsite ini. Terima Kasih Atas Kunjungannya.';
echo '</td></tr></table></div>';
}


?>