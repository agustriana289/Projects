<?
/** Recent Upload Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * http://waptok.asia
 */

$req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `type` = 'file'");
$total = mysql_result($req, 0);
    
    $req = mysql_query("SELECT * FROM `download` WHERE `type` = 'file' ORDER BY `id` DESC LIMIT 5");
$i = 0;
 {
echo '<div class="mainblok"><div class="phdr"><b>Recent Upload</b></div>'; 
    while ($newf = mysql_fetch_array($req)) {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        $fsz = filesize("download/$newf[adres]/$newf[name]");
        $fsz = round($fsz / 1024, 2);
        $ft = functions::format("$newf[adres]/$newf[name]");
        switch ($ft) {
            case "mp3" :
                $imt = "mp3.png";
                break;
            case "zip" :
                $imt = "rar.png";
                break;
            case "jar" :
                $imt = "jar.png";
                break;
            case "gif" :
                $imt = "gif.png";
                break;
            case "jpg" :
                $imt = "jpg.png";
                break;
            case "png" :
                $imt = "png.png";
                break;
            default :
                $imt = "file.gif";
                break;
        }
        echo '<img class="middle" src="images/arrow.png" alt="last upload"/> <a href="/download/?act=view&amp;file=' . $newf['id'] . '">' . htmlentities($newf['name'], ENT_QUOTES, 'UTF-8') . '</a> (' . $fsz . ' kB)';
        $l = mb_strlen($pat);
        $pat1 = mb_substr($pat, 0, $l - 1);
echo '</div>';
        ++$i;
    }
    if ($total == 0) {
    echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo'</div>';
}
?>