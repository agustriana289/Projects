<?php
/**
 * Change Theme Jcms v440
 * http://www.waptok.asia
 */

echo'<div class="mainblok"><div class="phdr"><b>Change Theme</b></div>';
echo'<div class="menu">';
if ($user_id || $set['active']) {
echo '<form action="' . $rootpath . 'users/?act=setskin" method="post" ><select name="skin">';
foreach (glob($rootpath . 'theme/*/*.css') as $val) {
$dir = explode('/', dirname($val));
$theme = array_pop($dir);
echo '<option' . (core::$user_set['skin'] == $theme ? ' selected="selected">' : '>') . $theme . '</option>';
}
echo '</select>' .
'<input type="submit" name="submit" value="Change"/></form></div>';
}
echo'</div>';
?>