<?php

define('_IN_JOHNCMS', 1);

$textl = 'Situs teman';
$headmod = 'Friendssite';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$maxsite = 100; //SLSzSaN?SlSLN?SL N?SzSaN,SlS2
$adddate = 3; //N?SlN?S"Sl S'S?SuSa SzSlN?S"Su NESuS"Sl S'S"NZ S'SlS+SzS2S"SuS?SlNZ N?SzSaN,Sz
$userssite = 3; //N?SlN?S"Sl NESzS.NESuN^SuS?S?N<Na N?SzSaN,SlS2 S?S'S"NZ SlS'S?SlS"Sl NZS.SuNESz
switch ($act) {
case 'delete':
// S<S'SzS"SuS?SlSu N?SzSaN,Sz
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_GET['yes'])) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Apakah anda yakin untuk menghapus situs ini dari daftar?<br/><a href="friendssite.php?act=delete&amp;id=' . $id . '&amp;yes">Ya</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Tidak</a></p></div>';
}
}
break;

case 'edit':
// S?SuS'SzSaN,SlNESlS2SzS?SlSu N?SzSaN,Sz
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 50) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;
$error = array();
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'Bidang tidak diperlukan';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Alamat situs tidak valid!';
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=edit&amp;id=' . $id . '">Ulangi</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("UPDATE `friendssite` SET `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "', `count`='$count' WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
require_once ("../incfiles/end.php");
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
$res = mysql_fetch_array($req);
echo '<div class="mainblok"><div class="phdr"><b>Perubahan situs</b></div>' .
'<div class="menu"><form action="friendssite.php?act=edit&amp;id=' . $id . '" method="post">' .
'Alamat&nbsp;-&nbsp;max. 25:<br/><input type="text" name="adres" maxlength="25" value="' . functions::checkout($res['site']) . '"/><br/> ' .
'Nama&nbsp;-&nbsp;max. 50:<br/><input type="text" name="name" maxlength="50" value="' . functions::checkout($res['name']) . '"/><br/>' .
'Deskripsi&nbsp;-&nbsp;max. 200:<br/><textarea cols="20" rows="2" name="opis">' . htmlentities($res['opis'], ENT_QUOTES, 'UTF-8') . '</textarea><br/>' .
'Views:<br/><input type="text" name="count" maxlength="50"  value="' . $res['count'] . '"/><br />' .
'<input name="submit" type="submit" title="klik untuk menambahkan situs" value="Simpan"/></form>' .
'</div><div class="phdr"><a href="' . $_SESSION['prd'] . '">Kembali</a></div></div>';
}
}
break;

case 'redirect':
// S?SuS'SlNESuSaN,
$req = mysql_query("SELECT `site` FROM `friendssite` WHERE `id`='$id' AND `type`='1'");
if(mysql_num_rows($req)) {         $res = mysql_fetch_assoc($req);
if (!$_SESSION['fr_site_' . $id]) {
mysql_query("UPDATE `friendssite` SET `count` = (`count`+1) WHERE `id` = '$id' LIMIT 1");
$_SESSION['fr_site_' . $id] = true;
}
header('location:' . $res['site']);
require_once ("../incfiles/end.php");
exit;

}
break;

case 'mass_del':
// SsSzN?N?SlS2SlSu N?S'SzS"SuS?SlSu N?SzSaN,SlS2
if ($rights >= 6) {
if (isset($_GET['yes'])) {
foreach ($_SESSION['dc'] as $delid) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='" . intval($delid) . "';");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
if (empty($_POST['delch'])) {
echo functions::display_error('Anda tidak memilih untuk menghapus', '<a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Kembali</a>');
require_once ("../incfiles/end.php");
exit;
}
foreach ($_POST['delch'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Apakah anda yakin untuk menghapus situs?<br/><a href="?act=mass_del&amp;yes">Ya</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Tidak</a></p></div>';
}
}
break;

case 'mod_site':
// S?SzSaN,N< S?Sz SLSlS'SuNESzN?SlSl
if ($rights >= 6) {
if (isset($_GET['pr'])) {
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `id` = '$id' LIMIT 1");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite)
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT 1");
header("location: friendssite.php?act=mod_site");
exit;
} elseif (isset($_GET['vs'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT $total_mod");
}
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `type` = '2'");
header("location: friendssite.php?act=mod_site");
exit;
}
else{

echo '<div class="mainblok"><div class="phdr"><b><a href="friendssite.php">Situs teman</a></b> | Periksa situs</div>';
$req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='2'");
if(mysql_num_rows($req)) {
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a><br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Tambah <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Hapus</span></a> | <a href="friendssite.php?act=mod_site&amp;id=' . $res["id"] . '&amp;pr">Terima</a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">Ubah</a></div></div></div>';
++$i;
}
echo '<div class="rmenu"><input type="submit" value="Hapus diperiksa"/></div></form>' .
'<div class="gmenu"><a href="friendssite.php?act=mod_site&amp;vs">Terima semua</a></div>';
}
else
echo '<div class="menu"><p>Daftar kosong</p></div></div>';
echo '<div class="phdr"><a href="friendssite.php">Kembali</a></div>';
}

}
break;


case 'add_site':
// S"SlS+SzS2S"SuS?SlSu N?SzSaN,Sz
if ($user_id) {
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
$error = array();
if ($total_site >= $userssite && $rights < 6)
$error[] = 'User hanya di izinkan untuk menambahkan satu ' . $userssite . ' situs!';
if ((time()  - $datauser['datereg']) < ($adddate * 86400) && $rights < 6)
$error[] = 'Pengguna hanya dapat menambahkan situs setidaknya setelah ' . $adddate . ' hari!';
$flood = functions::antiflood();
if ($flood)
$error[] = 'antiflood! Silahkan, tunggu ' . $flood . ' N?SuSa.';
if($error) {
echo display_error($error, '<a href="friendssite.php">Kembali</a>');
require_once ("../incfiles/end.php");
exit;
}
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 50) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$type = $rights >= 6 ? 2 : 2;
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'Semuanya harus diisi';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'Alamat situs tidak valid!';
if(!$error) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `name`='" . mysql_real_escape_string($name) . "' OR  `site`='http://" . mysql_real_escape_string($adres) . "'"), 0);
if ($total >= 1)
$error[] = 'Nama situs ini sudah ada!';

}
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=add_site">Ulangi</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("INSERT INTO `friendssite` SET `vr`='" . time() . "', `iduser`='$user_id', `type`='$type', `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
echo '<div class="gmenu">Situs telah ditambahkan' . ($rights >= 6 ? '' : ' Situs anda akan muncul dalam daftar setelah mendapatkan Verifikasi') . '<br/><a href="friendssite.php">Daftar situs</a></div>';
}
else {
echo '<div class="mainblok"><div class="phdr"><b><a href="friendssite.php">Situs teman</a></b> | Menambahkan situs</div>' .
'<div class="bmenu">Hanya diperbolehkan link langsung ke, lainnya akan dipotong.<br/>Tidak boleh ada yang kosong!</div><div class="menu">' .
'<form action="friendssite.php?act=add_site" method="post">' .
'Alamat&nbsp;-&nbsp;max. 25:<br/><input type="text" name="adres" maxlength="25" value="http://"/><br/> ' .
'Nama&nbsp;-&nbsp;max. 50:<br/><input type="text" name="name" maxlength="50"/><br/>' .
'Keterangan&nbsp;-&nbsp;max. 200:<br/><textarea cols="20" rows="2" name="opis"></textarea><br/>' .
'<input name="submit" type="submit" title="klik untuk menambahkan situs" value="Tambahkan situs"/></form>' .
'</div><div class="phdr"><a href="friendssite.php">Kembali</a></div></div>';
}
}
else {
header('location: ../login.php');
exit;
}
break;
default:
// S?SzSlN?SlSa N?SzSaN,SlS2
echo '<div class="mainblok"><div class="phdr"><b>Situs teman</b></div>';
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 6))
echo '<div class="gmenu"><a href="friendssite.php?act=add_site">Tambahkan situs</a> | Tambahkan juga Link Situs ini di Situsmu !</div>';
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="friendssite.php?act=mod_site">Situs untuk moderasi</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if($total) {          $req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='1' ORDER BY `friendssite`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 6)
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a> (' . $res['count'] . ')<br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Ditambahkan <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';
if ($rights >= 6)
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Hapus</span></a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">Ubah</a></div>';
echo '</div>';
++$i;
}
if ($rights >= 6)
echo '<div class="rmenu"><input type="submit" value="Hapus diperiksa"/></div></form>';
}

else

echo '<div class="menu"><p>Daftar kosong</p></div>';
echo '</div><div class="mainblok"><div class="phdr">Total:&nbsp;' . $total . '</div></div>';
if ($total > $kmess) {
echo '<div class="topmenu"><p>' . functions::display_pagination('friendssite.php?', $start, $total, $kmess) . '</p>';
echo '</div><p><form action="friendssite.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="Ke Halaman &gt;&gt;"/></form></p>';
}
}
                                             
require_once ("../incfiles/end.php");
              
 
?>
