<?php
/** Shortcuts Jcms
 * http://www.waptok.asia
 */

echo'<div class="mainblok"><div class="phdr"><b>Wapmaster</b></div><div class="menu"><select align="right" onchange="location.href=this.options[this.selectedIndex].value" style="width: 80px">
<option SELECTED  value="/">Service Tool</option><br />
<option value="http://wap2ftp.3owl.com">Wap2ftp</option><br/>
<option value="/service/kamus.php">Kamus Translate</option><br/>
<option value="/service/intip.php">Source Viewer</option><br/><option value="/multisearch">Multi Search</option><br/><option value="/service/colorcode.php">Color Code</option><br/><option value="/service/rainbow.php">Rainbow Text</option><br/><option value="/service/freesms.php">Free SMS</option><br/><option value="/screenshot">Screenshot</option><br/><option value="/service/teshtml.php">Tes HTML</option><br/><option value="/zipper">Wap Zipper</option><br/><option value="/grabmaker">Grab Maker</option><br/><option value="/service/prov.php">Prov Maker</option><br/><option value="/jad_to_jar">Jad to Jar</option><br/><option value="/status_fb_via">Status FB via</option><br/><option value="/service/spammail.php">Spam Mail</option></select>';
echo'</div></div>';
?>