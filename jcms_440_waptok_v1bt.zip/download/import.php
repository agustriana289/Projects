<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
if ($rights == 4 || $rights >= 6) {
    if (empty ($_GET['cat'])) {
        $loaddir = $loadroot;
    }
    else {
        $cat = intval($_GET['cat']);
        provcat($cat);
        $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" . $cat . "';");
        $adrdir = mysql_fetch_array($cat1);
        $loaddir = "$adrdir[adres]/$adrdir[name]";
    }
    if (isset ($_POST['submit'])) {
        $url = trim($_POST['url']);
        $opis = functions::check($_POST['opis']);
        $newn = functions::check($_POST['newn']);
        $tipf = functions::format($url);
        if (eregi("[^a-z0-9.()+_-]", $newn)) {
            echo
            "The new file name <b>$newn</b> contains invalid caracters<br/>Allowed only alphanumeric characters and same punctuation ( .()+_- )<br /><a href='?act=import&amp;cat="
            . $cat . "'>Repeat</a><br/>";
            require_once ('../incfiles/end.php');
            exit;
        }
        $import = "$loaddir/$newn.$tipf";
        $files = file("$import");
        if (!$files) {
            if (copy($url, $import)) {
                $ch = "$newn.$tipf";
                echo "File successfully downloaded<br/>";
                mysql_query("insert into `download` values(0,'$cat','" . mysql_real_escape_string($loaddir) . "','" . time() . "','" . mysql_real_escape_string($ch) . "','file','','','','" . $opis . "','');");
            }
            else {
                echo "File upload failed!<br/>";
            }
        }
        else {
            echo "Error, the file with the same name already exists in the directory<br/>";
        }
    }
    else {
        echo "Import from http<br/>";
        echo "<form action='?act=import&amp;cat=" . $cat . "' method='post'>";
        echo
        "Enter a URL:<br/><input type='text' name='url' value='http://'/> <br/>Description: <br/><textarea name='opis'></textarea><br/>Save as (no extension): <br/><input type='text' name='newn'/><br/>";
        echo "<input type='submit' name='submit' value='Download'/></form><br/>";
    }
}
else {
    echo "No access!";
}
echo "&#187;<a href='?cat=" . $cat . "'>In Folder</a><br/>";

?>