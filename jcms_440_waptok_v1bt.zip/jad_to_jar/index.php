<?php
error_reporting(0);
include_once 'head.php';
if($_POST)
{
$jad = $_POST['jad'];
$jad_url = preg_match('/http:\/\/.+\.jad/', $jad);
if($jad_url)
{
$file = @file($jad);
if(!empty($file))
{
//print_r($file);
$count = count($file);
//echo $count;
$i = 0;
while($i < $count)
{
$row = @explode(' ', $file[$i]);
 $left[$i] = $row[0];
 $right[$i] = $row[1];
$i++;
}
$key_1 = array_search('MIDlet-Jar-URL:', $left);
$key_2 = array_search('MIDlet-Jar-Size:', $left);
$key_3 = array_search('MIDlet-Name:', $left);
$key_4 = array_search('MIDlet-Version:', $left);
$data[0] = trim($right[$key_1]);
$data[1] = trim($right[$key_2]);
$data[2] = trim($right[$key_3]);
$data[3] = trim($right[$key_4]);
$url = preg_match('/http:\/\/.+\.jar/', $data[0]);
if($url)
{
echo '<div class="list1">JAR grabbed successfully...</div>';
echo '<div class="menu">';
echo "<b>Filename:</b> ";
echo basename($data[0]);
echo "<br />";
echo "<b>Size:</b> $data[1] bytes<br />";

if($data[3] == "")
{
   echo "<b>Version:</b> unknown<br />";

}
else{
echo "<b>Version:</b> $data[3]<br />";   
}
echo('<div class="list1"><a href="'.$data[0].'">Download JAR</a></div>');

echo '</div>';
}
else
{
   echo "<div class='tmn'>Uh oh, seems like the JAR is broken...</div>";
}
}
/*
Errors.....
*/
else
{
echo('<div class="tmn">Failed to grab JAR...</div>');
include_once 'form.php';
}
}
else
{

echo "<div class='tmn'>The URL is not a valid JAD...</div>";   
include_once 'form.php';
}
}
else
{
   
include_once 'form.php';
}
include_once'foot.php';
?>