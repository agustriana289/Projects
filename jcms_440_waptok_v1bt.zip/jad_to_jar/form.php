<div class="mainblok"><div class="phdr">Jad to Jar</div>
<div class="gmenu"><b>Enter the .JAD URL to make .JAR</b><br />

<form action='' method='post'><input type='text' value='' name='jad' /><br />
   <input type='submit' value='SUBMIT' /></form></div></div>