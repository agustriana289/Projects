<?php
/** Tolong jangan hapus tulisan ini jika anda menghargai penerjemah dan pengedit script . Translate & edited by Adie http://rainmob.tk . and original script download from 4mas.Ru

* Pack by http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'screenshot site';
$textl = 'Screenshot Site';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="mainblok"><div class="phdr"><b>Screenshot Online Site</b></div>';
echo '<div class="menu" align="center">';
echo '<form action="site.php">Site url (not use http://):
<br /><input name="site" type="text" size="15" value="waptok.asia"></input><br />Size:<br /><input name="x" type="text" value="240" size="3"></input>x<input name="y" type="text" value="320" size="3"></input><br />Format image:<br /><select name="format"> <option value="PNG">PNG</option>  <option value="JPEG">JPEG</option> </select> <br /><br /><input type="submit" value="SHOT"></input></form>';
echo '</div></div>';
require_once ("../incfiles/end.php");
?>
