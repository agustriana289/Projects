<?php
/** Tolong jangan hapus tulisan ini jika anda menghargai penerjemah dan pengedit script . Translate & edited by Adie http://rainmob.tk

* Pack by http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'Screenshot has created!';
$textl = 'Screenshot has created!';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="rmenu">';
echo '&raquo; <b>Click image to download files screenshot!</b><br />'.$mkmob.'<br /><a href="http://mini.s-shot.ru/'.$_GET['x'].'x'.$_GET['y'].'/'.$_GET['x'].'/'.$_GET['format'].'/?'.$_GET['site'].'"><img src="http://mini.s-shot.ru/'.$_GET['x'].'x'.$_GET['y'].'/'.$_GET['x'].'/'.$_GET['format'].'/?'.$_GET['site'].'" width="240" height="320" /></a><br />'.$mob.'<br /></div>';
echo '<div class="gmenu">&laquo; <a href="../screenshot" />Back</a></div>';
require_once ("../incfiles/end.php");
?>
