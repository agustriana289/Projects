<?php
    /**************************************************************************
     *  Adiquity Ad Code - Adiquity.com
     *  Copyright Guruji.com Software Pvt Ltd . All rights reserved. 
     *   Language: PHP (Curl)
     *   Version: 26082010
     **************************************************************************/

   $adq_params = array(
         "ADQ_PARAMS"  => array(
               "pazid"=>"adq5hhdk-14e9e1ml-t8b76",//PAZID      
               "adbgcolor"=>"FFFFFF", //Ad Unit Background color
               "adtcolor"=>"0063DC",  //Ad Unit Text color
                 )
         );

   /////////////////////////////////
   // Do not edit below this line //
   /////////////////////////////////

   $params = array();
   $params = array(
         "ua=" . urlencode($_SERVER["HTTP_USER_AGENT"]),
         "TIP=". urlencode($_SERVER["REMOTE_ADDR"]),
         "aclang=". "php",
         "acver=". "26082010" ,
         "cat"=>"s1,en"
         );
   if (!empty($adq_params["ADQ_PARAMS"])){
      foreach ($adq_params["ADQ_PARAMS"] as $k => $v){
         $params[] = urlencode($k) . "=" . urlencode($v);
      }
   }
   foreach ($_SERVER as $k => $v) {
      if ((substr($k, 0, 4) == "HTTP") ||(substr($k, 0, 3) == "REQ"))  {
         $params[] = $k . "=" . urlencode($v);
      }
   }
   $post = implode("&", $params);
   $request = curl_init();
   $request_timeout = 10; // 10 seconds timeout
   $adq_url = "http://ads.adiquity.com/mads";
   curl_setopt($request, CURLOPT_URL, $adq_url);
   curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($request, CURLOPT_TIMEOUT, $request_timeout);
   curl_setopt($request, CURLOPT_CONNECTTIMEOUT, $request_timeout);
   curl_setopt($request, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded", "Connection: Close"));
   curl_setopt($request, CURLOPT_POSTFIELDS, $post);

   $contents = curl_exec($request);
   if (curl_getinfo($request,CURLINFO_HTTP_CODE) == 200)
   {
      if ($contents === true || $contents === false)
         $contents = "";
         echo $contents;
   }
   curl_close($request);
   
?>