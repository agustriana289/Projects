<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
define('_IWB_', 1);
require_once('inc/indowapblog.php');
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'request_kupon':
if (isset($_POST['send']))
{
$email=strtolower($_POST['email']);
$code=$_POST['code'];
if (mb_strlen($email) < 5 || mb_strlen($email) > 40)
$error .='<li>'.$LANG['lenght_email'].'</li>';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$error .='<li>'.$LANG['incorrect_email'].'</li>';
if (empty($email))
$error .='<li>'.$LANG['empty_email'].'</li>';
$check_email=mysql_query("select id from user where email='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$error .='<li>'.$LANG['email_was_used'].'</li>';
if ($code != $_SESSION['captcha_code'])
$error .='<li>'.$LANG['incorrect_security_code'].'</li>';
if (empty($error))
{
$adm=mysql_fetch_array(mysql_query("select email from user where id='1'"));
$kupon = rand("11111","99999");
$waktu_kupon = time() + 3600;
mysql_query("insert into kupon_reg set code='".mysql_real_escape_string($kupon)."', email='".mysql_real_escape_string($email)."', time='".mysql_real_escape_string($waktu_kupon)."'");
$email = $email;
$subject=$LANG['reg_coupon_subject'];
$pesan .= "\r\n\r\n";
$pesan .= str_replace('::number::',$kupon,str_replace('::time::',waktu($waktu_kupon),str_replace('::link::',''.$site['url'].'/register.php',str_replace('::site_name::',$site['name'],str_replace('::site_url::',$site['url'],$LANG['reg_coupon_msg'])))));
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
$hasil=str_replace('::time::',waktu($waktu_kupon),$LANG['coupon_successfully_sent']);
}
else
{
$error='<div id="message"><ol id="error">'.$error.'</ol></div>';
}
}
$head_title=$LANG['request_coupon'];
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><p>';
if ($site['reg_email'] == 0)
{
echo $LANG['reg_not_using_coupon'];
}
else
{
if (!empty($hasil))
{
echo $hasil;
}
else
{
echo $error;
echo '<form method="post" action="register.php?iwb=request_kupon"><h4>'.$LANG['email'].'</h4>
<input class="iwb-text" name="email" type="text" value="'.htmlentities($email).'" maxlength="40" size="30"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>'.$LANG['security_code'].'</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><br/><center><input class="iwb-button" name="send" type="submit" value="'.$LANG['send'].'"/>
</center></form>';
}
}
echo '</div></div>';
require_once('inc/foot.php');
break;
case 'terms':
$head_title=$LANG['tos'];
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="register.php?">'.$LANG['registration'].'</a> | '.$LANG['tos'].'</div>';
echo '<p>'.$LANG['tos_text'].'</p>';
echo '</div></div>';
require_once('inc/foot.php');
break;
default:
if ($user_id)
{
header('location: dashboard.php');
exit;
}
if ($site['allow_reg'] == 0)
{
$head_title=$LANG['registration'];
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content">'.$LANG['registration_closed'].'</div></div>';
require_once('inc/foot.php');
}
else
{
$subdomain_forbidden = array("admin","wap","mobi","mobile","www","blog","blogs","help","mail","webmail","cpanel","hexagram","whm","panel","contact","indowapblog","administrator","support","google","gmail","plus","facebook","yahoo","youtube","twitter","blogger","book","blogspot","developer","market","network","mywapblog","user","users","code","email","username","name","nickname","main","forum","wordpress","chat","download","codex","meta","link","server","host","hosting","donasi","donation","free","atom","feed","subscribe","page","pages","fans","porn","horn","sexx","bugil","live","room","kontol","memek","itil","jembut","bego","horni","group","grup","community","komunitas","bantuan","register","registration","member","members","chatroom","guest","guestbook","follow","feedback","load","localhost","subdomain","domain","video","audio","xxxx","service","services","tool","tools","wapmaster","webmaster","master","show","adsense","webhost","webhosting","freehosting","profile","profil","wall","porno","webdisk","chatroom","adult","bing","bego","hack","hacker","windowslive","achunk","achunks","achunk17","cname","official");
$username=htmlentities(strtolower($_POST['username']));
$domain=htmlentities(strtolower($_POST['domain']));
$pass=$_POST['pass'];
$re_pass=$_POST['re_pass'];
$name=htmlentities($_POST['name']);
$email=strtolower($_POST['email']);
$code=$_POST['code'];
$kupon=$_POST['kupon'];
if (isset($_POST['register']))
{
if (in_array(strtolower($username), $subdomain_forbidden))
$error .='<li>'.$LANG['username_forbidden'].'</li>';
$st_check=strtolower('http://'.$username.'.'.$domain);
$check_site=mysql_query("select * from site where url='".mysql_real_escape_string($st_check)."' or url_www='".mysql_real_escape_string($st_check)."'");
if (mysql_num_rows($check_site) != 0)
$error .='<li>'.$LANG['site_was_registered'].'</li>';
if ($domain != $iwb_main_domain)
$error .='<li>'.$LANG['incorrect_domain'].'</li>';
if (mb_strlen($username) < 4 || mb_strlen($username) > 32)
$error .='<li>'.$LANG['lenght_username'].'</li>';
$awal=substr($username, 0, 1);
$akhir=substr($username, -1);
if ($awal == '-' || $awal == '_' || $akhir == '-' || $akhir == '_')
$error .='<li>'.$LANG['username_first_and_last'].'</li>';
if (preg_match("/[^a-z0-9\-]/", $username))
$error .='<li>'.$LANG['username_allowed_chars'].'</li>';
if (empty($username))
$error .='<li>'.$LANG['empty_username'].'</li>';
if ($pass != $re_pass)
$error .='<li>'.$LANG['incorrect_password'].'</li>';
if (mb_strlen($pass) < 4 || mb_strlen($pass) > 12)
$error .='<li>'.$LANG['lenght_password'].'</li>';
if (empty($pass) || empty($re_pass))
$error .='<li>'.$LANG['empty_password'].'</li>';
if ($site['reg_email'] == 1)
{
$k=mysql_query("select * from kupon_reg where code='".mysql_real_escape_string($kupon)."' and time > '".time()."'");
if (mysql_num_rows($k) == 0)
$error .='<li>'.$LANG['incorrect_coupon'].'</li>';
}
else
{
if (mb_strlen($email) < 5 || mb_strlen($email) > 40)
$error .='<li>'.$LANG['lenght_email'].'</li>';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$error .='<li>'.$LANG['incorrect_email'].'</li>';
if (empty($email))
$hasil .='<li>'.$LANG['empty_email'].'</li>';
$check_email=mysql_query("select id from user where email='".mysql_real_escape_string($email)."'");
if (mysql_num_rows($check_email) != 0)
$error .='<li>'.$LANG['email_was_used'].'</li>';
}
if (mb_strlen($name) < 4 || mb_strlen($name) > 30)
$error .='<li>'.$LANG['lenght_name'].'</li>';
if (preg_match("/[^a-zA-Z0-9\ \-\.\@\{\}\_]/", $name))
$error .='<li>'.$LANG['incorrect_name'].'</li>';
if (substr($name,0,1) == ' ' || substr($name,-1) == ' ')
$error .='<li>'.$LANG['incorrect_name'].'</li>';
if (empty($name))
$error .='<li>'.$LANG['empty_name'].'</li>';
if ($code != $_SESSION['captcha_code'])
$error .='<li>'.$LANG['incorrect_security_code'].'</li>';
if (empty($error))
{
$password=md5($pass);
$konf='0';
$st_url='http://'.$username.'.'.$domain.'';
$st_url_www='http://www.'.$username.'.'.$domain.'';
if ($site['reg_email'] == 1)
{
$em=mysql_fetch_array($k);
$email = $em['email'];
mysql_query("delete from kupon_reg where code='".mysql_real_escape_string($kupon)."'");
}
else
{
$email = $email;
}
mysql_query("insert into user set username='".mysql_real_escape_string($username)."', password='".mysql_real_escape_string($password)."', email='".mysql_real_escape_string($email)."', name='".mysql_real_escape_string($name)."', site='".mysql_real_escape_string($st_url)."', author='1', credit='500', confirm='".$konf."', date_reg='".time()."'");
$new_id=mysql_insert_id();
$st_title=''.$name.' Mobile Blog';
mysql_query("INSERT INTO `site` SET name='".mysql_real_escape_string($st_title)."', url='".mysql_real_escape_string($st_url)."', url_www='".mysql_real_escape_string($st_url_www)."', description='My Mobile Blog Powered By IndoWapBlog', keywords='tips, trick, gratisan, xl, indosat, tsel, indowapblog, open source, mobile blog', theme='default', theme_web='default.web', logo='', favicon='favicon.ico', cat_loc='index', display_following='1', comment_email='1', comment_mod='0', comment_captcha='1', num_post_main='10', desc_post_main='0', gmt='+7', category='10'") or die(mysql_error());
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='Komentar: <a href=\"_SITE_URL_/comment/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/comments/subscribe.xhtml\">[E-Mail]</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='Posting: <a href=\"_SITE_URL_/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/posts/subscribe.xhtml\">[E-Mail]</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/feedback.xhtml\">Feedback</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/guestbook.xhtml\">Buku Tamu</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/chat.php\">Chat Room</a>'");
mysql_query("INSERT INTO `navigation` SET site_id='".$new_id."', code='<a href=\"_SITE_URL_/follow.xhtml\">Follow</a>'");
//*Kategori pertama*//
mysql_query("insert into category set site_id='".$new_id."', link='tak-berkategori', name='Tak Berkategori'");
$new_cat_id=mysql_insert_id();
//*Posting Pertama Blog*//
$title='Hallo Dunia';
$teks='Ini adalah postingan pertama Anda, silakan ubah atau hapus postingan ini.';
mysql_query("insert into blog set site_id='".$new_id."', title='".mysql_real_escape_string($title)."', description='".mysql_real_escape_string($teks)."', link='hallo-dunia', time='".time()."', category='".$new_cat_id."', allow_comment='1', draft='0'");
$new_blog_id=mysql_insert_id();
//*Update kategori*//
mysql_query("update category set blog_id='".$new_blog_id."' where id='".$new_cat_id."'");
//*Komentar*//
mysql_query("insert into comment set site_id='".$new_id."', user_id='1', blog_id='".$new_blog_id."', name='IndoWapBlog.com', site='http://indowapblog.com', email='achunk17@gmail.com', text='Terima kasih telah berkreasi dengan IndoWapBlog.', status='1', time='".time()."'");
}
}
$head_title=$LANG['registration'];
require_once('inc/head.php');
echo '<div id="message">';
if (isset($_POST['register']) && empty($error))
{
echo '<div id="content">
<div id="main-content">';
echo '<p>'.$LANG['registration_successfully'].'</p>';
}
else
{
if (!empty($error))
echo '<ol id="error">'.$error.'</ol>';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar">'.$LANG['registration'].' | <a href="register.php?iwb=terms">'.$LANG['tos'].'</a></div>';
if ($site['reg_email'] == 1)
{
echo '<p>'.$LANG['coupon_info'].'</p><br />';
}
echo '<form method="post" action="register.php">
<h4>'.$LANG['username'].'</h4>
<input class="iwb-text" name="username" type="text" value="'.htmlentities($username).'" maxlength="32" size="30"/><br/>
<h4>'.$LANG['domain'].'</h4><select class="iwb-select" name="domain"><option value="'.$iwb_main_domain.'">'.$iwb_main_domain.'</option></select><br/>
<h4>'.$LANG['password'].'</h4>
<input class="iwb-password" name="pass" type="password" maxlength="12" size="30"/><br/>
<h4>'.$LANG['re_password'].'</h4>
<input class="iwb-password" name="re_pass" type="password" maxlength="12" size="30"/><br/>
<h4>'.$LANG['name'].'</h4>
<input class="iwb-text" name="name" type="text" value="'.htmlentities($name).'" maxlength="49" size="30"/><br/>';
if ($site['reg_email'] == 1)
echo '<h4>'.$LANG['coupon'].'</h4><input class="iwb-text" type="text" name="kupon" value="'.htmlentities($kupon).'" maxlength="5" size="30"/><br />';
else
echo '<h4>'.$LANG['email'].'</h4>
<input class="iwb-text" name="email" type="text" value="'.htmlentities($email).'" maxlength="40" size="30"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>'.$LANG['security_code'].'</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><br/>';
echo '<p style="text-align:center;">'.str_replace('::register::',$LANG['register'],$LANG['tos_notice']).'<br/>
<input class="iwb-button" name="register" type="submit" value="'.$LANG['register'].'"/>
</p>
</form>';
}
echo '</div></div>';
require_once('inc/foot.php');
}
}
?>
