<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
define('_IWB_', 1);
$iwb_redirecting='off';
require_once('inc/indowapblog.php');
$folder='data/'.$site['id'].'/';
$file=htmlentities($_GET['get']);
$open_file = $folder . $file;
if (file_exists($open_file))
{
if (substr($file,0,4) == 'f1-u')
{
$adrfile='http://1.f.indowapblog.com/files/'.$file.'';
$handle = fopen($open_file, "r");
$size = fread($handle, filesize($open_file));
fclose($handle);
}
else
{
$adrfile = $folder . $file;
$size = filesize($adrfile);
}
$sub4=substr($file,-4);
$sub5=substr($file,-5);
if ($sub5 == '.sisx')
{$t='o-epoc/x-sisx-app';}
elseif ($sub4 == '.css'){$t='text/css';}
elseif ($sub4 == '.jar'){$t='application/java-archive';}
elseif ($sub4 == '.tar'){$t='application/x-tar';}
elseif ($sub4 == '.zip')
{$t='application/zip';}
elseif ($sub4 == '.txt'){$t='text/plain';}
elseif ($sub4 == '.jpg'){$t='image/jpeg';}
elseif ($sub4 == '.png'){$t='image/png';}
elseif ($sub4 == '.gif'){$t='image/gif';}
elseif ($sub4 == '.ico'){$t='image/x-icon';}
elseif ($sub4 == '.sis'){$t='application/vnd.symbian.install';}
elseif ($sub4 == '.apk'){$t='application/vnd.android.package.archive';}
elseif ($sub4 == '.cab'){$t='application/cab';}
elseif ($sub4 == '.mp3'){$t='audio/mpeg';}
elseif ($sub4 == '.3gp'){$t='video/3gp';}
elseif ($sub4 == '.mp4'){$t='video/mp4';}
elseif ($sub4 == '.avi'){$t='video/avi';}
else{$t='application/octet-stream';}
$file_location=$adrfile;
$file_type=$t;
$file_name=$file;
}
else
{
$file_location='images/file_not_found.jpg';
$size = filesize($file_location);
$file_type='image/jpeg';
$file_name='file_not_found.jpg';
}
header('Content-Description: File Transfer');
header('Content-Type: ' . $file_type);
header('Content-Disposition: attachment; filename=' . $file_name);
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . $size);
ob_clean();
flush();
readfile($file_location);
exit;
mysql_close($iwb_connect);
?>
