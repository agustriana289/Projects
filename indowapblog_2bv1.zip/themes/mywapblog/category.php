<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$name=htmlentities($_GET['name']);
$page=htmlentities($_GET['page']);

$req=mysql_query("select * from category where site_id='".$site['id']."' and link='".mysql_real_escape_string($name)."'");

$head_title=$name;
require_once('themes/mywapblog/header.php');
echo '<div id="content">';
if (mysql_num_rows($req) == 0)
{
echo '<div class="post"><h2 class="title">Kategori Tidak ada</h2><p>Kategori '.htmlspecialchars($cat['name']).' tidak ada atau telah dihapus.</p></div></div>';
}
else
{
$cat=mysql_fetch_array($req);

$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' and url='".mysql_real_escape_string($site_url)."'"), 0);

if (!ctype_digit($page) || $page == 1 || empty($page) || $page > (ceil(count(explode(",",$cat['blog_id'])))))
$page='0';
$max_view=$site['num_post_main'];
$pgs=$page*$max_view;
$lmt=$pgs+$max_view;

echo '<h3>Menampilkan posting pada kategori <i>'.htmlspecialchars($cat['name']).'</i></h3>';
if (!empty($cat['blog_id']))
{
$eks=explode(",",$cat['blog_id']);
$count=count($eks);
if ($count < $lmt)
$lmt=$count;
$i=$pgs;
while ($i<$lmt)
{
if (!empty($eks[$i]) && ctype_digit($eks[$i]))
{
$blog=mysql_fetch_array(mysql_query("select * from blog where id='".mysql_real_escape_string($eks[$i])."' and draft='0'"));
echo '<div class="post"><h2 class="title"><a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a><br /><small>['.waktu($blog['time']).']</small></h2>';
$desc_leng=strlen(htmlentities(strip_tags($blog['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blog['description']),0,150);
if (($desc_mainpage=='1') || ($desc_leng<='149'))
$description=$blog['description'];
else
$description=''.$desc_put.'...<a href="'.$site['url'].'/'.$blog['link'].'.xhtml">[Selengkapnya]</a>';
$komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blog['id']."' and status='1'"),0);
if ($blog['private'] == 1)
{
if ($user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>Postingan ini hanya untuk Member. Untuk melihat postingan ini silakan login atau register terlebih dahulu.</p>';
}
elseif ($blog['private'] == 2)
{
if ($cf != 0 || $site_id == $user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>Postingan ini hanya untuk Pengikut (Follower).</p>';
}
else
{
echo '<p>'.iwb_html($description).'</p>';
}
echo '<p>[<a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.$komentar.' Komentar</a>]';
if ($site['display_count'] == 1)
echo ' ['.$blog['count'].' Dilihat]';
echo '</p>';
echo '<br />';
iwb_ads();
echo '</div>';
$i++;
}
}
echo '</div>';

$total=$count;
$link=''.$site['url'].'/category/'.$cat['link'].'/';
$q='.xhtml';
$pagination="on";
}
else
{
echo '<div class="post"><h2 class="title">Kategori Kosong</h2><p>Belum ada post dalam kategori '.htmlspecialchars($cat['name']).'</p></div></div>';
}
}
require_once('themes/mywapblog/footer.php');
?>