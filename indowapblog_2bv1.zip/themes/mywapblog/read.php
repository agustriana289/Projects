<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$t = htmlentities($_GET['t']);

$cek = mysql_query("SELECT * FROM blog WHERE site_id = '" . $site['id'] . "' AND link = '" . mysql_real_escape_string($t) . "' AND draft = '0' limit 1;");
if (mysql_num_rows($cek) == 0)
{
require_once('themes/mywapblog/header.php');
echo '<div id="content"><div class="post"><p>' . $LANG['blog_not_found'] . '</p></div></div>';
require_once('themes/mywapblog/footer.php');
}
else {
$blogs = mysql_fetch_array($cek);
$cf = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '" . $user_id . "' AND url = '" . mysql_real_escape_string($site_url) . "'"), 0);

$tot = $blogs['count'] + 1;
mysql_query("UPDATE blog SET count = '" . $tot . "' WHERE id = '" . $blogs['id'] . "'");

if ($blogs['private'] == 1) {
if ($user_id)
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2) {
if ($cf != 0 || $site_id == $user_id)
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_follower'];
}
else {
$blog_description = $blogs['description'];
}

$head_description = $blog_description;
$head_title = $blogs['title'];
require_once('themes/mywapblog/header.php');
echo '<div id="content">';

echo '<div class="post"><h2 class="title">'.htmlspecialchars($blogs['title']).'<br /><small>['.waktu($blogs['time']).']</small></h2>';
echo '<p>'.iwb_html($blog_description).'</p>';
echo '<p class="share_button"><a href="http://m.facebook.com/sharer.php?u='.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="http://indowapblog.com/images/button-fshare.gif" alt="Share on Facebook"/></a> <a href="http://mobile.twitter.com/home?status='.urlencode($blogs['title']).'+'.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="http://indowapblog.com/images/button-tshare.gif" alt="Share on Twitter"></a><br />';
echo '' . $LANG['author'] . ': ' . iwbid($site_id);
if (!empty($blogs['category']))
{
echo '<br/>' . $LANG['category']. ': ';
$explod = explode(",", $blogs['category']);
$count_exp = count($explod) - 1;
$rand = mt_rand(0, $count_exp);
$sql_related = $explod[$rand];
for ($e = 0; $e <= $count_exp; $e++) {
if ($_kat = mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id = '" . mysql_real_escape_string($explod[$e]) . "' AND site_id = '" . $site['id'] . "'")))
echo '<a href="' . $site['url'] . '/category/' . $_kat['link'] . '/1.xhtml">' . htmlentities($_kat['name']) . '</a>, ';
}
}
if (!empty($blogs['tag'])) {
echo '<br />' . $LANG['tag'] . ': ';
$explode = explode(",", $blogs['tag']);
if ($explode) {
$count = count($explode) -1;
for ($i = 0; $i <= $count; $i++) {
echo '<a href="' . $site_url . '/tag/' . $explode[$i] . '/1.xhtml">' . str_replace('-', ' ', $explode[$i]) . '</a> ';
}
}
else {
echo '<a href="' . $site_url . '/tag/' . $blogs['tag'] . '/1.xhtml">' . str_replace('-', ' ', $blogs['tag']) . '</a>';
}
}
echo '<br />';
// Iklan pemilik situs
iwb_ads();
echo '</p>';
echo '<h3>' . $LANG['related_post'] . '</h3><ol>';
if (!empty($blogs['category']))
{
$related = mysql_fetch_array(mysql_query("SELECT blog_id FROM category WHERE id = '" . mysql_real_escape_string($sql_related) . "' AND site_id = '" . $site['id'] . "'"));
$exp = explode(",", $related['blog_id']);
$count = count($exp) - 1;
if ($count > 4)
$cou = 4;
else
$cou = $count;
for ($i = 0; $i <= $cou; $i++) {
if ($exp[$i] == $blogs['id']) {
continue;
}
else {
if ($reads = mysql_fetch_array(mysql_query("SELECT title, link FROM blog WHERE id = '" . mysql_real_escape_string($exp[$i]) . "' AND site_id = '" . $site['id'] . "' AND draft = '0'")))
echo '<li><a href="' . $site['url'] . '/' . $reads['link'] . '.xhtml">' . htmlspecialchars($reads['title']) . '</a></li>';
}
}
}
echo '</ol>';
echo '</div></div>';
echo '<div id="comments"><h2><a
name="comment1">Komentar</a></h2>';
function show_comments()
{
global $blogs, $site, $user_id, $user_name, $user_site, $user_email, $t, $limit, $max_view;
$total_comments = mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM comment WHERE blog_id = '" . $blogs['id'] . "' AND status = '1'"), 0);

if ($total_comments > 0)
{
echo '<h4>'.$total_comments.' Respon untuk
&quot;'.htmlspecialchars($blogs['title']).'&quot;</h4>';}
if ($site['display_count'] == 1)
echo '<h4>Dilihat sebanyak &quot;'.$blogs['count'].'&quot; kali</h4>';

echo '<p>Berlangganan komentar melalui (<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">E-Mail</a>)</p>';
if ($total_comments < 1)
{
echo '<h4>Belum ada komentar. Mengapa tidak menjadi yang pertama?</h4>';
}
else
{
$comment = mysql_query("SELECT * FROM comment WHERE blog_id = '" . $blogs['id'] . "' AND status = '1' ORDER BY time ASC");
while ($comments = mysql_fetch_array($comment))
{
echo '<div class="comment">
<p class="title"><strong>';
if (empty($comments['site']))
echo htmlspecialchars($comments['name']);
else
echo '<a
href="'.htmlentities($comments['site']).'"
rel="nofollow">'.htmlspecialchars($comments['name']).'</a>';
echo '</strong>
<small> ['.waktu($comments['time']).']</small></p>
<p><small>'.bbsm($comments['text']).'</small></p>
</div>';
}
}
if ($blogs['allow_comment'] == 1)
{
echo '<h2><a name="new_comment">Komentar Baru</a></h2>';
$skrg='/'.$blogs['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil='Kode keamanan yang kamu masukan tidak benar';
if ($string == 'err_msg')
$hasil='Silakan masukan komentar anda';
if ($string == 'err_mail')
$hasil='Silakan masukan email anda';
if ($string == 'err_invalid_email')
$hasil='Email yang anda masukan tidak benar';

if ($string == 'err_leng_email')
$hasil='Panjang email 2 sampai 32 karakter';
if ($string == 'err_name')
$hasil='Silakan masukan nama anda';
if ($string == 'ok')
$hasil='Komentar akan ditampilkan setelah disetujui administrator';
if ($string == 'success')
$hasil='Komentar berhasil ditambahkan';
if (!empty($hasil))
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hasil.'</li></ol>';
if ($user_id) {
$form_title = $user_name;
$form_site = $user_site;
$form_email = $user_email;
}
else {
$form_title = stripslashes($_SESSION['nama']);
$form_email = stripslashes($_SESSION['email']);
$form_site = stripslashes($_SESSION['site']);
}
echo '<form
id="comment_form"
action="'.$site['url'].'/comment.xhtml"
method="post">
<p>';
$redir=''.$site['url'].'/'.$blogs['link'].'.xhtml#new_comment';
if (!$user_id)
echo '[<a
href="'.$site['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">Masuk</a>]<br/>';
else
echo '[<a
href="'.$site['url'].'/login.php?iwb=logout&amp;redir='.base64_encode($redir).'" rel="nofollow">Keluar</a>]<br />';
echo 'Nama: <br/>
<input type="text"
name="title" value="'.$form_title.'"/><br/>Situs: <br/>
<input type="text"
name="site" value="'.$form_site.'"/><br/>';
if ($site['comment_email'] == '1')
echo 'Email: <br/>
<input type="text"
name="email" value="'.$form_email.'"/>';
echo '<br/>
Komentar:<br/>
(Kamu bisa menggunakan <a href="'.$site['url'].'/bbsm.php?iwb=bbcode">BBCode</a> dan <a href="'.$site['url'].'/bbsm.php?iwb=smiley">Smiley</a>.)<br/>
<textarea
name="body" rows="4"/></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($site['comment_captcha'] == 1)
{
echo '<br />Kode keamanan:<br /><img src="'.$site['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" value=""/>';
}
else {
echo '<input type="hidden" name="code" value="'.htmlentities($_SESSION['captcha_code']).'">';
}
echo '</p><p><input type="hidden"
name="t" value="'.$t.'"/><input
name="comment"
type="submit" id="comment"
value="Kirim"/></p></form>';
}
else
{
echo '<h2><a name="new_comment">' . $GLOBALS['LANG']['comment_closed'] . '</a></h2>';
}
}

if (($blogs['private'] == 1 && $user_id) || $blogs['private'] == 0 || ($blogs['private'] == 2 && ($cf > 0 || $site_id == $user_id))) {
show_comments();
}
else {
echo '<p>' . $LANG['comment_hidden'] . '</p>';
}
echo '</div>';
require_once('themes/mywapblog/footer.php');
}
?>