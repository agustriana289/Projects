<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$t=strtolower(preg_replace('#([\W_]+)#','-',$_GET['t']));

$cek=mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' AND link='".mysql_real_escape_string($t)."' AND draft='0' ORDER BY id DESC LIMIT 1;");

if (mysql_num_rows($cek) == 0) {
require_once('themes/default/header.php');
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['post'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post"><div class="post-list"><p>'.$LANG['blog_not_found'].'</p></div></div>';
require_once('themes/default/footer.php');
}
else {
$blogs=mysql_fetch_array($cek);

$tot = $blogs['count'] + 1;
mysql_query("UPDATE blog SET count='".$tot."' WHERE id='".$blogs['id']."'");

$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' AND url='".mysql_real_escape_string($site_url)."'"), 0);


if ($blogs['private'] == 1) {
if ($user_id)
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_member'];
}
elseif ($blogs['private'] == 2) {
if ($user_id && ($cf != "0" || $site_id == $user_id))
$blog_description = $blogs['description'];
else
$blog_description=$LANG['post_only_for_follower'];
}
else {
$blog_description = $blogs['description'];
}
if (substr($_SERVER['REQUEST_URI'], -12) == "translate=en")
{
$blog_description = GoogleTranslate($blog_description,"en");
}
elseif (substr($_SERVER['REQUEST_URI'], -12) == "translate=ru")
{
$blog_description = GoogleTranslate($blog_description,"ru");
}
else {
$blog_description = $blog_description;
}
$head_description = substr(htmlentities(strip_tags($blog_description)),0,200);
$head_title=$blogs['title'];
require_once('themes/default/header.php');
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['post'].'</td></tr></tbody></table><!-- table nav end --><!-- post start --><div class="post">';

echo '<!-- post-list start --><div class="post-list"><h1 class="title-post">'.htmlspecialchars($blogs['title']).'</h1><div class="date-post">'.waktu($blogs['time']).'</div>';
$Trans2RU='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=ru">RU</a>]';
$Trans2EN='[<a href="'.$site_url.'/'.$blogs['link'].'.xhtml?translate=en">EN</a>]';
echo '<p>'.iwb_html(str_replace('[EN]',$Trans2EN,str_replace('[RU]',$Trans2RU,$blog_description))).'</p>';

echo '</div><!-- post-list end --><!-- share start --><div class="share"><a class="facebook" href="http://m.facebook.com/sharer.php?u='.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="http://indowapblog.com/images/facebook.png" alt="Share on Facebook"/></a> <a class="twitter" href="http://mobile.twitter.com/home?status='.urlencode($blogs['title']).'+'.urlencode(''.$site['url'].'/'.$blogs['link'].'.xhtml').'"><img src="http://indowapblog.com/images/twitter.png" alt="Share on Twitter"></a> <a class="sms" href="http://smester.net/?pesan='.urlencode($blogs['title']).'+'.urlencode('[url='.$site['url'].'/'.$blogs['link'].'.xhtml]').'"><img src="http://indowapblog.com/images/sms.png" alt="SMS Share"></a></div><!-- share end -->';
echo '<!-- post-info start --><div class="post-info">'.$LANG['author'].': '.iwbid($site_id);
if (!empty($blogs['category'])) {
echo '<br/>'.$LANG['category'].': ';
$explod = explode(",",$blogs['category']);
$count_exp = count($explod) -1;
$rand = mt_rand(0, $count_exp);

// Rand kategory
$q_related = $explod[$rand];

for ($e =0; $e <= $count_exp; $e++)
{
if ($_kat = mysql_fetch_array(mysql_query("SELECT name, link FROM category WHERE id='" . mysql_real_escape_string($explod[$e]) . "' AND site_id='" . $site['id'] . "'")))
echo '<a href="' . $site['url'] . '/category/' . $_kat['link'] . '/1.xhtml">' . htmlentities($_kat['name']) . '</a>, ';
}
}
if (!empty($blogs['tag'])) {
echo '<br />' . $LANG['tag'] . ': ';
$explode = explode(",", $blogs['tag']);
if ($explode) {
$count = count($explode) -1;
for ($i = 0; $i <= $count; $i++) {
echo '<a href="' . $site_url . '/tag/' . $explode[$i] . '/1.xhtml">' . str_replace('-', ' ', $explode[$i]) . '</a> ';
}
}
else {
echo '<a href="' . $site_url . '/tag/' . $blogs['tag'] . '/1.xhtml">' . str_replace('-', ' ', $blogs['tag']) . '</a>';
}
}
echo '</div><!-- post-info end --></div><!-- post end -->';
echo '<h1 id="see-also">'.$LANG['related_post'].'</h1><!-- see-also start --><div class="see-also">';
if (!empty($blogs['category']))
{
$_related = mysql_fetch_array(mysql_query("SELECT blog_id FROM category WHERE id='" . mysql_real_escape_string($q_related) . "' AND site_id='" . $site['id'] . "'"));
$exp = explode(",",$_related['blog_id']);
$count = count($exp) - 1;
if ($count > 4)
$cou = 4;
else
$cou = $count;
for ($i=0; $i <= $cou; $i++)
{
if ($exp[$i] == $blogs['id']) {
continue;
}
else {
if ($reads = mysql_fetch_array(mysql_query("SELECT title, link FROM blog WHERE id='" . mysql_real_escape_string($exp[$i]) . "' AND site_id='" . $site['id'] . "' AND draft = '0'")))
echo '<!-- see-also-list start --><div class="see-also-list"><a href="' . $site['url'] . '/' . $reads['link'] . '.xhtml">' . htmlspecialchars($reads['title']) . '</a></div><!-- see-also-list end -->';
}
}
}
echo '</div><!-- see-also end -->';
$AD=mysql_query("SELECT * FROM ads WHERE site_id='".$site['id']."' AND status='1'");
if (mysql_num_rows($AD) != 0) {
$ADS=mysql_fetch_array($AD);
$PB=$ADS['adcode'];
echo '<!-- ads start --><div class="ads">';
if ($ADS['adby'] == 'mobgold') {
ads_mobgold($PB);
}
elseif ($ADS['adby'] == 'buzzcity') {
ads_buzzcity($PB);
}
elseif ($ADS['adby'] == 'smaato') {
ads_smaato($PB);
}
if ($ADS['adby'] == 'mobday') {
ads_mobday($PB);
}
else {
}
echo '</div><!-- ads end -->';
}
else
{
echo '<!-- ads start --><!-- <div class="ads">Ads Here</div> --><!-- ads end -->';
}
$list_comments = mysql_query("SELECT * FROM comment WHERE blog_id='".$blogs['id']."' AND status='1' ORDER BY time asc");
$total_comments = mysql_num_rows($list_comments);

echo '<h1 id="comment">';
if ($site['display_count'] == 1)
{
echo ''.$LANG['comments'].' '.$total_comments.' | '.$LANG['hits'].' '.$blogs['count'].' | '.$LANG['subscribe'].' (<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">'.$LANG['email'].'</a>)';
}
else
{
echo ''.$LANG['comments'].' '.$total_comments.' | '.$LANG['subscribe'].' (<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">'.$LANG['email'].'</a>)';
}
echo '</h1><!-- comment start --><div class="comment">';

// Start function
function show_comments()
{
if ($GLOBALS['total_comments'] < 1)
{
echo '<!-- comment-list start --><div class="comment-list"><p>'.$GLOBALS['LANG']['comment_empty'].'</p></div><!-- comment-list end -->';
}
else
{
while ($comments=mysql_fetch_array($GLOBALS['list_comments']))
{
if (empty($comments['site']))
$show_user=$comments['name'];
else
$show_user='<a
href="'.htmlentities($comments['site']).'"
rel="dofollow">'.htmlspecialchars($comments['name']).'</a>';
echo '<!-- comment-list start --><div class="comment-list">
<table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%"><div class="comment-photo"><img src="'.$GLOBALS['site']['url'].'/img.php?img='.$comments['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/></div></td><td width="80%"><div class="comment-name">'.$show_user.'</div><span>'.waktu($comments['time']).'</span></td></tr></tbody></table>';
echo '<p class="comment-body">'.nl2br(bbsm($comments['text'])).'</p></div><!-- comment-list end -->';
}
}
if ($GLOBALS['blogs']['allow_comment'] == 1)
{
echo '<h2><a name="new_comment">'.$GLOBALS['LANG']['add_comment'].'</a></h2>';
$skrg='/'.$GLOBALS['blogs']['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil='<span id="error">'.$GLOBALS['LANG']['incorrect_security_code'].'</span>';
if ($string == 'err_msg')
$hasil='<span id="error">'.$GLOBALS['LANG']['empty_text'].'</span>';
if ($string == 'err_mail')
$hasil='<span id="error">'.$GLOBALS['LANG']['empty_email'].'</span>';
if ($string == 'err_invalid_email')
$hasil='<span id="error">'.$GLOBALS['LANG']['incorrect_email'].'</span>';

if ($string == 'err_leng_email')
$hasil='<span id="error">'.$GLOBALS['LANG']['lenght_email'].'</span>';
if ($string == 'err_name')
$hasil='<span id="error">'.$GLOBALS['LANG']['empty_name'].'</span>';
if ($string == 'ok')
$hasil='<span id="success">'.$GLOBALS['LANG']['comment_waiting_approved'].'</span>';
if ($string == 'success')
$hasil='<span id="success">'.$GLOBALS['LANG']['comment_successfully_added'].'</span>';
if (!empty($hasil))
echo '<!-- notice start --><div class="notice">'.$hasil.'</div><!-- notice end -->';
echo '<form id="comment-form" action="'.$GLOBALS['site']['url'].'/comment.xhtml" method="POST">';
$redir=''.$GLOBALS['site']['url'].'/'.$GLOBALS['blogs']['link'].'.xhtml#new_comment';
if ($GLOBALS['user_id'])
{
echo '<table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%"><div class="comment-photo"><img src="'.$GLOBALS['site']['url'].'/img.php?img='.$GLOBALS['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/></div></td><td width="80%"><div class="comment-name"><a href="'.$GLOBALS['site']['url'].'/user.php?id='.$GLOBALS['user_id'].'">'.htmlspecialchars($GLOBALS['user_name']).'</a></div><span>(<a href="'.$GLOBALS['site']['url'].'/login.php?iwb=logout&amp;redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['logout'].'</a>)</span></td></tr></tbody></table><p>';
}
else
{
echo '<p><a href="'.$GLOBALS['site']['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">'.$GLOBALS['LANG']['login'].'</a><br /><h3>'.$GLOBALS['LANG']['name'].'</h3><input type="text" name="name" id="name" value="'.htmlspecialchars(stripslashes($_SESSION['name'])).'" size="22">';
if ($GLOBALS['site']['comment_email'] == 1)
echo '<h3>'.$GLOBALS['LANG']['email'].'</h3><input type="text" name="email" id="email" value="'.htmlspecialchars(stripslashes($_SESSION['email'])).'" size="22">';
echo '<h3>'.$GLOBALS['LANG']['site'].'</h3><input type="text" name="site" id="site" value="'.htmlspecialchars(stripslashes($_SESSION['site'])).'" size="22">';
}
echo '<h3>'.$GLOBALS['LANG']['comments'].'</h3><textarea name="text" id="text" rows="8" cols="20"></textarea>';
$_SESSION['captcha_code'] = rand(1000, 9999);
if ($GLOBALS['site']['comment_captcha'] == 1)
{
echo '<h3>'.$GLOBALS['LANG']['security_code'].'</h3><img src="'.$GLOBALS['site']['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" id="captcha" value="" size="22">';
}
else
{
echo '<input type="hidden" name="code" value="'.htmlentities($_SESSION['captcha_code']).'"/>';
}
echo '<input type="hidden" name="t" value="'.htmlspecialchars($GLOBALS['t']).'"/><br /><input name="comment" type="submit" id="submit" value="'.$GLOBALS['LANG']['send'].'"/></p></form>';
}
else
{
echo '<!-- notice start --><div class="notice">'.$GLOBALS['LANG']['comment_closed'].'</div><!-- notice end -->';
}
}
// End function

if ($blogs['private'] == 1)
{
if ($user_id)
show_comments();
else
echo '<!-- notice start --><div class="notice">'.$GLOBALS['LANG']['comment_hidden'].'</div><!-- notice end -->';
}
elseif ($blogs['private'] == 2)
{
if ($user_id && ($cf != 0 || $site_id == $user_id))
show_comments();
else
echo '<!-- notice start --><div class="notice">'.$LANG['comment_hidden'].'</div><!-- notice end -->';
}
else
{
show_comments();
}
echo '</div><!-- comment end -->';
require_once('themes/default/footer.php');
}
?>