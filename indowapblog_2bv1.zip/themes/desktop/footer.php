<?php

/*

IndoWapBlog-MS_v1.0d.zip FULL DECODER by : Binex
Website : http://caramembuatblog.nogisa.com

*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

echo '<div class="sidebar">';

echo '<div class="widget"><form id="search_form" method="get" action="'.$site['url'].'/"><input type="text" name="search" value="" /><input type="submit" value="'.$LANG['search_submit'].'" /></form></div>';

echo '<div class="widget"><h2>'.$LANG['latest_post'].'</h2><ul>';
$recents = mysql_query("SELECT title, link FROM blog WHERE site_id = '".$site['id']."' AND draft = '0' ORDER BY time DESC LIMIT 10;");
while ($recent = mysql_fetch_array($recents))
{
echo '<li><a href="'.$site['url'].'/'.$recent['link'].'.xhtml">'.htmlspecialchars($recent['title']).'</a></li>';
}
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<li><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></li>';
}
echo '</ul></div>';

echo '<div class="widget"><h2>'.$LANG['category'].'</h2><ul>';
$cats = mysql_query("SELECT * FROM category WHERE site_id = '".$site['id']."' ORDER BY name DESC");
if (mysql_num_rows($cats) > 0) {
while ($cat = mysql_fetch_array($cats))
{
if (empty($cat['blog_id'])) {
$cat_count = 0;
}
else {
$cat_count = count(explode(",",$cat['blog_id']));
}
echo '<li><a href="'.$site['url'].'/category/'.$cat['link'].'/1.xhtml">'.htmlspecialchars($cat['name']).'</a> ('.$cat_count.')</li>';
}
}
else {
echo '<li>'.$LANG['empty'].'</li>';
}
echo '</ul></div></div>';
echo '<div class="sidebar">';

$followings = mysql_query("SELECT * FROM following WHERE site_id = '".$site['id']."' ORDER BY id DESC LIMIT 50;");
$total_followings = mysql_num_rows($followings);
if ($total_followings > 0)
{
echo '<div class="widget"><h2>'.$LANG['following'].'</h2><ul>';
while ($rs = mysql_fetch_array($followings))
{
echo '<li><a href="'.htmlentities($rs['url']).'">'.htmlspecialchars($rs['title']).'</a></li>';
}
echo '</ul></div>';
}
echo '<div class="widget"><h2>'.$LANG['navigation'].'</h2><ul>';

if ($homepage != 'off')
echo '<li><a href="'.$site['url'].'">'.$LANG['homepage'].'</a></li>';
$navs = mysql_query("SELECT * FROM navigation WHERE site_id = '".$site['id']."' ORDER BY place ASC");
while ($nav = mysql_fetch_array($navs))
{
echo '<li>'.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$site['url'],$nav['code']))).'</li>';
}
echo '</ul></div>';
echo '</div></div>';
echo '<div style="clear:both"></div></div></div>';
echo '<div id="footer">';

$t_day = date('d-m-Y', time());
$qr = mysql_query("SELECT total FROM stats WHERE site_id = '".$site['id']."' AND time = '".$t_day."'");
$Qr = mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("INSERT INTO stats SET site_id = '".$site['id']."', total = '1', time = '".$t_day."'");
}
else
{
mysql_query("UPDATE stats SET total = '".$new_count."' WHERE site_id = '".$site['id']."' AND time = '".$t_day."'");
}

echo '&copy; '.date('Y', time()).' <a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a>.<br /><small>Powered by <a href="http://indowapblog.com">IndoWapBlog.com</a></small></div></body></html>';
mysql_close($iwb_connect);
?>