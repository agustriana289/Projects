<?php


defined('_IWB_') or die('Akser Terlarang!');

if ($user_id) {
$sol = time() - 300;
if ($user_lastdate < $sol) {
mysql_query("UPDATE user SET lastdate = '".time()."' WHERE id = '".$user_id."'");
}
if ($indowapblog['ban'] == 1) {
header("Location: ".$site_url."/login.php?iwb=logout");
exit;
}
}

$head_title = isset($head_title) ? $head_title : $site['name'];

if ($head_title != $site['name'])
$head_title = "".$head_title." | ".$site['name'];
else
$head_title = $head_title;
$head_title = htmlspecialchars($head_title);

$head_description = isset($head_description) ? $head_description : $site['description'];$head_description = substr(strip_tags($head_description), 0, 200);$head_description = htmlentities($head_description);

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="'.$site['url'].'/theme/desktop/style.css" type="text/css" />
<title>'.$head_title.'</title><link rel="alternate" media="handheld" href="'.$site['url'].'/" title="Mobile/PDA" /><meta name="description" content="'.$head_description.'" /><!-- Update your html tag to include the itemscope and itemtype attributes -->
<itemscope itemtype="http://schema.org/Blog">

<!-- Add the following three tags inside head -->
<meta itemprop="name" content="'.$head_title.'">
<meta itemprop="description" content="'.$head_description.'"><meta name="keywords" content="'.htmlentities($site['keywords']).'" />';
echo '<link rel="alternate" type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml" />';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

echo '<link rel="icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" />
    <link rel="shortcut icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" /><script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script></head>
<body><div id="container">';
if (!empty($site['logo'])) {
$headitem = '<img src="'.$site['url'].'/content/'.htmlentities($site['logo']).'" alt="'.htmlentities($site['name']).'"/>';
}
else {
$headitem = htmlspecialchars($site['name']);
}
echo '<div id="header"><div id="left"><h1><a href="'.$site['url'].'">'.$headitem.'</a></h1><h2>'.htmlspecialchars($site['description']).'</h2></div></div>';
echo '<div style="clear: both;"></div><div id="content-container">';

?>