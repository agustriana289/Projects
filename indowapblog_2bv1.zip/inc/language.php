<?php

defined('_IWB_') or die('Akses Terlarang.');
if ($user_id) {
$default_lang = isset($_SESSION['language']) ? $_SESSION['language'] : $indowapblog['language'];
}
else {
$default_lang = isset($_SESSION['language']) ? $_SESSION['language'] : $site['language'];
}
switch ($default_lang) {
case 'id':
$lang_file = "id.php";
break;
case 'en':
$lang_file = "en.php";
break;
default:
$lang_file = "id.php";
break;
}
include("".$root."inc/languages/".$lang_file);
?>