<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
defined('_IWB_') or die('Akses Dilarang!');
ini_set('session.use_cookies', true);
ini_set('session.use_trans_sid', true);
ini_set('arg_separator.output', '&amp;');
mb_internal_encoding('UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
session_name('IndoWapBlog');
session_start();
$root=isset($root) ? $root : '';
if (!file_exists(''.$root.'inc/config.php'))
{
header('location: '.$root.'install.php');
exit;
}
else
{
require(''.$root.'inc/config.php');
}
$iwb_connect=mysql_connect($dbhost,$dbuser,$dbpass);
if (!$iwb_connect)
{
echo('Tidak dapat terhubung ke database!');
exit;
}
$iwb_select_db=mysql_select_db($dbname);
if (!$iwb_select_db)
{
echo('Tidak dapat terhubung ke database yang dipilih!');
exit;
}
if (substr($_SERVER['HTTP_HOST'], 0, 4) == 'www.')
$host = substr($_SERVER['HTTP_HOST'], 4);
else
$host = $_SERVER['HTTP_HOST'];
$host='http://'.$host.'';
$subdomain=mysql_query("select * from site where url='".mysql_real_escape_string($host)."' or url_www='".mysql_real_escape_string($host)."'");
if (mysql_num_rows($subdomain) == 0)
{
header("HTTP/1.1 301 Moved Permanently");
header("Location: http://".$iwb_main_domain);
exit;
}
else
{
$site=mysql_fetch_array($subdomain);
$site_id = $site['id'];
$site_name=htmlspecialchars($site['name']);
$site_url=$site['url'];
if (preg_match("/".$iwb_main_domain."/i", $_SERVER['HTTP_HOST']))
{
$iwb_key=isset($_COOKIE['keylog']) ? $_COOKIE['keylog'] : time();
}
else
{
$iwb_key=isset($_COOKIE['keylog2']) ? $_COOKIE['keylog2'] : time();
}
if (empty($iwb_key) || strlen($iwb_key) != 32)
$iwb_key = time();
$iwb_req=mysql_query("SELECT * FROM `user` WHERE `cookie`='".mysql_real_escape_string($iwb_key)."'");
if (mysql_num_rows($iwb_req) != 0)
{
$indowapblog=mysql_fetch_array($iwb_req);
$user_id=$indowapblog['id'];
$user_username=$indowapblog['username'];
$user_name=$indowapblog['name'];
$user_email=$indowapblog['email'];
$user_site=$indowapblog['site'];
$user_admin=$indowapblog['admin'];
$user_author=$indowapblog['author'];
$is_admin = $user_admin == 1;
$is_author = $user_author > 0;
$user_lastdate=$indowapblog['lastdate'];
}
else
{}
include("".$root."inc/language.php");
include(''.$root.'inc/functions.php');
}
$iwb_redirecting=isset($iwb_redirecting) ? $iwb_redirecting : 'on';
if ($iwb_redirecting == 'on')
{
$redirecting = 'http://'.$iwb_main_domain.str_replace('&amp;','&',htmlspecialchars($_SERVER['REQUEST_URI']));
if ($_SERVER['HTTP_HOST'] != $iwb_main_domain)
{
header('HTTP/1.1 301 Moved Permanently');
header('Location: '.$redirecting);
exit;
}
}
?>
