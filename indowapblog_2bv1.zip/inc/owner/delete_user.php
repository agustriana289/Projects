<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
$id=$_GET['id'];
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$res=mysql_fetch_array($cek);

if ($res['admin'] == 1)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("delete from user where id='".mysql_real_escape_string($id)."'");

mysql_query("delete from site where id='".mysql_real_escape_string($id)."'");

mysql_query("delete from blog where site_id='".mysql_real_escape_string($id)."'");


mysql_query("delete from comment where site_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from comment where user_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from category where user_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from navigation where site_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from guestbook where user_id='".mysql_real_escape_string($id)."'");


mysql_query("delete from `pm` where `receiver_id`='".mysql_real_escape_string($id)."' or `sender_id`='".mysql_real_escape_string($id)."'");

mysql_query("delete from ads where site_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from chat where user_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from guestbook where site_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from following where site_id='".mysql_real_escape_string($id)."'");

mysql_query("delete from following where url='".mysql_real_escape_string($res['site'])."'");

if (is_dir('data/'.$id.'/'))
{
$files = glob('data/'.$id.'/*');
foreach ($files as $file)
{
unlink($file);
}
}

$head_title='Hapus Pengguna';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">User berhasil dihapus.</div></div>';
require_once('inc/foot.php');
exit;
}
}


$head_title='Hapus Pengguna';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<p>Anda yakin ingin menghapus <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a> sebagai pengguna?<br/>[<a href="owner.php?iwb=delete_user&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="user.php?iwb=list">TIDAK</a>]</p>';
echo '</div></div>';
require_once('inc/foot.php');
}
?>