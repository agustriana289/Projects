<?php

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$dbhost = 'mysql.fav.cc';
$dbname = 'u512542876_db';
$dbuser = 'u512542876_bagas';
$dbpass = 'bagas0';
$iwb_main_domain = 'indowap.fav.cc';

?>