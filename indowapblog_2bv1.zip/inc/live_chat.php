<?php
/*
IndoWapBlog-MS_v1.d.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*/
defined('_IWB_') or die('Akses Terlarang!');
$live_chat=isset($live_chat);
if (!$live_chat)
$live_chat='on';
if ($user_id && $live_chat != 'off')
{
$lc_msg=$_POST['lc_msg'];
$sess=$_POST['sess'];
if (isset($_POST['write_live_chat']) && $user_id)
{
$_flood = ($is_admin) ? 40 : 90;
$flooding = time() - $_flood;
$isflood=mysql_query("select id from chat where user_id='".$user_id."' and time > $flooding");
if (mysql_num_rows($isflood) != 0)
{
$lcerr=$LANG['flooding'];
}
elseif ($_SESSION['sess'] != $sess)
{
$lcerr=$LANG['session_timeout'];
}
elseif (empty($lc_msg))
{
$lcerr=$LANG['empty_text'];
}
elseif (mb_strlen($lc_msg) > 500)
{
$lcerr=str_replace('::number::','500',$LANG['text_max']);
}
elseif ($indowapblog['credit'] < 10)
{
$lcerr=str_replace('::number::','10',str_replace('::more::','<a href="'.$site_url.'/admin.php?iwb=credit">'.$LANG['more'].' &raquo;</a>',$LANG['minim_credit']));
}
else
{
unset($_SESSION['sess']);
}
if (empty($lcerr))
{
$kredit = $indowapblog['credit'] - 10;
mysql_query("update user set credit='".$kredit."' where id='".$user_id."'");
mysql_query("insert into chat set user_id='".$user_id."', text='".mysql_real_escape_string($lc_msg)."', time='".time()."'");
}
else
{
echo '<div id="message"><ol id="error"><li>'.$lcerr.'</li></ol></div>';
}
}
echo '<form action="'.$site['url'].htmlspecialchars($_SERVER['REQUEST_URI']).'" method="post"><div class="two-col-btn"><input class="iwb-text" name="lc_msg" type="text" value=""/>';
$_SESSION['sess'] = md5(strval(rand(1000, 9999)));
echo '<input type="hidden" name="sess" value="'.htmlentities($_SESSION['sess']).'"/><input class="iwb-button" type="submit" name="write_live_chat" style="width: 30%" value="'.$LANG['save'].'"/></div></form>';
$lcreq=mysql_query("select * from chat order by time desc limit 5;");
while ($lcres=mysql_fetch_array($lcreq))
{
echo $i % 2 ? '<div class="row0">' : '<div class="row1">';
echo '<img src="'.$site['url'].'/img.php?img='.$lcres['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/> <a href="'.$site['url'].'/user.php?id='.$lcres['user_id'].'">';
$usr=mysql_fetch_array(mysql_query("select name, author, admin from user where id='".$lcres['user_id']."'"));
if ($usr['author'] == 1 && $usr['admin'] == 0)
{
echo '<font color="green">'.htmlspecialchars($usr['name']).'</font>';
}
elseif ($usr['author'] == 2 && $usr['admin'] == 0)
{
echo '<font color="red">'.htmlspecialchars($usr['name']).'</font>';
}
elseif ($usr['author'] == 3 && $usr['admin'] == 0)
{
echo '<font color="blue">'.htmlspecialchars($usr['name']).'</font>';
}
elseif ($usr['author'] == 4 && $usr['admin'] == 0)
{
echo '<font color="orange">'.htmlspecialchars($usr['name']).'</font>';
}
elseif ($usr['admin'] == 1)
{
echo '<font color="#731174"><b>'.htmlspecialchars($usr['name']).'</b></font>';
}
else
{
echo '<font color="black">'.htmlspecialchars($usr['name']).'</font>';
}
echo '</a>: ';
if (mb_strlen($lcres['text']) > 150)
echo ''.bbsm(substr($lcres['text'],0,150)).' [<a href="'.$site['url'].'/chat.php?iwb=read&amp;cid='.$lcres['id'].'">...</a>]';
else
echo bbsm($lcres['text']);
echo '<br/><span color="#666666">'.time_ago($lcres['time']).'</span>';
echo '<br/>';
$like=mysql_query("select id from chat_like where chat_id='".$lcres['id']."'");
$totallike=mysql_num_rows($like);
$cm = mysql_query("select id from chat_comment where chat_id='".$lcres['id']."'");
$totalcom=mysql_num_rows($cm);
echo '<small><a href="'.$site['url'].'/chat.php?iwb=read&amp;cid='.$lcres['id'].'&amp;view_like='.$lcres['id'].'">'.$totallike.' '.$LANG['likes'].'</a> | <a href="'.$site['url'].'/chat.php?iwb=read&amp;cid='.$lcres['id'].'">'.$totalcom.' '.$LANG['comments'].'</a></small>';
++$i;
echo '</div>';
}
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}
}
?>
