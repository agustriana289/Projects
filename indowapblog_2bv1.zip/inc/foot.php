<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
defined('_IWB_') or die('Akses Terlarang!');
include(''.$root.'inc');
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}
echo '<form action="'.$site['url'].'/search.php" method="get"><div class="two-col-btn"><input class="iwb-text" name="q" type="text" value=""/><input class="iwb-button" type="submit" style="width: 50%" value="'.$LANG['search_submit'].'"/></div></form><br />';
echo '<div id="footer">';
$ol = time() - 300;
$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);
echo 'Online : <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;"><a href="'.$site['url'].'/online.php">'.$user_ol.'</a></span><br/>';
echo '&copy; '.date('Y',time()).' <a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a>
<br><font color="red">Design : <a href="http://id.fav.cc">I.F.C</a></font><br/>Powered by <a href="http://indowapblog.com">IndoWapBlog.com</a></div>';
echo '</body></html>';
mysql_close($iwb_connect);
?>
