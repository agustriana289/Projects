<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang');


set_time_limit(300);
$head_title='Domain Parking';
require_once('inc/head.php');
if (!$is_author)
{
forbidden();
}
else
{
$usite=mysql_fetch_array(mysql_query("SELECT url_www FROM site WHERE id='".$user_id."'"));
$usite1 = str_replace('http://www.', 'http://', $usite['url_www']);
$usite2 = str_replace('http://', 'http://www.', $usite1);



if (isset($_POST['parking']))
{
$domain = htmlentities(strtolower($_POST['domain']));
$dns_a=dns_get_record($domain, DNS_A);
$dns_cname=dns_get_record($domain, DNS_CNAME);
$dns_ns=dns_get_record($domain, DNS_NS);
if ($dns_a[0]['ip'] != '75.126.127.176' &&  $dns_cname[0]['target'] != 'cname.indowapblog.com')
$err .='</li>Record DNS tidak benar</li>';
if (substr($user_site, 7) == $domain)
$err .='<li>Silakan masukan domain baru Anda.</li>';
if (preg_match("/[^a-z0-9\.\_\-]/", $domain))
$err .='<li>Karakter domain tidak benar.</li>';
if (substr($domain, 0, 4) == 'www.' || substr($domain, -15) == 'indowapblog.com' || substr($domain, -7) == 'fixi.in')
$err .='<li>Silakan masukan Domain yang benar.</li>';
if ($domain == 'example.com')
$err .='<li>Silakan masukan domain Anda.</li>';
if (mb_strlen($domain) > 32 || mb_strlen($domain) < 4)
$err .='<li>Domain minimal 4 dan maksimal 32 karakter.</li>';
if (empty($domain))
$err .='<li>Silakan masukan domain.</li>';
$cek_dom='http://'.$domain.'';
$sql=mysql_query("select * from user where site='".mysql_real_escape_string($cek_dom)."'");
if (mysql_num_rows($sql) != 0)
$err .='<li>Domain ini sudah ada yang menggunakan.</li>';
if ($indowapblog['credit'] < 5000)
$err .='<li>Kredit Anda kurang dari Rp 5.000. <a href="'.$site_url.'/admin.php?iwb=credit">Selengkapnya &raquo;</a></li>';
if (empty($err))
{
$opts = array(
'http' =>array(
'method' => "GET",
'header' => "Accept-language: en\r\n" .
"Cookie: foo=bar\r\n"
)
);
$context = stream_context_create($opts);
$request=file_get_contents("http://indowapblog.com.nu/cd.php?dom=".$domain."&act=add&host=indowapblog.com&user=indowapb", false, $context);
if (preg_match("#Sukses#i", $request) || preg_match("#gagal#i", $request))
{
$new_dom='http://'.$domain.'';
mysql_query("update following set url='".mysql_real_escape_string($new_dom)."' where url='".mysql_real_escape_string($user_site)."'");

if (substr($user_site, -15) == 'indowapblog.com' || substr($user_site, -7) == 'fixi.in')
{
mysql_query("update site set url='".mysql_real_escape_string($new_dom)."', url_www='".mysql_real_escape_string($user_site)."' where id='".$user_id."'");
}
else
{
mysql_query("update site set url='".mysql_real_escape_string($new_dom)."' where id='".$user_id."'");
}
$credit = $indowapblog['credit'] - 5000;
mysql_query("update user set site='".mysql_real_escape_string($new_dom)."', credit='".$credit."' where id='".$user_id."'");
$hasil='<ol id="success"><li>Domain <b>'.$domain.'</b> berhasil di parking. Mohon tunggu maksimal 3 jam untuk proses setup dan pastikan pengaturan <b>Name Server (NS)</b> atau <b>Zona Record</b> telah benar.</li></ol>';
}
else
{
$hasil='<ol id="error"><li>Parking domain Gagal. Silakan coba beberapa saat lagi.</li></ol>';
}
}
else
{
$hasil='<ol id="error">'.$err.'</ol>';
}
}

if (isset($_POST['reset']))
{
if ($usite1 == $user_site)
{
$hasil='<ol id="error"><li>Anda belum memparking domain.</li></ol>';
}
else
{
$dd=str_replace('http://', '', $user_site);

mysql_query("update following set url='".mysql_real_escape_string($usite1)."' where url='".mysql_real_escape_string($user_site)."'");

mysql_query("update site set url='".mysql_real_escape_string($usite1)."', url_www='".mysql_real_escape_string($usite2)."' where id='".$user_id."'");
mysql_query("update user set site='".mysql_real_escape_string($usite1)."' where id='".$user_id."'");
$hasil='<ol id="success"><li>Domain berhasil direset menjadi <b>'.$usite1.'</b></li></ol>';
}
}
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content"><div id="main-content">Domain Anda sekarang adalah <b>'.str_replace('http://', '', $user_site).'</b>. Jika Anda ingin memparking domain silakan lihat pengatura <b>Zona Record</b><br /><br /><br /><b>*Zona Record</b><br />A : 75.126.127.176<br />CNAME : cname.indowapblog.com<br /><br />Silakan edit salah satu pengaturan tersebut (NS atau Zona Record) pada hosting yang menyediakan domain Anda.<br /><br /><form method="post" action="admin.php?iwb=domain_parking"><b>Domain:</b><br />';
if (substr($user_site, -15) == 'indowapblog.com' || substr($user_site, -7) == 'fixi.in')
$dom='example.com';
else
$dom=str_replace('http://', '', $user_site);
echo '<input class="iwb-text" type="text" name="domain" value="'.$dom.'"/><br /><small>tanpa menggunakan www</small><br /><div class="two-col-btn"><input class="iwb-button" type="submit" name="parking" value="Parking"/> <input class="iwb-button" type="submit" name="reset" value="Reset"/></div></form></div></div>';
}
require_once('inc/foot.php');
?>
