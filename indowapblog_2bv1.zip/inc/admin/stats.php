<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$page=htmlentities($_GET['page']);
$all=mysql_fetch_array(mysql_query("select sum(total) as totals from stats where site_id='".$user_id."'"));

if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($all['totals'] / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title=$LANG['visitor_statistic'];
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">'.$LANG['total_visitor'].' : '.$all['totals'].'</div>';
echo '<ol>';
$req=mysql_query("select * from stats where site_id='".$user_id."' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<strong>'.$LANG['date'].'</strong> : '.$res['time'].'<br/><strong>'.$LANG['visitor'].'</strong> : '.$res['total'].'';
++$i;
echo '</li>';
}
echo '</ol></div>';
$total=mysql_result(mysql_query("select count(*) as num from stats where site_id='".$user_id."'"), 0);
$link='admin.php?iwb=stats&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
require_once('inc/foot.php');
?>