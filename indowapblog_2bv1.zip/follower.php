<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
define('_IWB_', 1);
require_once('inc/indowapblog.php');
if (!$user_id)
relogin();
$page=$_GET['page'];
$id=isset($_GET['id']) ? trim($_GET['id']) : $user_id;
$req=mysql_query("select name, site from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($req) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$f=mysql_fetch_array($req);
$total=mysql_result(mysql_query("SELECT COUNT(*) AS NUM FROM `following` WHERE `site_id`!='".mysql_real_escape_string($id)."' AND `url`='".mysql_real_escape_string($f['site'])."'"), 0);
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title=''.$LANG['follower'].' '.htmlspecialchars($f['name']).'';
require_once('inc/head.php');
echo '<style type="text/css">
#iphone-list {margin: 2px; padding: 2px;}
#iphone-list li {list-style-type: none; margin: 2px; padding: 2px;}
#iphone-list .heading {list-style-type: none; margin: 2px; padding: 6px 5px 6px 5px; background-color: #333333; color: #FFFFFF; font-weight: bold;}
#iphone-list li a { display:block; padding: 6px 5px 6px 5px;}
.iphone-list-border li a {border-top: 2px solid #B4B4B4;}
#iphone-list li a:hover
{background-color: #E1E1E1;}</style>';
echo '<div id="message">';
echo '</div><div id="content"><div id="main-content"><ul id="iphone-list">';
echo '<li class="heading">'.$LANG['follower'].' '.htmlspecialchars($f['name']).'</li>';
if ($total > 0)
{
$req=mysql_query("select `site_id` from `following` where `site_id`!='".mysql_real_escape_string($id)."' and `url`= '".$f['site']."' order by `time` desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
$follower=mysql_fetch_array(mysql_query("select name, url from site where id='".$res['site_id']."'"));
echo '<li><a href="'.$follower['url'].'">'.htmlspecialchars($follower['name']).'</a></li>';
}
}
else
{
echo '<li>'.$LANG['empty'].'</li>';
}
echo '</ul>';
$link='follower.php?id='.htmlspecialchars($id).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div></div>';
require_once('inc/foot.php');
?>
