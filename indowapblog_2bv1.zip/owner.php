<?php
/*
IndoWapBlog-MS_v1.0.zip
http://id.fav.cc
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/
define('_IWB_', 1);
require_once('inc/indowapblog.php');
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
if (!$user_id)
relogin();
if (!$is_admin)
{
include('inc/head.php');
forbidden();
include('inc/foot.php');
exit;
}
switch ($iwb)
{
case 'post': include('inc/owner/post.php');
break;
case 'filter': include('inc/owner/filter.php');
break;
case 'unbanned':
include('inc/owner/unbanned.php');
break;
case 'forum_setting':
include('inc/owner/forum_setting.php');
break;
case 'delete_user':
include('inc/owner/delete_user.php');
break;
case 'banned':
include('inc/owner/banned.php');
break;
case 'author':
include('inc/owner/author.php');
break;
default:
include('inc/owner/index.php');
break;
}
?>
