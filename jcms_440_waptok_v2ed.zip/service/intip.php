<?php
/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                             Content Management System              //
// Official the project site:      http://johncms.com                     //
// Additional support site:      http://gazenwagen.com                  //
// Additional translation script site:      http://wapmod.net                  //
////////////////////////////////////////////////////////////////////////////////
// JohnCMS core team:                                                         //
// Author john77          john77@gazenwagen.com                  //
// And support by AlkatraZ          alkatraz@gazenwagen.com                //
// Translation english by RYN          admin@wapmod.net                //
//                                                                            //
// Version information see the file version.txt              //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);
$headmod = 'viewer';
$textl = 'Source Viewer';

require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
/*
Source viewer untuk Jcms v3.22
created by RYN
buat member di http://wapmod.net
*/
function wapmod($view){
$view=str_replace("wapmod.net","<b>wapmod.net</b>",$view);
$view=preg_replace("~&lt;[^<>]*&gt;~iU",
"<font color=\"#7fffd4\">\\0</font>",$view);
$view=preg_replace("~(&lt;[^\s!]*\s)([^<>]*)([/?]?&gt;)~iU",
"\\1<font color=\"#00ff00\">\\2</font>\\3",$view);
$view=preg_replace("~&lt;!--.*--&gt;~iU",
"<font color=\"#ffaaff\">\\0</font>",$view);
$view=preg_replace("~(&quot;|&#039;)[^<>]*(&quot;|&#039;)~iU",
"<font color=\"#ffff00\">\\0</font>",$view);
$view=preg_replace("/\{(.*?)\}/i","<font color=\"red\">{\\1}</font>",$view);
$view=str_replace("\r","<br />\r\n",$view);
$view=str_replace("\r\n","<br />",$view);
return $view;}
//jumlah char perhalaman
//$char_per_page=1000;
$karakter=$_GET["kar"];
if($karakter<1000){
/* jika jumlah char perhalaman kurang dari 1000 kita pakai default 1000 */
$karakter=1000;}
//warna text
$text="#0000ff";
//jangan diedit mulai dr sini.. tp boleh aja klo mao edit.
$url=$_GET["url"];
$copy=$_GET["copy"];
//halaman. . .
$hal=$_GET["hal"];
if($hal==""||$hal<=0
)$hal=1;
if(ereg("^http://",$url)){
$ff=@htmlspecialchars(file_get_contents($url));
$ff=nl2br($ff);
}else{
echo '<div class=\"mainblok\"><div class=\"phdr\">Source Viewer</div>';
echo '<div class=\"fmenu\">';
echo "Enter Url<br />";
}
$jumlah=strlen($ff);
$jumlah_items=$jumlah;
$items_per_page=$karakter;
$jumlah_pages=ceil($jumlah_items/$items_per_page); if(($hal>$jumlah_pages)&&
$hal!=1)$hal=$jumlah_pages;
$limit_start=($hal-1)*$items_per_page;
echo "<form action=\"intip.php?copy=$copy\" method=\"get\"><input type=\"text\" name=\"url\" value=\"http://\" /><br />\n";
echo "Lines/page:<input name=\"kar\" type=\"text\" format=\"*n\" size=\"4\" maxlength=\"4\" value=\"3000\" /><br />\n";
//echo "</div>\n";

echo "<input type=\"submit\" value=\"View\" /></form><br />\n";
$pr=($hal*$karakter)-$karakter;
$view=substr($ff,$pr,$karakter);

if($url!="")
{
echo "<div class=\"maintxt\"><a href=\"$url\">$url</a></div>\n";}
echo "<div class=\"maintxt\">\n";
if($copy=="yes"){
echo "<textarea>$view</textarea>";}
else{
echo wapmod($view);}
echo "</div>\n";
//echo "</div>\n";
echo "<div class=\"gmenu\">";
if($copy=="yes"){
echo "<a href=\"intip.php?url=$url&amp;hal=$hal&amp;kar=$karakter\">Mode Normal</a>";}
else{
echo "<a href=\"intip.php?url=$url&amp;copy=yes&amp;hal=$hal&amp;kar=$karakter\">Mode Copy Paste</a>";}
echo "</div>\n";
echo "<div class=\"gmenu\">\n";
if($hal>1 ){
$phal=$hal-1;
echo "<a href=\"intip.php?url=$url&amp;copy=$copy&amp;kar=$karakter&amp;hal=$phal\">[Back|</a>";
}
echo "<a href=\"#top\">Up</a>";
if($hal<$jumlah_pages){
$nhal=$hal +1 ;
echo "<a href=\"intip.php?url=$url&amp;copy=$copy&amp;kar=$karakter&amp;hal=$nhal\">|Next]</a>";
}
if($page>'0' && $num_pages<='10'){
echo "<br />";
for($i=1;$i<=$jumlah_pages;$i++){
if($i!=$hal){
echo "[<a href=\"intip.php?url=$url&amp;hal=$i&amp;copy=$copy&amp;kar=$karakter\">$i</a>]";}else{
echo "[$i]";}}}else
{
echo "<br />$hal/$jumlah_pages<form action=\"intip.php?url=$url&amp;copy=$copy&amp;kar=$karakter\" method=\"get\"><input type=\"text\" format=\"*n\" name=\"hal\" size=\"2\" value=\"\"/><input type=\"submit\" value=\"Go\"/>";
echo "</div>\n";

}
echo "</div>\n";

echo "</div>\n";

require_once('../incfiles/end.php');
?>