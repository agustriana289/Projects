<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

require('../incfiles/head.php');
if (empty($_GET['id'])) {
    echo functions::display_error($lng['error_wrong_data']);
    require('../incfiles/end.php');
    exit;
}
$s = intval($_GET['s']);
// S-SzSzNESlN? N?SlSlS+NeSuS?SlNZ
$req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`, `users`.`podpis`, `users`.`postforum`
FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
WHERE `forum`.`type` = 'm' AND `forum`.`id` = '$id'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . " LIMIT 1");
$res = mysql_fetch_array($req);

// S-SzSzNESlN? N,SuSLN<
$them = mysql_fetch_array(mysql_query("SELECT * FROM `forum` WHERE `type` = 't' AND `id` = '" . $res['refid'] . "'"));
echo '<div class="mainblok"><div class="phdr"><b>' . $lng_forum['topic'] . ':</b>';

#MOD RE PREFIX
echo '<b>';
switch ($them['waptok']){
case 0 :
echo '&nbsp;<span style="color: #000000">[DEFAULT]</span>';
break;
case 1 :
echo '&nbsp;<span style="color: #008000">[SHARE]</span>';
break;
case 2 :
echo '&nbsp;<span style="color: #008000">[MODD]</span>';
break;
case 3 :
echo '&nbsp;<span style="color: #008000">[FIX]</span>';
break;
case 4 :
echo '&nbsp;<span style="color: #ff0000">[ASK]</span>';
break;
case 5 :
echo '&nbsp;<span style="color: #ff0000">[HELP]</span>';
break;
case 6 :
echo '&nbsp;<span style="color: #ff0000">[HOT]</span>';
break;
case 7 :
echo '&nbsp;<span style="color: #0000ff">[DISCUSS]</span>';
break;
case 8 :
echo '&nbsp;<span style="color: #0000ff">[INFO]</span>';
break;
case 9 :
echo '&nbsp;<span style="color: #0000ff">[NOTIFE]</span>';
break;
default:
break;
}
echo '</b>';
echo '&nbsp;' . $them['text'] . '';
echo '</div>';


echo '<div class="newsx">';
if ($set_user['avatar']) {
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td width="32" align="left" valign="top">';
if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
echo '<span class="avatar"><img src="../files/users/avatar/' . $res['user_id'] . '.png" width="32" height="32" alt="' . $res['from'] . '" /></span>';
else
echo '<span class="avatar"><img src="../images/empty.png" width="32" height="32" alt="' . $res['from'] . '" /></span> ';
}

echo '</td><td width="auto" align="left" valign="top">';
if (!empty($user_id) && ($user_id != $res['user_id'])) {
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$res['user_id']. "' LIMIT 1;"), 0);
echo '&nbsp;<a href="../' .$name_lat. '"><b>' . $res['from'] . '</b></a> ';
} else {
echo '&nbsp;<b>' . $res['from'] . '</b>&nbsp;';
}
echo (time() > $res['lastdate'] + 300 ? '<span class="red"> &bull;</span>':'<span class="green"> &bull;</span>');
echo '<br />&nbsp;';
if ($res['postforum'] != 0) {
$arank = $res['postforum'];
if ($arank <= 75)
$arank = 'Newbie';
elseif ($arank <= 200)
$arank = ''.$set['copyright'].' User';
elseif ($arank <= 400)
$arank = ''. $set['copyright'].' Activist';
elseif ($arank <= 600)
$arank = ''.$set['copyright'].' Holic';
elseif ($arank <= 850)
$arank = ''.$set['copyright'].' Addict';
elseif ($arank <= 1200)
$arank = ''.$set['copyright'].' Maniac';
elseif ($arank <= 3200)
$arank = ''.$set['copyright'].' Geek';
elseif ($arank <= 4500)
$arank = ''.$set['copyright'].' Freak';
elseif ($arank >= 5000)
$arank = 'Made in '.$set['copyright'].'';
}
if (!empty($res['pangkat'])){
$jenenge = '' . bbcode::tags($res['pangkat']). '';
}else{
$jenenge = ''.$arank.'';
}
$user_rights = array(
0 => '' . $jenenge . '',
3 => 'Moderator',
6 => 'Staff',
7 => 'Admin',
9 => '<font color="#CC6600">Head Admin</font>'
);
echo @$user_rights[$res['rights']];
echo '</td><td width="auto" align="right" valign="top">';
#PM TOTAL POST
 if ($user_id && $user_id != $res['user_id'])
echo '<a href="../users/pradd.php?act=write&amp;adr=' . $res['user_id'] . '"><b>PM <img src="../images/pm.png"></b></a><br/>';
echo 'Post: <a href="/users/profile.php?act=activity&amp;user=' . $res['user_id'] . '">' . $res['postforum'] . '</a>';

//if (!empty($res['status']))
// Mod total thanks
$waptok = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_thank` WHERE `user` = " . $res['user_id'] . ";"), 0);
echo '<br/><img src="jempol.png" width="14" height="14" alt="waptokthank"/> ' . $waptok . '';

//echo '<br/>' . $res['status'] . '';
if ($set_user['avatar'])
echo '</td></tr></table>';
include 'rank.php';
echo '</div>';
                                      
echo '<div class="forumtxt">';

$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = nl2br($text);
$text = bbcode::tags($text);
if ($set_user['smileys'])
    $text = functions::smileys($text, ($res['rights'] >= 1) ? 1 : 0);
if($user_id) {
$text = str_replace('[you]', $login, $text);
}
else {

$text = str_replace('[you]', 'Guest', $text);
}
$checkthank = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $res['id'] . '" and `user` = "' . $res['user_id'] . '"');
$thankcheck = mysql_result($checkthank, 0);
if($thankcheck < 1 && $user_id != $res['user_id']) {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '<div class="rmenu"><center><b>Hidden content</b></center></div><div class="rmenu"><center>Please Thanks this article to be considered hidden content</center></div>', $text);
} else {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '\1', $text);
}
echo $text;


if ($res['kedit']) {
echo '<p><span class="gray"><small>Edited</small>&nbsp;<b>' . $res['edit'] . '</b>&nbsp;(' . functions::display_date($res['tedit']). ') <b>[' . $res['kedit'] . ']</b></span></p>';
}

$freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] . "'");
if (mysql_num_rows($freq) > 0) {
$fres = mysql_fetch_assoc($freq);
$fls = round(@filesize('../files/forum/attach/' . $fres['filename']) / 1024, 2);
echo '<div class="func"><span class="gray">' . $lng_forum['attached_file'] . ':';
$att_ext = strtolower(functions::format('./files/forum/attach/' . $fres['filename']));
$pic_ext = array(
'gif',
'jpg',
'jpeg',
'png'
);
if (in_array($att_ext, $pic_ext)) {
echo '<div><a href="index.php?act=file&amp;id=' . $fres['id'] . '">';
echo '<img src="thumbinal.php?file=' . (urlencode($fres['filename'])) . '" alt="' . $lng_forum['click_to_view'] . '" /></a></div>';
} else {
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3){
echo '<br /><b>File Locked <img src="../images/lock.gif"/></b><p><span class="red">Min 3 Posts, To Download This File</span></p>';
} else {
echo '<br /><a href="index.php?act=file&amp;id=' . $fres['id'] . '">' . $fres['filename'] . '</a>';
echo ' (' . $fls . ' kb)<br/>';
echo $lng_forum['downloads'] . ': ' . $fres['dlcount'] . ' ' . $lng_forum['time'] . '</span>';
$file_id = $fres['id'];
     if ($rights >= 6)
echo' <a href="index.php?act=delfile&amp;id=' . $fres['id'] . '">Delete attachment</a>';
if ($fls == 0) {
echo'<br/><span style="color : #ff0000">File has been deleted</span>';
}                    
}
}
echo '</div>';
}
include ('prus_mod/ngusere_seneng.php');
include ('prus_mod/ngusere.php');

echo '</div>';

#Mod. Signature
if(!empty($res['podpis']))
echo '<div class="nonex">&#160;<small>' . functions::smileys(bbcode::tags($res['podpis'])) . '</small></div>';
# Bpe? ?c?
echo '<div class="forumb"><table width="100%" cellspacing="0" cellpadding="0"><tr><td width="auto" align="left">';
if ($user_id && $user_id != $res['user_id']) {
include ('prus_mod/ngusere_prus.php');
}
echo '&#160;';
echo '</td><td width="auto" align="right">';
if ($user_id && $user_id != $res['user_id']) {
echo ' <a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '"><img src="../images/reply.png" alt="Reply" /></a>&#160;' .'<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '&amp;cyt"><img src="../images/fquote.png" alt="Quote" /></a>';
}
echo '</td></tr></table></div>';
// S'N<N?SlN?S"NZSuSL, S?Sz SaSzSaSlSa N?N,NESzS?SlN?Su N?SlSlS+NeSuS?SlSu?
$page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" . $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">=" : "<=") . " '$id'"), 0) / $kmess);
echo '<div class="phdr"><a href="index.php?id=' . $res['refid'] . '&amp;page=' . $page . '">' . $lng_forum['back_to_topic'] . '</a></div></div>';
echo '<p><a href="index.php">' . $lng['to_forum'] . '</a></p>';

?>