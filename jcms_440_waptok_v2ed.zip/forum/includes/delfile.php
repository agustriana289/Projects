<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
$error = false;
if ($rights >= 6) {
if ($id) {
//---Get info file---//
//---http://waptok.asia---//
$req = mysql_query("SELECT * FROM `cms_forum_files` WHERE `id` = '$id'");
if (mysql_num_rows($req)) {
$res = mysql_fetch_array($req);
mysql_query("DELETE FROM `cms_forum_files` WHERE `id` = '$id'");
if (file_exists('../files/forum/attach/' . $res['filename'])) {
unlink('../files/forum/attach/' . $res['filename']);
}
require('../incfiles/head.php');
echo'<div class="rmenu">Succesfully deleted<br/><a href="../forum/">To Forum</a></div>';
require('../incfiles/end.php');
} else {
$error = true;
}
if ($error) {
require('../incfiles/head.php');
echo '<div class="rmenu">Not be deleted<br/><a href="../forum/">To Forum</a></div>';
require('../incfiles/end.php');
exit;
}
} else {
require('../incfiles/head.php');
echo functions::display_error($lng['error_wrong_data']);
require('../incfiles/end.php');
exit;
}
}  else {
echo functions::display_error($lng['access_forbidden']);
}
?>