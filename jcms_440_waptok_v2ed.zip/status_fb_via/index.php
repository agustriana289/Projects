<?php
/*
* FunnyFacebook.org Grabber
* Author: Agus Ibrahim
* http://series60.heck.in
* Moduls grab edited in Jcms by http://waptok.asia
*/

include 'head.php';
$home=basename($_SERVER['SCRIPT_FILENAME']);
echo '<div class="mainblok"><div class="phdr"><center><b>STATUS FACEBOOK VIA</b></center></div>
';
$sel=$_GET['via'];
$pg=$_GET['page'];
if (!$sel){
$s=file_get_contents("http://funnyfacebook.org/az_listing.php?page=$pg");
$pecah=explode('<div id="author">',$s);
for ($i=1;$i<sizeof($pecah);$i++){
$via=$pecah[$i];
$via=explode('<div id="item">',$via);
$via=explode('</div>',$via[1]);
$via=$via[0];
$via=str_replace('http://funnyfacebook.org/status_via/','?via=',$via);
echo '<div class="menu"><img src="http://jamesspratt.org/images/icons/16x16/fb_16.gif"> '.$via.'</div>';
} // end for
$nav=explode('<p class="pagination" align="center">',$s);
$nav=explode('</p>',$nav[1]);
$nav=str_replace('http://funnyfacebook.org/az_listing/all/all/all.php','',$nav[0]);
echo "<div class='title'>$nav</div>";
}//end if
else{
//echo 'ok: '.$sel;
$s=file_get_contents("http://funnyfacebook.org/status_via/$sel");
$p=explode('facebook.com/dialog/',$s);
$p=explode("')",$p[1]);
$url='http://facebook.com/dialog/'.$p[0];
header("location: $url");
}
echo'</div>';
include 'foot.php';
                                                  
?>