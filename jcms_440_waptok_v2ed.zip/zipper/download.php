<?php

$url = $_GET[url];
$jar = basename($url);
$zip = str_replace('jar', 'zip', $jar);
$zip = explode('?', $zip);
$zip = trim($zip[0]);

$content = file_get_contents($url);
header('Content-type: application/octet-stream');
header('Content-disposition: inline; filename='.$zip);
header('Content-Length: '.strlen($content));
echo $content;
?>