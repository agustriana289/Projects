<?php

/** Moduls grab Jcms Mod by Whiznoe
* http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'grab maker';
$textl = 'Grab Maker';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");


if (!empty($_POST['site']) and  preg_match('|^[a-z0-9\.\/\?\-\_\=\+\*\&\;\:\#\@\!\,]+$|i',$_POST['site'],$out))
{

$site='http://'.preg_replace('|http\:\/\/|i','',$out[0]);

$text='<?php
$file=file_get_contents(\''.$site.'?\'.$_SERVER[\'QUERY_STRING\']);
';
for($i=1; $i<count($_POST); $i++)
{
if (!empty($_POST['search_'.$i]))
{
$search=$_POST['search_'.$i];
$replace=$_POST['replace_'.$i];
$text.='$file=str_replace(\''.$search.'\',\''.$replace.'\',$file);
';
}
}


$text.='echo $file;
?>';
$array=explode("\r\n",$text);
$rows=count($array)+1;
echo'<div class="menu">
<span style="font-size:16px;">Copy paste kode PHP di bawah ini !<br/></span>
</div>
<div class="fmenu">
<textarea cols="50" rows="'.$rows.'">
'.htmlspecialchars(stripslashes($text), ENT_QUOTES).'
</textarea>
</div>
';
}
else
{
echo '<div class="rmenu">
anda dapat mengulang!<br/>
</div>
';
}
echo'</body>
</html>
';
echo'<div class="gmenu"><a href="index.php"><< Kembali</a></div>';
require_once ("../incfiles/end.php");
?>
