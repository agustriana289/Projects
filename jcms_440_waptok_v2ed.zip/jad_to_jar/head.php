<?php  

/** Moduls grab Jcms Mod by Whiznoe
* http://waptok.asia
*/

define('_IN_JOHNCMS', 1);
$headmod = 'jad to jar';
$textl = 'Jad to Jar';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

?>