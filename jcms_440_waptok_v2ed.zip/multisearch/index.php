<?php
/**
* by http://4alka.tk
* Multi Search & Load Files Jcms
* Moduls Grab repack by http://waptok.asia
*/

include 'config.php';
$title = ''.$searchname.' &#187; by Waptok.Asia';

include 'head.php';
if ($advs == 'on') 
{ 
echo '<div class="mainblok">'; 
include 'ads.php'; 
echo '</div>'; 
} else {
 echo ' '; 
}
echo '<div class="mainblok"><div class="phdr"><a href="/full-search"><b>Search & Load Files</b></a></div>';
echo'<div class="menu"><form method="get" action="'.$searchurl.'/search.php">
<input type="text" name="search" value=""><br>
<select name="sort"><option value="2">All Size</option><option value="1">-1 MB</option></select>
<select name="type">
<option value="mp3">mp3</option>
<option value="mid">mid</option>
<option value="midi">midi</option>
<option value="amr">amr</option>
<option value="wav">wav</option>
<option value="3gp">3gp</option>
<option value="avi">avi</option>
<option value="mp4">mp4</option>
<option value="mpeg">mpeg</option>
<option value="mpg">mpg</option>
<option value="swf">swf</option>
<option value="flv">flv</option>
<option value="bmp">bmp</option>
<option value="gif">gif</option>
<option value="jpg">jpg</option>
<option value="jpeg">jpeg</option>
<option value="png">png</option>
<option value="rar">rar</option>
<option value="zip">zip</option>
<option value="doc">doc</option>
<option value="pdf">pdf</option>
<option value="txt">txt</option>
<option value="xls">xls</option>
<option value="exe">exe</option>
<option value="jar">jar</option>
<option value="jad">jad</option>
<option value="sis">sis</option>
<option value="sisx">sisx</option>
<option value="nth">nth</option>
<option value="thm">thm</option>
<option value="all">all files</option>
</select><br><input value="Search" type="submit"></form>
</div></div>';
echo '<div class="rmenu">Dont Know What To Download then just try our suggested Links</div>';
echo'<div class="mainblok"><div class="menu">';
include 'lastsearch.php';
echo '</div></div>';
if ($advs == 'on') 
{ 
echo '<div class="mainblok">'; 
include 'ads2.php'; 
echo '</div>'; 
} else { 
echo ' '; 
}
include 'foot.php';
?>
