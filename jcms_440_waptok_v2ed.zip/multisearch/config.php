<?php
define('LOGIN','waptok.asia@gmail.com');
define('PASSWORD','your-password');
//edit in account 4shared.com

//ganti dulu dengan akun 4shared punyamu

$searchurl = 'http://waptok.asia/multisearch';
//edit your url without slash at the end

$searchname = 'Unlimited Downloads';
//your site name

$copymark = 'Waptok.Asia | Multi Search & Loads';
//footer text

////////////ads//////////////

$advs = 'off';
//set 'off' or 'on' to show ads & make sure to edit ads.php

?>
