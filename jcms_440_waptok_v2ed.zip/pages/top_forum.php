<?
/** Top Forum Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * http://waptok.asia
 */

echo '<div class="mainblok"><div
class="phdr"><b>Top Forum</b></div>';
echo '<div class="list1"><font color="gray">&bull;&nbsp;<a href="./forum/engine-jcms-v440-waptok_1332_p1.html
">Engine Jcms v440 Waptok</a><div class="sub">
<span class="gray">Engine JohnCMS v440 Mod by <b>Waptok.Asia</b>...</span></div>
</font>
</div>';

echo '<div class="list2"><font color="gray">&bull;&nbsp;<a href="./forum/contes-mod-ads-script_972_p1.html">Kontes Mod Ads Script</a><div class="sub">
<span class="gray">Dapatkan Hadiah Pulsa di <b>Kontes Mod Ads Script</b>...</span></div>
</font>
</div>';

echo '<div class="list1">
&bull;&nbsp;<a href="./forum/jcms_2.html">JohnCMS All Share</a><div class="sub">
<span class="gray">Share here all kind of Johncms scripts, theme, module, etc...</span></div>
</font>
</div></div>';

?>