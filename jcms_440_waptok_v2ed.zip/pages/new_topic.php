<?
// New Topik by mbetixz fixed me
$total_new = mysql_result (mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `close`!='1' "),0);
$xfriends = mysql_query("SELECT * FROM `forum` WHERE `type`='t' ORDER BY `id` DESC LIMIT 5");
$i = 0;
echo '<div class="mainblok">';
echo '<div class="phdr"><b>New Topic</b></div>';
while($topik_baru = mysql_fetch_array($xfriends)){
echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
$uname= mysql_result(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$topik_baru['user_id']."' LIMIT 1"),0);
$tai= mysql_fetch_array(mysql_query("SELECT `time`,`text` FROM `forum` WHERE `refid`='".$topik_baru['id']."' AND `type`= 'm' ORDER BY `id` ASC LIMIT 1"));
echo '<a href="/forum/index.php?id='.$topik_baru['id'].'">'.$topik_baru['text'].'</a> By: '.$topik_baru['from'].' - '.functions::display_date($topik_baru['time']).'</div>';
++$i;
}
echo '</div>';
?>
