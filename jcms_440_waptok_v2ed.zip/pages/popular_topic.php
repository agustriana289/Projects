<?
/** Popular Topic Forum Jcms
 * Copyright Jcms 4.4.0
 * Author http://johncms.com/about
 * http://waptok.asia
 */

echo '<div class="mainblok">';
echo '<div class="phdr"><b>Popular Topic</b></div>';
if (!$is_mobile) {
$req = mysql_query("SELECT *, `id` AS `onespot`, (SELECT COUNT(*) FROM `forum` WHERE `refid` = `onespot` AND `type` = 'm' AND `close` != '1') AS `total_post` FROM `forum` WHERE `type`='t' AND `edit` != '1' AND `close` != '1' ORDER BY `total_post` DESC LIMIT 5");
}else{
$req = mysql_query("SELECT *, `id` AS `onespot`, (SELECT COUNT(*) FROM `forum` WHERE `refid` = `onespot` AND `type` = 'm' AND `close` != '1') AS `total_post` FROM `forum` WHERE `type`='t' AND `edit` != '1' AND `close` != '1' ORDER BY `total_post` DESC LIMIT 5");
}
$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
echo '&#160;<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html'. ($cpg > 1 && $_SESSION['uppost'] ? '&amp;clip&amp;page=' . $cpg : '') . '">' . $res['text'] . '</a>&#160;[' . $colmes1 . ']';
if ($cpg > 1)
echo '&#160;<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&rarr;</a>';
echo '<span class="gray">&nbsp;by: '.$res['from'].'</span>';
echo '</div>';
++$i;
}
echo '</div>';

?>