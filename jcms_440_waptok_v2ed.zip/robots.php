<?php

/*
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights < 7) {
    echo display_error('access denied');
    require_once ('../incfiles/end.php');
    exit;
}
switch ($_GET['from']) {

    default:
    $arrt     = file('../robots.txt');
     echo '<div class="phdr"><a href="index.php"><b>Admin Panel</b></a> | editing robot</div>';
     if ($_GET['m']==1)
      echo '<div class="rmenu">File robot update!</div>';
     echo ' <form action="index.php?act=robots&amp;from=save" method="post">';
                
echo "<textarea id=\"user_text\" rows=\"14\" cols=\"30\" name=\"text1\">";
    foreach ($arrt as $output)
    {
      echo  $output;
    }
echo "</textarea>";
 echo '<div class="phdr">
     <input type="submit" name="submit" value="Submit" />
   </div>
 </form>';
echo '<div class="menu"><a href="index.php?act=robots&amp;from=bots">Boots</a></div>';
    break;
case 'save':    
    $Saved_file = fopen('../robots.txt', 'w+');
fwrite($Saved_file, $_POST['text1']);
fclose($Saved_file);
echo '<script language="JavaScript">
  window.location.href = "index.php?act=robots"
</script>';
break;
case 'bots':
echo '<div class="phdr"><a href="index.php"><b>Admin Panel</b></a> | <a href="index.php?act=robots"><b>Editing Robots</b></a> | View bots</div>';
?>    
    <table>
      <tr>
         <th>Search Engine</th>
         <th><span class="caps"><span class="caps">URL</span></span> </th>
         <th>User-agent </th>
      </tr>
      <tr>
         <td> Google </td>
         <td> <a href="http://www.google.com">http://www.google.com</a> </td>
         <td> Googlebot </td>
      </tr>
      <tr>
         <td> Yahoo! </td>
         <td> <a href="http://www.yahoo.com">http://www.yahoo.com</a> </td>
         <td> Slurp <br />
 Yahoo! Slurp </td>
      </tr>
      <tr>
         <td> <span class="caps"><span class="caps">AOL</span></span> </td>
         <td> <a href="http://www.aol.com">http://www.aol.com</a> </td>
         <td> Slurp </td>
      </tr>
      <tr>
         <td> <span class="caps"><span class="caps">MSN</span></span> </td>
         <td> <a href="http://www.msn.com">http://www.msn.com</a> </td>
         <td> <span class="caps"><span class="caps">MSNB</span></span>ot </td>
      </tr>
      <tr>
         <td> Live </td>
         <td> <a href="http://www.live.com">http://www.live.com</a> </td>
         <td> <span class="caps"><span class="caps">MSNB</span></span>ot </td>
      </tr>
      <tr>
         <td> Ask </td>
         <td> <a href="http://www.ask.com">http://www.ask.com</a> </td>
         <td> Teoma </td>
      </tr>
      <tr>
         <td> AltaVista </td>
         <td> <a href="http://www.altavista.com">http://www.altavista.com</a> </td>
         <td> Scooter </td>
      </tr>
      <tr>
         <td> Alexa </td>
         <td> <a href="http://www.alexa.com">http://www.alexa.com</a> </td>
         <td> ia_archiver </td>
      </tr>
      <tr>
         <td> Lycos </td>
         <td> <a href="http://www.lycos.com">http://www.lycos.com</a> </td>
         <td> Lycos </td>
      </tr>
      <tr>
         <td>Yandex</td>
         <td> <a href="http://www.ya.ru">http://www.ya.ru</a> </td>
         <td> Yandex </td>
      </tr>
      <tr>
         <td> Rambler </td>
         <td> <a href="http://www.rambler.ru">http://www.rambler.ru</a> </td>
         <td> StackRambler </td>
      </tr>
      <tr>
         <td> Mail.ru </td>
         <td> <a href="http://mail.ru">http://mail.ru</a> </td>
         <td> Mail.Ru </td>
      </tr>
      <tr>
         <td> Aport </td>
         <td> <a href="http://www.aport.ru">http://www.aport.ru</a> </td>
         <td> Aport </td>
      </tr>
      <tr>
         <td> Webalta </td>
         <td> <a href="http://www.webalta.ru">http://www.webalta.ru</a> </td>
         <td> WebAlta <br />
 WebAlta Crawler/2.0 </td>
      </tr>
   </table>
    
    <br />


   <p><strong>Note:</strong><br />Some of the major search engines in addition to the major search bots there are robots to index blogs, news, images, etc. Here are some of them:</p>

   <p><strong>Googlebot-Mobile</strong>crawls pages to include in the mobile index.<br />
<strong>Googlebot-Image</strong>page scans for inclusion in the index image.<br />
<strong>Mediapartners-Google</strong>crawls pages to determine AdSense content ads.<br />
<strong>Adsbot-Google</strong>crawls pages to determine the quality of AdWords landing pages.<br />
<strong><span class="caps">MSNB</span>ot-NewsBlogs</strong>- scans to search for news on the Internet.<br />
<strong><span class="caps">MSNB</span>ot-Products</strong>- scans to search for products that can be purchased online.<br />
<strong><span class="caps">MSNB</span>ot-Media</strong> - scans the page to search for multimedia files.<br />
<br />
</p>
    <?php
    break;
}
?>
<!-- Robots.txt Edit by dimko Translite by Aan Gabriel -->
<p>Robots.txt Edit 0.1</p>
<p><a href="index.php">Cpanel</a></p>