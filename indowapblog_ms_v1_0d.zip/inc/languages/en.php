<?php

$LANG = array(
// A
'about' => 'About',
'add' => 'Add',
'added' => 'Added',
'address' => 'Address',
'admin_panel' => 'Panel Owner',
'add_comment' => 'Add Comment',
'add_credit' => 'Top Up Credit',
'add_credit_successfully' => 'Transaction successfully. Please wait for 1x24
hours.',
'Add_file' => 'Add file',
'add_new' => 'Add New',
'admin' => 'Admin',
'ads' => 'Advertising',
'ads_by' => 'Providers
advertising',
'ads_not_added' => 'You have not add advertising',
'ads_smaato_info' => 'Smaato: input AdSpaceID
PublisherID and separated by a
-. Example: PublisherID =
923841640, AdSpaceID =
65,761,223. Then in the form
code that you input the
Publisher:
923841640-65761223',
'ads_was_added' => 'Previously you
had to add ad',
'advertisement' => 'Advertisement',
'advertisement_info' => 'We provide advertising services at a price which is very cheap.<br />Ads will appear in all the pages at random. PPC ads are not using the system but uses a system of the Old Contract.<br />Here are the advertising rates based on the Old Contract',
'ago' => 'ago',
'all' => 'All',
'allow_comment' => 'Allow comment',
'allow_registration' => 'Allow registration',
'allow_registration_author' => 'New
users make the Author',
'all_page' => 'All pages',
'answer' => 'Answer',
'answer_question' => 'Answer',
'approved' => 'Approved',
'art_and_cultur' => 'Art and Culture',
'as_author' => 'Make as Author',
'author' => 'Author',

//B
'back' => 'Back',
'ban' => 'Block',
'baned' => 'Blocked',
'bbcode' => 'BBCode',
'birthday' => 'Date of birth',
'blog' => 'Blog',
'blog_category_
info' => 'Category blog',
'blog_empty' => 'No one published any blog.',
'blog_name' => 'Name',
'blog_name_info' => 'name or title of the blog',
'blog_not_found' => 'Blog does not exist or has been deleted.',
'blog_settings' => 'Blog Settings',
'bookmark' => 'Bookmark',
'blog_category' => 'Blog Category',
'business_and_finance' => 'Business and Finance',
'by' => 'By',

// C
'category' => 'Category',
'category_empty' => 'There are no posts in the category ::name::',
'category_exists' => 'category name already exists',
'category_location' => 'Location Category',
'category_not_found' => 'Category ::name:: does not exist or has been deleted.',
'cancel' => 'Cancel',
'cannot_answer_againt' => 'You can not answer this quiz again',
'change' => 'Edit',
'change_email' => 'Change email',
'change_password' => 'Change password',
'change_saved' => 'Changes saved successfully',
'chatroom' => 'Chat Room',
'chat_notification' => '::name:: comment on your ::chat:: message',
'chat_notification2' => '::name:: also commented on the ::chat:: ::name2::',
'click' => 'Click',
'click_here' => 'Click here',
'code' => 'Code',
'comments' => 'Comment',
'comment_moderate' => 'Comment moderation',
'comment_captcha' => 'Security Code',
'comment_captcha_info' => 'Security code on the comment form',
'comment_email' => 'Email Comments',
'comment_empty' => 'Comment empty',
'comment_notification' => 'There are ::number:: comments awaiting moderation',
'comment_successfully_added' => 'Comment was successfully added',
'comment_waiting_approved' => 'Comment added successfully and will be displayed once approved by the Administrator',
'community' => 'Community',
'confirm' => 'Confirm',
'confirmation_successfully' => 'Confirm
successfully',
'confirm_code_was_sent' => 'confirmation code was sent to your ::via::',
'confirm_new_pwd_msg' =>'To confirm your new password please click ::link::

Thanks.
::site_name::
::site_url::',
'confirm_new_pwd_sbjct' => 'Confirm Password',
'confirm_subscribe' => 'Confirm Subscription',
'contact_us' => 'Contact Us',
'copy_code_here' => 'Copy the code here...',
'country_code' =>'Country code',
'coupon_successfully_sent' => 'Coupon successfully sent to your email, a coupon is valid s/d ::time::',
'coupon_info' => 'If you don\'t have a registration coupon please <a href="register.php?iwb=request_kupon">click here</a>',
'coupon_registration' => 'Enable the registration coupon',
'coupon_registration_info' => 'If enabled will confirm registration email',
'coupon' => 'Coupon',
'create_quiz' => 'Create a quiz',
'credit' => 'Credit',
'credit_after_transfer' => 'Minimum credit remaining after the transfer Rp ::rp::',
'credit_back' => 'Returns the credit',
'credit_back_info' => 'If you have not answered the quiz questions and quizzes are no longer valid please ::click here:: for lines of credit you back',
'credit_not_back' => 'No credit will be returned',
'credit_not_enough' => 'Credit is not enough.',
'credit_was_back' => 'Credit amounting Rp ::number:: successfully restored',

// D
'dashboard' => 'Dashboard',
'date' => 'Date',
'date_register' => 'Registered',
'day' => 'day',
'decade' => 'decade',
'delete' => 'Delete',
'delete_all' => 'Delete all',
'delete_confirm' => 'Are you sure to delete this?',
'delete_post' => 'Delete post',
'delete_author' => 'Delete Author',
'delete_user' => 'Delete user',
'description' => 'Description',
'desc_main_page' => 'Description of the homepage',
'desc_main_page_info' => 'Description blog on category list or homepage',
'display_default' => 'View original display',
'display_html' => 'View source code',
'domain' => 'Domain',
'domain_parking' => 'Domain Parking',
'draft' => 'Draft',

// E
'edit' => 'Edit',
'education' => 'Education',
'email' => 'Email',
'email_not_found' => 'This email address is not found in our database!',
'email_was_used' => 'This email already use by anothor user.',
'empty' => 'Empty!',
'empty_email' => 'Please enter the email',
'empty_text' => 'Text can not be empty',
'empty_title' => 'Title, Description and Category can not be empty',
'empty_username' => 'Please enter your Username',
'empty_password' => 'Please enter password',
'empty_name' => 'Please enter name',
'expired' => 'Valid until',

// F
'failed' => 'Failed',
'feedback' => 'Feedback',
'female' => 'Female',
'field_digit_only' => 'There is not a column
filled with numbers',
'file' => 'File',
'file_exists' =>'Name ::filename:: already exists',
'file_deleted' => 'File successfully deleted',
'file_must_txt' => 'The file extension must be. txt',
'file_must_text_plain' => 'Type the file must be text/plain',
'file_not_found' => 'File not found',
'flooding' => 'Please wait a few seconds longer',
'follow' => 'Follow',
'follow_confirm' => 'Are you sure you
to follow ::site_name::?',
'follower' => 'Follower',
'following' => 'Following',
'follow_date' => 'Follow from',
'following_notification' => 'There are ::number:: new post from blog that you follow',
'forbidden' => 'Access Forbidden. You don\'t have permission to access this page.',
'forgot_password' => 'Forgot password',
'format_birthday' => 'Format the date of birth must be DD-MM-YYYY.',
'forum' => 'Forum',
'for_all' => 'for all',
'for_member' => 'For members',
'for_follower' => 'For followers',
'free_credit' => 'Free Credit',
'free_credit_was_set' => 'Credit Rp ::number:: successfully sent to your account.',
'free_credit_not_sent' => 'Free Credit failed to send.',
'free_credit_term' => 'Terms<br/>* Your credit must be less than Rp 150,<br />* Free Credit can only be taken on Saturday and Sunday.',

// G
'gender' => 'Gender',
'general' => 'General',
'get_free_credit' => 'Get a free credit every Saturday and Sunday, ::link::',
'google_verification' => 'Google Verification',
'google_verification_info' => 'In order to
verify your blog on Google please ::link::. Once you click on the link then select the <b>HTML file upload</b> method and click VERIFY.<br />To access Google Webmaster Tools you must have a Google account.',
'guestbook' => 'Guest Book',
'guestbook_empty' => 'There are no messages in the Guest Book',
'guestbook_notification' => 'There are ::number:: message on the guestbook awaiting moderation.',

// H
'hadiah' => 'Gift',
'health' => 'Health',
'hits' => 'Views',
'hobbies_and_lifestyle' => 'Hobbies and Lifestyle',
'hour' => 'hours',
'homepage' => 'Home',
'html_code' => 'HTML Code',
'html_allowed' => 'HTML code is allowed',
'html_tutorial' => 'HTML tutorial',
'html_tutorial_info' => 'If you want to know more codes in HTML please visit ::w3shools::.',

// I
'icon' => 'Icon',
'icon_info' => 'Favicon must be .ico',
'inbox' => 'Inbox',
'incorrect_ads' => 'Provider of advertising is not true',
'incorrect_confirm_code' => 'Wrong confirmation code!',
'incorrect_coupon' => 'Incorrect coupon
code or out of date.',
'incorrect_data' => 'Incorrect data',
'incorrect_domain' => 'Incorrect Domain',
'incorrect_email' => 'Email address not valid!',
'incorrect_file_type' => 'Incorrect file type',
'incorrect_html_tag' => 'HTML tag not valid!',
'incorrect_name' => 'Name is incorrect!',
'incorrect_password' => 'Password is incorrect!',
'incorrect_phone_number' => 'phone number not valid!',
'incorrect_security_code' => 'Wrong security code!',
'info' => 'Info',
'insert_publisher_code' => 'Please insert the ad code',
'invalid_credit' => 'Credit is not valid.',
'invalid_voucher_code' => 'Voucher code is not Valid.',
'ip_blocked' => 'Your IP ::ip:: blocked from accessing this website.',

// J
'just_now' => 'Just now',

// K
'keywords' => 'Keyword',
'knowledge_base' => 'Knowledge Base',

// L
'language' => 'Language',
'lama_kontrak' => 'Contract',
'last_login' => 'Last login',
'latest_post' => 'Latest Post',
'lenght_category' => 'Name of the category of at least 2 and a maximum of 30 characters',
'lenght_email' => 'Email length of at least 5 and maximum 40 character',
'lenght_name' => 'The length name must least 2 and maximum of 30 characters',
'lenght_password' => 'Password length of at least 4 and maximum of 12 characters',
'lenght_username' => 'The length of username at least 4 and maximum of 32 character.',
'likes' => 'Like',
'likely' => 'You and ::number:: people like this. ::unlike::',
'likely2' => '::number:: people like this, ::likes::',
'link' => 'Link',
'login' => 'Login',
'logo' => 'Logo',
'logout' => 'Exit',

// M
'male' => 'Male',
'manage' => 'Manage',
'manage_comments' => 'Manage comments',
'manage_guestbook' => 'Manage Guestbook',
'manage_post' => 'Manage Blog',
'max_nav_item' => 'Maximum navigation is ::number:: item.',
'member' => 'Member',
'message' => 'Message',
'message_added_successfully' => 'Your message was successfully added',
'message_waiting_approved' => 'Your message successfully added and will be displayed once approved by Administrator',
'message_successfully_deleted' => 'Messages successfully deleted',
'message_successfully_sent' => 'Message successfully sent',
'meta_google' => 'Meta Tag Google',
'minim_credit' => 'The rest of your credit is less than
Rp ::number::, ::more::',
'minute' => 'minutes',
'more' => 'More',
'month' =>'months',
'my_quiz' =>
'My Quiz',

// N
'name' => 'Name',
'navigation' => 'Navigation',
'new_password' => 'New password',
'new_member' => 'New Member',
'next' => 'Next',
'no' => 'No',
'no_logo' => 'No logo',
'not_answer' => 'Not answered',
'not_login' => 'No login',
'not_have_account' => 'Not have an Account',
'not_subscribe' => 'Not subscribe',
'num_post_main' => 'Total posts',
'num_post_main_info' => 'Number of posts displayed on the homepage.',

// O
'official_blog' => 'Official Blog',
'old_password' => 'Old Password',
'on' => 'On',
'other' => 'Other',

// P
'page' => 'Page',
'page_not_found' => 'The page you\'re going does not exist or has been deleted.',
'password' => 'Password',
'payout_credit' => 'Credit Swap',
'payout_credit_successfully' => 'Exchange credit successfully and will be process 1x24 hours.',
'payout_credit_notification' => 'You have tried to swap the loan amounting to Rp ::rp::. Number of transactions ::transaksi::. Please wait for 1x12 hours.',
'penuh' => 'Full',
'permissions' => 'Permissions',
'personal' => 'Personal',
'phone_number' => 'Phone
Number',
'photo' => 'Photo',
'photo_max_200kb' => 'Maximum image size of 200kb',
'photo_successfully_upload' => 'Photo successfully uploaded',
'pm_notification' => 'You have ::number:: new messages',
'post' => 'Post',
'post_empty' => 'Post empt',
'post_only_for_follower' => 'Post only for followers',
'post_only_for_member' => 'Post only
for registered members',
'post_successfully_deleted' => 'Post was successfully deleted',
'post_successfully_publish' => 'Post had published',
'post_successfully_saved' => 'Post successfully saved as draft',
'post_upload_notice' => 'If you want to post using the upload file .txt',
'powered_by' => 'Powered by',
'price' => 'Price',
'private_message' => 'Private Message',
'profile' => 'Profile',
'publish' => 'Published',
'publisher_code' => 'Ad code',
'pulsa' => 'Pulse',

// Q
'question' => 'Question',
'quiz' => 'Quiz',
'quiz_expired' => 'Quiz is no longer valid',
'quiz_was_answered' => 'This quiz has been answered',
'quiz_winer' => 'Successfully answered by ::name::',

// R
'receiver_not_found' => 'Recipient not found',
'receiver_id' => 'Recipient ID',
'redirect' => 'Redirecting...',
'refresh' => 'Refresh',
'reg_coupon_msg' =>
'Coupon Code: ::number::
Expired: ::time::

To continue registration please visit ::link:: and enter the Coupon Code.
Thanks.
::site_name::
::site_url::',
'reg_coupon_subject' => 'Coupon Registration',
'register' => 'Sign Up',
'register_here' => 'Register here',
'registration' => 'registration',
'registration_closed' => 'Registration closed',
'registration_successfully' => 'Registration successful. Please
<a href="login.php">Log in</a> to access your account',
'reg_not_using_coupon' => 'Register does not use the coupon',
'related_post' => 'Related Posts',
'reply' => 'Reply',
'request_coupon' => 'Request Coupon',
'reset' => 'Reset',
'result' => 'Result',
're_password' => 'Repeat password',
're_new_password' => 'Confirm new password',

// S
'save' => 'Save',
'search' => 'Search',
'search_for' => 'Search for',
'search_result' => ' Found ::number:: results for search ::query::',
'search_submit' => 'Search',
'search_not_found' => 'Search not found',
'second' => 'seconds',
'security_code' => 'Security Code',
'select_code' => 'Select Code',
'select_file' => 'Choose file',
'send' =>
'Send',
'sent' => 'Sent',
'send_message' => 'Send Message',
'service_not_available' => 'Service Unavailable',
'session_timeout' => 'Session is up!',
'settings' => 'Settings',
'science_and_technology' => 'Sain and Technology',
'show'=> 'Show',
'show_counter' => 'Show counter',
'show_counter_info' => 'Displays visitor statistics',
'show_following' => 'Show Following',
'show_following_info' => 'Display a link blog that you Follow',
'singkat' => 'Short',
'site' => 'Sites',
'site_not_found' => 'The URL ::site:: not found!',
'site_was_registered' => 'The URL has been used by someone',
'size' => 'Size',
'smiley' => 'Smiley',
'spam' => 'Spam',
'sport' => 'Sports',
'statistics' => 'Statistics',
'subscribe' => 'Subscribe',
'subscribe_comment' => 'Subscribe to comments',
'subscribe_comment_successfully' => 'You
have successfully subscribed',
'subscribe_comment_msg' => 'If You have tried to subscribe to
comment on a post ::blog:: Please click ::link:: to confirm.

Thanks.
::site_name::
::site_url::',
'subscribe_new_comment' => 'Subscribe to new comments',
'subscribe_new_comment_successfully' => 'You have successfully
subscribed to the latest comment',
'subscribe_new_comment_msg' => 'If you have tried to subscribe Recent
comments on ::site_name:: Please click ::link:: to confirm.

Thanks.
::site_name::
::site_url::',
'subscribe_new_post' => 'Subscribe to latest post',
'subscribe_new_post_msg' => 'If you have tried to subscribe to the latest post on ::site_name
please click the ::link:: to confirm
it.

Thanks.
::site_name::
::site_url::',
'subscribe_new_post_successfully' => 'You have successfully subscribed to the latest post',
'subscribe_successfully' => 'You have successfully subscribed',
'successfully_added' => 'Successfully added',
'successfully_confirm' => 'Your account successfully confirmed',

// T
'tag' => 'Tag',
'text' => 'text',
'text_max' => 'Text
maximum ::number:: characters.',
'theme' => 'theme',
'time_zone' => 'Time
zone',
'title' => 'Title',
'to' => 'To',
'total_visitor' => 'Total visitor',
'to_continue' => 'to continue.',
'tos' => 'Terms of Service',
'tos_notice' => 'By clicking &quot;::register::&quot; means you agreed to the Terms
of Service.',
'tos_text' => 'Should not be writing a blog
from the copy.<br/>Forbidden to write blogs
that are scams, sara,
pornography, and harassing
a person.
<br />Prohibited from making
comment SPAM
<br />Prohibited from making a
scene and harassing
members
<br /><br />If you forbid terms then we will follow up and will result in post deletion or blocking of the account.',
'total_credit' => 'The amount of credit you are currently at Rp ::rp::',
'transfer_credit' => 'Transfer Credit',
'transfer_minimum' => 'Transfer of credit of at least Rp ::rp::',
'transfer_notification' => 'You have transferred credit of Rp ::rp:: by ::name::',
'transfer_successfully' => 'Transfer Credit successfully',

// U
'unapproved' => 'Pending',
'unban' => 'Remove Block',
'unfollow' => 'Un Follow',
'unfollow_confirm' => 'Are You sure you to stop following ::site_name::?',
'unlike' => 'Un like',
'unsubscribe' => 'Unsubscribe',
'unsubscribe_successfully' => 'You has been unsubscribed',
'update_time' => 'Update time',
'upload' => 'Upload',
'upload_photo' => 'Upload photo',
'uploaded' => 'Uploaded',
'upload_successfully' => '::filename:: successfully uploaded',
'username' => 'Username',
'username_allowed_chars' => 'Username is
allowed only characters a-z 0-9
and -',
'username_first_and_last' => 'Username must not begin or end in -',
'user_blocked' => 'Sorry, your account has been blocked.<br />Here is your account data
- ID: ::id::<br />- Username: ::username::<br />
- Email: ::email::<br />
If you have any questions about this block please Contact Us',
'users_list' => 'List Members',
'user_not_have_email' => 'This user has no email address in profile!',

// V
'visitor' => 'Visitors',
'visitor_statistic' => 'Visitor Statistics',
'visit_blog' => 'View blog',
'voucher_code' => 'Voucher Code',
'view_code' => 'View Code',

// W
'wap_template' => 'Template WAP',
'web_template' => 'Template WEB',
'week' => 'weeks',
'was_subscribe' => 'You have previously subscribed to.',
'welcome' => '<h3>Ismi.Tk</h3><b>Mobile Blog Hosting service for FREE</b>.<br />Our services are designed and dedicated for mobile phone users who want to have a blog that can be accessed or managed through a mobile phone browser.<br />
Get a blog with a subdomain address that We have provided a Free,
<br />Such as:<br /><b><font color="red">your-name</font>.ismi.tk</b>',
'write' => 'Write',
'write_message' => 'Write message',
'write_post' => 'Write Blog',

// Y
'year' => 'years',
'yes' => 'Yes',
'your_answer' => 'Your
Answer'
);
?>
