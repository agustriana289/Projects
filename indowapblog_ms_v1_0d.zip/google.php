<?php
/*
*Nama Script: IndoWapBlog Multi Site
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

eval(base64_decode("CgojYXV0aG9yOiBkYXJraG9ybgojZGVza3JpcHNpOiBhdXRvIGdvb2dsZSB2ZXJpZmljYXRpb24KJHZlcj1zdWJzdHIoc3RydG9sb3dlcihwcmVnX3JlcGxhY2UoJyMoW1xXX10rKSMnLCctJywkX1NFUlZFUlsnUkVRVUVTVF9VUkknXSkpLDEpOwplY2hvICdnb29nbGUtc2l0ZS12ZXJpZmljYXRpb246ICcuJHZlcjsK"));
?>