<?php
/* Mod QuickChat JohnCMS_4.3.0*/
/* Mod by (Airul) www.wapline.tk */

define('_IN_JOHNCMS', 1);

echo "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='ru'>
<head>
<meta http-equiv='content-type' content='application/xhtml+xml; charset=utf-8'/>";
echo "<link rel='shortcut icon' href='favicon.ico' />
<title>Qchat430 &trade;</title>
<style type='text/css'>
body { font-weight: normal; font-family: Georgia; font-size: 14px; color: #333333; background-color: white; max-width: 550px; margin: auto; padding: 10px; text-align: left }
a:link, a:visited { text-decoration: underline; color : #0000CC}
a:active { text-decoration: underline; color : #0000CC; font-weight: bold; background: #FFFF66 }
a:hover { text-decoration: none; font-size: 12px; color : #FF9733; font-weight: bold; padding:  2px}
.r { color: #000000; font-weight: bold; padding: 5px; text-align: center; font-size: 18px; background: #1e90FF }
.g { color: #000000; font-weight: bold; padding: 5px; text-align: center; font-size: 18px; background: #483086 }
</style>
</head><body>";

require_once ("incfiles/db.php");
        $connect = mysql_connect($db_host, $db_user, $db_pass) or die('cannot connect to server</body></html>');
        mysql_select_db($db_name) or die('cannot connect to db');
        mysql_query("SET NAMES 'utf8'", $connect);

echo '<div class="g">INSTALLATION Qchat Johncms4.3.0 Mod WapLine</div>';

$do = isset($_GET['do']) ? $_GET['do'] : '';

switch ($do)
{
case '1':
echo '<div class="r">Step 1<br />Create Tabel</div>';                      
    mysql_query("CREATE TABLE IF NOT EXISTS `qchat` (
  `id` int(11) NOT NULL auto_increment,
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `time` (`time`)
 ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;") or die('Error step 1!</body></html>');

          
echo 'Installation went well!<br />';
echo '<hr /><a href="install.php?do=2">Next</a>';
break;
        
case '2':
echo '<div class="r">Step 2<br />Installation complete</div>';
echo 'System Configuration Complete!<div class="r">Warning!</div>after installation is complete, do not forget to immediately delete the file install.php';
echo '<br /><a href="index.php">Enter</a><br/>';
break;
   
default:
echo '<div class="r">Quickchat V4.3.0 Mod WapLine</div>';
echo '<br /><a href="install.php?do=1">Start Installation</a>';

}
echo '</body>
</html>';

?>