<?
{
$roq = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 4;");;
while ($res = mysql_fetch_array($roq))
{
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
// icon seks
global $set_user, $realtime, $user_id, $admp, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/avatar/' . $res['user_id'] . '.png')))
echo '<img src="' . $set['homeurl'] . '/files/users/avatar/' . $res['user_id'] . '.png" width="15" height="15" alt="' . $user['name'] . '" /> ';
else
echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="15" height="15" alt="' . $user['name'] . '" /> ';
}
$ontimes = $res['lastdate'] + 300;
if (time() > $ontimes)
{
echo '<span class="red">&bull;</span>';
}
else
{
echo '<font color="blue">&bull;</font>';
}

if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="' . $set['homeurl'] . '/users/profile.php?user=' . $res['user_id'] . '"><b>' . $res['name'] . '</b></a>';
}
else {
echo '<b>' . $res['name'] . '</b>';
}

echo ':';
echo ' ';
$post = (functions::checkout($res['text'], 1, 1));
$post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
// text
if (mb_strlen($post) >= 1000)
{
$post = mb_substr($post, 0, 150);
echo $post.' ';
}
else
{
echo $post;
echo '<br/>';
echo functions::update_time($res['time']);
}
echo '</div>';
++$i;
}
}
echo '<div class="fmenu"><center><a href="index.php?id=' . $user['id'] .'&amp;start=' . $start . '&amp;ob=' . $refr . '">Refresh</a> &bull; <a href="/pages/faq.php?act=smileys">Smileys</a> &bull; <a href="/users/qchat.php">Shoutbox</a></center></div>';
?>
