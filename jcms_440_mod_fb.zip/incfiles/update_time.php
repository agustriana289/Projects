<?php
/*
-----------------------------------------------------------------
Update time
-----------------------------------------------------------------
*/

function update_time($jam) {
global $set_user;
$realtime = time();
$waktu = $jam + ($set_user['sdvig'] * 3600);
$waktu = $jam + ($set_user['sdvig'] * 3600);
$lama=round(($realtime-$waktu)/60);
if($lama==0){
$lama= 'a few second ago';
}
if($lama >0 && $lama < 60){
$lama= $lama . ' minutes ago';
}
if($lama>=60 && $lama<120){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=120 && $lama<180){
$lama=round($lama/60);
$lama=$lama . ' hours ago';}
if($lama>=180 && $lama<240){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=240 && $lama<300){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=300 && $lama<360){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=360 && $lama<420){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=420 && $lama<480){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=480 && $lama<540){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=540 && $lama<600){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=600 && $lama<660){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=660 && $lama<720){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=720 && $lama<780){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=780 && $lama<820){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=820 && $lama<880){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=880 && $lama<920){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=920 && $lama<980){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=980 && $lama<1020){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1020 && $lama<1080){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1080 && $lama<1140){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1140 && $lama<1200){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1200 && $lama<1260){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1260 && $lama<1320){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1320 && $lama<1380){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}
if($lama>=1380 && $lama<1440){
$lama=round($lama/60);
$lama=$lama . ' hours ago';
}

// Jika lebih dari 24 jam
if($lama>=1440 && $lama<2880){
$lama=round($lama/60/24);
$lama='yesterday';
}
// Jika lebih dari 2 hari
if($lama>=2880){
$lama = date("F d h:ia", $waktu);
}
return $lama;

}
?>
