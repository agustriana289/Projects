<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!empty($cms_ads[2]))
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
if ($user_id || $set['active']) { 

echo'<center><div class= "tmn" ><a href= "/" > Beranda </a> &#8226 <a href= "/users/profile.php" > Profil </a> &#8226 <a href= "users/friend.php" > Teman </a> &#8226 <a href= "/users/pradd.php?act=in" > Pesan </a></div></center>';
}
if ($set_user['quick_go']) {
    echo '<form action="' . $set['homeurl'] . '/go.php" method="post">';
    echo '<div><select name="adres" style="font-size:x-small">
    <option selected="selected">' . $lng['quick_jump'] . '</option>
    <option value="guest">' . $lng['guestbook'] . '</option>
    <option value="forum">' . $lng['forum'] . '</option>
    <option value="news">' . $lng['news'] . '</option>
    <option value="gallery">' . $lng['gallery'] . '</option>
    <option value="down">' . $lng['downloads'] . '</option>
    <option value="lib">' . $lng['library'] . '</option>
    <option value="gazen">Gazenwagen :)</option>
    </select><input type="submit" value="Go!" style="font-size:x-small"/>';
    echo '</div></form>';
}
if ($user_id || $set['active']) { 

echo'<center><div class="tmn"><a href= "/users/profile.php?act=office" > Personal</a> &#8226 <a href= "/users/profile.php?act=settings" > Pengaturan </a> &#8226 <a href= "/pages/faq.php" > Bantuan </a></div></center>';

echo'<div class="phdr" ><a href="/exit.php" > Keluar </a> &#8226 [' . ($user_id ? '<b>' . $login . '</b>' : $lng['guest'] . '') . '] &#8226 <a href= "/users/index.php" > Survei </a></div>';
}
   echo '<div class="footer"><a href="' . $set['homeurl'] . '/users/">Member:' . counters::users() . ' </a></div>';
echo '<div class="footer">' . counters::online() . '</div>';
   echo '<div class="list2">'; include_once('member.php');
echo'</div>';
if ($user_id || $set['active']) { 
echo '<div class="tmn"><img src="/images/lib.png"/>  Obrolan Terbaru Q Chat</div>';
echo '<div class="list2">'; echo '<form action="../users/qchat.php?act=say" method="post" id="date">';
echo '<textarea cols="20" rows="1" name="msg"></textarea>';
echo "<input type='submit' title='mengirim pesan' name='submit' value='Shout'/></form>"; echo '</div>';
require_once ($rootpath . 'incfiles/func_quick.php');}
echo'<div class="phdr"><a href="/rina.jar"><b> Unduh </b> </a>Bookmark Ritzclub untuk ponsel anda </div>'; 
echo '<center><div class="phdr">&copy; 2011-KIAMAT  <a href="http://rinanovitasari.mywapblog.com">WWW.RITZCLUB.TK</a></div></center>';
echo '</div></body></html>';
