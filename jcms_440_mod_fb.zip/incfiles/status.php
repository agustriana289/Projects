<?php
define("_IN_JOHNCMS",1);

require 'update_time.php';

//
//
// Tambah status
if(isset($_POST['status']) AND isset($user_id))
{
$status = $_POST['status'];
$err = '';
if(mb_strlen($status) > 200) $err .= 'Maksimal status 200 karakter<br/>';
if(mb_strlen($status) < 5) $err .= 'Minimal status 5 karakter<br/>';
$sama =mysql_result(mysql_query("SELECT COUNT(*) FROM `status` WHERE `id_user` = '".$user_id."' AND `msg` = '".mysql_escape_string($status)."' AND `time` > 'time ()-300' LIMIT 1"),0); if($sama!=0) $err.='Status Sudah Ditambahkan Sebelumnya';
if($err != '')
{
echo '<div class="center">'.functions::display_error($err).'</div>';
}
else
{
$status = mysql_escape_string($status);
@mysql_query("INSERT INTO `status` (`id_user`,  `time`,`msg`,`priv`) values('".$user_id."', '".time()."', '".$status."','yes')");
@mysql_query("UPDATE `users` SET
`status` = '" . $status . "'  WHERE `id` = '" . $user_id . "' LIMIT 1");
echo '<div class="phdr">Status berhasil di ubah</div>';
}
}
// Jika akses pengguna valid maka form akan tampil
if ($user_id && !$ban['1'] && !$ban['10']) {
echo '<form action="?id=' . $user_id . '" method="post">';
echo '<div class="gmenu">';
echo '<b class="shade">Apa yang Anda pikirkan ?</b> <br/>';
echo '<input type="text" value="" name="status" /><br /><input type="submit" value="Bagikan" name="submit" class="button"/>&nbsp;<a href="'.$home.'/pages/faq.php?act=smileys"> SMILE</a>';
echo '</div></form>';
} echo '<div class="phdr">Recent Activity</div>';
require_once 'list.php';

?>
