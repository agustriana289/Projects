<?php
Define("_IN_JOHNCMS",1);
require_once '../incfiles/core.php';
require_once '../incfiles/update_time.php';
$textl='Comments';
require_once '../incfiles/head.php';

if (!isset($_GET['id']) && !is_numeric($_GET['id'])){header("Location: index.php");exit;}
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `status` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"), 0)==0){header("Location: index.php?".SID);exit;}
$status =mysql_query("SELECT * FROM `status` WHERE `id` = '".intval($_GET['id'])."'");
$stats = mysql_fetch_array($status);
$alz = mysql_query("SELECT * FROM `users` WHERE `id` = '".$stats['id_user']."'");
$alzz = mysql_fetch_array ($alz);
echo '<div class="phdr"><a href="'.$home.'/users/profile.php?user='.$alzz["id"].'">'.$alzz["name"].'</a></div><div class="list2 style="padding:2px"><table cellspacing="0"><tr><td class="vtop">';
if (file_exists(('../files/users/photo/' . $stats['id_user'] . '.jpg')))
{ echo '<img src="../files/users/photo/' . $stats['id_user'] . '_small.jpg" width="110" height="110" alt="' . $alzz["name"] . '" />';} else { echo '<img src="../images/empty.png" width="100" height="110" alt="' . $alzz["name"] . '" />'; } echo '</td><td class="vtop">'.$stats[msg].'</td></tr></table>';
echo '<div class="right">';
if($user_id == $stats['id_user'] || $rights >= 7)
{echo '<a href="'.$home.'/status/del.php?id='.$stats["id"].'">Delete</a><br/>';}
echo'<span class="gray">'.update_time($stats["time"],$lama).'</span></div></div>';
if (isset($_POST['msg']) && isset($user))
{
$msg=$_POST['msg'];
if (mb_strlen($msg)>500){$err='Komentar terlalu panjang';}
elseif (mb_strlen($msg)<2){$err='Komentar terlalu pendek';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `status_komm` WHERE `id_status` = '".intval($_GET['id'])."' AND `id_user` = '$user_id' AND `msg` = '".mysql_escape_string($msg)."' LIMIT 1"),0)!=0){$err='Kommentar Sudah Ditambahkan';}
elseif(!isset($err) && (!empty($user_id))) {
mysql_query("INSERT INTO `status_komm` (`id_user`, `time`, `msg`, `id_status`) values('".$user_id."', '".time()."', '".mysql_escape_string($msg)."', '".intval($_GET['id'])."')");
}
}

echo functions::display_error($err);



$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `status_komm` WHERE `id_status` = '".intval($_GET['id'])."'"),0);
if ($total==0){ }else {echo '<div class="phdr">'.$total.' Kommentar</div>';}
$q=mysql_query("SELECT * FROM `status_komm` WHERE `id_status` = '".intval($_GET['id'])."' ORDER BY `id` DESC LIMIT $start, $kmess");
while ($post = mysql_fetch_array($q))
{
$userz =mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` ='".$post['id_user']."'"));
echo $i % 2 ? '<div class="list1">' : '<div class="list2">' ;
//
//
//
echo '<a href="'.$home.'/users/profile.php?user='.$userz["id"].'"><b class="shade">'.$userz["name"].'</b></a>&nbsp;'; echo (time() > $userz['lastdate'] + 300 ? '<img src="'.$home.'/images/user_off.png" alt=""/><br/>' : '<img src="'.$home.'/images/user_on.png" alt=""/><br/>');
$isi_koment = $post['msg'] ; $isi_koment = functions::checkout($isi_koment,1,1); $isi_koment = functions::smileys($isi_koment);
echo ''.$isi_koment.'<div  style="display:block;text-align:right"><span class="gray">'.update_time($post['time'],$lama).'</span></div>';
echo '</div>'; 
++$i;
}
if ($total>$kmess) {echo functions::display_pagination("komm.php?id=".intval($_GET['id']).'&amp;',$start,$total,$kmess);}
// Buaoa copaieo

if (!empty($user_id))
{
echo '<div class="phdr center">Tambahkan Komentar<form method="POST" action="?id='.intval($_GET["id"]).'">
<textarea name = "msg" value=""></textarea>
<input type="submit" value="Post" class="button"/></form></div>';
}
require_once '../incfiles/end.php';
?>
