<?php
/**
* @ORIGINAL SCRIPT BY MBETIXZ (HTTP://JAVA-FANS.TK)
* @AUTHOR: MBETIXZ
* @SITE: HTTP://JAVA-FANS.TK
* @NOTE: TOLONG JANGAN DI HAPUS ATHOR HARGAI KARYA KAMI JIKA ANDA ADALAH MODIFER DAN WAPER SEJATI
*/

define("_IN_JOHNCMS",1);
{
global $realtime; global $user_id;
if(!empty($user_id))
{
$ran_us= mysql_query("SELECT * FROM `users` WHERE `id` != '".$user_id."' ORDER by RAND() LIMIT 1");
while ($rand_us=mysql_fetch_array($ran_us)){
// HTTP://JAVA-FANS.TK
echo '<div class="tmn"><img src="../images/star.gif"> <font color="white">Orang yang mungkin Anda kenal</font></div>';
// HTTP://JAVA-FANS.TK
echo '<div class="maintxt"><table width="100%" border="0"><td width="25%" border="0" color="green"><center>';
// HTTP://JAVA-FANS.TK
global $set_user, $realtime, $user_id, $admp, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/photo/' . $rand_us['id'] . '.jpg')))
echo '<div class="maintxt"><img src="' . $set['homeurl'] . '/files/users/photo/' . $rand_us['id'] . '.jpg" width="50" height="65" alt="' . $rand_us['name'] . '" /></div>';
else
echo '<div class="list1"><img src="' . $set['homeurl'] . '/images/empty.png" width="50" height="60" alt="' . $rand_us['name'] . '" /></div>';
}
echo '</center></td><td>';
echo '<font color="green"><a href="/users/profile.php?user=' . $rand_us['id'] . '"><b>' . $rand_us['name'] . '</b></a></font><br/>';
// HTTP://JAVA-FANS.TK
// Jumlah teman
$belum = 'belum punya';
$friend = mysql_result(mysql_query("SELECT COUNT(*) FROM `friend` WHERE `user` = '" . $rand_us['id'] . "'"), 0);
echo '<b>' . $friend . '</b> <a href="/users/friend.php?user=' . $rand_us['id'] . '">Teman</a><br>';
// HTTP://JAVA-FANS.TK
$friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `friend` WHERE (`user` = '" . $rand_us['id'] . "' AND `friend` = '$user_id') OR (`user` = '$user_id' AND `friend` = '" . $rand_us['id'] . "')"), 0);
if ($rand_us['id'] !=$user_id && mysql_result(mysql_query("SELECT COUNT(*) FROM `friend_notice` WHERE (`user` = '" . $rand_us['id'] . "' AND `to` = '$user_id') OR (`user` = '$user_id' AND `to` = '" . $rand_us['id'] . "')"), 0) == 0 && $friends == 0)
echo '<a    href="/users/friend.php?act=add&amp;user=' . $rand_us['id'] . '">Jadikan Teman</a>&#160;';
if ($friends > 0) echo '<a href="/users/friend.php?act=del&amp;id=' . $rand_us['id'] . '">Hapus Teman ini</a>';
echo'</td></table></div>';
echo '<div class="maintxt"><table width="100%"><tr><td><div align="left">&#187; <a href="' . $set['homeurl'] . '/users/index.php?act=userlist">Lihat saran teman lainnya</a></div></td><td><div align="right"><b>&rarr;</b></div></td></tr></table></div>';
++$i;
}
}
}
?>
