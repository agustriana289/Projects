<?php
define('_IN_JOHNCMS', 1);
$width = '10';
$height = '15';
$med = ($res['postforum'] + $res['postguest'] + $res['komm'] + $res['balans'] + $res['karma_plus']) / ($res['karma_minus'] + 100); 
if ($med >= 1 && $med < 5) 
echo '<img src = "../img/medal/1.png" width="' . $width . '" height="' . $height . '" /> ';
if ($med >= 5 && $med < 10) 
echo '<img src = "../img/medal/2.png" width="' . $width . '" height="' . $height . '" /> ';
if ($med >= 10 && $med < 100) 
echo '<img src = "../img/medal/3.png" width="' . $width . '" height="' . $height . '" /> ';
?>