<?
/*
FULLY MODIFIED BY NGUPRUS
HTTP://NGUPRUS.COM
WE LOVE INDONESIA
*/

$thongkethank = mysql_query("SELECT COUNT(*) from `forum_thank` where `topic`='" . $res["id"] . "'");
$thongkethanks = mysql_result($thongkethank, 0);

$thongkea= @mysql_query("select * from `forum_thank` where `topic` = '" . $res['id'] . "'");
$thongke=mysql_fetch_array($thongkea);
$idthongke=trim($_GET['idthongke']);
if($thongkethanks>0&&(empty($_GET['idthongke'])))
{echo'<div class="gray"><a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;idthongke='.$thongke['id'].'#'.$thongke['id'].'">'.$thongkethanks.' thanks</a></div>';}
if(!empty($idthongke)&&$thongke['id']==$idthongke)
{echo'<div id="'.$idthongke.'" class="camon">People thanked: ';
$thongkeaa= @mysql_query("select * from `forum_thank` where `topic` = '" . $res['id'] . "'");
while ($thongkea = mysql_fetch_array($thongkeaa))
{
{
$dentv=mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$thongkea['userthank'].'"'));
echo '<a href="/users/profile.php?user='.$thongkea['userthank'].'">'.$dentv['name'].'</a>, ';
}
++$f;
}
echo'</div>';}
?>
