<?
/*
FULLY MODIFIED BY NGUPRUS
HTTP://NGUPRUS.COM
WE LOVE INDONESIA
*/

//Terima thank
$checkthank = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $res['id'] . '" and `user` = "' . $res['user_id'] . '"');
if ($user_id && $user_id != $res['user_id'] && (mysql_result($checkthank, 0) < 1)) {
echo'<a href="index.php?id=' . $id . '&amp;thanks=' . $res['id'] . '&amp;user=' . $res['user_id'] . '&amp;start=' . $start . '&amp;thank#thanksyou"><img src="prus_mod/like.gif" alt="like"/>';
echo '</a>';
}


?>
