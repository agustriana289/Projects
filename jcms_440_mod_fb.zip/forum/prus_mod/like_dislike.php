<?
/*
FULLY MODIFIED BY NGUPRUS
HTTP://NGUPRUS.COM
WE LOVE INDONESIA
*/

$checkthankdau = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $_GET['thanks'] . '" and `user` = "' . $_GET['user'] . '"');
if ($user_id && $user_id != $_GET['user'] && (mysql_result($checkthankdau, 0) < 1)) {
if ((isset ($_GET['thank']))&&(isset ($_GET['user']))&&(isset ($_GET['thanks']))) {


echo '<div class="rmenu" id="thanksyou">Ucapan terima kasih anda telah kami terima !</div>';
mysql_query("INSERT INTO `forum_thank` SET
`user` = '".trim($_GET['user'])."',
`topic` = '".trim($_GET['thanks'])."' ,
`time` = '$realtime',
`userthank` = '$user_id',
`chude` = '".$_GET["id"]."'
");

$anu=mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "' . trim($_GET['user']) . '"'));
mysql_query("UPDATE `users` SET `thanked`='" . ($anu['thanked'] + 1) . "' WHERE `id` = '" . trim($_GET['user']) . "'");
mysql_query("UPDATE `users` SET `thanks`='" . ($datauser['thanks'] + 1) . "' WHERE `id` = '" . $user_id . "'");

}
}



?>
