<?php
define("_IN_JOHNCMS",1);
require '../incfiles/core.php';
$textl ='DELETE ';
require '../incfiles/head.php';
if(!$user_id){ header("location:$home"); }
$id =$_GET['id'];
if(empty($_GET['id'])) {header("location:$home"); }
if($rights == 9) {mysql_query("DELETE FROM `status` WHERE `id` = '".$id."' ");}
$q=mysql_query("SELECT * FROM `status` WHERE `id` = '".$id."' AND `id_user` = '".$user_id."'");
while($post= mysql_fetch_array($q)) {
//
if($user_id == $post['id_user']) {mysql_query("DELETE FROM `status` WHERE `id` = '".$id."' AND `id_user` = '".$user_id."'");}
//
mysql_query("OPTIMIZE TABLE `status`");
echo '<div class="phdr center"> Status Berhasil Di Hapus</div>';
require '../incfiles/end.php'; exit; }
//
//
header("location:$home");
//
?>
