<?php

$totalz = mysql_result(mysql_query("SELECT COUNT(*) FROM `status`"),0);

if($totalz==0){   echo '<div class="phdr">No new developments!</div>';
}

$q=mysql_query("SELECT * FROM `status`  ORDER BY `id` DESC LIMIT " . $start . "," . $kmess . ";");
while ($post = mysql_fetch_array($q)){
echo $i % 2 ? '<div class="list1" style="padding:2px">':'<div class="list2" style="padding:2px">';

$uz = @ mysql_query("select * from `users` where id='" . $post['id_user'] . "';");
$ul=mysql_fetch_array($uz);
echo '<table cellspacing="0"><tr><td class="vtop">';
if (file_exists(('./files/users/photo/' . $post['id_user'] . '.jpg')))
{ echo '<img src="./files/users/photo/' . $post['id_user'] . '_small.jpg" width="48" height="48" alt="' . $ul["name"] . '" />&nbsp;';}
else
{ echo '<img src="./images/empty.png" width="32" height="32" alt="' . $ul["name"] . '" />&nbsp;'; }

echo '</td><td class="vtop">';
echo '<a  class="shade" href="'.$home.'/users/profile.php?user='.$ul["id"].'">'.$ul["name"].'</a><br/>'.bbcode::tags($post['msg']).'</td></tr></table>';

if($post['priv'] == 'yes')

{ $komm=mysql_query("SELECT * FROM `status_komm` WHERE `id_status` = '".$post['id']."'");
$komm_count=mysql_num_rows($komm);
echo $komm_count ? '<div style="display:block;text-align:left"><a href="'.$home.'/status/komm.php?id='.$post["id"].'">'.$komm_count.' Comment</a></div>' : '&nbsp;&nbsp;<a href="'.$home.'/status/komm.php?id='.$post["id"].'">Comment</a>';
}
echo'<div style="display:block;text-align:right"><span class="gray">'.update_time($post['time']).'</span></div></div>';
++$i;
}
if($totalz>$kmess){
echo functions::display_pagination('index.php?',$start,$totalz,$kmess);
}
?>
