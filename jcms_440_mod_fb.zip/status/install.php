<?php
Define("_IN_JOHNCMS",1);
require_once '../incfiles/core.php';
require_once '../incfiles/head.php';

@mysql_query("CREATE TABLE `status` (
`id` int(11) NOT NULL auto_increment,
`id_user` int(11) NOT NULL default '0',
`time` int(11) NOT NULL,
`priv` varchar(3) NOT NULL,
`msg` varchar(1024) character set utf8 collate utf8_unicode_ci default NULL,
PRIMARY KEY  (`id`),
KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");


@mysql_query("CREATE TABLE `status_komm` (
`id` int(11) NOT NULL auto_increment,
`id_user` int(11) NOT NULL,
`msg` varchar(500) NOT NULL,
`time` int(11) NOT NULL,
`id_status` int(11) NOT NULL,
PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");


echo "<div class='msg'>Table berhasil dibuat</div>";
echo '<b>PERHATIAN!</b> Segera hapus file ('.$_SERVER['SCRIPT_NAME'].') dari situs!<br />';
require_once '../incfiles/end.php';
?>
