<?php
define('_IN_JOHNCMS', 1);
$headmod = 'priz';
require_once ("../incfiles/core.php");
if (!$user_id) {
require_once ('../incfiles/head.php');
display_error('Only for registered users');
require_once ('../incfiles/end.php');
exit;
}
$user = functions::get_user($user);
if (!$user) {
require('../incfiles/head.php');
echo functions::display_error($lng['user_does_not_exist']);
require('../incfiles/end.php');
exit;
}
if (!$user_id && !$id) {
$textl = 'Mo� �o�ap��';
require_once ('../incfiles/head.php');
echo display_error('Specify <b>id</b> Users!');
require_once ('../incfiles/end.php');
exit;
}
$id = $user['komu'] ? $id: $user_id;
$uz = mysql_query("select `name`, `sex`, `id` from `users` where id='" . $user['id'] . "';");
$mass1 = mysql_fetch_array($uz);
switch ($act) {
case 'in':
$textl = 'Gifts that are received' . ($mass1['sex'] == 'm' ? '' : 'a') .' '.$mass1['name'].'';
require_once ("../incfiles/head.php");
echo '<div class="phdr"><b>'.$textl.'</b> | <a href="../users/profile.php?user='.$id.'">Profile '.$mass1['name'].'</a></div>';
$req = mysql_query("SELECT COUNT(*) FROM `podarok` where `komu`='".$user['id']."' ");
$total = mysql_result($req, 0);
if ($total > 0) {
$req = mysql_query("SELECT * FROM `podarok`  where `komu`='".$user['id']."' ORDER BY `time` DESC LIMIT " . $start . "," . $kmess);
while ($newf = mysql_fetch_array($req)) {
echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
echo '<img src="../podarok/' . $newf['priz'].'.gif" alt="" />';
$nik = mysql_query("select `name`, `rights` from `users` where `id`='" . $newf['user'] . "';");
$nikus = mysql_fetch_array($nik);
echo '<div class="func">From: <a href="profile.php?user='. $newf['user'] . '">'.$nikus['name'].'</a><br/>';
if(!empty($newf['text'])){
$text = $newf['text'];
$text = checkout($text, 1, 1);
if ($set_user['smileys'])$text = smileys($text, $nikus['rights'] >= 1 ? 1: 0);
echo '<b>Comment</b>: ' . $text.'<br/>';}
echo '<b>Date:</b> ' . date("d.m.Y / h:i", $newf['time'] + $set_user['sdvig'] * 3600) . '<br/>';
echo "</div></div>";
++$i;
}
if ($total > $kmess) {
echo '<p>' . pagenav('priz.php?id=' . $id . '&amp;act=in&amp;', $start, $total, $kmess) . '</p>';
}
}
else {
echo "No gifts.<br/>";
}
echo '<div class="phdr">Total gift ' . $total . '</div>';
break;
default:
$textl = 'Gifts, which gave' . ($mass1['sex'] == 'm' ? '' : 'a') .' '.$mass1['name'].'';
require_once ("../incfiles/head.php");
echo '<div class="phdr"><b>'.$textl.'</b> | <a href="../user/profile.php?user='.$id.'">'.$mass1['name'].'</a></div>';
$req = mysql_query("SELECT COUNT(*) FROM `podarok` where `user`='".$id."' ");
$total = mysql_result($req, 0);
if ($total > 0) {
$req = mysql_query("SELECT * FROM `podarok`  where `user`='".$id."' ORDER BY `time` DESC LIMIT " . $start . "," . $kmess);
while ($newf = mysql_fetch_array($req)) {
echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
echo '<img src="../podarok/' . $newf['priz'].'.gif" alt="" />';
$nik = mysql_query("select `name`, `rights` from `users` where `id`='" . $newf['komu'] . "';");
$nikus = mysql_fetch_array($nik);
echo '<div class="func"><b>For:</b> <a href="profile.php?user='. $newf['komu'] . '">'.$nikus['name'].'</a><br/>';
if(!empty($newf['text'])){
$text = $newf['text'];
$text = checkout($text, 1, 1);
if ($set_user['smileys'])$text = smileys($text, $nikus['rights'] >= 1 ? 1: 0);
echo '<b>Comment: </b>' . $text.'<br/>';}
echo '<b>Date:</b> ' . date("d.m.Y / h:i", $newf['time'] + $set_user['sdvig'] * 3600) . '<br/>';
echo "</div></div>";
++$i;
}
if ($total > $kmess) {
echo '<p>' . pagenav('priz.php?id=' . $id . '', $start, $total, $kmess) . '</p>';
}
}
else {
echo "No gift =(<br/>";
}
echo '<div class="phdr">Total gift: ' . $total . '</div>';
break;
}
require_once ("../incfiles/end.php");
?>
