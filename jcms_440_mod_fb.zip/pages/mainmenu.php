<?


defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ($rootpath . 'incfiles/activ.php');

echo'<div class= "tmn"><img src="/images/master.png" />  Kabar berita </div>'; echo'<div class="list1">&#8226 <a href="forum/"><b> Topik  Populer</b></a>(' . counters::forum() . ')</div>';


$mp = new mainpage();

echo $mp->news;

require_once ('last_topik.php');
require_once ($rootpath . 'incfiles/rand_users.php');

echo'<div class= "tmn" ><img src="/images/master.png" />  Bookmark</div>';
echo'<div class= "list1" >&#8226 <a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')<br />&#8226 <a href="pages/faq.php">' . $lng['information'] . ', FAQ</a><br />';
if ($set['mod_guest'] || $rights >= 7) 
   echo'&#8226  <a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')<br />';
if ($set['mod_forum'] || $rights >= 7)
echo'&#8226  <a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')<br/>';
if ($set['mod_down'] || $rights >= 7)
echo'&#8226 <a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')<br/>';
if ($set['mod_lib'] || $rights >= 7)
echo'&#8226  <a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')<br/>';
if ($set['mod_gal'] || $rights >= 7)
echo'&#8226  <a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')<br/>';
if ($user_id || $set['active']) { 
echo'&#8226 <a href="users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')<br/>';
echo'&#8226 <a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')<br/>';
}echo'</div>';
?>