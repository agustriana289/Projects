<?php

define('_IN_JOHNCMS', 1);

$textl = 'situs teman';
$headmod = 'friendssite';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$maxsite = 100; //максимум сайтов
$adddate = 3; //число дней после реги для добавления сайта
$userssite = 3; //число разрешенных сайтов ждля одного юзера
switch ($act) {
case 'delete':
// Удаление сайта
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_GET['yes'])) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>apakah anda yakin untuk menghapus situs ini dari daftar?<br/><a href="friendssite.php?act=delete&amp;id=' . $id . '&amp;yes">ya</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">tidak</a></p></div>';
}
}
break;

case 'edit':
// Редактирование сайта
$req = mysql_query("SELECT * FROM `friendssite` WHERE id='$id' LIMIT 1");
if ($rights >= 6 && mysql_num_rows($req)) {
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 50) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;
$error = array();
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'bidang tidak diperlukan';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'alamat situs tidak valid!';
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=edit&amp;id=' . $id . '">ulangi</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("UPDATE `friendssite` SET `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "', `count`='$count' WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
$res = mysql_fetch_array($req);
echo '<div class="phdr"><b>perubahan situs</b></div>' .
'<div class="menu"><form action="friendssite.php?act=edit&amp;id=' . $id . '" method="post">' .
'alamat&nbsp;-&nbsp;max. 25:<br/><input type="text" name="adres" maxlength="25" value="' . functions::checkout($res['site']) . '"/><br/> ' .
'nama&nbsp;-&nbsp;max. 50:<br/><input type="text" name="name" maxlength="50" value="' . functions::checkout($res['name']) . '"/><br/>' .
'deskripsi&nbsp;-&nbsp;max. 200:<br/><textarea cols="20" rows="2" name="opis">' . htmlentities($res['opis'], ENT_QUOTES, 'UTF-8') . '</textarea><br/>' .
'views:<br/><input type="text" name="count" maxlength="50"  value="' . $res['count'] . '"/><br />' .
'<input name="submit" type="submit" title="klik untuk menambahkan situs" value="simpan"/></form>' .
'</div><div class="phdr"><a href="' . $_SESSION['prd'] . '">kembali</a></div>';
}
}
break;

case 'redirect':
// Редирект
$req = mysql_query("SELECT `site` FROM `friendssite` WHERE `id`='$id' AND `type`='1'");
if(mysql_num_rows($req)) {			$res = mysql_fetch_assoc($req);
if (!$_SESSION['fr_site_' . $id]) {
mysql_query("UPDATE `friendssite` SET `count` = (`count`+1) WHERE `id` = '$id' LIMIT 1");
$_SESSION['fr_site_' . $id] = true;
}
header('location:' . $res['site']);
exit;

}
break;

case 'mass_del':
// Массовое удаление сайтов
if ($rights >= 6) {
if (isset($_GET['yes'])) {
foreach ($_SESSION['dc'] as $delid) {
mysql_query("DELETE FROM `friendssite`  WHERE `id`='" . intval($delid) . "';");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
}
else {
if (empty($_POST['delch'])) {
echo functions::display_error('anda tidak memilih untuk menghapus', '<a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">kembali</a>');
require_once ("../incfiles/end.php");
exit;
}
foreach ($_POST['delch'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>apakah anda yakin untuk menghapus situs?<br/><a href="?act=mass_del&amp;yes">ya</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">tidak</a></p></div>';
}
}
break;

case 'mod_site':
// Сайты на модерации
if ($rights >= 6) {
if (isset($_GET['pr'])) {
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `id` = '$id' LIMIT 1");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite)
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT 1");
header("location: friendssite.php?act=mod_site");
exit;
} elseif (isset($_GET['vs'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if ($total > $maxsite) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
mysql_query("DELETE FROM `friendssite` where `type`='1' ORDER BY `vr` ASC LIMIT $total_mod");
}
mysql_query("UPDATE `friendssite` SET `type` = '1' WHERE `type` = '2'");
header("location: friendssite.php?act=mod_site");
exit;
}
else{

echo '<div class="phdr"><b><a href="friendssite.php">situs teman</a></b> | periksa situs</div>';
$req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='2'");
if(mysql_num_rows($req)) {
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a><br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>tambah <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">hapus</span></a> | <a href="friendssite.php?act=mod_site&amp;id=' . $res["id"] . '&amp;pr">terima</a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">ubah</a></div></div>';
++$i;
}
echo '<div class="rmenu"><input type="submit" value="hapus diperiksa"/></div></form>' .
'<div class="gmenu"><a href="friendssite.php?act=mod_site&amp;vs">terima semua</a></div>';
}
else
echo '<div class="menu"><p>daftar kosong</p></div>';
echo '<div class="phdr"><a href="friendssite.php">kembali</a></div>';
}

}
break;

case 'add_site':
// Добавление сайта
if ($user_id) {
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
$error = array();
if ($total_site >= $userssite && $rights < 6)
$error[] = 'user hanya di izinkan untuk menambahkan satu ' . $userssite . ' situs!';
if ((time()  - $datauser['datereg']) < ($adddate * 86400) && $rights < 6)
$error[] = 'pengguna hanya dapat menambahkan situs setidaknya setelah ' . $adddate . ' hari!';
$flood = functions::antiflood();
if ($flood)
$error[] = 'antiflood! Silahkan, tunggu ' . $flood . ' сек.';
if($error) {
echo display_error($error, '<a href="friendssite.php">Назад</a>');
require_once ("../incfiles/end.php");
exit;
}
if (isset($_POST['submit'])) {
$adres = isset($_POST['adres']) ? parse_url(trim($_POST['adres'])) : array();
$adres = mb_substr($adres['host'], 0, 25);
$name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0, 50) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 200) : '';
$type = $rights >= 6 ? 2 : 2;
if (empty($adres) || empty($name) || empty($opis))
$error[] = 'semuanya harus diisi';
else if (preg_match("/[^\da-zA-Z\.\-\/\?\:\_]+/", $adres))
$error[] = 'alamat situs tidak valid!';
if(!$error) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `name`='" . mysql_real_escape_string($name) . "' OR  `site`='http://" . mysql_real_escape_string($adres) . "'"), 0);
if ($total >= 1)
$error[] = 'nama situs ini sudah ada!';

}
if($error) {
echo functions::display_error($error, '<a href="friendssite.php?act=add_site">ulangi</a>');
require_once ("../incfiles/end.php");
exit;
}
mysql_query("INSERT INTO `friendssite` SET `vr`='" . time() . "', `iduser`='$user_id', `type`='$type', `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `site`='http://" . mysql_real_escape_string($adres) . "'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
echo '<div class="gmenu">situs telah ditambahkan' . ($rights >= 6 ? '' : ' situs anda akan muncul dalam daftar setelah mendapatkan ferivikasi') . '<br/><a href="friendssite.php">daftar situs</a></div>';
}
else {
echo '<div class="phdr"><b><a href="friendssite.php">situs teman</a></b> | menambahkan situs</div>' .
'<div class="bmenu">hanya diperbolehkan link langsung ke,lainya akan dipotong</div><div class="menu">' .
'<form action="friendssite.php?act=add_site" method="post">' .
'alamat&nbsp;-&nbsp;max. 25:<br/><input type="text" name="adres" maxlength="25" value="http://"/><br/> ' .
'nama&nbsp;-&nbsp;max. 50:<br/><input type="text" name="name" maxlength="50"/><br/>' .
'keterangan&nbsp;-&nbsp;max. 200:<br/><textarea cols="20" rows="2" name="opis"></textarea><br/>' .
'<input name="submit" type="submit" title="klik untuk menambahkan situs" value="tambahkan situs"/></form>' .
'</div><div class="phdr"><a href="friendssite.php">Назад</a></div>';
}
}
else {
header('location: ../login.php');
exit;
}
break;
default:
// Список сайтов
echo '<div class="phdr"><b>situs teman</b></div>';
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 6))
echo '<div class="gmenu"><a href="friendssite.php?act=add_site">tambahkan situs</a></div>';
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="friendssite.php?act=mod_site">situs untuk moderasi</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if($total) {    		$req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='1' ORDER BY `friendssite`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 6)
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a> (' . $res['count'] . ')<br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>ditambahkan <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';
if ($rights >= 6)
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="friendssite.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">hapus</span></a> | <a href="friendssite.php?act=edit&amp;id=' . $res["id"] . '">ubah</a></div>';
echo '</div>';
++$i;
}
if ($rights >= 6)
echo '<div class="rmenu"><input type="submit" value="hapus diperiksa"/></div></form>';
}
else
echo '<div class="menu"><p>daftar kosong</p></div>';
echo '<div class="phdr">total:&nbsp;' . $total . '</div>';
if ($total > $kmess) {
echo '<p>' . functions::display_pagination('friendssite.php?', $start, $total, $kmess) . '</p>';
echo '<p><form action="friendssite.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="kehalaman &gt;&gt;"/></form></p>';
}
}
require_once ("../incfiles/end.php");

?>
