//new member//
echo'<div class="footer"><b>New Member: </b></div>';
require_once ($rootpath . 'incfiles/func_warna.php');

echo'<div class="list1">';
$req=mysql_query("SELECT `id`, `name`, `datereg` FROM `users` WHERE (sex='m') ORDER BY `datereg` DESC LIMIT 1; ");
$arr=mysql_fetch_array($req);
echo'<div><img src="../images/lanang.png" width="40" height="40" alt="'.$arr['name'] .'"/><br/> ';
require_once ($rootpath . 'incfiles/func_warna.php');
print'<a href="../users/profile.php?id='.$arr['id'] .'">'.  Warna($arr['name']) .'</a>';

echo'</div>';
/************************************/
echo'<div class="list1">';

$req=mysql_query("SELECT `id`, `name`, `datereg` FROM `users` WHERE (sex='zh') ORDER BY `datereg` DESC LIMIT 1; ");
$arr=mysql_fetch_array($req);
echo'<div><img src="../images/wadon.png"  width="40" height="40" alt="'.$arr['name'] .'"/><br/> ';
print' <a href="../users/profile.php?id='.$arr['id'] .'">'.  Warna($arr['name']) .'</a>';

echo '</div>';
