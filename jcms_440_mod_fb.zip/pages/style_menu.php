<?php

echo '<div class="tmn"><center>' .
(isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act) ? '<a href=\'' . $set['homeurl'] . '\'>' . $lng['homepage'] . '</a> &bull; ' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/users/profile.php?act=office">' . $lng['personal'] . '</a> &bull; ' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/exit.php">' . $lng['exit'] . '</a>' : '<a href="' . $set['homeurl'] . '/login.php">' . $lng['login'] . '</a> &bull; <a href="' . $set['homeurl'] . '/registration.php">' . $lng['registration'] . '</a>') .
'</center></div>';

echo '<div class="phdr"><b>Selamat Datang!!</b></div>';

echo '<center><div class="rmenu"> Indonesian Community</div></center>'; 

echo '<center><div class="phdr"><font color="white">Membantu & menemani Anda mencari Teman, Hiburan, Solusi, Tips dan lain-lain yang mungkin berguna untuk Anda Ayo bergabung bersama Kami disini!!</font></div></center>';
    echo '<div class="gmenu"><form action="login.php" method="post"><p>' . $lng['login_name'] . ':<br/>' .
         '<input type="text" name="n" value="' . htmlentities($user_login, ENT_QUOTES, 'UTF-8') . '" maxlength="20"/>' .
         '<br/>' . $lng['password'] . ':<br/>' .
         '<input type="password" name="p" maxlength="20"/></p>' .
         '<p><input type="checkbox" name="mem" value="1" checked="checked"/>' . $lng['remember'] . '</p>' .
         '<p><input type="submit" value="' . $lng['login'] . '"/></p>' .
         '</form></div>' .
         '<div class="phdr"><a href="users/skl.php?continue">' . $lng['forgotten_password'] . '?</a></div>';
echo'<div class="list1">Belum punya akun Indonesian Community?! <a href="/registration.php">Mendaftar</a></div>';

// Mod new user cowox
$req = mysql_query("SELECT COUNT(*) FROM `users`");
$total = mysql_result($req, 0);
$req = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser` FROM `users` WHERE (sex='m') ORDER BY `datereg` DESC LIMIT 2");
while ($req = mysql_fetch_assoc($req)){
echo '<div align="center"><b>' . $req['name'] . '</b><br>';
// icon seks
global $set_user, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/photo/' . $req['id'] . '.jpg')))
echo '<img src="' . $set['homeurl'] . '/files/users/photo/' . $req['id'] . '.jpg" width="70" height="90" alt="' . $req['name'] . '" /> ';
else
echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="70" height="90" alt="' . $req['name'] . '" /> ';
}

echo '</div>';
}
echo '</div></td><td width="50%"><div class="footer"><b><center>Wanita</center></b></div><div class="list1">';
// Mod new user cewex

$req = mysql_query("SELECT COUNT(*) FROM `users`");
$total = mysql_result($req, 0);
$req = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser` FROM `users` WHERE (sex='zh') ORDER BY `datereg` DESC LIMIT 2");
while ($req = mysql_fetch_assoc($req)){
echo '<div align="center"><b>' . $req['name'] . '</b><br>';
// icon seks
global $set_user, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/photo/' . $req['id'] . '.jpg')))
echo '<img src="' . $set['homeurl'] . '/files/users/photo/' . $req['id'] . '.jpg" width="70" height="90" alt="' . $req['name'] . '" /> ';
else
echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="70" height="90" alt="' . $req['name'] . '" /> ';
}


echo '</div>';
}
echo '</div></td></table>';
?>
