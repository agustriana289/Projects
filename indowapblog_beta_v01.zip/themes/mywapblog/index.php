<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

$search = htmlentities(urlencode($_GET['search']));
$tag = htmlentities($_GET['tag']);
$page = htmlentities($_GET['page']);

if (isset($_GET['search'])) {
$total=mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id='".$site['id']."' and (title LIKE '%".mysql_real_escape_string(urldecode($search))."%' or description LIKE '%".mysql_real_escape_string(urldecode($search))."%') and draft='0'"),0);
$head_title='Pencarian untuk: '.urldecode($search).'';
}
elseif (isset($_GET['tag'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id='".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft = '0'"),0);
$head_title=''.$LANG['tag'].': '.str_replace('-', ' ', $tag);
}
else {
$total=mysql_result(mysql_query("select count(*) as Num from blog where site_id='".$site['id']."' and draft='0'"),0);
}
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

require_once('themes/mywapblog/header.php');
if (isset($_GET['search']))
{
echo '<p class="search_info"><i>'.$total.'</i> ditemukan untuk &quot;<i>'.urldecode($search).'</i>&quot;</p>';
$blog=mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' and (title LIKE '%".mysql_real_escape_string($search)."%' or description LIKE '%".mysql_real_escape_string($search)."%') and draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
}
elseif (isset($_GET['tag'])) {
echo '<p class="search_info">'.$LANG['tag'].' <i>'.str_replace('-', ' ', $tag).'</i></p>';
$blog = mysql_query("SELECT * FROM blog WHERE site_id='".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft='0' ORDER BY time DESC LIMIT $limit,$max_view");
}
else {
$blog=mysql_query("select * from blog where site_id='".$site['id']."' and draft='0' order by time desc limit $limit,$max_view");
}
echo '<div id="content">';

if ($total > 0)
{
$cf=mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id='".$user_id."' and url='".mysql_real_escape_string($site_url)."'"), 0);

while ($blogs=mysql_fetch_array($blog))
{
echo '<div class="post"><h2 class="title"><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">'.htmlspecialchars($blogs['title']).'</a><br /><small>['.waktu($blogs['time']).']</small></h2>';
$desc_leng=strlen(htmlentities(strip_tags($blogs['description'])));
$desc_mainpage=$site['desc_post_main'];
$desc_put=substr(strip_tags($blogs['description']),0,150);
if ($desc_mainpage == 1 || $desc_leng < 149)
$description=$blogs['description'];
else
$description=''.$desc_put.'...<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">[Selengkapnya]</a>';

$komentar=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blogs['id']."' and status='1'"),0);

if ($blogs['private'] == 1)
{
if ($user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>Postingan ini hanya untuk Member. Untuk melihat postingan ini silakan login atau register terlebih dahulu.</p>';
}
elseif ($blogs['private'] == 2)
{
if ($cf != 0 || $site_id == $user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>Postingan ini hanya untuk Pengikut (Follower).</p>';
}
else
{
echo '<p>'.iwb_html($description).'</p>';
}
echo '<p>[<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml#comments">'.$komentar.' Komentar</a>]';
if ($site['display_count'] == 1)
echo ' ['.$blogs['count'].' Dilihat]';
echo '</p>';
echo '<br />';
iwb_ads();
echo '</div>';
}
}
else
{
if (isset($_GET['search']))
{
echo '<div class="post"><h2 class="title">Pencarian tidak ditemukan</h2><p>Pencarian dengan kata kunci &quot;'.urldecode($search).'&quot; tidak ditemukan.</p></div>';
}
elseif (isset($_GET['tag']))
{
echo '<div class="post"><h2 class="title">'.$LANG['tag'].'</h2><p>'.$LANG['empty'].'</p></div>';
}
else {
echo '<div class="post"><h2 class="title">Blog Tidak Ada</h2><p>Belum ada satu pun blog yang dipublikasikan.</p></div>';
}
}
echo '</div>';
if (isset($_GET['search'])) {
$link=''.$site['url'].'/?search='.$search.'&amp;page=';
$q='';
$pagination="on";
$homepage="on";
}
elseif (isset($_GET['tag'])) {
$link=''.$site['url'].'/tag/'.$tag.'/';
$q='.xhtml';
$pagination="on";
$homepage="on";
}
else {
$link=''.$site['url'].'/page/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}
require_once('themes/mywapblog/footer.php');
?>