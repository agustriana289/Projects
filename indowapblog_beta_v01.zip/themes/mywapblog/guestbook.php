<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');
$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) from guestbook where site_id='".$site['id']."' and status='1'"), 0);
$gp = ceil($total / $site['num_post_main']);

if (!ctype_digit($page) || empty($page) || $page > $gp)
{
$page=$gp;
}
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title='Buku Tamu';
require_once('themes/mywapblog/header.php');
echo '<div id="content"><div id="comments"><h2><a name="guestbook">Buku Tamu</a></h2>';
if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$uid=$user_id;
$url=$site_url;
}
else
{
$nama=$_POST['name'];
$email=$_POST['email'];
$uid='0';
$url='';
}
$pesan=$_POST['message'];

if ($site['comment_mod'] == 1)
{
 if ($is_admin)
$sts='1';
else
$sts='0';
}
else
{
$sts='1';
}
$code=intval($_POST['captcha']);

if (isset($_POST['guestbook']))
{

if ($code != $_SESSION['captcha_code'])
$hsl='Kode keamanan yang Anda masukan tidak benar';

if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl='Pesan minimal 2 dan maksimal 500 karakter';
if (empty($pesan))
$hsl='Silakan masukan pesan Anda';
if (empty($email))
$hsl='Silakan masukam Email Anda';
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)
$hsl='Panjang email minimal 5 dan maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl='Alamat Email tidak benar';
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl='Nama minimal 2 dan maksimal 30 karakter';
if (empty($nama))
$hsl='Silakan masukan nama Anda';
if (empty($hsl))
{

mysql_query("insert into `guestbook` set site_id='".$site['id']."', `user_id`='".$uid."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `site`='".mysql_real_escape_string($url)."', `text`='".mysql_real_escape_string($pesan)."', status='".$sts."', `time`='".time()."'") or die(mysql_error());
if ($sts == 1)
$hsl='Pesan Anda berhasil ditambahkan';
else
$hsl='Pesan terkirim dan akan ditampilkan setelah disetujui administrator';
}
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hsl.'</li></ol>';
}

if ($total != 0)
{
$req=mysql_query("select * from guestbook where site_id='".$site['id']."' and status='1' order by time asc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo '<div class="comment">
<p class="title"><strong>';
if (!empty($res['site']))
echo '<a href="'.htmlentities($res['site']).'" rel="nofollow">'.htmlspecialchars($res['name']).'</a>';
else
echo htmlspecialchars($res['name']);
echo '</strong>
<small> ['.waktu($res['time']).']</small></p>
<p><small>'.bbsm($res['text']).'</small></p>
</div>';
}
}
else
{
echo '<div class="comment">
<p class="title"><strong>'.htmlspecialchars($site['name']).'</strong></p><p>Belum ada pesan pada Buku Tamu.<br />Kenapa Anda tidak menjadi penulis pertama?</p></div>';
}
echo '<h2><a name="new_entry">Tulis Baru</a></h2>
<form action="'.$site['url'].'/guestbook.xhtml" method="post">';
$rdr = $site['url'] . htmlspecialchars($_SERVER['REQUEST_URI']);
echo '<p>';
if (!$user_id)
{
echo '[<a href="'.$site['url'].'/login.php?redir='.base64_encode($rdr).'" rel="nofollow">Masuk</a>]<br/>';
}
echo 'Nama: <br/>';
if ($user_id)
{
echo '<b>'.htmlspecialchars($user_name).'</b>';
}
else
{
echo '<input type="text" name="name" value=""/>';
}
echo '<br/>
Email:<br/>';
if ($user_id)
{
echo '<b>'.$user_email.'</b>';
}
else
{
echo '<input type="text" name="email" value=""/>';
}
echo '<br/>Pesan:<br/>
(Kamu bisa menggunakan <a href="'.$site['url'].'/bbsm.php?iwb=bbcode">BBCode</a> dan <a href="'.$site['url'].'/bbsm.php?iwb=smiley">Smiley</a>.)<br/>
<textarea name="message" rows="4"/></textarea>
<br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo 'Keamanan:<br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/>(Masukan kode keamanan)<br/>
<input type="text" name="captcha" value=""/><br/>';
echo '<input name="guestbook" type="submit" value="Simpan"/>
</p>
</form>
</div></div>';

$link=''.$site['url'].'/guestbook/page/';
$q='.xhtml';
$pagination="on";

require_once('themes/mywapblog/footer.php');

?>