<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

if ($_SERVER['REDIRECT_STATUS'] == 400)
{
$head_title='Bad Request';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 403)
{
$head_title='Access Forbidden';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 404)
{
$head_title='Halaman Tidak Ditemukan';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 414)
{
$head_title='Long URI';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 500)
{
$head_title='Internal Server Error';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 502)
{
$head_title='Bad Gateway';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 503)
{
$head_title='Layanan Tidak Tersedia';
}
elseif ($_SERVER['REDIRECT_STATUS'] == 505)
{
$head_title='HTTP Tidak Didukung';
}
else
{
$head_title='Ooopps...';
}

require_once('themes/mywapblog/header.php');
echo '<div class="post"><h2 class="title">'.htmlspecialchars($head_title).'</h2>';
echo '</p>Error Status: '.htmlspecialchars($head_title).'</p></div>';
require_once('themes/mywapblog/footer.php');
?>