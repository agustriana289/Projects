<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');
if ($site['cat_loc']=="foot")
{
show_category();
}

$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) == 0) {

}
else {
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<!-- ads start --><div style="text-align:center;"><a style="color:green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div><!-- ads end -->';
}


echo '<h1 id="navigation">'.$LANG['navigation'].'</h1><!-- navigation start --><div class="navigation">';

if ($homepage != 'off')
echo '<!-- navigation-list start --><div class="navigation-list"><a href="'.$site['url'].'">'.$LANG['homepage'].'</a></div><!-- navigation-list end -->';
$nav=mysql_query("select * from navigation where site_id='".$site['id']."' order by place asc");
while ($navs=mysql_fetch_array($nav))
{
echo '<!-- navigation-list start --><div class="navigation-list">'.iwb_html(str_replace('_SITE_NAME_',$site['name'],str_replace('_SITE_URL_',$site['url'],$navs['code']))).'</div><!-- navigation-list end -->';
}
echo '</div><!-- navigation end -->';

echo '</div><!-- container end --><!-- footer start --><div class="footer"><p>';

$t_day=date('d-m-Y', time());
$qr=mysql_query("select total from stats where site_id='".$site['id']."' and time='$t_day'");
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set site_id='".$site['id']."', total='1', time='$t_day'");
}
else
{
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
mysql_query("update stats set total='$new_count' where site_id='".$site['id']."' and time='$t_day'");
}

if ($site['display_count'] == 1)
{
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats where site_id='".$site['id']."'"));

echo 'Hits Visitor: <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;">'.$t_all['total'].'</span><br/>';
}
echo '&copy; '.date('Y', time()).' - <a href="'.$site['url'].'">'.htmlspecialchars($site['name']).'</a>.<br /><small>'.$LANG['powered_by'].' <a href="http://cuplis.tk">WapMasTer</a></small</p></div><!-- footer end -->';
echo '</body></html>';
mysql_close($iwb_connect);
?>