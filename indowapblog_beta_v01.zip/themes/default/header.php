<?php

defined('_IWB_') or die('Akses Dilarang!');

if ($user_id)
{
if ($indowapblog['ban'] == '1')
{
header('Location: http://indowapblog.com/pulsa.php');
exit;
}
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
if (mysql_num_rows($ip_cek) != 0)
{
header('location: http://indowapblog.com/pulsa.php');
exit;
}
}
$head_title=isset($head_title) ? $head_title : $site['name'];

if ($head_title != $site['name'])
$head_title=''.htmlspecialchars($head_title).' | '.htmlspecialchars($site['name']).'';
else
$head_title=htmlspecialchars($head_title);

$head_description=isset($head_description) ? $head_description : $site['description'];
$head_description=strip_tags($head_description);
$head_description=substr($head_description,0,200);

header("Cache-Control: public");
header('Content-type: application/xhtml+xml; charset=UTF-8');

echo '<?xml version="1.0" encoding="iso-8859-1"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>'.stripslashes($head_title).'</title><link rel="icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" /><link rel="shortcut icon" href="'.$site['url'].'/content/'.htmlspecialchars($site['favicon']).'" type="image/x-icon" /><meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=iso-8859-1" /><meta name="HandheldFriendly" content="True" /><meta name="description" content="'.htmlentities(strip_tags(stripslashes($head_description))).'" /><meta name="keywords" content="'.htmlentities($site['keywords']).'" /><link rel="alternate"
type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml"/>';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

echo '<meta name="viewport" content="width=320" /><meta name="viewport" content="initial-scale=1.0" /><meta name="viewport" content="user-scalable=false" /><meta http-equiv="Cache-Control" content="max-age=1" /><link rel="stylesheet" type="text/css" href="'.$site['url'].'/theme/default/style.css" media="all, handheld">';
echo '<script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script></head><body>';

if (!empty($site['logo']))
{
$headitem='<img src="'.$site['url'].'/content/'.htmlentities($site['logo']).'" alt="'.htmlentities($site['name']).'"/>';
}
else
{
$headitem=htmlspecialchars($site['name']);
}

echo '<!--- header start --><div class="header"><h1><a href="http://cuplis.tk/home.xhtml">'.$headitem.'</a></h1><span>'.htmlspecialchars(stripslashes($site['description'])).'</span></div><!-- header end -->';

echo '<!-- search-bar start --><div id="search-bar"><form action="'.$site['url'].'/" method="GET"><table width="100%" cellspacing="0" cellpadding="0"><tbody><tr align="center"><td width="85%" colspan="4"><input id="search-input" type="text" name="search" value=""></td><td width="15%"><input id="search-submit" type="submit" value="'.$LANG['search_submit'].'"></td></tr></tbody></table></form></div><!-- search-bar end --><!-- container start --><div class="container">';
?>