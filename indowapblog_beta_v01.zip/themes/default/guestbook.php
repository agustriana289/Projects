<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');
$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) from guestbook where site_id='".$site['id']."' and status='1'"), 0);
$gp = ceil($total / $site['num_post_main']);

if (!ctype_digit($page) || empty($page) || $page > $gp)
{
$page=$gp;
}
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

if (isset($_POST['guestbook']))
{

if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$uid=$user_id;
$url=$site_url;
}
else
{
$nama=$_POST['name'];
$email=$_POST['email'];
$uid='0';
$url='';
}
$pesan=$_POST['message'];

if ($site['comment_mod'] == 1)
{
 if ($is_admin)
$sts='1';
else
$sts='0';
}
else
{
$sts='1';
}
$code=intval($_POST['captcha']);

if ($code != $_SESSION['captcha_code'])
$hsl=$LANG['incorrect_security_code'];

if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl=str_replace('::number::','500',$LANG['text_max']);
if (empty($pesan))
$hsl=$LANG['empty_text'];
if (empty($email))
$hsl=$LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)
$hsl=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl=$LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl=$LANG['lenght_name'];
if (empty($nama))
$hsl=$LANG['empty_name'];
if (empty($hsl))
{

mysql_query("insert into `guestbook` set site_id='".$site['id']."', `user_id`='".$uid."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `site`='".mysql_real_escape_string($url)."', `text`='".mysql_real_escape_string($pesan)."', status='".$sts."', `time`='".time()."'") or die(mysql_error());
if ($sts == 1)
$hsl=$LANG['message_added_successfully'];
else
$hsl=$LANG['message_waiting_approved'];
}
$hasil=$hsl;
}
$head_title=$LANG['guestbook'];
require_once('themes/default/header.php');
if ($hasil)
echo '<div class="notice">'.$hasil.'</div>';
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">'.$LANG['homepage'].'</a></td><td width="50%" class="nav-menu current">'.$LANG['guestbook'].'</td></tr></tbody></table><!-- table nav end --><!-- comment start --><div class="comment">';

if ($total != 0)
{
$req=mysql_query("select * from guestbook where site_id='".$site['id']."' and status='1' order by time asc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
if (!empty($res['site']))
$show_user='<a href="'.htmlentities($res['site']).'" rel="dofollow">'.htmlspecialchars($res['name']).'</a>';
else
$show_user = htmlspecialchars($res['name']);
echo '<!-- comment-list start --><div class="comment-list">
<table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%"><div class="comment-photo"><img src="'.$site['url'].'/img.php?img='.$res['user_id'].'.jpg&amp;w=40&amp;h=40" alt=""/></div></td><td width="80%"><div class="comment-name">'.$show_user.'</div><span>'.waktu($res['time']).'</span></td></tr></tbody></table>';
echo '<p class="comment-body">'.bbsm($res['text']).'</p></div><!-- comment-list end -->';
}
$link=''.$site['url'].'/guestbook/page/';
$q='.xhtml';
show_pagination($page,$max_view,$total,$link,$q);
}
else
{
echo '<div class="comment-list">
<p>'.$LANG['guestbook_empty'].'</p></div>';
}
echo '<h2><a name="new_comment">'.$LANG['add'].' '.$LANG['message'].'</a></h2>
<form id="comment-form" action="'.$site['url'].'/guestbook.xhtml" method="post">';
$rdr = $site['url'] . htmlspecialchars($_SERVER['REQUEST_URI']);
if ($user_id)
{
echo '<table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%"><div class="comment-photo"><img src="'.$site['url'].'/img.php?img='.$user_id.'.jpg&amp;w=40&amp;h=40" alt=""/></div></td><td width="80%"><div class="comment-name"><a href="'.$site['url'].'/user.php?id='.$user_id.'">'.htmlspecialchars($user_name).'</a></div><span>(<a href="'.$site['url'].'/login.php?iwb=logout&amp;redir='.base64_encode($rdr).'" rel="nofollow">'.$LANG['logout'].'</a>)</span></td></tr></tbody></table><p>';
}
else
{
echo '<p><a href="'.$site['url'].'/login.php?redir='.base64_encode($rdr).'" rel="nofollow">'.$LANG['login'].'</a><br /><h3>'.$LANG['name'].': </h3><input type="text" name="name" id="name" value="" size="22"><br/><h3>'.$LANG['email'].'</h3><input type="text" name="email" id="email" value="" size="22"><br />';
}
echo '<h3>'.$LANG['message'].':</h3><textarea name="message" id="text" rows="8" cols="20"></textarea>
<br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo '<h3>'.$LANG['security_code'].':</h3>
<img src="'.$site['url'].'/captcha.php" alt="'.$LANG['refresh'].'...."/><br/>
<input type="text" name="captcha" id="captcha" value="" size="22"><br/>';
echo '<input name="guestbook" type="submit" id="submit" value="'.$LANG['send'].'"/></p></form></div>';

require_once('themes/default/footer.php');

?>