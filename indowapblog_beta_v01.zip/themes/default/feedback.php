<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');


if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$sender=$user_id;
}
else
{
$nama=$_POST['senders_name'];
$email=$_POST['senders_email'];
$sender='0';
}
$pesan=$_POST['message'];
$code=intval($_POST['captcha']);

$head_title=$LANG['feedback'];
require_once('themes/default/header.php');
if (isset($_POST['send']))
{
if ($code != $_SESSION['captcha_code'])
$hsl=$LANG['incorrect_security_code'];
if (mb_strlen($pesan) > 500)
$hsl=str_replace('::number::','500',$LANG['text_max']);
if (empty($pesan))
$hsl=$LANG['empty_text'];
if (empty($email))
$hsl=$LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)
$hsl=$LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl=$LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl=$LANG['lenght_name'];
if (empty($nama))
$hsl=$LANG['empty_name'];
if (empty($hsl))
{
mysql_query("insert into `pm` set `receiver_id`='".$site['id']."', `sender_id`='".$sender."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `text`='".mysql_real_escape_string($pesan)."', `read`='1', `time`='".time()."'") or die(mysql_error());
$hsl=$LANG['message_successfully_sent'];
}
echo '<div class="notice">'.$hsl.'</div>';
}
echo '<!-- table nav start --><table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="50%" class="nav-menu"><a href="'.$site_url.'/home.xhtml">Beranda</a></td><td width="50%" class="nav-menu current">'.$LANG['feedback'].'</td></tr></tbody></table><div class="comment">';

echo '<form id="comment-form" action="'.$site['url'].'/feedback.xhtml" method="post">';
if ($user_id)
{
echo '<table width="100%" cellspacing="0" cellpadding="5"><tbody><tr align="center"><td width="20%"><div class="comment-photo"><img src="'.$site['url'].'/img.php?img='.$user_id.'.jpg&amp;w=40&amp;h=40" alt=""/></div></td><td width="80%"><div class="comment-name"><a href="'.$site['url'].'/user.php?id='.$user_id.'">'.htmlspecialchars($user_name).'</a></div><span>(<a href="'.$site['url'].'/login.php?iwb=logout" rel="nofollow">'.$LANG['logout'].'</a>)</span></td></tr></tbody></table><p>';
}
else
{
echo '<p><h3>'.$LANG['name'].'</h3><input type="text" name="senders_name" id="name" value="" size="22"><br /><h3>'.$LANG['email'].'</h3><input type="text" name="senders_email" id="email" value="" size="22"><br />';
}
echo '<h3>'.$LANG['message'].'</h3>
<textarea name="message" id="text" rows="8" cols="20"></textarea><br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo '<h3>'.$LANG['security_code'].'</h3>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/><input type="text" name="captcha" id="captcha" value="" size="22"><br/><input type="submit" name="send" id="submit" value="'.$LANG['send'].'"/></form></div>';
require_once('themes/default/footer.php');
?>