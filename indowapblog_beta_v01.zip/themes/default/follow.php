<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Dilarang!');

if (!$user_id)
{
relogin();
}
else {
$cek=mysql_result(mysql_query("select count(*) as num from following where site_id='".$user_id."' and url='".$site['url']."'"), 0);
if ($cek == 0) {
header("Location: ".$site_url."/admin.php?iwb=following&action=follow&id=".$site_id);
}
else {
header('Location: '.$site['url']);
}
}
?>