<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$search = urlencode($_GET['search']);
$tag = htmlentities($_GET['tag']);
$page = htmlentities($_GET['page']);

if (isset($_GET['search'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND (title LIKE '%".mysql_real_escape_string(urldecode($search))."%' or description LIKE '%".mysql_real_escape_string(urldecode($search))."%') AND draft = '0'"), 0);

$head_title=''.$LANG['search_for'].': '.urldecode($search);
}
elseif (isset($_GET['tag'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft = '0'"), 0);

$head_title=''.$LANG['tag'].': '.str_replace('-', ' ', $tag);
}
else {
$total = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM blog WHERE site_id = '".$site['id']."' AND draft = '0'"), 0);
}

if (empty($page) || $page == 0 || !ctype_digit($page) || $page > (ceil($total / $site['num_post_main'])))
$page = 1;
$page--;
$max_view = $site['num_post_main'];
$limit = $page * $max_view;
$page++;

require_once('themes/desktop/header.php');
echo '<div id="content">';
if (isset($_GET['search']))
{
echo '<h3>'.str_replace('::number::','<i>'.$total.'</i>',str_replace('::query::','&quot;<i>'.htmlentities(urldecode($search)).'</i>&quot;',$LANG['result'])).'</h3>';

$blog = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND (title LIKE '%".mysql_real_escape_string($search)."%' OR description LIKE '%".mysql_real_escape_string($search)."%') AND draft = '0' ORDER BY time DESC LIMIT $limit, $max_view");
}
elseif (isset($_GET['tag'])) {
echo '<h3>'.$LANG['tag'].' <li>'.str_replace('-', ' ', $tag).'</li></h3>';

$blog = mysql_query("SELECT * FROM blog WHERE site_id = '".$site['id']."' AND tag LIKE '%".mysql_real_escape_string($tag)."%' AND draft = '0' ORDER BY time DESC LIMIT $limit, $max_view");
}
else {
$blog=mysql_query("select * from blog where site_id='".$site['id']."' and draft='0' order by time desc limit $limit,$max_view");
}
if ($total > 0)
{
$is_follower = mysql_result(mysql_query("SELECT COUNT(*) FROM following WHERE site_id = '".$user_id."' AND url = '".mysql_real_escape_string($site_url)."'"), 0);
$posted = iwbid($site_id);
while ($blogs = mysql_fetch_array($blog))
{
echo '<div class="post"><h2><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">'.htmlspecialchars($blogs['title']).'</a></h2><p class="meta">'.$LANG['by'].' '.$posted.' '.$LANG['on'].' '.waktu($blogs['time']).'</p><div style="float: left;"></div>';

$desc_leng = strlen(strip_tags($blogs['description']));
$desc_mainpage = $site['desc_post_main'];
$desc_put = substr(strip_tags($blogs['description']),0,300);

if ($desc_mainpage == 1 || $desc_leng < 249)
$description = $blogs['description'];
else
$description = ''.$desc_put.'...<a href="'.$site['url'].'/'.$blogs['link'].'.xhtml">['.$LANG['more'].']</a>';

$komentar = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM comment WHERE blog_id = '".$blogs['id']."' AND status = '1'"), 0);
if ($blogs['private'] == 1) {
if ($user_id)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>'.$LANG['post_only_for_member'].'</p>';
}
elseif ($blogs['private'] == 2) {
if ($site_id == $user_id || $is_follower > 0)
echo '<p>'.iwb_html($description).'</p>';
else
echo '<p>'.$LANG['post_only_for_follower'].'</p>';
}
else {
echo '<p>'.iwb_html($description).'</p>';
}
echo '<p class="comment-meta"><a href="'.$site['url'].'/'.$blogs['link'].'.xhtml#comments">'.$komentar.'</a></p><div style="clear:both"></div></div>';
}
}
else {
if (isset($_GET['search'])) {
echo '<div class="post"><h2>'.$LANG['search_not_found'].'</h2><div style="float: left;"></div></div>';
}
elseif (isset($_GET['tag'])) {
echo '<div class="post"><h2>'.$LANG['tag'].' '.$LANG['empty'].'</h2><div style="float: left;"></div></div>';
}
else {
echo '<div class="post"><h2>'.$LANG['blog_empty'].'</h2><div style="float: left;"></div></div>';
}
}
if (isset($_GET['search'])) {
$link=''.$site['url'].'/?search='.$search.'&amp;page=';
$q='';
$pagination="on";
$homepage="on";
}
elseif (isset($_GET['tag'])) {
$link=''.$site['url'].'/tag/'.$tag.'/';
$q='.xhtml';
$pagination="on";
$homepage="on";
}
else {
$link=''.$site['url'].'/page/';
$pagination="on";
$q='.xhtml';
$homepage="off";
}

if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1) {
echo '<div id="pagination_links">'.$LANG['page'].':<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++) {
if ($page==$i) {
$num=' ['.$i.'] ';
}
else {
$num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';
}
echo $num;
}
echo '</div></div>';
}
echo '</div>';

require_once('themes/desktop/footer.php');
?>