<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$page = $_GET['page'];
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM guestbook WHERE site_id = '".$site['id']."' AND status = '1'"), 0);
$gp = ceil($total / $site['num_post_main']);

if (empty($page) || !ctype_digit($page) || $page == 0 || $page > $gp)
$page = $gp;
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title = $LANG['guestbook'];
require_once('themes/desktop/header.php');
echo '<div id="content">
<div id="comments">
<h2>'.$LANG['guestbook'].'</h2>';
if ($user_id) {
$nama = $user_name;
$email = $user_email;
$uid = $user_id;
$url = $site_url;
}
else {
$nama = $_POST['name'];
$email = $_POST['email'];
$uid = 0;
$url = '';
}
$pesan = $_POST['message'];

$comment_mod=$site['comment_mod'];
if ($comment_mod == 1) {
 if ($is_admin)
$sts = 1;
else
$sts = 0;
}
else {
$sts = 1;
}
$code=intval($_POST['captcha']);

if (isset($_POST['guestbook']))
{
if ($code != $_SESSION['captcha_code'])
$hsl = $LANG['incorrect_security_code'];

if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl = str_replace('::number::','500',$LANG['text_max']);
if (empty($pesan))
$hsl = $LANG['empty_text'];
if (empty($email))
$hsl = $LANG['empty_email'];
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)$hsl = $LANG['lenght_email'];
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl = $LANG['incorrect_email'];
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl = $LANG['lenght_name'];
if (empty($nama))
$hsl = $LANG['empty_name'];
if (empty($hsl))
{
mysql_query("INSERT INTO `guestbook` SET site_id = '".$site['id']."', `user_id` = '".$uid."', `name` = '".mysql_real_escape_string($nama)."', `email` = '".mysql_real_escape_string($email)."', `site` = '".mysql_real_escape_string($url)."', `text` = '".mysql_real_escape_string($pesan)."', status = '".$sts."', `time` = '".time()."'") or die(mysql_error());
if ($sts == 1)
$hsl = $LANG['message_added_successfully'];
else
$hsl = $LANG['message_waiting_approved'];
}
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hsl.'</li></ol>';
}

if ($total != 0)
{
$req = mysql_query("SELECT * FROM guestbook WHERE site_id = '".$site['id']."' AND status = '1' ORDER BY time ASC LIMIT $limit, $max_view");
while ($res=mysql_fetch_array($req))
{
echo '<div class="comment">
<p class="title"><strong>';
if (!empty($res['site']))
echo '<a href="'.htmlentities($res['site']).'" rel="nofollow">'.htmlspecialchars($res['name']).'</a>';
else
echo htmlspecialchars($res['name']);
echo '</strong>
<small> ['.waktu($res['time']).']</small></p>
<p><small>'.bbsm($res['text']).'</small></p>
</div>';
}
}
else
{
echo '<div class="comment">
<p class="title"><strong>'.htmlspecialchars($site['name']).'</strong></p><p>'.$LANG['guestbook_empty'].'</p></div>';
}
echo '<h2><a name="new_entry">'.$LANG['add_new'].'</a></h2>
<form action="'.$site['url'].'/guestbook.xhtml" method="post">';
$rdr=''.$site['url'].$_SERVER['REQUEST_URI'].'';
echo '<p>';
if (!$user_id)
{
echo '[<a href="'.$site['url'].'/login.php?redir='.base64_encode($rdr).'" rel="nofollow">'.$LANG['login'].'</a>]<br/>';
}
echo ''.$LANG['name'].'<br/>';
if ($user_id)
{
echo '<b>'.htmlspecialchars($user_name).'</b>';
}
else
{
echo '<input type="text" name="name" value=""/>';
}
echo '<br/>'.$LANG['email'].'<br/>';
if ($user_id)
{
echo '<b>'.$user_email.'</b>';
}
else
{
echo '<input type="text" name="email" value=""/>';
}
echo ''.$LANG['message'].'<br/>
<textarea name="message" rows="4"/></textarea>
<br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo ''.$LANG['security_code'].'<br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/>
<input type="text" name="captcha" value=""/><br/>';
echo '<input name="guestbook" type="submit" value="'.$LANG['save'].'"/>
</p>
</form>
</div>';
$link=''.$site['url'].'/guestbook/page/';
$q='.xhtml';

if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1)
{
echo '<div id="pagination_links">'.$LANG['page'].':<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</div></div>';
}
echo '</div>';
require_once('themes/desktop/footer.php');
?>