<?php

/*
* author darkhorn
*/

defined('_IWB_') or die('Akses Terlarang');


$head_title=$LANG['google_verification'];
require_once('inc/head.php');
if (!$is_author)
{
forbidden();
}
else
{
echo '<div id="message"></div><div id="content"><div id="main-content">'.str_replace('::link::','<a href="https://www.google.com/webmasters/verification/verification?hl=en&siteUrl='.$user_site.'/&continue=https://www.google.com/webmasters/tools/dashboard?hl%3Den%26siteUrl%3D'.$user_site.'/&pli=1">'.$LANG['click_here'].'</a>',$LANG['google_verification_info']).'</div></div>
';
}
require_once('inc/foot.php');
?>