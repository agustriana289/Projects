<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
$id=htmlentities($_GET['id']);
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
if (isset($_GET['yes']))
{
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
else
{
mysql_query("delete from subscribe where id='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
header('location: admin.php?iwb=subscribe');
}
}
$req=mysql_query("select * from subscribe where id='".mysql_real_escape_string($id)."' and site_id='".$user_id."'");
$head_title='Hapus Pelanggan';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Hapus Pelanggan | <a href="admin.php?iwb=subscribe">Semua Pelanggan</a></div>';
if (mysql_num_rows($req) != 0)
{
$res=mysql_fetch_array($req);
if ($res['sub'] == 'new_posts')
{
$subs='<a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_posts">Posting Terbaru</a>';
}
elseif($res['sub'] == 'new_comments')
{
$subs='<a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_comments">Komentar Terbaru</a>';
}
else
{
$blog=mysql_fetch_array(mysql_query("select title from blog where site_id='".$user_id."' and link='".$res['sub']."'"));
$subs='<a href="admin.php?iwb=subscribe&amp;action=view&amp;sub='.$res['sub'].'">'.htmlspecialchars($blog['title']).'</a>';
}
echo '<p>Anda yakin ingin menghapus <a href="admin.php?iwb=subscribe&amp;action=email&amp;email='.htmlentities($res['email']).'">'.$res['email'].'</a> dari pelanggan '.$subs.'?<br/>[<a href="admin.php?iwb=subscribe&amp;action=delete&amp;id='.$id.'&amp;yes">Ya</a>] [<a href="admin.php?iwb=subscribe">Tidak</a>]</p>';
}
else
{
echo '<p>Pelanggan tidak ditemukan.</p>';
}
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'email':
$email=htmlentities($_GET['email']);
$page=htmlentities($_GET['page']);
if (!ctype_digit($page) || empty($page) || $page == 0)
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title='Pelanggan: '.$email.'';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
$total=mysql_result(mysql_query("select count(*) from subscribe where site_id='".$user_id."' and email='".mysql_real_escape_string($email)."' and status='1'"), 0);
echo '<div id="show_bar">'.$head_title.' ('.$total.') | <a href="admin.php?iwb=subscribe">Semua Pelanggan</a></div>';
if ($total == 0)
{
echo '<p>Belum ada pelanggan.</p>';
}
else
{
echo '<ol>';
$req=mysql_query("select * from subscribe where site_id='".$user_id."' and email='".mysql_real_escape_string($email)."' and status='1' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo 'Berlangganan: '.waktu($res['time']).'<br/>';
if ($res['sub'] == 'new_posts')
{
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_posts">Posting Terbaru</a>';
}
elseif($res['sub'] == 'new_comments')
{
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_comments">Komentar Terbaru</a>';
}
else
{
$blog=mysql_fetch_array(mysql_query("select title from blog where site_id='".$user_id."' and link='".$res['sub']."'"));
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub='.$res['sub'].'">'.htmlspecialchars($blog['title']).'</a>';
}
echo '<br/><span class="action_links">[<a class="delete" href="admin.php?iwb=subscribe&amp;action=delete&amp;id='.$res['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol>';
}
echo '</div>';
if ($total != 0)
{
$link='admin.php?iwb=subscribe&amp;action=email&amp;email='.htmlentities($email).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');
break;

case 'view':
$sub=htmlentities($_GET['sub']);
$page=htmlentities($_GET['page']);

$total=mysql_result(mysql_query("select count(*) from subscribe where site_id='".$user_id."' and sub='".mysql_real_escape_string($sub)."' and status='1'"), 0);

if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
if ($sub == 'new_posts')
{
$head_title='Pelanggan: Posting Terbaru';
}
elseif($sub == 'new_comments')
{
$head_title='Pelanggan: Komentar Terbaru';
}
else
{
$blog=mysql_fetch_array(mysql_query("select title from blog where site_id='".$user_id."' and link='".mysql_real_escape_string($sub)."'"));
$head_title='Pelanggan: '.$blog['title'].'';
}
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">'.$head_title.' ('.$total.') | <a href="admin.php?iwb=subscribe">Semua Pelanggan</a></div>';
if ($total == 0)
{
echo '<p>Belum ada pelanggan.</p>';
}
else
{
echo '<ol>';
$req=mysql_query("select * from subscribe where site_id='".$user_id."' and sub='".mysql_real_escape_string($sub)."' and status='1' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo 'Email: <a href="admin.php?iwb=subscribe&amp;action=email&amp;email='.htmlentities($res['email']).'">'.$res['email'].'</a><br/>Berlangganan: '.waktu($res['time']).'';
echo '<br/><span class="action_links">[<a class="delete" href="admin.php?iwb=subscribe&amp;action=delete&amp;id='.$res['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol>';
}
echo '</div>';
if ($total != 0)
{
$link='admin.php?iwb=subscribe&amp;action=view&amp;sub='.htmlentities($sub).'&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');
break;

default:
if (!$user_id)
relogin();

if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$page=htmlentities($_GET['page']);

$total=mysql_result(mysql_query("select count(*) from subscribe where site_id='".$user_id."' and status='1'"), 0);

if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $site['num_post_main'])))
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title='Pelanggan Blog';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Total Pelanggan: '.$total.'</div>';
if ($total == 0)
{
echo '<p>Belum ada pelanggan.</p>';
}
else
{
echo '<ol>';
$req=mysql_query("select * from subscribe where site_id='".$user_id."' and status='1' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo 'Email: <a href="admin.php?iwb=subscribe&amp;action=email&amp;email='.htmlentities($res['email']).'">'.$res['email'].'</a><br/>Berlangganan: '.waktu($res['time']).'<br/>';
if ($res['sub'] == 'new_posts')
{
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_posts">Posting Terbaru</a>';
}
elseif($res['sub'] == 'new_comments')
{
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub=new_comments">Komentar Terbaru</a>';
}
else
{
$blog=mysql_fetch_array(mysql_query("select title from blog where site_id='".$user_id."' and link='".$res['sub']."'"));
echo 'Topik: <a href="admin.php?iwb=subscribe&amp;action=view&amp;sub='.$res['sub'].'">'.htmlspecialchars($blog['title']).'</a>';
}
echo '<br/><span class="action_links">[<a class="delete" href="admin.php?iwb=subscribe&amp;action=delete&amp;id='.$res['id'].'">Hapus</a>]</span>';
++$i;
echo '</li>';
}
echo '</ol>';
}
echo '</div>';
if ($total != 0)
{
$link='admin.php?iwb=subscribe&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
}
echo '</div>';
require_once('inc/foot.php');
}
?>