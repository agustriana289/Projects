<?php


defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();
if (!$is_author) {
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}

$template = isset($_GET['template']) ? trim($_GET['template']) : '';

switch ($template) {

case 'wap_default':
$head_title='Default (WAP)';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=css_editor">Template</a> | Default (WAP)</div>';
if (isset($_POST['save'])) {
$css = htmlentities($_POST['css']);
if (file_put_contents('themes/default/css/'.$user_id.'.css',$css))
echo '<p>'.$LANG['change_saved'].'</p>';
else
echo '<p>'.$LANG['failed'].'</p>';
}
elseif (isset($_POST['reset'])) {
if (file_exists('themes/default/css/'.$user_id.'.css'))
unlink('themes/default/css/'.$user_id.'.css');
echo '<p>'.$LANG['change_saved'].'</p>';
}
else {
if (file_exists('themes/default/css/'.$user_id.'.css'))
$file = 'themes/default/css/'.$user_id.'.css';
else
$file = 'themes/default/css/default.css';
echo '<p><form method="post" action="admin.php?iwb=css_editor&amp;template=wap_default"><textarea name="css" cols="26" rows="15">'.htmlspecialchars(file_get_contents($file)).'</textarea><br /><br /><div class="two-col-btn"><input type="submit" name="save" value="'.$LANG['save'].'"><input type="submit" name="reset" value="'.$LANG['reset'].'"></div></form><br />';
}
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'wap_mywapblog':
$head_title='MyWapBlog (WAP)';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=css_editor">Template</a> | MyWapBlog (WAP)</div>';
if (isset($_POST['save'])) {
$css = htmlentities($_POST['css']);
if (file_put_contents('themes/mywapblog/css/'.$user_id.'.css',$css))
echo '<p>'.$LANG['change_saved'].'</p>';
else
echo '<p>'.$LANG['failed'].'</p>';
}
elseif (isset($_POST['reset'])) {
if (file_exists('themes/mywapblog/css/'.$user_id.'.css'))
unlink('themes/mywapblog/css/'.$user_id.'.css');
echo '<p>'.$LANG['change_saved'].'</p>';
}
else {
if (file_exists('themes/mywapblog/css/'.$user_id.'.css'))
$file = 'themes/mywapblog/css/'.$user_id.'.css';
else
$file = 'themes/mywapblog/css/default.css';
echo '<p><form method="post" action="admin.php?iwb=css_editor&amp;template=wap_mywapblog"><textarea name="css" cols="26" rows="15">'.htmlspecialchars(file_get_contents($file)).'</textarea><br /><br /><div class="two-col-btn"><input type="submit" name="save" value="'.$LANG['save'].'"><input type="submit" name="reset" value="'.$LANG['reset'].'"></div></form><br />';
}
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'desktop':
$head_title='Default (WEB)';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><div id="show_bar"><a href="admin.php?iwb=css_editor">Template</a> | Default (WEB)</div><p><a href="'.$user_site.'/desktop.iwb">Preview &raquo;</a></p>';
if (isset($_POST['save'])) {
$css = htmlentities($_POST['css']);
if (file_put_contents('themes/desktop/css/'.$user_id.'.css',$css))
echo '<p>'.$LANG['change_saved'].'</p>';
else
echo '<p>'.$LANG['failed'].'</p>';
}
elseif (isset($_POST['reset'])) {
if (file_exists('themes/desktop/css/'.$user_id.'.css'))
unlink('themes/desktop/css/'.$user_id.'.css');
echo '<p>'.$LANG['change_saved'].'</p>';
}
else {
if (file_exists('themes/desktop/css/'.$user_id.'.css'))
$file = 'themes/desktop/css/'.$user_id.'.css';
else
$file = 'themes/desktop/css/default.css';
echo '<p><form method="post" action="admin.php?iwb=css_editor&amp;template=desktop"><textarea name="css" cols="26" rows="15">'.htmlspecialchars(file_get_contents($file)).'</textarea><br /><br /><div class="two-col-btn"><input type="submit" name="save" value="'.$LANG['save'].'"><input type="submit" name="reset" value="'.$LANG['reset'].'"></div></form><br />';
}
echo '</div></div>';
require_once('inc/foot.php');
break;

default:
$head_title='CSS Editor';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><div id="show_bar">Template</div>';
echo '<div class="row0"><a href="admin.php?iwb=css_editor&amp;template=wap_default">Default (WAP)</a></div><div class="row1"><a href="admin.php?iwb=css_editor&amp;template=wap_mywapblog">MyWapBlog (WAP)</a></div><div class="row0"><a href="admin.php?iwb=css_editor&amp;template=desktop">Default (WEB)</a></div>';
echo '</div></div>';
require_once('inc/foot.php');
break;
}
?>