<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

$root=isset($root) ? $root : '';

$head_title=isset($head_title) ? $head_title : $site['name'];

$head_title=htmlspecialchars($head_title);
$deskripsi=isset($head_description) ? $head_description : $site['description'];

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>'.$head_title.'</title><link rel="icon" href="'.$site['url'].'/files/'.$site['favicon'].'" type="image/x-icon" /><link rel="shortcut icon" href="http://indowapblog.com/favicon.ico" type="image/x-icon" /><meta name="description" content="'.htmlspecialchars($deskripsi).'" /><meta name="viewport" content="width=320" /><meta name="viewport" content="initial-scale=1.0" /><meta name="viewport" content="user-scalable=false" /><meta http-equiv="Cache-Control" content="max-age=1" /><meta name="HandheldFriendly" content="True" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="all"/><link rel="stylesheet" href="'.$site['url'].'/mobile.css" type="text/css" media="handheld"/><script language="JavaScript">
 var message="Gak pake klik kanan kaleee...";
 function click(z) {
  if (document.all) {
   if (event.button == 2) {
    alert(message);
    return false;
   }
  }
  if (document.layers) {
   if (z.which == 3) {
    alert(message);
    return false;
   }
  }
 }
 if (document.layers) {
  document.captureEvents(Event.MOUSEDOWN);
 }
 document.onmousedown=click;
</script>
</head>';
echo '<body><div id="header"><a href="'.$site['url'].'/">';
if (!empty($site['logo'])){
echo '<img src="'.$site['url'].'/content/'.htmlspecialchars($site['logo']).'" alt="'.htmlspecialchars($site['name']).'"/>';
}
else
{
echo htmlspecialchars($site['name']);
}
echo '</a>';

if ($user_id)
{
echo '<br/><br/><a href="'.$site['url'].'/user.php"><img src="http://greentooth.xtgem.com/i2/admn5.png"/></a>&nbsp;<a href="'.$site['url'].'/dashboard.php"><img src="http://greentooth.xtgem.com/i1/hom.png"/></a>&nbsp;<a href="'.$site['url'].'/chat.php"><img src="http://greentooth.xtgem.com/i2/chat3.png"/></a>&nbsp;<a href="'.$site['url'].'/message.php"><img src="http://greentooth.xtgem.com/i2/dlstr.png"/></a>&nbsp;';
if ($is_admin)
echo '<a href="'.$site['url'].'/owner.php"><img src="http://greentooth.xtgem.com/i3/w.png"/></a>&nbsp;';
echo '<a href="'.$user_site.'/home.xhtml"><img src="http://greentooth.xtgem.com/i/oo.png"/></a>&nbsp;<a href="'.$user_site.'/login.php?iwb=logout"><img src="http://greentooth.xtgem.com/i2/toff.png"/></a>';
}


echo '</div></div>';

if ($user_id)
{
if ($indowapblog['ban'] == 1)
{
echo '<div id="message"></div><div id="content">
<div id="main-content">';
echo '<p>'.str_replace('::id::',$user_id,str_replace('::username::',$user_username,str_replace('::email::',$user_email,$LANG['user_blocked']))).'</p></div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
}
else
{
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where site_id='".$site['id']."' and ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");

if (mysql_num_rows($ip_cek) != 0)
{
$ip_blocked=mysql_fetch_array($ip_cek);

echo '<div id="message"></div><div id="content">
<div id="main-content">';
echo '<p>'.str_replace('::ip::',$ip_blocked['ip'],$LANG['ip_blocked']).'</p></div></div>';
require_once(''.$root.'inc/foot.php');
exit;
}
}

if ($user_id)
{
$kuis=mysql_query("SELECT id, pertanyaan FROM kuis WHERE status='1' AND time > '".time()."' ORDER BY id DESC LIMIT 3;");
if (mysql_num_rows($kuis) != 0)
{
while ($quis=mysql_fetch_array($kuis))
{
$new .='<li>&raquo; '.$LANG['quiz'].': '.bbsm(substr($quis['pertanyaan'],0,30)).'...<a href="'.$site['url'].'/kuis.php?iwb=read&amp;id='.$quis['id'].'#show_bar">&raquo;</a></li>';
}
}
$total_pms=mysql_result(mysql_query("select count(*) as Num from `pm` where `receiver_id`='".$user_id."' and `read`='1'"), 0);
if ($total_pms > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/message.php?">'.$total_pms.'</a>',$LANG['pm_notification']).'</li>';
if ($dashboard == 'on')
{
$taim = time() - 172800;
$total_following_post=mysql_result(mysql_query("select count(*) as Num from `following_post` where `read` LIKE '%<".$user_id.">%' and `time`>'".$taim."'"), 0);
if ($total_following_post > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/admin.php?iwb=following&amp;action=read">'.$total_following_post.'</a>',$LANG['following_notification']).'</li>';

$total_kom=mysql_result(mysql_query("select count(*) as Num from `comment` where `site_id`='".$user_id."' and `status`='0'"), 0);

$total_gb=mysql_result(mysql_query("select count(*) as Num from `guestbook` where site_id='".$user_id."' and `status`='0'"), 0);

if ($total_kom > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_comment.php?iwb=unapproved">'.$total_kom.'</a>',$LANG['comment_notification']).'</li>';

if ($total_gb > 0)
$new .='<li>&raquo; '.str_replace('::number::','<a href="'.$site['url'].'/manage_guestbook.php?iwb=unapproved">'.$total_gb.'</a>',$LANG['guestbook_notification']).'</li>';

} else { }
$notify=mysql_query("select `id`,`text`,`time` from `pm` where `receiver_id`='".$user_id."' and `read`='2' order by `time` desc limit 1;");
if (mysql_num_rows($notify) != 0)
{
$notice=mysql_fetch_array($notify);
$new .='<li>&raquo; '.html_entity_decode(bbsm($notice['text'])).'</li>';
mysql_query("DELETE FROM `pm` WHERE `id`='".$notice['id']."' OR `text`='".mysql_real_escape_string($notice['text'])."'");
}
if (!empty($new))
echo '<div id="message"><ol id="notice">'.$new.'</ol></div>';
}
include(''.$root.'inc/live_chat.php');

?>