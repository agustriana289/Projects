<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();

if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from user where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
exit;
}
$res=mysql_fetch_array($cek);

if (isset($_GET['yes']))
{
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
mysql_query("update user set ban='1' where id='".mysql_real_escape_string($id)."'");
header('location: user.php?iwb=list');
}
$head_title='Blokir Pengguna';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<p>Anda yakin ingin memblokir <a href="user.php?id='.$res['id'].'">'.htmlspecialchars($res['name']).'</a>?<br/>[<a href="owner.php?iwb=banned&amp;id='.$res['id'].'&amp;yes">YA</a>] [<a href="user.php?iwb=list">TIDAK</a>]</p>';
echo '</div></div>';
require_once('inc/foot.php');
?>