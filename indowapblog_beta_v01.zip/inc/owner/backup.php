<?php

/*
*Nama Script: IndoWapBlog Multi Site
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

defined('_IWB_') or die('Akses Terlarang!');

if (!$user_id)
relogin();
if (!$is_admin)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
if (isset($_POST['backup']) && $is_admin)
{
$send_to=$_POST['send_to'];
$tipe=$_POST['tipe'];
$tables='*';
if ($tables == '*') {
$extname = 'all';
}else{
$extname = str_replace(",", "_", $tables);
$extname = str_replace(" ", "_", $extname);
}

$backupfile = $dbname . date("d-m-Y") . '.sql';
function backup_tables()
{
global $tables,$extname,$backupfile;				if($tables == '*') {
$tables = array();
$result = mysql_query('SHOW TABLES');
while($row = mysql_fetch_row($result)) {
$tables[] = $row[0];
}
} else {
if (is_array($tables)) {
$tables = explode(',', $tables);
}
}
foreach($tables as $table) {
$result = mysql_query('SELECT * FROM '.$table);
$num_fields = mysql_num_fields($result);
$return .= 'DROP TABLE IF EXISTS `' . $table . '`;';

$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
$return .= "\n\n" . $row2[1] . ";\n\n";

for ($i = 0; $i < $num_fields; $i++) {
while($row = mysql_fetch_row($result)) {
$return.= 'INSERT INTO `'.$table.'` VALUES(';
for($j=0; $j<$num_fields; $j++) {
$row[$j] = addslashes($row[$j]);
$row[$j] = ereg_replace("\n","\\n",$row[$j]);
if (isset($row[$j])) {
$return .= '"' . $row[$j] . '"';
} else {
$return .= '""';
}
if ($j<($num_fields-1)) {
$return.= ',';
}
}
$return.= ");\n";
}
}
$return.="\n\n\n";
}
$handle = fopen("data/$user_id/$backupfile","w+");
fwrite($handle,$return);
fclose($handle);
}
backup_tables();
if ($send_to != '' || $tipe == 'zip')
{
fopen("data/$user_id/$backupfile.zip","w");
$zip = new ZipArchive;
if ($zip->open("data/$user_id/$backupfile.zip") === TRUE)
{
$zip->addFile("data/$user_id/$backupfile", "$backupfile") or die('Tidak dapat membuat file Zip!');
}
$zip->close();
$hasil='Database berhasil dibackup.<br/><a href="content/'.$backupfile.'.zip">Download '.$backupfile.'.zip</a>';
} else {
$hasil='Database berhasil dibackup.<br/><a href="content/'.$backupfile.'">Download '.$backupfile.'</a>';
}if ($send_to != '')
{
$filename=''.$backupfile.'.zip';
$my_path='data/'.$user_id.'/';
$my_subject = "BACKUP - ".$site['name']."";
$my_message = "Hai ".$user_name.",\r\nini adalah file mysql backup pada blog ".$site['name'].".\r\n\r\nSalam. Achunk JealousMan";

$file = $my_path.$filename;
$file_size = filesize($file);
$handle = fopen($file, "r");
$content = fread($handle, $file_size);
fclose($handle);
$content = chunk_split(base64_encode($content));
$uid = md5(uniqid(time()));
$name = basename($file);
$header = "From: Achunk JealousMan <achunk17@gmail.com>\r\n";
$header .= "Reply-To: achunk17@gmail.com\r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
$header .= "Ini adalah multi-part pesan pada MIME format.\r\n";
$header .= "--".$uid."\r\n";
$header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
$header .= $my_message."\r\n\r\n";
$header .= "--".$uid."\r\n";
$header .= "Content-Type: application/zip; name=\"".$filename."\"\r\n";
$header .= "Content-Transfer-Encoding: base64\r\n";
$header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r \n";
$header .= $content."\r\n\r\n";
$header .= "--".$uid."--";
if (mail($send_to, $my_subject, "", $header))
{
$hasil='Database berhasil dibackup dan telah dikirim ke '.$send_to.'<br/><a href="content/'.$filename.'">Download '.$filename.'</a>';
}
else
{
$hasil='Gagal mengirim file ke '.$send_to.'';
}
}
else
{}
}
$head_title='Backup Database';
require_once('inc/head.php');
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content"><p>';
if (!empty($hasil))
echo '<b>'.$hasil.'</b><br/>';
echo '<form method="post" action="owner.php?iwb=backup"><h4>Kirim ke Email</h4><input class="iwb-text" name="send_to" type="text" value="'.$user_email.'" size="30"/><br/><span>Mengirim file ke Email. (opsional)</span><br/><h4>Tipe File</h4><input type="radio" name="tipe" value="sql" checked/>.sql<br/><input type="radio" name="tipe" value="zip"/>.zip<br/>
<p><input class="iwb-button" type="submit" name="backup" value="Backup"/></p></form>';
echo '</div></div>';
require_once('inc/foot.php');
?>