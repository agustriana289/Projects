<?php

/*

IndoWapBlog-beta-v01.zip Full Editing by : Master Chef IWB
Facebook : http://fb.com/mhozacuplis1
Website : http://cuplascuplis.jw.lt
Website : http://cuplis.tk
Website : http://cuplis.fixi.in

*Nama Script: IndoWapBlog-beta-v01
*Versi: (Lihat VERSION.txt)
*Pembuat: Achunk JealousMan
*Email: achunk17[at]gmail[dot]com
*Situs: http://indowapblog.com
*Facebook: http://www.facebook.com/achunks
*/

define('_IWB_', 1);

require_once('inc/indowapblog.php');
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
$f=isset($_GET['f']) ? trim($_GET['f']) : '';
$f=htmlentities(base64_decode($f));
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}
$folder='data/'.$user_id.'/';
$adrfile = $folder . $f;
if (file_exists($adrfile))
{
unlink($adrfile);
header('location: file.php?notif=file_deleted');
}
else
{
header('location: file.php?notif=file_not_found');
}
break;
default:
if (!$user_id)
relogin();
if (!$is_author)
{
require_once('inc/head.php');
forbidden();
require_once('inc/foot.php');
exit;
}

function nama_file($var) {
$var = strrev(strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$var))));
$nf = explode("-",$var, 2);
$nf = substr(strrev($nf[1]), 0, 30);
$extensi = explode('-',$var);
$extensi = ".".strrev($extensi[0]);
return "".$nf . $extensi;
}

if (!is_dir("data/".$user_id.""))
{
mkdir("data/".$user_id."", 0755);
copy("data/copy_htaccess.txt", "data/".$user_id."/.htaccess");
copy("data/index.php", "data/".$user_id."/index.php");
}
foreach (glob("data/".$user_id."/*") as $file)
{
$name=basename($file);
if ($name != 'index.php' || $name != '.htaccess')
{
if (!$kb)
$kb='0';
$size=filesize($file);
$kb = $size + $kb;
}
}
$penggunaan = $kb; // Penggunaan memori yang sudah terpakai

$penggunaan_ditambahkan = $penggunaan + $_FILES['file']['size']; // Total penggunaan memori ditambahkan ukuran file yang diupload

$maksimal_penggunaan='50000000'; // Batas penggunaan memori maksimal 50MB
$ukuran_per_upload='2000000'; // Maksimal ukuran file perupload 2MB

if (isset($_POST['upload']))
{
$filename = nama_file($_FILES['file']['name']);
$fail=$_FILES['file']['tmp_name'];

$arr3 = array("o-epoc/x-sisx-app","text/css","application/java-archive","application/x-tar","application/zip","text/plain","image/jpg","image/jpeg","image/png","image/gif","image/x-icon","application/vnd.symbian.install","application/vnd.android.package.archive","application/cab","audio/mpeg","video/3gp","video/mp4","video/avi");
if (!function_exists('mime_content_type')) {
if (!in_array($_FILES['file']['type'],$arr3,true))
$hsl='<ol id="error"><li>Jenis file tidak benar.</li></ol>';
}
else {
if (!in_array(mime_content_type($fail),$arr3,true))
$hsl='<ol id="error"><li>Jenis file tidak diijinkan</li></ol>';
}
$arr4=array("sisx",".css",".jar",".tar",".zip",".txt",".jpg",".png",".gif",".ico",".sis",".apk",".cab",".mp3",".3gp",".mp4",".avi");
if (!in_array(substr($filename,-4), $arr4))
$hsl='<ol id="error"><li>Ekstensi file tidak diijinkan</li></ol>';

if (file_exists("data/".$user_id."/".$filename.""))
$hsl='<ol id="error"><li>'.str_replace('::filename::',$filename,$LANG['file_exists']).'</li></ol>';
if ($_FILES['file']['size'] == 0)
$hsl='<ol id="error"><li>'.$LANG['failed'].'</li></ol>';

if (empty($filename))
$hsl='<ol id="error"><li>'.$LANG['failed'].'</li></ol>';
$krdt=ceil(round($_FILES['file']['size'] / 1024, 2));
if ($indowapblog['credit'] < $krdt)
$hsl='<ol id="error"><li>'.str_replace('::number::',strrev(wordwrap(strrev($krdt),3,".",true)),str_replace('::more::','<a href="admin.php?iwb=credit">'.$LANG['more'].' &raquo;</a>',$LANG['minim_credit'])).'</li></ol>';
if (empty($hsl))
{
if (move_uploaded_file($fail, "data/".$user_id."/".$filename))
{
$kredit = $indowapblog['credit'] - $krdt;
mysql_query("update user set credit='".$kredit."' where id='".$user_id."'");
$hsl='<ol id="success"><li>'.str_replace('::filename::',$filename,$LANG['upload_successfully']).'.</li></ol>';
}
else
{
$hsl='<ol id="error"><li>'.$LANG['failed'].'</li></ol>';
}
}
}
$notif=$_GET['notif'];
if($notif == 'file_deleted')
$hsl='<ol id="success"><li>'.$LANG['file_deleted'].'</li></ol>';
if ($notif == 'file_not_found')
$hsl='<ol id="error"><li>'.$LANG['file_not_found'].'</li></ol>';

$head_title=$LANG['file'];
require_once('inc/head.php');
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<form action="file.php" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="5242880" type="hidden"/>
    <h4>'.$LANG['select_file'].'</h4>
<input type="file" name="file"/><br/>
    <input name="upload" type="submit" value="'.$LANG['upload'].'"/></form><br />';
echo 'Type File: .sisx, .css, .jar, .tar, .zip, .txt, <br />.jpg, .png, .gif, .ico, <br />.sis, .apk, .cab, <br />.mp3, .3gp, .mp4, .avi<br /><ol>';
foreach (glob("data/".$user_id."/*") as $file)
{
$ft = filemtime($file);
$ft = date("d M Y - H:i",$ft);
$fs=filesize($file);
$fs = round($fs / 1024, 2);
$files=basename($file);
$f=base64_encode($files);
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
if ($files == 'index.php' || $files == '.htaccess')
{
continue;
}
echo '<a href="'.$user_site.'/content/'.htmlspecialchars($files).'">'.htmlspecialchars($files).'</a> [<a href="file.php?iwb=delete&amp;f='.$f.'"><font color="red">'.$LANG['delete'].'</font></a>]<br /><span>'.$LANG['uploaded'].': '.$ft.'<br/>'.$LANG['size'].': '.$fs.' kb</span>';
++$i;
echo '</li>';
}

echo '</ol>            </div>
        </div>';
require_once('inc/foot.php');
}
?>