<?php



define('_IWB_', 1);

require_once('inc/indowapblog.php');
$live_chat='off';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
if (!$user_id)
relogin();
$id=htmlentities($_GET['id']);
if ($is_admin)
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."'");
}
else
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."' AND `site_id`='".$user_id."'");
}
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
}
else
{
$res=mysql_fetch_array($cek);
if (isset($_POST['yes']))
{
mysql_query("DELETE FROM `sponsor` WHERE `id`='".$res['id']."'");
header("Location: iklan.php?iwb=pasang");
exit;
}
if (isset($_POST['no']))
{
header("Location: iklan.php?iwb=pasang");
exit;
}
$head_title=$LANG['delete'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div id="message">';
if (empty($hasil))
echo $hasil;
echo '</div><div id="content"><div id="main-content">';
echo '<center>'.$LANG['delete_confirm'].'<br /><form method="post" action="iklan.php?iwb=delete&amp;id='.$id.'"><div class="two-col-btn"><input class="iwb-button" type="submit" name="yes" value="'.$LANG['yes'].'"/><input class="iwb-button" type="submit" name="no" value="'.$LANG['no'].'"/></div></form></center>';
require_once('inc/foot.php');
}
break;

case 'edit':
if (!$user_id)
relogin();
$id=htmlentities($_GET['id']);
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `id`='".mysql_real_escape_string($id)."' AND `site_id`='".$user_id."'");
if (mysql_num_rows($cek) == 0)
{
require_once('inc/head.php');
page_not_found();
require_once('inc/foot.php');
}
else
{
$res=mysql_fetch_array($cek);
if (isset($_POST['cancel']))
{
header("Location: iklan.php?iwb=pasang");
exit;
}
if (isset($_POST['save']))
{
$judul=$_POST['judul'];
$url=$_POST['url'];
$kontrak=$_POST['kontrak'];
if (empty($judul) || empty($url))
$err .='<li>Ada kesalahan pada pengisian formulir.</li>';
if (mb_strlen($judul) > 100 || mb_strlen($url) > 100)
$err .='<li>'.str_replace('::number::','100',$LANG['text_max']).'</li>';
if (empty($err))
{
mysql_query("UPDATE `sponsor` SET `title`='".mysql_real_escape_string($judul)."', `url`='".mysql_real_escape_string($url)."' WHERE `id`='".$res['id']."'");
header("Location: iklan.php?iwb=pasang");
exit;
}
else
{
$hasil='<ol id="error">'.$err.'</ol>';
}
}
$head_title=$LANG['edit'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div><div id="content"><div id="main-content">';
echo '<form method="post" action="iklan.php?iwb=edit&amp;id='.$id.'"><h4>'.$LANG['title'].'</h4><input class="iwb-text" type="text" name="judul" maxlenght="100" value="'.htmlspecialchars($res['title']).'"/><br /><h4>'.$LANG['link'].'</h4><input class="iwb-text" type="text" name="url" maxlenght="100" value="'.htmlspecialchars($res['url']).'"/><br /><span>Max 100 karakter</span><br/><div class="two-col-btn"><input class="iwb-button" type="submit" name="save" value="'.$LANG['save'].'"/><input class="iwb-button" type="submit" name="cancel" value="'.$LANG['cancel'].'"/></div></form>';
echo '</div></div>';
require_once('inc/foot.php');
}
break;

case 'pasang':
if (!$user_id)
relogin();
$head_title=$LANG['add_new'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content">';
if ($indowapblog['credit'] < '7000')
{
minim_credit();
}
else
{
if (isset($_POST['send']))
{
$judul=$_POST['judul'];
$url=$_POST['url'];
$kontrak=$_POST['kontrak'];
$code=$_POST['code'];
if (empty($judul) || empty($url) || empty($kontrak))
$err .='<li>'.$LANG['empty_text'].'</li>';
if (mb_strlen($judul) > 100 || mb_strlen($url) > 100)
$err .='<li>'.str_replace('::number::','100',$LANG['text_max']).'</li>';
if ($kontrak != 7 && $kontrak != 15 && $kontrak != 30)
$err .='<li>'.$LANG['incorrect_data'].'</li>';
if ($kontrak == 7)
{
$harga='10000';
}
elseif ($kontrak == 15)
{
$harga='15000';
}
else
{
$harga='25000';
}

if ($code != $_SESSION['captcha_code'])
$err .='<li>'.$LANG['incorrect_security_code'].'</li>';
if ($indowapblog['credit'] < $harga)
$err .='<li>'.str_replace('::number::','...',str_replace('::more::','',$LANG['minim_credit'])).'</li>';
if (empty($err))
{
$hari='86400';
$expired = time() + ($hari * $kontrak);
mysql_query("INSERT INTO `sponsor` SET `site_id`='".$user_id."', `title`='".mysql_real_escape_string($judul)."', `url`='".mysql_real_escape_string($url)."', `expired`='".$expired."', `time`='".time()."'");
$kredit = $indowapblog['credit'] - $harga;
mysql_query("UPDATE `user` SET `credit`='".$kredit."' WHERE `id`='".$user_id."'");
$hasil='<ol id="success"><li>'.$LANG['successfully_added'].'</li></ol>';
}
else
{
$hasil='<ol id="error">'.$err.'</ol>';
}
}
if ($hasil)
echo '<div id="message">'.$hasil.'</div>';
echo '<form method="post" action="iklan.php?iwb=pasang"><h4>'.$LANG['title'].'</h4><input class="iwb-text" type="text" name="judul" maxlenght="100" value=""/><br /><h4>'.$LANG['link'].'</h4><input class="iwb-text" type="text" name="url" maxlenght="100" value="http://"/><br /><h4>'.$LANG['lama_kontrak'].'</h4><select class="iwb-select" name="kontrak"><option value="7">7 Hari</option><option value="15">15 Hari</option><option value="30">30 Hari</option></select><br />';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>'.$LANG['security_code'].'</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><br/><center><input class="iwb-button" type="submit" name="send" value="'.$LANG['save'].'"/></center></form>';
if ($is_admin)
{
$cek=mysql_query("SELECT * FROM `sponsor` ORDER BY `time` desc");
}
else
{
$cek=mysql_query("SELECT * FROM `sponsor` WHERE `site_id`='".$user_id."' ORDER BY `time` desc");
}
if (mysql_num_rows($cek) == 0)
{
}
else
{
echo '<br /><h1>Iklan Anda</h1>';
while ($res=mysql_fetch_array($cek))
{
echo $i % 2 ? '<div class="row0">' : '<div class="row1">';
echo '<a href="'.htmlspecialchars($res['url']).'">'.htmlspecialchars($res['title']).'</a><br />'.$LANG['show'].': '.$res['show'].'<br />'.$LANG['click'].': '.$res['click'].'<br />'.$LANG['added'].': '.waktu($res['time']).'<br />'.$LANG['expired'].': '.waktu($res['expired']).'<br />';
if ($is_admin)
echo ''.$LANG['by'].': '.iwbid($res['site_id']).'<br />';
echo '<span class="action_link">[<a href="iklan.php?iwb=edit&amp;id='.$res['id'].'">'.$LANG['edit'].'</a>]&nbsp;[<a class="delete" href="iklan.php?iwb=delete&amp;id='.$res['id'].'">'.$LANG['delete'].'</a>]</span>';
++$i;
echo '</div>';
}
}
}
echo '</div></div>';
require_once('inc/foot.php');
break;

case 'info':
$head_title=$LANG['advertisement'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><br /><form method="get" action="iklan.php"><input type="hidden" name="iwb" value="pasang"/><center><input class="iwb-button" type="submit" value="'.$LANG['add_new'].'"/></center></form><br />';
echo $LANG['advertisement_info'];
echo '<br /><table border="1"><tr><th>'.$LANG['lama_kontrak'].'</th><th>'.$LANG['price'].'</th></tr><tr><td>7 '.$LANG['day'].'</td><td>Rp 10.000</td></tr><tr><td>15 '.$LANG['day'].'</td><td>Rp 15.000</td></tr><tr><td>30 '.$LANG['day'].'</td><td>Rp 25.000</td></tr></table><br />';
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY RAND() LIMIT 1;");
if (mysql_num_rows($cekadsponsor) != 0)
{
$adsponsor=mysql_fetch_array($cekadsponsor);
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align: center;"><a style="color: green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
}
echo '<br /><form method="get" action="iklan.php"><input type="hidden" name="iwb" value="pasang"/><center><input class="iwb-button" type="submit" value="'.$LANG['add_new'].'"/></center></form><br /></div></div>';
require_once('inc/foot.php');
break;
default:
$head_title=$LANG['advertisement'];
$head_description='Pasang iklan di indowapblog.com cuma 5.000 per minggu';
require_once('inc/head.php');
echo '<div id="message"></div><div id="content"><div id="main-content"><br /><form method="get" action="iklan.php"><input type="hidden" name="iwb" value="info"/><center><input class="iwb-button" type="submit" value="'.$LANG['add_new'].'"/></center></form><br />';
$cekadsponsor=mysql_query("SELECT * FROM `sponsor` WHERE `expired` > '".time()."' ORDER BY `time` desc;");
if (mysql_num_rows($cekadsponsor) != 0)
{
while ($adsponsor=mysql_fetch_array($cekadsponsor))
{
echo $i % 2 ? '<div class="row0">' : '<div class="row1">';
$adshow = $adsponsor['show'] + 1;
mysql_query("UPDATE `sponsor` SET `show`='".$adshow."' WHERE `id`='".$adsponsor['id']."'");
echo '<div style="text-align: center;"><a style="color: green;" href="'.$site['url'].'/sponsor.php?id='.$adsponsor['id'].'">'.htmlspecialchars($adsponsor['title']).'</a></div>';
++$i;
echo '</div>';
}
}
echo '<br /><form method="get" action="iklan.php"><input type="hidden" name="iwb" value="info"/><center><input class="iwb-button" type="submit" value="'.$LANG['add_new'].'"/></center></form><br /></div></div>';
require_once('inc/foot.php');
break;
}
?>