<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
$lng_chat = core::load_lng('chat');
// Ограничение доступа
if ($rights != 9){ 
  header("location: $home?err");
 exit;
}

// Задаем настройки системы
$req = mysql_query("SELECT * FROM `chat_settings`");
$chat_settings = array();
while ($res = mysql_fetch_row($req)) $chat_settings[$res[0]] = $res[1];
mysql_free_result($req);

// системные переменные
$headmod = 'admin';
$textl = $lng['admin_panel'];
require('../incfiles/head.php');

/*
-----------------------------------------------------------------
Переключаем режимы работы
-----------------------------------------------------------------
*/
$array = array (
  'mod_bots',
  'mod_rooms',
  'mod_moders',
  'mod_search',
  'mod_messages',
  'mod_phrases',
  'mod_chat'
);
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/panel/' . $array[$key] . '.php')) {
  require('includes/panel/' . $array[$key] . '.php');
} else {

/*
-----------------------------------------------------------------
Вывод меню Админ панели чата
-----------------------------------------------------------------
*/
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="../' . $set['admp'] . '/index.php"><b>' . $lng['admin_panel'] . '</b></a> | ' . $lng_chat['control_chat'] . '</div>';
$i = 0;
$soob = 0;
$soob_s = 0;
$room = mysql_query("SELECT * FROM `chat_rooms`");
while ($room_d = mysql_fetch_assoc($room)) {
  $soob = $soob + mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_" . $room_d['id'] . "`"), 0);
  $soob_s = $soob_s + mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_room_" . $room_d['id'] . "` WHERE `tip` = '1'"), 0);
 ++$i;
}
$boty = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_bot`"), 0);
$vop = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_vop`"), 0);
$moders = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `rights` = '1'"), 0);
$zaban = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `ban_time` > '". time() ."'"), 0);
$users_chat_ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `ban_time` > '0'"), 0);
echo '<div class="gmenu"><p><h3><img src="../images/rate.gif" width="16" height="16" class="left" />&#160;' . $lng_chat['statistics'] . '</h3><ul>';
echo '<li>' . $lng_chat['bots'] . ':&#160;' . $boty . '</li>';
echo '<li>' . $lng_chat['phrases'] . ':&#160;' . $vop . '</li>';
echo '<li>' . $lng_chat['rooms'] . ':&#160;' . $i . '</li>';
echo '<li>' . $lng_chat['messages_total'] . ':&#160;' . $soob . '</li>';
echo '<li>' . $lng_chat['messages_hidden'] . ':&#160;<span class="red">' . $soob_s . '</span></li>';
echo '</ul></p></div>';
echo '<div class="menu"><p><h3><img src="../images/settings.png" width="16" height="16" class="left" />&#160;' . $lng_chat['management'] . '</h3><ul>';
echo '<li><a href="menu.php?act=mod_chat"><b>' . $lng['settings'] . '</b></a></li>';
if ($boty)
  echo '<li><a href="menu.php?act=mod_bots"><b>' . $lng_chat['bots'] . '</b></a> <small>(' . $boty . '/' . $vop . ')</small></li>';
else
  echo '<li><a href="menu.php?act=mod_bots&amp;mod=nev"><b>' . $lng_chat['add_bot'] . '</b></a></li>';
if ($soob)
  echo '<li><a href="menu.php?act=mod_messages"><b>' . $lng_chat['cleaning'] . '</b></a> <small>(' . $soob . '/<span class="red">' . $soob_s . '</span>)</small></li>';
if ($i)
  echo '<li><a href="menu.php?act=mod_rooms"><b>' . $lng_chat['rooms'] . '</b></a> <small>(' . $i . ')</small></li>';
else
  echo '<li><a href="menu.php?act=mod_rooms&amp;mod=add"><b>' . $lng_chat['add_room'] . '</b></a></li>';
if ($zaban)
  echo '<li><a href="index.php?act=ban&amp;mod=users_ban"><b>' . $lng_chat['banned'] . '</b></a> <small>(<span class="red">' . $zaban . '</span>)</small></li>';
if ($users_chat_ban)
  echo '<li><a href="index.php?act=ban&amp;mod=col_vo"><b>Ð�Ð°Ñ�Ñ�Ñ�Ð¸Ñ�ÐµÐ»Ð¸</b></a> <small>(<span class="red">' . $users_chat_ban . '</span>)</small></li>';
echo '<li><a href="menu.php?act=mod_moders"><b>' . $lng_chat['chat_moders'] . '</b></a> <small>(' . $moders . ')</small></li>';
echo '</ul></p></div>';
echo '<div class="nfooter"><a href="index.php">' . $lng_chat['to_chat'] . '</a></div><p>';
echo '<a href="../' . $set['admp'] . '/index.php">' . $lng['admin_panel'] . '</a></p>';
}
require('../incfiles/end.php');

?>