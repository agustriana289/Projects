<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$id || !$id_k || !$user_id || $chat_us_d['rights'] != 1 && $rights < 6) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Скрытие/восстановление сообщения
-----------------------------------------------------------------
*/
$soob = mysql_query("SELECT `id_u`, `author` FROM `chat_room_".$id_k."` WHERE `id` = '$id'");
// проверяем существование сообщения
if (mysql_num_rows($soob)) {
  // Получаем данные сообщения
  $soob_d = mysql_fetch_assoc($soob);
  // Получаем данные автора сообщения
  $us_d = mysql_fetch_assoc(mysql_query("SELECT `rights` FROM `users` WHERE `id` = '" . $soob_d['id_u'] . "'"));
  $post_us_d = mysql_fetch_assoc(mysql_query("SELECT `postchat`, `rights` FROM `chat_users` WHERE `id_u` = '" . $soob_d['id_u'] . "'"));
  $set_author = array();
  $set_author = unserialize($soob_d['author']);
  $set_author['name_delete'] = $login;
  // Получаем должность автора сообщения
  $rights_us_d = $us_d['rights'] ? $us_d['rights'] : $post_us_d['rights']; 
  // Получаем мою должность
  $rights_d = $rights ? $rights : $chat_us_d['rights']; 
  // Выбираем скрыть или восстановить сообщение
  if ($mod && $rights_us_d < $rights_d || $mod && $rights == 9) {
    // Скрываем сообщение
    mysql_query("UPDATE `chat_room_".$id_k."` SET `author` = '" . mysql_real_escape_string(serialize($set_author)) . "', `tip` = '1' WHERE `id` = '$id'");
    $postchat = $post_us_d['postchat'] > 0 ? $post_us_d['postchat'] - 1 : 0;
    mysql_query("UPDATE `chat_users` SET `postchat` = '" . $postchat . "' WHERE `id_u` = '" . $soob_d['id_u'] . "'");
  } elseif (!$mod && $rights > 6) {
    // Восстанавливаем сообщение
    mysql_query("UPDATE `chat_room_".$id_k."` SET `author` = '" . mysql_real_escape_string(serialize($set_author)) . "', `tip` = '0' WHERE `id` = '$id'");
    mysql_query("UPDATE `chat_users` SET `postchat` = '" . ($post_us_d['postchat'] + 1) . "' WHERE `id_u` = '" . $soob_d['id_u'] . "'");
  }
  header("Location: index.php?id=$id_k");
} else
  header("Location: index.php");

?>