<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

/*
-----------------------------------------------------------------
Список модераторов чата
-----------------------------------------------------------------
*/ 
echo '<div class="phdr"><a href="index.php"><b>'.$lng_chat['chat'].'</b></a> | '.$lng_chat['chat_moders'].'</div>';
$mod = mysql_query("SELECT * FROM `chat_users` WHERE `rights`='1'");
if (mysql_num_rows($mod)) {
  while ($res = mysql_fetch_assoc($mod)) {
    $mod_u = mysql_query("SELECT * FROM `users` WHERE `id`='".$res['id_u']."'");
    $mod_u_d = mysql_fetch_assoc($mod_u);
    echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
    echo functions::display_user($mod_u_d) . '</div>';
   ++$i;
  }
} else {
  echo '<div class="rmenu"><p><b>'.$lng_chat['the_list_is_empty'].'</b></p></div>';
}
echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';

?>