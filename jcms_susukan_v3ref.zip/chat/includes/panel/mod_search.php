<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверяем права доступа
if ($rights < 9) {
  header("Location: $home?err");
 exit;
}
$bot_d = mysql_fetch_assoc(mysql_query("select `name`, `tip` from `chat_bot` where id='" . $id . "'"));

/*
-----------------------------------------------------------------
Функция подсветки результатов запроса
-----------------------------------------------------------------
*/
function ReplaceKeywords($search, $text) {
  $search = str_replace('*', '', $search);
  return mb_strlen($search) < 4 ? $text : preg_replace('|('.preg_quote($search, '/').')|siu','<span style="background-color: #FFFF33">$1</span>',$text);
}
echo '<div class="phdr"><a href="menu.php?act=mod_phrases&amp;id='.$id.'"><b>'.$lng_chat['phrases'].'</b></a> | <b>'.$bot_d['name'].':</b> '.$lng_chat['search_phrases'].'</div>';

/*
-----------------------------------------------------------------
Принимаем данные, выводим форму поиска
-----------------------------------------------------------------
*/
$search = isset ($_POST['search']) ? trim($_POST['search']) : '';
$search = $search ? $search : rawurldecode(trim($_GET['search']));
$search = preg_replace("/[^\w\x7F-\xFF\s]/", " ", $search);
$search_t = isset($_REQUEST['t']) && $bot_d['tip'] ? abs(intval($_REQUEST['t'])) : 0;
echo '<div class="gmenu"><form action="?act=mod_search&amp;id='.$id.'" method="post"><p>';
echo '<input type="text" value="' . ($search ? functions::checkout($search) : '') . '" name="search" />';
echo '<input type="submit" value="'.$lng_chat['search'].'" name="submit" />';
if ($bot_d['tip']) {
  echo '<p><b>'.$lng_chat['search'].'</b><br />';
  echo '<input type="radio" value="0" name="t"'.(!$search_t ? ' checked="checked"' : '').'/>&#160;'.$lng_chat['in_phrase'].'<br />';
  echo '<input type="radio" value="1" name="t"'.($search_t == 1 ? ' checked="checked"' : '').'/>&#160;'.$lng_chat['in_answers'].'<br />';
  echo '<input type="radio" value="2" name="t"'.($search_t == 2 ? ' checked="checked"' : '').'/>&#160;'.$lng_chat['phrase_and_answers'].'</p>';

}
echo '</p></form></div>';

/*
-----------------------------------------------------------------
Проверям на ошибки
-----------------------------------------------------------------
*/
$error = false;
if ($search && mb_strlen($search) < 4)
  $error = $lng_chat['query_length_is_not_less'];
if ($search && mb_strlen($search) > 64)
  $error = $lng_chat['query_length_is_not_more'];
if ($search && !$error) {
  
  /*
  -----------------------------------------------------------------
  Выводим результаты поиска
  -----------------------------------------------------------------
  */
  echo '<div class="bmenu">'.$lng_chat['search_results'].'</div>';
  switch ($search_t) {
    case 1:
      $sql = " (`otvet`) like ('%" . mysql_real_escape_string($search) . "%')";
    break;

    case 2:
      $sql = " ((`otvet`) like ('%" . mysql_real_escape_string($search) . "%') OR (`vopros`) like ('%" . mysql_real_escape_string($search) . "%'))";
    break;
    
    default :
      $sql = " (`vopros`) like ('%" . mysql_real_escape_string($search) . "%')";
  }
  $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_vop` WHERE".$sql." AND `id_bot` = '" .$id . "'"), 0);
  if (!empty($total)) {
    $req = mysql_query("SELECT * FROM `chat_vop` WHERE".$sql." AND `id_bot` = '" .$id . "' LIMIT $start, $kmess");
    while ($res = mysql_fetch_assoc($req)) {
      echo is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
      echo '<b>'.($bot_d['tip'] ? $lng_chat['question'] : $lng_chat['phrase']).':</b> '. (!$search_t ? ReplaceKeywords($search, $res['vopros']) : $res['vopros']);
      if ($res['otvet'])
        echo '<br /><b>'.$lng_chat['reply'].':</b> '. ($search_t ? ReplaceKeywords($search, $res['otvet']) : $res['otvet']);
      echo '<div class="sub"><a href="?act=mod_phrases&amp;mod=red&amp;id=' . $res['id'] . '">'.$lng_chat['edit'].'</a> - ';
      echo '<a href="?act=mod_phrases&amp;mod=dell&amp;id=' . $res['id'] . '">'.$lng['delete'].'</a>';
      echo '</div></div>';
     ++$i;
    }
  } else {
    echo '<div class="rmenu"><p>'.$lng_chat['no_results'].'</p></div>';
  }
  echo '<div class="phdr">'.$lng_chat['all'].': ' . $total . '</div>';
  // Постраничная навигация
  if ($total > $kmess) {
    echo '<div class="topmenu">' . functions::display_pagination('?act=mod_search&amp;id='.$id. '&amp;' . ($search_t ? 't='.$search_t.'&amp;' : '') . 'search=' . rawurlencode($search) . '&amp;', $start, $total, $kmess) . '</div>';
    echo '<p><form action="?act=mod_search&amp;id='.$id. '&amp;' . ($search_t ? 't='.$search_t.'&amp;' : '') . 'search=' . rawurlencode($search) . '" method="post">';
    echo '<input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
  }
} else {
  
  /*
  -----------------------------------------------------------------
  Выводим сообщение об ошибке
  -----------------------------------------------------------------
  */
  if ($error)
    echo '<small><div class="rmenu"><p><b>' . $lng['error'] . '</b><br />' . $error . '</p></div></small>';
  // Инструкции для поиска
  echo '<div class="phdr">'.$lng_chat['user_search'].'</div>';
}
echo '<p>' . ($search ? '<a href="?act=mod_search&amp;mod=mod_search&amp;id='.$id.'">'.$lng_chat['new_search'].'</a><br />' : '') . '<a href="?act=mod_phrases&amp;id='.$id.'">'.$lng_chat['the_phrase'].'</a></p>';

?>