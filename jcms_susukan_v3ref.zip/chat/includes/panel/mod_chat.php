<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверяем права доступа
if ($rights < 9) {
  header("Location: $home?err");
 exit;
}
echo '<div class="phdr"><a href="../' . $set['admp'] . '/index.php"><b>'.$lng['admin_panel'].'</b></a> | '.$lng_chat['chat_settings'].'</div>';

if ($mod == 'reset') {
  mysql_query("UPDATE `chat_settings` SET `val`='1' WHERE `key` = 'access'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'balls'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'color_nik'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'color_nik_text'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'color_text'");
  if ($chat_settings['auto_delete'])
    mysql_query("UPDATE `chat_settings` SET `val`='" . time() . "' WHERE `key` = 'time'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'auto_delete'");
  mysql_query("UPDATE `chat_settings` SET `val`='1' WHERE `key` = 'faq'");
  mysql_query("UPDATE `chat_settings` SET `val`='0' WHERE `key` = 'leave_post'");
  echo '<div class="gmenu">'.$lng['settings_default'].'</div>';
  $req = mysql_query("SELECT * FROM `chat_settings`");
  $chat_settings = array ();
  while ($res = mysql_fetch_row($req)) $chat_settings[$res[0]] = $res[1];
}

if (isset($_POST['submit'])) {
  /*
  -----------------------------------------------------------------
  Сохраняем настройки чата
  -----------------------------------------------------------------
  */
  switch (intval($_POST['auto_delete'])) {

    case 3:
      $auto_dell = 86400;
    break;
    
    case 2:
      $auto_dell = 172800;
    break;
    
    case 1:
      $auto_dell = 604800;
    break;
    
    default :
      $auto_dell = 0;
  }
  mysql_query("UPDATE `chat_settings` SET `val`='" . intval($_POST['access']) . "' WHERE `key` = 'access'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . intval($_POST['balls']) . "' WHERE `key` = 'balls'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . intval($_POST['color_nik']) . "' WHERE `key` = 'color_nik'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . intval($_POST['color_nik_text']) . "' WHERE `key` = 'color_nik_text'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . intval($_POST['color_text']) . "' WHERE `key` = 'color_text'");
  if ($auto_dell != $chat_settings['auto_delete'])
    mysql_query("UPDATE `chat_settings` SET `val`='" . time() . "' WHERE `key` = 'time'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . $auto_dell . "' WHERE `key` = 'auto_delete'");
  mysql_query("UPDATE `chat_settings` SET `val`='" . (isset($_POST['faq']) ? 1 : 0) . "' WHERE `key` = 'faq'"); 
  mysql_query("UPDATE `chat_settings` SET `val`='" . (isset($_POST['leave_post']) && $auto_dell ? intval($_POST['leave_post']) : 0) . "' WHERE `key` = 'leave_post'");
  $req = mysql_query("SELECT * FROM `chat_settings`");
  $chat_settings = array ();
  while ($res = mysql_fetch_row($req)) $chat_settings[$res[0]] = $res[1];
  echo '<div class="gmenu">'.$lng['settings_saved'].'</div>';
}    
$color = array('red', 'yelow', 'green', 'gray');    
echo '<form action="?act=mod_chat" method="post">';      
echo '<div class="menu">';

/*                                                                                                                              
-----------------------------------------------------------------
Управление доступом к Чату
-----------------------------------------------------------------
*/
echo '<p><h3><img src="../images/' . $color[$chat_settings['access']] . '.gif" width="16" height="16" class="left"/>&#160;'.$lng_chat['rights'].'</h3>';
echo '<div style="font-size: x-small">';
echo '&#160;<input type="radio" value="2" name="access" ' . ($chat_settings['access'] == 2 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['access_open'].'<br />';
echo '&#160;<input type="radio" value="1" name="access" ' . ($chat_settings['access'] == 1 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['access_login'].'<br />';
echo '&#160;<input type="radio" value="0" name="access" ' . (!$chat_settings['access'] ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['access_close'];
echo '</div></p>';

echo '<p><h3><img src="img/tables.png" width="16" height="16" class="left" />&#160;'.$lng_chat['table_balls'].'</h3>';      
echo '<div style="font-size: x-small">';
echo '&#160;<input type="radio" value="0" name="balls" ' . (!$chat_settings['balls'] == 1 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['table'].' <span style="font-style:italic">chat_users</span><br />';
echo '&#160;<input type="radio" value="1" name="balls" ' . ($chat_settings['balls'] ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['table'].' <span style="font-style:italic">users</span><br />';
echo '&#160;&#160;&#160;<span class="gray"><small>'.$lng_chat['to_text'].' <span style="font-style:italic">balans</span></small></span>';
echo '</div></p>';     

echo '<p><h3><img src="img/color-swatches.png" width="16" height="16" class="left" />&#160;'.$lng_chat['value_color'].'</h3>';      
echo '<div style="font-size: x-small"><ul>';
echo '<li>'.$lng_chat['color_nick'].':&#160;<br /><input type="text" name="color_nik" value="' . $chat_settings['color_nik'] . '"/></li>';
echo '<li>'.$lng_chat['color_source_in_the_text'].':&#160;<br /><input type="text" name="color_nik_text" value="' . $chat_settings['color_nik_text'] . '"/></li>';
echo '<li>'.$lng_chat['color_your_posts'].':&#160;<br /><input type="text" name="color_text" value="' . $chat_settings['color_text'] . '"/><br />';
echo '&#160;&#160;<span class="gray"><small><span style="font-style:italic">0</span> - '.$lng_chat['free'].'</small></span></li>';
echo '</ul></div></p>';    

echo '<p><h3><img src="img/clock_delete.png" width="16" height="16" class="left" />&#160;'.$lng_chat['auto_clear'].'</h3>';      
echo '<div style="font-size: x-small">';
echo '&#160;<input type="radio" value="3" name="auto_delete" ' . ($chat_settings['auto_delete'] == 86400 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['order_night'].'<br />';
echo '&#160;<input type="radio" value="2" name="auto_delete" ' . ($chat_settings['auto_delete'] == 172800 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['order_2_days'].'<br />';
echo '&#160;<input type="radio" value="1" name="auto_delete" ' . ($chat_settings['auto_delete'] == 604800 ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['order_week'].'<br />';
echo '&#160;<input type="radio" value="0" name="auto_delete" ' . (!$chat_settings['auto_delete'] ? 'checked="checked"' : '') . '/>&#160;'.$lng_chat['not_clear'].'<br />';
echo '&#160;&#160;&#160;<input type="text" name="leave_post" size="3" maxlength="3" value="' . $chat_settings['leave_post'] . '"/>&#160;'.$lng_chat['always_leave_post'].'<br />';
echo '&#160;&#160;&#160;&#160;&#160;<span class="gray"><small><span style="font-style:italic">0</span> - '.$lng_chat['do_not_leave_post'].'</small></span>';
echo '</div></p>';                                       

echo '<p><h3><img src="img/information.png" width="16" height="16" class="left" />&#160;'.$lng_chat['information'].'</h3>';      
echo '<div style="font-size: x-small"><ul>';
echo '<li><input type="checkbox" name="faq"' . ($chat_settings['faq'] ? ' checked="checked"' : '') . '/>&#160;'.$lng_chat['upon_entering_the_room'].'</li>';
echo '</ul></div></p>';

echo '</div><div class="gmenu">';      
echo '<input type="submit" name="submit" value="'.$lng['save'].'"/>';
echo '</div>';
echo '</form>';
echo '<div class="phdr"><a href="?act=mod_chat&amp;mod=reset">'.$lng_chat['reset'].'</a></div>';
echo '<p><a href="menu.php">'.$lng_chat['menu'].'</a><br /><a href="../' . $set['admp'] . '/index.php">'.$lng['admin_panel'].'</a></p>';

?>