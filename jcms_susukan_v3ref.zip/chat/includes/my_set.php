<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$user_id) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Личные настройки чата
-----------------------------------------------------------------
*/ 
$cv = array(
  $lng_chat['standart'] => '',
  $lng_chat['red'] => '#FF0000',
  $lng_chat['green'] => '#32CD32',
  $lng_chat['blue'] => '#0000FF',
  $lng_chat['orange'] => '#FFA500',
  $lng_chat['gray'] => '#808080',
  $lng_chat['pink'] => '#FF00FF'
);
$chat_balans = $chat_settings['balls'] ? $datauser['balans'] : $chat_us_d['balans'];

switch ($mod) {
  case 'nik':
    if ($chat_settings['color_nik'] && $chat_balans >= $chat_settings['color_nik']) {
      echo '<div class="phdr">'.$lng_chat['nik_color'].'</div>';
      if (isset($_GET['yes'])) {
        $cvet_n = (isset($_POST['cvet_n']) && in_array(trim($_POST['cvet_n']), $cv)) ? trim($_POST['cvet_n']) : ''; 
        if ($cvet_n != $set_chat['cvet_n']) {
          $set_chat['cvet_n'] = $cvet_n;
          $balans = $chat_balans - $chat_settings['color_nik'];
          if (!$chat_settings['balls']) {
            mysql_query("UPDATE `chat_users` SET `balans` = '".$balans."', `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          } else {
            mysql_query("UPDATE `users` SET `balans` = '".$balans."' WHERE `id` = '".$user_id."'");
            mysql_query("UPDATE `chat_users` SET `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          }
        }
        header("Location: index.php?act=my_set");
      } else {
        echo '<form action="index.php?act=my_set&amp;mod=nik&amp;yes" method="post"><div class="menu">';
        echo '&#160;'.$lng_chat['color_nick'].':<br />&#160;<select name="cvet_n">';
        foreach ($cv as $val => $key) {
          echo '<option value="'.$key.'"' . ($set_chat['cvet_n'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
        }
        echo '</select><br />';
        echo '<p><input type="submit" name="submit" value="'.$lng['save'].'"/></p></div></form>';
      }
      echo '<div class="phdr"><a href="index.php?act=my_set">'.$lng['back'].'</a></div>';
    } else {
      header("Location: index.php?act=my_set");
     exit;
    }
  break;

  case 'nik_text':
    if ($chat_settings['color_nik_text'] && $chat_balans >= $chat_settings['color_nik_text']) {
      echo '<div class="phdr">'.$lng_chat['nik_text_color'].'</div>';
      if (isset($_GET['yes'])) {
        $cvet_ns = (isset ($_POST['cvet_ns']) && in_array(trim($_POST['cvet_ns']), $cv)) ? trim($_POST['cvet_ns']) : ''; 
        if ($cvet_ns != $set_chat['cvet_ns']) {
          $set_chat['cvet_ns'] = $cvet_ns;
          $balans = $chat_balans - $chat_settings['color_nik_text'];
          if (!$chat_settings['balls']) {
            mysql_query("UPDATE `chat_users` SET `balans` = '".$balans."', `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          } else {
            mysql_query("UPDATE `users` SET `balans` = '".$balans."' WHERE `id` = '".$user_id."'");
            mysql_query("UPDATE `chat_users` SET `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          }
        }
        header("Location: index.php?act=my_set");
      } else {
        echo '<form action="index.php?act=my_set&amp;mod=nik_text&amp;yes" method="post"><div class="menu">';
        echo '&#160;'.$lng_chat['color_source_in_the_text'].':<br />&#160;<select name="cvet_ns">';
        foreach ($cv as $val => $key) {
          echo '<option value="'.$key.'"' . ($set_chat['cvet_ns'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
        }
        echo '</select><br />';
        echo '<p><input type="submit" name="submit" value="'.$lng['save'].'"/></p></div></form>';
      }
      echo '<div class="phdr"><a href="index.php?act=my_set">'.$lng['back'].'</a></div>';
    } else {
      header("Location: index.php?act=my_set");
     exit;
    }
  break;
  
  case 'text':
    if ($chat_settings['color_text'] && $chat_balans >= $chat_settings['color_text']) {
      echo '<div class="phdr">'.$lng_chat['text_color'].'</div>';
      if (isset($_GET['yes'])) {
        $cvet = (isset($_POST['cvet']) && in_array(trim($_POST['cvet']), $cv)) ? trim($_POST['cvet']) : ''; 
        if ($cvet != $set_chat['cvet']) {
          $set_chat['cvet'] = $cvet;
          $balans = $chat_balans - $chat_settings['color_text'];
          if (!$chat_settings['balls']) {
            mysql_query("UPDATE `chat_users` SET `balans` = '".$balans."', `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          } else {
            mysql_query("UPDATE `users` SET `balans` = '".$balans."' WHERE `id` = '".$user_id."'");
            mysql_query("UPDATE `chat_users` SET `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
          }
        }
        header("Location: index.php?act=my_set");
      } else {
        echo '<form action="index.php?act=my_set&amp;mod=text&amp;yes" method="post"><div class="menu">';
        echo '&#160;'.$lng_chat['color_your_posts'].':<br />&#160;<select name="cvet">';
        foreach ($cv as $val => $key) {
          echo '<option value="'.$key.'"' . ($set_chat['cvet'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
        }
        echo '</select><br />';
        echo '<p><input type="submit" name="submit" value="'.$lng['save'].'"/></p></div></form>';
      }
      echo '<div class="phdr"><a href="index.php?act=my_set">'.$lng['back'].'</a></div>';
    } else {
      header("Location: index.php?act=my_set");
     exit;
    }
  break;

  default :
    echo '<div class="phdr"><a href="index.php"><b>'.$lng_chat['chat'].'</b></a> | '.$lng['settings'].'</div>';
    if (isset($_POST['submit'])) {
      
      /*
      -----------------------------------------------------------------
      Установка новых настроек
      -----------------------------------------------------------------
      */ 
      $set_chat['refresh'] = isset($_POST['refresh']) ? intval($_POST['refresh']) : 20;
      $set_chat['chmes'] = isset($_POST['chmes']) ? intval($_POST['chmes']) : 10;
      $set_chat['carea'] = isset($_POST['carea']) ? 1 : 0;
      $set_chat['avatar'] = isset($_POST['avatar']) ? 1 : 0;
      if (!$chat_settings['color_text'])
        $set_chat['cvet'] = (isset($_POST['cvet']) && in_array(trim($_POST['cvet']), $cv)) ? trim($_POST['cvet']) : '';
      if (!$chat_settings['color_nik'])
        $set_chat['cvet_n'] = (isset($_POST['cvet_n']) && in_array(trim($_POST['cvet_n']), $cv)) ? trim($_POST['cvet_n']) : '';
      if (!$chat_settings['color_nik_text'])
        $set_chat['cvet_ns'] = (isset($_POST['cvet_ns']) && in_array(trim($_POST['cvet_ns']), $cv)) ? trim($_POST['cvet_ns']) : '';
      if ($set_chat['refresh'] < 10)
        $set_chat['refresh'] = 10;
      elseif ($set_chat['refresh'] > 99)
        $set_chat['refresh'] = 99;
      if ($set_chat['chmes'] < 5)
        $set_chat['chmes'] = 5;
      elseif ($set_chat['chmes'] > 40)
        $set_chat['chmes'] = 40;
      mysql_query("UPDATE `chat_users` SET `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '".$user_id."'");
      echo '<div class="rmenu">'.$lng['settings_saved'].'</div>';
    }
    if (isset($_GET['reset']) || empty($set_chat)) {
      
      /*
      -----------------------------------------------------------------
      Сброс настроек
      -----------------------------------------------------------------
      */ 
      $set_chat = array();
      $set_chat = array (
        'refresh' => 20,
        'chmes' => 10,
        'carea' => 0,
        'avatar' => 1,
        'cvet' => '',
        'cvet_n' => '',
        'cvet_ns' => ''
      );
      mysql_query("UPDATE `chat_users` SET `set_chat` = '" . mysql_real_escape_string(serialize($set_chat)) . "' WHERE `id_u` = '$user_id' LIMIT 1");
      echo '<div class="rmenu">'.$lng['settings_default'].'</div>';
    }

    /*
    -----------------------------------------------------------------
    Форма ввода личных настроек чата
    -----------------------------------------------------------------
    */ 
    echo '<form action="index.php?act=my_set" method="post"><div class="menu"><p><h3><img src="img/edit.png" width="16" height="16" class="left" />&#160;'.$lng_chat['basik_settings'].'</h3>';
    if ($set_user['avatar'])
      echo '&#160;<input name="avatar" type="checkbox" value="1" ' . ($set_chat['avatar'] ? 'checked="checked"' : '') . ' />&#160;'.$lng_chat['avatar_chat'].'<br />';
    echo '&#160;<input name="carea" type="checkbox" value="1" ' . ($set_chat['carea'] ? 'checked="checked"' : '') . ' />&#160;'.$lng_chat['insert_a_text_box'].'<br />';
    echo '&#160;<input type="text" name="refresh" size="2" maxlength="2" value="' . $set_chat['refresh'] . '"/>&#160;'.$lng_chat['update'].'<br />';
    echo '</p><p><h3><img src="img/color_edit.png" width="16" height="16" class="left" />&#160;'.$lng_chat['colors'].'</h3>';
    $cv2 = array_flip($cv);
    if (!$chat_settings['color_nik']) {
      echo '&#160;'.$lng_chat['color_nick'].':<br />&#160;<select name="cvet_n">';
      foreach ($cv as $val => $key) {
        echo '<option value="'.$key.'"' . ($set_chat['cvet_n'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
      }
      echo '</select><br />';
    } else {
      echo '<p>&#160;'.$lng_chat['color_nick'].':&#160;';
      if ($set_chat['cvet_n'])
        echo '<span style="color: '.$set_chat['cvet_n'].'">'.$cv2[$set_chat['cvet_n']].'</span>';
      else
        echo $cv2[$set_chat['cvet_n']].'';
      if ($chat_balans >= $chat_settings['color_nik']) {
        echo '<br />&#160;<small><a href="index.php?act=my_set&amp;mod=nik">'.$lng_chat['change_color'].'</a> <span class="gray">('.$lng_chat['points'].': '.$chat_settings['color_nik'].')</span></small>';
      } else {
        echo '<br />&#160;<small><span class="gray">('.$lng_chat['enough_points'].')</span></small>';
      }
      echo '</p>';
    }
    if (!$chat_settings['color_nik_text']) {
      echo '&#160;'.$lng_chat['color_source_in_the_text'].':<br />&#160;<select name="cvet_ns">';
      foreach ($cv as $val => $key) {
        echo '<option value="'.$key.'"' . ($set_chat['cvet_ns'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
      }
      echo '</select><br />';
    } else {
      echo '<p>&#160;'.$lng_chat['color_source_in_the_text'].':&#160;';
      if ($set_chat['cvet_ns'])
        echo '<span style="color: '.$set_chat['cvet_ns'].'">'.$cv2[$set_chat['cvet_ns']].'</span>';
      else
        echo $cv2[$set_chat['cvet_ns']].'';
      if ($chat_balans >= $chat_settings['color_nik_text']) {
        echo '<br />&#160;<small><a href="index.php?act=my_set&amp;mod=nik_text">'.$lng_chat['change_color'].'</a> <span class="gray">('.$lng_chat['points'].': '.$chat_settings['color_nik_text'].')</span></small>';
      } else {
        echo '<br />&#160;<small><span class="gray">('.$lng_chat['enough_points'].')</span></small>';
      }
      echo '</p>';
    }
    if (!$chat_settings['color_text']) {
      echo '&#160;'.$lng_chat['color_your_posts'].':<br />&#160;<select name="cvet">';
      foreach ($cv as $val => $key) {
        echo '<option value="'.$key.'"' . ($set_chat['cvet'] == $key ? ' selected="selected">' : '>') . $val . '</option>';
      }
      echo '</select><br />';
    } else {
      echo '<p>&#160;'.$lng_chat['color_your_posts'].':&#160;';
      if ($set_chat['cvet'])
        echo '<span style="color: '.$set_chat['cvet'].'">'.$cv2[$set_chat['cvet']].'</span>';
      else
        echo $cv2[$set_chat['cvet']].'';
      if ($chat_balans >= $chat_settings['color_text']) {
        echo '<br />&#160;<small><a href="index.php?act=my_set&amp;mod=text">'.$lng_chat['change_color'].'</a> <span class="gray">('.$lng_chat['points'].': '.$chat_settings['color_text'].')</span></small>';
      } else {
        echo '<br />&#160;<small><span class="gray">('.$lng_chat['enough_points'].')</span></small>';
      }
      echo '</p>';
    }
    echo '</p><p><input type="submit" name="submit" value="'.$lng['save'].'"/></p></div></form>';
    echo '<div class="phdr"><a href="index.php?act=my_set&amp;reset">'.$lng_chat['reset'].'</a></div>';
}
echo '<p><a href="../chat">'.$lng_chat['to_chat'].'</a></p>';

?>