<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v.:4.3.x                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);

/*
-----------------------------------------------------------------
Закрываем от неавторизованных юзеров
-----------------------------------------------------------------
*/
if (!$user_id) {
  echo functions::display_error($lng['access_guest_forbidden']);
  require('../incfiles/end.php');
 exit;
}

/*
-----------------------------------------------------------------
Функция вывода 10 лучших 
-----------------------------------------------------------------
*/
function get_top($order = 'postchat') {
  global $lng_chat;
  global $user_id;
  global $chat_settings;
  if ($order == 'balans' && $chat_settings['balls']) {
    $req = mysql_query("SELECT * FROM `users` WHERE `" . $order . "` > 0 ORDER BY `" . $order . "` DESC LIMIT 10");
  } else {
    $req = mysql_query("SELECT * FROM `chat_users` WHERE `" . $order . "` > 0 ORDER BY `" . $order . "` DESC LIMIT 10");
  }
  if (mysql_num_rows($req)) {
    $out = '';
    $i = 0;
    $pz = false;
    while ($res = mysql_fetch_assoc($req)) {
      ++$i;
      if (($order == 'balans' && $chat_settings['balls'] ? $res['id'] : $res['id_u']) == $user_id) {
        $out .= '<div class="gmenu">';
        $pz = 1;
      } else
        $out .= is_integer($i / 2) ? '<div class="list1">' : '<div class="list2">';
      $us = mysql_query("SELECT * FROM `users` WHERE `id` = '".($order == 'balans' && $chat_settings['balls'] ? $res['id'] : $res['id_u'])."' LIMIT 1");
      $us_d = mysql_fetch_assoc($us);
      $arg = array (
        'stshide' => 1,
        'header' => ' <b>' . $res[$order] . '</b>'
      );
      $out .= functions::display_user($us_d, $arg). '</div>';
    }
    if (!$pz) {
      if ($order == 'balans' && $chat_settings['balls']) {
        $req2 = mysql_query("SELECT * FROM `users` WHERE `" . $order . "` > 0 ORDER BY `" . $order . "` DESC");
      } else {
        $req2 = mysql_query("SELECT * FROM `chat_users` WHERE `" . $order . "` > 0 ORDER BY `" . $order . "` DESC");
      }
      $i = 0;
      while ($res2 = mysql_fetch_assoc($req2)) {
        ++$i;
        if (($order == 'balans' && $chat_settings['balls'] ? $res2['id'] : $res2['id_u']) == $user_id) {
          $out .= '<div class="gmenu">' . $lng_chat['you_have_typed'] . ':  ' . $res2[$order] . '<br />' . $lng_chat['your_position'] . ': ' . $i . '</div>';
          $pz = 1;
        }
      }
     if (!$pz) {
       $out .= '<div class="rmenu">' . $lng_chat['you_do_not_participate'] . '<br />' . $lng_chat['points_null'] . '</div>';
     }
    }
    return $out;
  } else {
    return '<div class="menu"><p>' . $lng_chat['the_list_is_empty'] . '</p></div><div class="rmenu">' . $lng_chat['you_do_not_participate'] . '<br />' . $lng_chat['points_null'] . '</div>';
  }
}



/*
-----------------------------------------------------------------
Показываем топ чата    
-----------------------------------------------------------------
*/ 
switch ($mod) {
    
  case 'bal':
    /*
    -----------------------------------------------------------------
    Балов
    -----------------------------------------------------------------
    */ 
    echo '<div class="phdr"><a href="index.php"><b>' . $lng_chat['chat'] . '</b></a> | ' . $lng_chat['rechest_chat'] . '</div>';
    echo '<div class="topmenu"><a href="index.php?act=top">' . $lng_chat['posts'] . '</a> | <a href="index.php?act=top&amp;mod=otv">' . $lng_chat['replies'] . '</a> | <b>' . $lng_chat['points'] . '</b></div>';
    echo get_top('balans');
    echo '<div class="phdr"><a href="index.php">' . $lng_chat['to_chat'] . '</a></div>';
  break;

  case 'otv':
    /*
    -----------------------------------------------------------------
    Ответов
    -----------------------------------------------------------------
    */ 
    echo '<div class="phdr"><a href="index.php"><b>' . $lng_chat['chat'] . '</b></a> | ' . $lng_chat['the_smartest_chat'] . '</div>';
    echo '<div class="topmenu"><a href="index.php?act=top">' . $lng_chat['posts'] . '</a> | <b>' . $lng_chat['replies'] . '</b> | <a href="index.php?act=top&amp;mod=bal">' . $lng_chat['points'] . '</a></div>';
    echo get_top('otvetov');
    echo '<div class="phdr"><a href="index.php">' . $lng_chat['to_chat'] . '</a></div>';
  break;
 
  default:
    /*
    -----------------------------------------------------------------
    Постов
    -----------------------------------------------------------------
    */ 
    echo '<div class="phdr"><a href="index.php"><b>' . $lng_chat['chat'] . '</b></a> | ' . $lng_chat['most_active_in_chat'] . '</div>';
    echo '<div class="topmenu"><b>' . $lng_chat['posts'] . '</b> | <a href="index.php?act=top&amp;mod=otv">' . $lng_chat['replies'] . '</a> | <a href="index.php?act=top&amp;mod=bal">' . $lng_chat['points'] . '</a></div>';
    echo get_top('postchat');
    echo '<div class="phdr"><a href="index.php">' . $lng_chat['to_chat'] . '</a></div>';
}

echo '<p><a href="../users/index.php">' . $lng['community'] . '</a></p>';

?>