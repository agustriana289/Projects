<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$lng_chat_faq = core::load_lng('chat_faq');
switch ($mod) {

  case 'private':
    /*
    -----------------------------------------------------------------
    Приватные сообщения
    -----------------------------------------------------------------
    */  
    if (!$user_id) {
      header("Location: index.php");
     exit;
    }
    echo '<div class="phdr"><a href="index.php?act=faq"><b>F.A.Q.</b></a> | '.$lng_chat_faq['name_private_messages'].'</div>';
    echo '<div class="menu"><p>';
    echo $lng_chat_faq['private_messages'];
    if ($rights == 9)
      echo $lng_chat_faq['sv_private_messages'];
    echo '</p></div>';
    echo '<div class="phdr"><a href="index.php">В чат</a></div>';
  break;

  case 'rules':
    /*
    -----------------------------------------------------------------
    Правила чата
    -----------------------------------------------------------------
    */
    echo '<div class="phdr"><a href="index.php?act=faq"><b>F.A.Q.</b></a> | '.$lng_chat_faq['name_chat_rules'].'</div>';
    echo '<div class="menu"><p>';
    echo $lng_chat_faq['chat_rules'];
    echo '</p></div>';
    if ($id)
      echo '<div class="phdr"><a href="index.php?id='.$id.'">'.$lng["back"].'</a></div><p><a href="index.php">'.$lng_chat['to_chat'].'</a></p>';
    else
      echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
  break;

  case 'on_password':
    /*
    -----------------------------------------------------------------
    Интим
    -----------------------------------------------------------------
    */
    $room1 = mysql_query("SELECT `id`, `name` FROM `chat_rooms` WHERE `tip` = 'in'");
    if (!mysql_num_rows($room1) && !$user_id) {
      header("Location: index.php");
     exit;
    }
    $room_d1 = mysql_fetch_assoc($room1);    
    echo '<div class="phdr"><a href="index.php?act=faq"><b>F.A.Q.</b></a> | '.$lng_chat['room'].' <a href="index.php?id='.$room_d1['id'].'">'.$room_d1['name'].'</a></div>';
    echo '<div class="menu"><p>';
    echo ' <b>'.$room_d1['name'].'</b>';
    echo $lng_chat_faq['on_password'];
    echo '</p></div>';
    echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
  break;

  case 'off_ban':
    /*
    -----------------------------------------------------------------
    Беспредел
    -----------------------------------------------------------------
    */
    $room2 = mysql_query("SELECT `id`, `name` FROM `chat_rooms` WHERE `tip` = 'sr'");
    if (!mysql_num_rows($room2)) {
      header("Location: index.php");
     exit;
    }
    $room_d2 = mysql_fetch_assoc($room2);    
    echo '<div class="phdr"><a href="index.php?act=faq"><b>F.A.Q.</b></a> | '.$lng_chat['room'].' <a href="index.php?id='.$room_d2['id'].'">'.$room_d2['name'].'</a></div>';
    echo '<div class="menu"><p>';
    echo ' <b>'.$room_d2['name'].'</b>';
    echo $lng_chat_faq['off_ban'];
    echo '</p></div>';
    echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
  break;

  case 'off_login':
    /*
    -----------------------------------------------------------------
    Инкогнито
    -----------------------------------------------------------------
    */
    $room3 = mysql_query("SELECT `id`, `name` FROM `chat_rooms` WHERE `tip` = 'an'");
    if (!mysql_num_rows($room3)) {
      header("Location: index.php");
     exit;
    }
    $room_d3 = mysql_fetch_assoc($room3);  
    echo '<div class="phdr"><a href="index.php?act=faq"><b>F.A.Q.</b></a> | '.$lng_chat['room'].' <a href="index.php?id='.$room_d3['id'].'">'.$room_d3['name'].'</a></div>';
    echo '<div class="menu"><p>';
    echo ' <b>'.$room_d3['name'].'</b>';
    echo $lng_chat_faq['off_login'];
    echo '</p></div>';
    echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
  break;
    
  default :
    /*
    -----------------------------------------------------------------
    Главное меню FAQ
    -----------------------------------------------------------------
    */
    
    echo '<div class="phdr"><a href="index.php"><b>'.$lng_chat["chat"].'</b></a> | F.A.Q.</div>';
    echo '<div class="menu"><a href="index.php?act=faq&amp;mod=rules">'.$lng_chat_faq['name_chat_rules'].'</a></div>';
    if ($user_id)
      echo '<div class="menu"><a href="index.php?act=faq&amp;mod=private">'.$lng_chat_faq['who_private'].'</a></div>';
    $room1 = mysql_query("SELECT `name` FROM `chat_rooms` WHERE `tip` = 'in'");
    if (mysql_num_rows($room1) && $user_id) {
      $room_d1 = mysql_fetch_assoc($room1);
      echo '<div class="menu"><a href="index.php?act=faq&amp;mod=on_password">'.$lng_chat_faq['name_chat_room'].' <b>'.$room_d1['name'].'</b>?</a></div>';
    }
    $room2 = mysql_query("SELECT `name` FROM `chat_rooms` WHERE `tip` = 'sr'");
    if (mysql_num_rows($room2)) {
      $room_d2 = mysql_fetch_assoc($room2);
      echo '<div class="menu"><a href="index.php?act=faq&amp;mod=off_ban">'.$lng_chat_faq['name_chat_room'].' <b>'.$room_d2['name'].'</b>?</a></div>';
    }    
    $room3 = mysql_query("SELECT `name` FROM `chat_rooms` WHERE `tip` = 'an'");
    if (mysql_num_rows($room3)) {
      $room_d3 = mysql_fetch_assoc($room3);
      echo '<div class="menu"><a href="index.php?act=faq&amp;mod=off_login">'.$lng_chat_faq['name_chat_room'].' <b>'.$room_d3['name'].'</b>?</a></div>';
    }
    echo '<div class="phdr"><a href="index.php">'.$lng_chat["to_chat"].'</a></div>';
}

?>