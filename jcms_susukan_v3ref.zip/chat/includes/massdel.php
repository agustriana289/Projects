<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$id || !$user_id || $chat_us_d['rights'] != 1 && $rights < 6) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Удаление выбранных постов из чата 
-----------------------------------------------------------------
*/ 
if (isset ($_GET['yes'])) {
  $dc = $_SESSION['dc'];
  if (isset ($_GET['del']) && $rights == 9) {
    foreach ($dc as $delid) {
      $soob = mysql_query("SELECT `id_u` FROM `chat_room_" . $id . "` WHERE `id` = '" . intval($delid) . "'");
      if (mysql_num_rows($soob)) {
        $message = mysql_fetch_assoc($soob);
        $post_us_d = mysql_fetch_assoc(mysql_query("SELECT `postchat` FROM `chat_users` WHERE `id_u` = '" . $message['id_u'] . "'"));
        $postchat = $post_us_d['postchat'] > 0 ? $post_us_d['postchat'] - 1 : 0;
        mysql_query("UPDATE `chat_users` SET `postchat` = '" . $postchat . "' WHERE `id_u` = '" . $message['id_u'] . "'");
        mysql_query("DELETE FROM `chat_room_" . $id . "` WHERE `id` = '" . intval($delid) . "'");
      }
    }
    header("Location: index.php?id=$id");
   exit;
  } else {
    foreach ($dc as $delid) {
      $soob = mysql_query("SELECT `id_u`, `author` FROM `chat_room_" . $id . "` WHERE `id` = '" . intval($delid) . "'");
      if (mysql_num_rows($soob)) {
        $message = mysql_fetch_assoc($soob);
        $us_d = mysql_fetch_assoc(mysql_query("SELECT `rights` FROM `users` WHERE `id` = '" . $message['id_u'] . "'"));
        $post_us_d = mysql_fetch_assoc(mysql_query("SELECT `postchat`, `rights` FROM `chat_users` WHERE `id_u` = '" . $message['id_u'] . "'"));
        // Получаем должность автора сообщения
        $rights_us_d = $us_d['rights'] ? $us_d['rights'] : $post_us_d['rights'];
        // Получаем мою должность
        $rights_d = $rights ? $rights : $chat_us_d['rights'];
        if ($rights_us_d < $rights_d || $rights == 9) {
          // Скрываем сообщение
          $set_author = array();
          $set_author = unserialize($message['author']);
          $set_author['name_delete'] = $login;
          mysql_query("UPDATE `chat_room_" . $id . "` SET `author` = '" . mysql_real_escape_string(serialize($set_author)) . "', `tip` = '1' WHERE `id` = '" . intval($delid) . "'");
          $postchat = $post_us_d['postchat'] > 0 ? $post_us_d['postchat'] - 1 : 0;
          mysql_query("UPDATE `chat_users` SET `postchat` = '" . $postchat . "' WHERE `id_u` = '" . $message['id_u'] . "'");
        }
      }
    }
    header("Location: index.php?id=$id");
   exit;
  }
} else {
  if (empty ($_POST['delch'])) {
    echo functions::display_error($lng_chat['nothing_selected'], '<a href="index.php?id='.$id.'">'.$lng['back'].'</a>');
    require("../incfiles/end.php");
   exit;
  }
  foreach ($_POST['delch'] as $v) {
    $dc[] = intval($v);
  }
  $_SESSION['dc'] = $dc; 
  echo '<div class="phdr">'.$lng_chat['mass_dell'].'</div><div class="menu">';
  if ($rights == 9) {
    echo $lng_chat['select_variant'].': <p><a href="index.php?act=massdel&amp;id='.$id.'&amp;yes&amp;del">'.$lng['delete'].'</a> | <a href="index.php?act=massdel&amp;id='.$id.'&amp;yes">'.$lng_chat['hide'].'</a></p>';
  } else {
    echo $lng['delete_confirmation'].'<p><a href="index.php?act=massdel&amp;id='.$id.'&amp;yes">'.$lng_chat['action_yes'].'</a> | <a href="index.php?id='.$id.'">'.$lng_chat['action_no'].'</a></p>';
  }
  echo '</div><div class="phdr"><a href="index.php?id='.$id.'">Назад</a></div>';
}

?>