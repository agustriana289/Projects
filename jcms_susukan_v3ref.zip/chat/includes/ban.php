<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

/*
-----------------------------------------------------------------
Получаем основные данные
-----------------------------------------------------------------
*/
if (!$user_id) {
  header("Location: index.php");
 exit;
}
$us = mysql_query("SELECT * FROM `users` WHERE `id` = '" . (($user == $user_id || !$user) ? $user_id : $user) . "'");
if (!mysql_num_rows($us)) {
  $user = false;
  $us_d = $datauser;
} else  
  $us_d = mysql_fetch_array($us);
$post_us = mysql_query("SELECT * FROM `chat_users` WHERE `id_u` = '" . (($user == $user_id || !$user) ? $user_id : $user) . "'");
$post_us_d = mysql_fetch_array($post_us);
$set_user_ban = array();
if (mysql_num_rows($post_us))
  $set_user_ban = unserialize($post_us_d['ban_text']);
// Настроки по-умолчанию
if (!isset($set_user_ban) || empty($set_user_ban))
  $set_user_ban = array (
    'name_ban' => '',
    'count' => 0,
    'text' => ''
  );
switch ($mod) {
  case 'yes':
    /*
    -----------------------------------------------------------------
    Баним пользователя
    -----------------------------------------------------------------
    */
    if (!$user || $chat_us_d['rights'] != 1 && $rights < 6 || $rights < $us_d['rights'] || $chat_us_d['rights'] == 1 && $post_us_d['rights'] == 1) {
      header("Location: index.php");
     exit;
    }
    $error = false;
    $time = isset($_POST['time']) ? intval($_POST['time']) : '';
    $ban_time = isset($_POST['ban_time']) ? intval($_POST['ban_time']) : '';
    $set_user_ban['name_ban'] = $login;
    $set_user_ban['count'] = $set_user_ban['count'] + 1;
    $set_user_ban['text'] = !empty($_POST['ban_text']) ? trim($_POST['ban_text']) : $lng_chat['reason_not_specified'];
    if (empty($ban_time))
      $error = $lng['error_empty_fields'];
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `id_u` = '" . $user . "' AND `ban_time` > '" . time() . "'"), 0))
      $error = $lng_chat['user_already_banned'];
    switch ($time) {
      case 2:
        // Часы
        if ($ban_time > 24)
          $ban_time = 24;
        $ban_time = $ban_time * 3600;
       break;

      case 3:
        // Дни
        if ($ban_time > 30)
          $ban_time = 30;
        $ban_time = $ban_time * 86400;
       break;

      case 4:
        // До отмены (на 10 лет)
        $ban_time = 315360000;
       break;

      default:
        // Минуты
        if ($ban_time > 60)
          $ban_time = 60;
        $ban_time = $ban_time * 60;
    }
    if ($datauser['rights'] < 6 && $ban_time > 86400)
      $ban_time = 86400;
    if ($datauser['rights'] < 7 && $ban_time > 2592000)
      $ban_time = 2592000;
    echo '<div class="phdr"><a href="../users/profile.php?user='.$user.'"><b>'.$us_d['name'].'</b></a> | '.$lng_chat['ban_chat'].'</div>';
    if (!$error) {
      // Заносим в базу
      mysql_query("UPDATE `chat_users` SET `ban_naz_time`='" . $ban_time . "', `ban_time`='" . ($ban_time+time()) . "', `ban_text`='" . mysql_real_escape_string(serialize($set_user_ban)) . "' WHERE `id_u` = '" . $user . "' LIMIT 1");
      if ($set_karma['on']) {
        $points = $set_karma['karma_points'] * 2;
        mysql_query("INSERT INTO `karma_users` SET `user_id` = '0', `name` = '" . $lng_chat['sustem'] . "', `karma_user` = '" . $user . "', `points` = '" . $points . "', `type` = '0', `time` = '" . time() . "', `text` = '" . $lng_chat['ban_chat'] . "'");
        mysql_query("UPDATE `users` SET `karma_minus`='" . ($us_d['karma_minus'] + $points) . "' WHERE `id` = '" . $user . "' LIMIT 1");
        $text = ' '.$lng_chat['and_received'].' <span class="red">-' . $points . ' '.$lng_chat['points'].'</span> '.$lng_chat['to_karma'];
      }
      echo '<div class="rmenu"><p><h3>'.$lng_chat['user_is_banned'].' ' . $text . '</h3></p></div>';
    } else {
      echo functions::display_error($error);
    }
    echo '<div class="phdr"><a href="index.php?id=' . $id . '">'.$lng['back'].'</a></div>';
  break;

  case 'ban':
    /*
    -----------------------------------------------------------------
    Форма ввода параметров бана
    -----------------------------------------------------------------
    */
    if (!$user || $chat_us_d['rights'] != 1 && $rights < 6 || $rights < $us_d['rights'] || $chat_us_d['rights'] == 1 && $post_us_d['rights'] == 1) {
      header("Location: index.php");
     exit;
    }
    echo '<div class="phdr"><a href="../users/profile.php?user='.$user.'"><b>'.$us_d['name'].'</b></a> | '.$lng_chat['ban_chat'].'</div>';    
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `id_u` = '" . $user . "' AND `ban_time` > '" . time() . "'"), 0)) {
      echo functions::display_error($lng_chat['user_already_banned']);
      echo '<div class="phdr"><a href="index.php?id=' . $id . '">'.$lng['back'].'</a></div>';
      require('../incfiles/end.php');
     exit;
    }
    echo '<form action="index.php?act=ban&amp;mod=yes&amp;user='.$user.'&amp;id='.$id.'" method="post"><div class="menu">';
    echo '<p><h3>'.$lng_chat['term_ban'].'</h3>';
    echo '&#160;<input type="text" name="ban_time" size="2" maxlength="2" value="12"/>&#160;'.$lng['time'].'<br />';
    echo '&#160;<input name="time" type="radio" value="1" />&#160;'.$lng_chat['minutes_ban'].'<br />';
    echo '&#160;<input name="time" type="radio" value="2" checked="checked" />&#160;'.$lng_chat['hours_ban'].'<br />';
    if ($rights >= 6)
      echo '&#160;<input name="time" type="radio" value="3" />&#160;'.$lng_chat['days_ban'].'<br />';
    if ($rights >= 7)
      echo '&#160;<input name="time" type="radio" value="4" />&#160;<b>'.$lng_chat['to_cancel'].'</b>';
    echo '</p><p><h3>'.$lng_chat['reason_ban'].'</h3>';
    echo '&#160;<textarea cols="20" rows="4" name="ban_text"></textarea>';
    echo '</p><p><input type="submit" value="'.$lng_chat['ban_yes'].'" name="submit" />';
    echo '</p></div></form>';
    echo '<div class="phdr"><a href="index.php?id=' . $id . '">'.$lng['back'].'</a></div>';
  break;

  case 'users_ban':
    /*
    -----------------------------------------------------------------
    Список забаненых
    -----------------------------------------------------------------
    */
    echo '<div class="phdr"><a href="../panel/"><b>' . $lng['admin_panel'] . '</b></a> | '.$lng_chat['banned_in_chat'].'</div>';
    echo '<div class="topmenu"><b>'.$lng_chat['users_ban'].'</b> | <a href="index.php?act=ban&amp;mod=col_vo">'.$lng_chat['violations_users'].'</a> | <a href="index.php?act=ban">'.$lng_chat['my_violations'].'</a></div>';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `ban_time` > '" . time() . "'"), 0);
    $chat_ban = mysql_query("SELECT `id_u` FROM `chat_users` WHERE `ban_time` > '" . time() . "' LIMIT $start, $kmess");
    if ($total) {
      while ($chat_ban_d = mysql_fetch_assoc($chat_ban)) {
        $ban_us = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser`, `rights` FROM `users` WHERE `id` = '" . $chat_ban_d['id_u'] . "'");
        $ban_us_d = mysql_fetch_assoc($ban_us);
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        $arg = array (
        'stshide' => 1,
        'sub' => '<a href="index.php?act=ban&amp;user='.$ban_us_d['id'].'">' . $lng['in_detail'] . '</a>'
        );
        echo functions::display_user($ban_us_d, $arg). '</div>';
       ++$i;
      }
      echo '<div class="phdr">'.$lng_chat['all'].': <b>' . $total . '</b></div>';
      // Постраничная навигация
      if ($total > $kmess) {
        echo '<div class="topmenu">' . functions::display_pagination('users.php?', $start, $total, $kmess) . '</div>';
        echo '<p><form action="users.php" method="post"><input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
      }
    } else { 
      echo '<div class="rmenu"><p>'.$lng_chat['the_list_is_empty'].'!</p></div>';
      echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
    }
  break;

  case 'col_vo':
    /*
    -----------------------------------------------------------------
    Список нарушителей
    -----------------------------------------------------------------
    */
    echo '<div class="phdr"><a href="../panel/"><b>' . $lng['admin_panel'] . '</b></a> | '.$lng_chat['violations_users'].' в чате</div>';
    echo '<div class="topmenu"><a href="index.php?act=ban&amp;mod=users_ban">'.$lng_chat['users_ban'].'</a> | <b>'.$lng_chat['violations_users'].'</b> | <a href="index.php?act=ban">'.$lng_chat['my_violations'].'</a></div>';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `ban_time` > '0'"), 0);
    $chat_ban = mysql_query("SELECT `id_u` FROM `chat_users` WHERE `ban_time` > '0' LIMIT $start, $kmess");
    if ($total) {
      while ($chat_ban_d = mysql_fetch_assoc($chat_ban)) {
        $ban_us = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser`, `rights` FROM `users` WHERE `id` = '".$chat_ban_d['id_u']."'");
        $ban_us_d = mysql_fetch_assoc($ban_us);
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        $arg = array (
          'stshide' => 1,
          'sub' => '<a href="index.php?act=ban&amp;user='.$ban_us_d['id'].'">' . $lng['in_detail'] . '</a>'
        );
        echo functions::display_user($ban_us_d, $arg). '</div>';
       ++$i;
      }
      echo '<div class="phdr">'.$lng_chat['all'].': <b>' . $total . '</b></div>';
      // Постраничная навигация
      if ($total > $kmess) {
        echo '<div class="topmenu">' . functions::display_pagination('users.php?', $start, $total, $kmess) . '</div>';
        echo '<p><form action="users.php" method="post"><input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
      }
    } else { 
      echo '<div class="rmenu"><p>'.$lng_chat['the_list_is_empty'].'!</p></div>';
      echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
    }
  break;

  case 'no_ban':
    /*
    -----------------------------------------------------------------
    Разан пользователя
    -----------------------------------------------------------------
    */
    if (!$user || $rights != 9) {
      header("Location: index.php");
     exit;
    }
    $set_user_ban['name_ban'] = '';
    $set_user_ban['count'] = $set_user_ban['count'] ? $set_user_ban['count'] - 1 : 0;
    $set_user_ban['text'] = '';
    mysql_query("UPDATE `chat_users` SET `ban_time`='" . time() . "', `ban_text`='" . mysql_real_escape_string(serialize($set_user_ban)) . "' WHERE `id_u` = '" . $user . "' LIMIT 1");
    echo '<div class="phdr"><a href="../users/profile.php?user='.$user.'"><b>'.$us_d['name'].'</b></a> | '.$lng_chat['removal_of_ban'].'</div>';
    echo '<div class="menu"><p>'.$lng_chat['user_unban'].'</p></div>';
    echo '<div class="phdr"><a href="index.php?act=ban'.($user ? '&amp;user='.$user : '&amp;user='.$user_id).($id ? '?id='.$id : '').'">'.$lng['back'].'</a></div>';
  break;
  
  case 'no_is':
    /*
    -----------------------------------------------------------------
    Очистка истории нарушений
    -----------------------------------------------------------------
    */
    if (!$user || $rights != 9) {
      header("Location: index.php");
     exit;
    }
    mysql_query("UPDATE `chat_users` SET `ban_time`='0', `ban_text`='0' WHERE `id_u` = '" . $user . "' LIMIT 1");
    echo '<div class="phdr"><a href="../users/profile.php?user='.$user.'"><b>'.$us_d['name'].'</b></a> | '.$lng_chat['removal_of_ban'].'</div>';
    echo '<div class="topmenu"><a href="index.php?act=ban&amp;mod=users_ban">'.$lng_chat['users_ban'].'</a> | <a href="index.php?act=ban&amp;mod=col_vo">'.$lng_chat['violations_users'].'</a> | <a href="index.php?act=ban">'.$lng_chat['my_violations'].'</a></div>';
    echo '<div class="menu"><p>'.$lng_chat['story_cleared'].'</p></div>';
    echo '<div class="phdr"><a href="index.php?act=ban'.($user ? '&amp;user='.$user : '&amp;user='.$user_id).($id ? '?id='.$id : '').'">'.$lng['back'].'</a></div>';
  break;
 
  default:
    /*
    -----------------------------------------------------------------
    Просмотр подробностей бана
    -----------------------------------------------------------------
    */
    echo '<div class="phdr">' . (($user == $user_id || !$user) ? $lng_chat['my_violations'] : '<a href="../users/profile.php?user='.$user.'"><b>'.$us_d['name'].'</b></a> | '.$lng_chat['violations'].'') . ' </div>';
    if ($rights == 9)
      echo '<div class="topmenu"><a href="index.php?act=ban&amp;mod=users_ban">'.$lng_chat['users_ban'].'</a> | <a href="index.php?act=ban&amp;mod=col_vo">'.$lng_chat['violations_users'].'</a> | '.(($user == $user_id || !$user) ? '<b>'.$lng_chat['my_violations'].'</b>' : '<a href="index.php?act=ban">'.$lng_chat['my_violations'].'</a>').'</div>';
    if ($set_user_ban['count']) {
      echo '<div class="' . (($post_us_d['ban_time'] > time()) ? 'r' : '') . 'menu">';
      echo '<p><h3>'.$lng_chat['last_ban'].'</h3><ul>';
      if (!empty($set_user_ban['name_ban']) || !empty($set_user_ban['text'])) {
        echo '<li><span class="gray">'.$lng_chat['banned_moders'].':</span> <b>'.$set_user_ban['name_ban'].'</b></li>';
        echo '<li><span class="gray">'.$lng_chat['term'].':</span> <b>'.functions::timecount($post_us_d['ban_naz_time']).'</b></li>';
        if ($post_us_d['ban_time'] > time())
          echo '<li><span class="gray">'.$lng_chat['left'].':</span> <b>'.functions::timecount($post_us_d['ban_time'] - time()).'</b></li>';
        echo '</ul></p>';
        echo '<p><h3>'.$lng_chat['reason_ban'].'</h3><ul>' . functions::smileys(functions::checkout($set_user_ban['text'], 1, 1), 1).'</ul></p>';
      } else {
        echo '<li><span class="gray">'.$lng_chat['no_information_ban'].'!</span></li></ul></p>';
      }
      if ($rights == 9) {
        echo '<p><h3>'.$lng_chat['actions'].'</h3><ul>';
         if ($post_us_d['ban_time'] > time())
          echo '<li><a href="index.php?act=ban&amp;mod=no_ban'.($user ? '&amp;user='.$user : '&amp;user='.$user_id).($id ? '&amp;id='.$id : '').'">'.$lng_chat['unban'].'</a></li>';
        echo '<li><a href="index.php?act=ban&amp;mod=no_is'.($user ? '&amp;user='.$user : '&amp;user='.$user_id).($id ? '&amp;id='.$id : '').'">'.$lng_chat['clear_historu'].'</a></li>';
        echo '</ul></p>';
      }
      echo '</div>';
      echo '<div class="phdr">'.$lng_chat['total_violations_chat'].': <b>'.$set_user_ban['count'].'</b></div>';
    } else {
      echo '<div class="rmenu">';
      echo '<p>'.$lng_chat['violations_in_chat_was_not'].'</p>';
      echo '</div>';
      echo '<div class="phdr"><a href="index.php">'.$lng_chat['to_chat'].'</a></div>';
    }
}
if ($rights) {
  echo '<p><a href="menu.php">'.$lng_chat['menu'].'</a><br />';
  echo '<a href="../panel">' . $lng['admin_panel'] . '</a></p>';
} else {
  echo '<p><a href="index.php'.($id ? '?id='.$id : '').'">'.$lng['back'].'</a></p>';
}

?>