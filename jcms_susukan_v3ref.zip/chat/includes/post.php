<?php

/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                     Чат v.:6.0 для JohnCMS v.:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                               Автор: k_2                                   //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Проверка прав доступа
if (!$id || !$id_k) {
  header("Location: index.php");
 exit;
}

/*
-----------------------------------------------------------------
Вывод отдельного сообщения
-----------------------------------------------------------------
*/ 
$sql = $rights > 6 ? "" : " AND `tip` != '1'";
if ($rights != 9)
  $sql .= " AND (`id_s` = '0' OR `id_u` = '" . $user_id . "' OR `id_s` = '" . $user_id . "')";
$soob = mysql_query("SELECT * FROM `chat_room_" . $id_k . "` WHERE `id` = '" . $id . "'" . $sql . "");
if (!mysql_num_rows($soob)) {
  header("Location: index.php");
 exit;
}
// Получаем данные сообщения
$soob_d = mysql_fetch_assoc($soob);
// Получаем данные комнаты
$kat_d = mysql_fetch_assoc(mysql_query("SELECT `name`, `tip` FROM `chat_rooms` WHERE `id` = '" . $id_k . "'"));
if ($kat_d['tip'] == 'in' && (!$_SESSION['key'] || $soob_d['pas'] != $_SESSION['key']) || $kat_d['tip'] == 'in' && !$user_id || $kat_d['tip'] == 'an') {
  header("Location: index.php");
 exit;
}
// Получаем данные юзера/бота, автора поста
$set_author = array();
$set_author = unserialize($soob_d['author']);
// Настроки по-умолчанию
if (!isset($set_author) || empty($set_author))
$set_author = serialize(array (
  'av' => '',
  'sex' => 'm',
  'status' => '',
  'name' => $lng_chat['ticker'],
  'name_delete' => '',
  'cvet' => '',
  'cvet_n' => '',
  'ip' => '2130706433',
  'soft' => 'k_2_bot',
  'rights' => 0
));
if ($soob_d['tip'] < 2) {
  if ($soob_d['id_u'] != $user_id)
    $us_d = mysql_fetch_assoc(mysql_query("SELECT `datereg`, `lastdate`, `rights` FROM `users` WHERE `id` = '" . $soob_d['id_u'] . "'"));
  else
    $us_d = $datauser;
  $rights_p = $set_author['rights'] ? $set_author['rights'] : $us_d['rights'];
} else
  $rights_p = 0;
$text = $soob_d['text'];
$text = functions::checkout($text, 1, 1);
echo '<div class="phdr"><b>'.$lng_chat['room'].':</b> '.$kat_d['name'].'</div><div class="menu">';
// Аватар
if ($set_user['avatar'] && $set_chat['avatar']) {
  echo '<table cellpadding="0" cellspacing="0"><tr><td>';
  if (file_exists((!$soob_d['id_bot'] ? '../files/users/avatar/'.$soob_d['id_u'] : 'img/'.$set_author['av']) . '.png'))
    echo '<img src="' . (!$soob_d['id_bot'] ? '../files/users/avatar/'.$soob_d['id_u'] : 'img/'.$set_author['av']) . '.png" width="32" height="32" alt="" />&#160;';
  else
    echo '<img src="../images/empty.png" width="32" height="32" alt="" />&#160;';
  echo '</td><td>';
}
// Метка пола
echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($set_author['sex'] == 'zh' ? 'w' : 'm') . (!$soob_d['id_bot'] ? ($us_d['datereg'] > time() - 86400 ? '_new' : '') : '') . '.png" width="16" height="16" align="middle" />&#160;'; 
// Ник автора поста и ссылка на его анкету
if ($user_id && ($user_id != $soob_d['id_u'] || $soob_d['id_bot'])) {
  echo '<a href="'.($soob_d['id_bot'] ? '' : '../users/').'profile.php?user='.$soob_d['id_u'].'"><b>'.($set_author['cvet_n'] ? "<span style='color: ".$set_author['cvet_n']."'>" : "") .$set_author['name'].($set_author['cvet_n'] ? '</span>' : '').'</b></a> ';
  echo '<a href="index.php?act=messages&amp;mod=txt&amp;id='.$id.'&amp;id_k=' . $id_k . '">'.$lng_chat['reply_btn'].'</a>&#160;<a href="index.php?act=messages&amp;mod=citata&amp;id=' . $id . '&amp;id_k=' . $id_k . '">'.$lng_chat['cytate_btn'].'</a> ';
} else {
  echo '<b>'.($set_author['cvet_n'] ? "<span style='color: ".$set_author['cvet_n']."'>" : "") .$set_author['name'].($set_author['cvet_n'] ? '</span>' : '').'</b> ';
}
// Метка должности юзера
if (!$soob_d['id_bot']) {
  $user_rights = array(6 => ' (Smd)', 7 => ' (Adm)', 9 => ' (SV!)');
  echo $user_rights[$us_d['rights']];
  if ($set_author['rights'])
    echo ' (Cmod)';
}
// Метка Онлайн / Офлайн
echo (time() > (!$soob_d['id_bot'] ? $us_d['lastdate'] + 300 : time()) ? '<span class="red"> [Off]</span> ' : '<span class="green"> [ON]</span> ');
// Время поста
$shift = (core::$system_set['timeshift'] + core::$user_set['timeshift']) * 3600;
echo ' <span class="gray">(' . date("d.m.Y/H:i", $soob_d['time'] + $shift) . ')</span><br />';
// Статус юзера
if ($set_author['status'])
  echo '<div class="status"><img src="../theme/' . $set_user['skin'] . '/images/label.png" alt="" align="middle"/>&#160;' . $set_author['status'] . '</div>';
// Аватар
if ($set_user['avatar'] && $set_chat['avatar'])
  echo '</td></tr></table>';
// Подсвечиваем ник в тексте
if ($set_chat['cvet_ns'])
  $text = preg_replace('|'.$login.'|si', '<span style="color:'.$set_chat['cvet_ns'].'">'.$login.'</span>', $text); // Подсветка ника в тексте
// Обрабатываем смайлы
if  ($set_user['smileys'])
  $text = functions::smileys($text, ($rights_p ? 1 : 0));
// Задаём цвет постов
$text = '<span style="color: '.$set_author['cvet'].'">'.$text.'</span>';
// Вводим текст сообщения
echo $text;
if ($chat_us_d['rights'] && $rights >= $rights_p || $rights >= 6 && $rights > $rights_p || $rights == 9)
  echo '<div class="sub"><span class="gray">' . long2ip($set_author['ip']) . ' - ' . $set_author['soft'] . '</span></div>';
echo '</div>';
echo '<div class="phdr"><a href="index.php?id=' . $id_k . '"><b>'.$lng['back'].'</b></a></div>';
echo '<p><a href="index.php">'.$lng_chat['hallway'].'</a></p>';

?>