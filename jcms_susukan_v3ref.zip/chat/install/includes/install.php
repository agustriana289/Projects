<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
/*
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                      Чат v.:6.0 для JohnCMS v:4.3.x                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                            Автор: k_2 (k202)                               //
//                                                                            //
//                Благодарности выражать на: WMR 250322967425.                //
//                                                                            //
//                     Обратная связь: k2022@rambler.ru                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
*/

defined('INSTALL') or die('Error: restricted access');

switch ($_GET['mod']) {
  case 'final':
    /*
    -----------------------------------------------------------------
    Установка завершена
    -----------------------------------------------------------------
    */
    echo '<h2 class="blue">'.$chat_lng['install'].'</h2>';
    echo $chat_lng['install_completed'];  
    echo '<hr /><p><a href="index.php">'.$chat_lng['home'].'</a><br />';
    echo '<a href="../../index.php">'.$chat_lng['on_site'].'</a><br />';
    echo '<a href="../../panel">'.$chat_lng['admin_panel'].'</a></p>';
  break;

  case 'set':
    /*
    -----------------------------------------------------------------
    Создание таблиц чата
    -----------------------------------------------------------------
    */
    mysql_query("DROP TABLE IF EXISTS `chat_rooms`;");
    mysql_query("CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `op` varchar(500) NOT NULL,
  `tip` varchar(3) NOT NULL,
  `bot` text NOT NULL,
  `nev` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    mysql_query("DROP TABLE IF EXISTS `chat_bot`;");
    mysql_query("CREATE TABLE `chat_bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tip` int(3) NOT NULL,
  `mass_bot` text NOT NULL,
  `mass_author` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    mysql_query("DROP TABLE IF EXISTS `chat_vop`;");
    mysql_query("CREATE TABLE `chat_vop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `vopros` text NOT NULL,
  `otvet` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bot` (`id_bot`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    mysql_query("DROP TABLE IF EXISTS `chat_users`;");
    mysql_query("CREATE TABLE `chat_users` (
  `id_u` int(11) NOT NULL,
  `ban_naz_time` int(11) NOT NULL,
  `ban_time` int(11) NOT NULL,
  `ban_text` text NOT NULL,
  `postchat` int(10) NOT NULL default '0',
  `otvetov` int(11) NOT NULL default '0',
  `rights` tinyint(1) NOT NULL default '0',
  `balans` int(11) NOT NULL default '0',
  `set_chat` text NOT NULL,
  PRIMARY KEY  (`id_u`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    mysql_query("DROP TABLE IF EXISTS `chat_settings`;");
    mysql_query("CREATE TABLE `chat_settings` (
  `key` tinytext NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`key`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    mysql_query("INSERT INTO `chat_settings` (`key`, `val`) VALUES
('access', '1'),
('balls', '0'),
('color_nik', '0'),
('color_nik_text', '0'),
('color_text', '0'),
('auto_delete', '0'),
('faq', '1'),
('time', '0'),
('leave_post', '0');");    
    header("location: index.php?act=install&mod=final");
  break;

  default:
    /*
    -----------------------------------------------------------------
    Предупреждение о создании таблиц чата
    -----------------------------------------------------------------
    */
    echo '<big><span class="red">'.$chat_lng['warning'].'</span></big>';
    echo '<ul><li>'.$chat_lng['install_table'].'</li></ul>';
    echo '<ul><li>'.$chat_lng['install_table_1'].'</li></ul>';
    echo '<ul><li>'.$chat_lng['install_table_2'].'</li></ul>';
    echo '<hr />'.$chat_lng['are_you_sure'].'<br /><a href="index.php?act=install&mod=set">'.$chat_lng['continue'].'</a><br /><a href="?">'.$chat_lng['home'].'</a>'; 
  break;
}

?>