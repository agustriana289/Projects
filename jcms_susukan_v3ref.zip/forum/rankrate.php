<?
/*
Originally by: gtlover
Modded by gretonger.com
*/

$user_u = $res['user_id'];
$req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_u' LIMIT 1");
$res_u = mysql_fetch_array($req_u);
$exp = $res_u['postforum'] + $res_u['postguest'] + $res_u['komm'];
if ($res_u['rights']<9){

if ($exp>=0 && $exp<=25)
echo ' <img src = "../images/medal/0.0.gif" height="' . $height . '" /> ';
if ($exp>=25 && $exp<=50)
echo ' <img src = "../images/medal/0.5.gif" height="' . $height . '" /> ';
if ($exp>=50 && $exp<=80)
echo ' <img src = "../images/medal/1.0.gif" height="' . $height . '" /> ';
if ($exp>=80 && $exp<=100)
echo ' <img src = "../images/medal/1.5.gif" height="' . $height . '" /> ';
if ($exp>=100 && $exp<=150)
echo ' <img src = "../images/medal/2.0.gif" height="' . $height . '" /> ';
if ($exp>=150 && $exp<=200)
echo ' <img src = "../images/medal/2.5.gif" height="' . $height . '" /> ';
if ($exp>=250 && $exp<=300)
echo ' <img src = "../images/medal/3.0.gif" height="' . $height . '" /> ';
if ($exp>=300 && $exp<=400)
echo ' <img src = "../images/medal/3.5.gif" height="' . $height . '" /> ';
if ($exp>=400 && $exp<=500)
echo ' <img src = "../images/medal/4.0.gif" height="' . $height . '" /> ';
if ($exp>=500 && $exp<=1000)
echo ' <img src = "../images/medal/4.5.gif" height="' . $height . '" /> ';
if ($exp>=1000 && $exp<=5000)
echo ' <img src = "../images/medal/5.0.gif" height="' . $height . '" /> ';
if ($exp>100000)
echo ' <img src = "../images/medal/5.0.gif" height="' . $height . '" /> ';

}else
echo ' <img src = "../images/medal/5.0.gif" height="' . $height . '" /> ';

?>