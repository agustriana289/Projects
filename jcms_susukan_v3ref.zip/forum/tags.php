<?php
/*
mod tag by shockvn.mobi
*/ 
echo'<div class="list1"><b>Tags:&nbsp;</b><a href="'.$home.'/forum/search.php?search=' . urlencode($type1['text']) .'"><font color="blue">'.$type1['text'].'</font></a>'; $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `refid`='$type1[refid]' AND `id`!='$id' ORDER BY `vip` DESC, `time` DESC LIMIT 5"); $total = mysql_num_rows($req); if($total!=0) { while ($res = mysql_fetch_assoc($req)) { echo is_integer($i / 2) ? ' , ' : ' , '; echo'<a href="'.$home.'/forum/search.php?search=' . urlencode($res['text']). '">'.$res['text'].'</a>'; echo'</span>'; } } echo'</div>';
?>