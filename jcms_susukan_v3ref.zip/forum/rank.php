<?
/*
Originally by: FIKTIFisme
Modded by kayukalek.org
*/

$user_u = $res['user_id'];
$req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_u' LIMIT 1");
$res_u = mysql_fetch_array($req_u);
$exp = $res_u['postforum'] + $res_u['postguest'] + $res_u['komm'];
if ($res_u['rights']<9){

if ($exp>=0 && $exp<=50)
echo '<font color="orange">sperma</font>';
if ($exp>=50 && $exp<=100)
echo '<font color="green">embrio</font>';
if ($exp>=100 && $exp<=200)
echo '<font color="blue">janin</font>';
if ($exp>=200 && $exp<=500)
echo '<font color="indigo">bayi</font>';
if ($exp>=500 && $exp<=750)
echo '<font color="red">balita</font>';
if ($exp>=750 && $exp<=1000)
echo '<font color="brown">anakkecil</font>';
if ($exp>=1000 && $exp<=1200)
echo '<font color="chocolate">pubertas</font>';
if ($exp>=1200 && $exp<=1500)
echo '<font color="silver">remaja</font>';
if ($exp>=1500 && $exp<=2000)
echo '<font color="gold">dewasa</font>';
if ($exp>=2000 && $exp<=10000)
echo '<font color="magenta">orangtua</font>';
if ($exp>=10000 && $exp<=50000)
echo '<font color="cyan">almarhum</font>';
if ($exp>50000)
echo '<font color="deepblue">gentayangan</font>';

}else
echo '<font color="olive">ahlisurga</font>';

?>