<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require('../incfiles/head.php');
if (!$id || !$user_id) {
    echo functions::display_error($lng['error_wrong_data']);
    require('../incfiles/end.php');
    exit;
}
// &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1103;&#1077;&#1084;, &#1090;&#1086;&#1090; &#1083;&#1080; &#1102;&#1079;&#1077;&#1088; &#1079;&#1072;&#1083;&#1080;&#1074;&#1072;&#1077;&#1090; &#1092;&#1072;&#1081;&#1083;
$req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id'");
$res = mysql_fetch_assoc($req);
if ($res['user_id'] != $user_id) {
    echo functions::display_error($lng['error_wrong_data']);
    require('../incfiles/end.php');
    exit;
}
$req1 = mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `post` = '$id'");
if (mysql_result($req1, 0) > 0) {
    echo functions::display_error($lng_forum['error_file_uploaded']);
    require('../incfiles/end.php');
    exit;
}
switch ($res['type']) {
    case "m":
        if (isset($_POST['submit'])) {
            /*
            -----------------------------------------------------------------
            &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072;, &#1073;&#1099;&#1083; &#1083;&#1080; &#1074;&#1099;&#1075;&#1088;&#1091;&#1078;&#1077;&#1085; &#1092;&#1072;&#1081;&#1083; &#1080; &#1089; &#1082;&#1072;&#1082;&#1086;&#1075;&#1086; &#1073;&#1088;&#1072;&#1091;&#1079;&#1077;&#1088;&#1072;
            -----------------------------------------------------------------
            */
            $do_file = false;
            $do_file_mini = false;
            if ($_FILES['fail']['size'] > 0) {
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1079;&#1072;&#1075;&#1088;&#1091;&#1079;&#1082;&#1080; &#1089; &#1086;&#1073;&#1099;&#1095;&#1085;&#1086;&#1075;&#1086; &#1073;&#1088;&#1072;&#1091;&#1079;&#1077;&#1088;&#1072;
                $do_file = true;
                $fname = strtolower($_FILES['fail']['name']);
                $fsize = $_FILES['fail']['size'];
            } elseif (strlen($_POST['fail1']) > 0) {
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1079;&#1072;&#1075;&#1088;&#1091;&#1079;&#1082;&#1080; &#1089; Opera Mini
                $do_file_mini = true;
                $array = explode('file=', $_POST['fail1']);
                $fname = strtolower($array[0]);
                $filebase64 = $array[1];
                $fsize = strlen(base64_decode($filebase64));
            }
            /*
            -----------------------------------------------------------------
            &#1054;&#1073;&#1088;&#1072;&#1073;&#1086;&#1090;&#1082;&#1072; &#1092;&#1072;&#1081;&#1083;&#1072; (&#1077;&#1089;&#1083;&#1080; &#1077;&#1089;&#1090;&#1100;), &#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1085;&#1072; &#1086;&#1096;&#1080;&#1073;&#1082;&#1080;
            -----------------------------------------------------------------
            */
            if ($do_file || $do_file_mini) {
                // &#1057;&#1087;&#1080;&#1089;&#1086;&#1082; &#1076;&#1086;&#1087;&#1091;&#1089;&#1090;&#1080;&#1084;&#1099;&#1093; &#1088;&#1072;&#1089;&#1096;&#1080;&#1088;&#1077;&#1085;&#1080;&#1081; &#1092;&#1072;&#1081;&#1083;&#1086;&#1074;.
                $al_ext = array_merge($ext_win, $ext_java, $ext_sis, $ext_doc, $ext_pic, $ext_arch, $ext_video, $ext_audio, $ext_other);
                $ext = explode(".", $fname);
                $error = array();
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1085;&#1072; &#1076;&#1086;&#1087;&#1091;&#1089;&#1090;&#1080;&#1084;&#1099;&#1081; &#1088;&#1072;&#1079;&#1084;&#1077;&#1088; &#1092;&#1072;&#1081;&#1083;&#1072;
                if ($fsize > 1024 * $set['flsz'])
                    $error[] = $lng_forum['error_file_size'] . ' ' . $set['flsz'] . 'kb.';
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1092;&#1072;&#1081;&#1083;&#1072; &#1085;&#1072; &#1085;&#1072;&#1083;&#1080;&#1095;&#1080;&#1077; &#1090;&#1086;&#1083;&#1100;&#1082;&#1086; &#1086;&#1076;&#1085;&#1086;&#1075;&#1086; &#1088;&#1072;&#1089;&#1096;&#1080;&#1088;&#1077;&#1085;&#1080;&#1103;
                if (count($ext) != 2)
                    $error[] = $lng_forum['error_file_name'];
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1076;&#1086;&#1087;&#1091;&#1089;&#1090;&#1080;&#1084;&#1099;&#1093; &#1088;&#1072;&#1089;&#1096;&#1080;&#1088;&#1077;&#1085;&#1080;&#1081; &#1092;&#1072;&#1081;&#1083;&#1086;&#1074;
                if (!in_array($ext[1], $al_ext))
                    $error[] = $lng_forum['error_file_ext'] . ':<br />' . implode(', ', $al_ext);
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1085;&#1072; &#1076;&#1083;&#1080;&#1085;&#1091; &#1080;&#1084;&#1077;&#1085;&#1080;
                if (strlen($fname) > 30)
                    $error[] = $lng_forum['error_file_name_size'];
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1085;&#1072; &#1079;&#1072;&#1087;&#1088;&#1077;&#1097;&#1077;&#1085;&#1085;&#1099;&#1077; &#1089;&#1080;&#1084;&#1074;&#1086;&#1083;&#1099;
                if (preg_match("/[^\da-z_\-.]+/", $fname))
                    $error[] = $lng_forum['error_file_symbols'];
                // &#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1072; &#1085;&#1072;&#1083;&#1080;&#1095;&#1080;&#1103; &#1092;&#1072;&#1081;&#1083;&#1072; &#1089; &#1090;&#1072;&#1082;&#1080;&#1084; &#1078;&#1077; &#1080;&#1084;&#1077;&#1085;&#1077;&#1084;
                if (file_exists("../files/forum/attach/$fname")) {
                    $fname = time() . $fname;
                }
                // &#1054;&#1082;&#1086;&#1085;&#1095;&#1072;&#1090;&#1077;&#1083;&#1100;&#1085;&#1072;&#1103; &#1086;&#1073;&#1088;&#1072;&#1073;&#1086;&#1090;&#1082;&#1072;
                if (!$error && $do_file) {
                    // &#1044;&#1083;&#1103; &#1086;&#1073;&#1099;&#1095;&#1085;&#1086;&#1075;&#1086; &#1073;&#1088;&#1072;&#1091;&#1079;&#1077;&#1088;&#1072;
               $fname = "Susukan.Us--".$fname."";
                    if ((move_uploaded_file($_FILES["fail"]["tmp_name"], "../files/forum/attach/$fname")) == true) {
                        @chmod("$fname", 0777);
                        @chmod("../files/forum/attach/$fname", 0777);
                        echo $lng_forum['file_uploaded'] . '<br/>';
                    } else {
                        $error[] = $lng_forum['error_upload_error'];
                    }
                } 
            elseif ($do_file_mini) {
                    // &#1044;&#1083;&#1103; Opera Mini
                    if (strlen($filebase64) > 0) {
                        $FileName = "../files/forum/attach/$fname";
                        $filedata = base64_decode($filebase64);
                        $fid = @fopen($FileName, "wb");
                        if ($fid) {
                            if (flock($fid, LOCK_EX)) {
                                fwrite($fid, $filedata);
                                flock($fid, LOCK_UN);
                            }
                            fclose($fid);
                        }
                        if (file_exists($FileName) && filesize($FileName) == strlen($filedata)) {
                            echo $lng_forum['file_uploaded'] . '<br/>';
                        } else {
                            $error[] = $lng_forum['error_upload_error'];
                        }
                    }
                }
                if (!$error) {
                    // &#1054;&#1087;&#1088;&#1077;&#1076;&#1077;&#1083;&#1103;&#1077;&#1084; &#1090;&#1080;&#1087; &#1092;&#1072;&#1081;&#1083;&#1072;
                    $ext = strtolower($ext[1]);
                    if (in_array($ext, $ext_win))
                        $type = 1;
                    elseif (in_array($ext, $ext_java))
                        $type = 2;
                    elseif (in_array($ext, $ext_sis))
                        $type = 3;
                    elseif (in_array($ext, $ext_doc))
                        $type = 4;
                    elseif (in_array($ext, $ext_pic))
                        $type = 5;
                    elseif (in_array($ext, $ext_arch))
                        $type = 6;
                    elseif (in_array($ext, $ext_video))
                        $type = 7;
                    elseif (in_array($ext, $ext_audio))
                        $type = 8;
                    else
                        $type = 9;
                    // &#1054;&#1087;&#1088;&#1077;&#1076;&#1077;&#1083;&#1103;&#1077;&#1084; ID &#1089;&#1091;&#1073;&#1082;&#1072;&#1090;&#1077;&#1075;&#1086;&#1088;&#1080;&#1080; &#1080; &#1082;&#1072;&#1090;&#1077;&#1075;&#1086;&#1088;&#1080;&#1080;
                    $req2 = mysql_query("SELECT * FROM `forum` WHERE `id` = '" . $res['refid'] . "'");
                    $res2 = mysql_fetch_array($req2);
                    $req3 = mysql_query("SELECT * FROM `forum` WHERE `id` = '" . $res2['refid'] . "'");
                    $res3 = mysql_fetch_array($req3);
                    // &#1047;&#1072;&#1085;&#1086;&#1089;&#1080;&#1084; &#1076;&#1072;&#1085;&#1085;&#1099;&#1077; &#1074; &#1073;&#1072;&#1079;&#1091;
                    mysql_query("INSERT INTO `cms_forum_files` SET
                        `cat` = '" . $res3['refid'] . "',
                        `subcat` = '" . $res2['refid'] . "',
                        `topic` = '" . $res['refid'] . "',
                        `post` = '$id',
                        `time` = '" . $res['time'] . "',
                        `filename` = '" . mysql_real_escape_string($fname) . "',
                        `filetype` = '$type'
                    ");
                } else {
                    echo functions::display_error($error, '<a href="index.php?act=addfile&amp;id=' . $id . '">' . $lng['repeat'] . '</a>');
                }
            } else {
                echo $lng_forum['error_upload_error'] . '<br />';
            }
            $pa = mysql_query("SELECT `id` FROM `forum` WHERE `type` = 'm' AND `refid` = '" . $res['refid'] . "'");
            $pa2 = mysql_num_rows($pa);
            $page = ceil($pa2 / $kmess);
            echo '<br/><a href="index.php?id=' . $res['refid'] . '&amp;page=' . $page . '">' . $lng['continue'] . '</a><br/>';
        } else {
            /*
            -----------------------------------------------------------------
            &#1060;&#1086;&#1088;&#1084;&#1072; &#1074;&#1099;&#1073;&#1086;&#1088;&#1072; &#1092;&#1072;&#1081;&#1083;&#1072; &#1076;&#1083;&#1103; &#1074;&#1099;&#1075;&#1088;&#1091;&#1079;&#1082;&#1080;
            -----------------------------------------------------------------
            */
            echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $lng_forum['add_file'] . '</b></div>' .
                 '<div class="gmenu"><form action="index.php?act=addfile&amp;id=' . $id . '" method="post" enctype="multipart/form-data"><p>';
            if (stristr($agn, 'Opera/8.01')) {
                echo '<input name="fail1" value =""/>&#160;<br/><a href="op:fileselect">' . $lng_forum['select_file'] . '</a>';
            } else {
                echo '<input type="file" name="fail"/>';
            }
            echo '</p><p><input type="submit" name="submit" value="' . $lng_forum['upload'] . '"/></p></form></div>' .
                 '<div class="nfooter">' . $lng_forum['max_size'] . ': ' . $set['flsz'] . 'kb.</div></div></div>';
        }
        break;

    default:
        echo functions::display_error($lng['error_wrong_data']);
}
?>