<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'mainpage';
require('../incfiles/core.php');
require('url.php'); 
$lng_forum = core::load_lng('forum');
if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);

/*
-----------------------------------------------------------------
??????????? ???????
-----------------------------------------------------------------
*/
$set_forum = $user_id && !empty($datauser['set_forum']) ? unserialize($datauser['set_forum']) : array(
    'farea' => 0,
    'upfp' => 0,
    'preview' => 1,
    'postclip' => 1,
    'postcut' => 2
);

/*
-----------------------------------------------------------------
????????? ??????????? ???????, ???????????? ?? ??????????
-----------------------------------------------------------------
*/
// ??????? ?????????
$ext_arch = array(
    'zip',
    'rar',
    '7z',
    'tar',
    'gz'
);
// ??????????? ???????
$ext_audio = array(
    'mp3',
    'amr'
);
// ??????? ??????????? ?? ????????
$ext_doc = array(
    'txt',
    'pdf',
    'doc',
    'rtf',
    'djvu',
    'xls'
);
// ??????? Java
$ext_java = array(
    'jar',
    'jad'
);
// ??????? ??????????
$ext_pic = array(
    'jpg',
    'jpeg',
    'gif',
    'png',
    'bmp'
);
// ??????? SIS
$ext_sis = array(
    'sis',
    'sisx'
);
// ??????? ??????
$ext_video = array(
    '3gp',
    'avi',
    'flv',
    'mpeg',
    'mp4'
);
// ??????? Windows
$ext_win = array(
    'exe',
    'msi'
);
// ???????? ????? ??????? (???? ??? ???????????? ?????)
$ext_other = array('wmf');

/*
-----------------------------------------------------------------
?????????????? ??????? ?? ?????????
-----------------------------------------------------------------
*/
$error = '';
if (!$set['mod_forum'] && $rights < 7)
    $error = $lng_forum['forum_closed'];
elseif ($set['mod_forum'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error) {
    require('../incfiles/head.php');
    echo '<div class="rmenu"><p>' . $error . '</p></div>';
    require('../incfiles/end.php');
    exit;
}

$headmod = $id ? 'forum,' . $id : 'forum';

/*
-----------------------------------------------------------------
??????????? ????????? ???????
-----------------------------------------------------------------
*/
if (empty($id)) {
    $textl = '' . $lng['forum'] . '';
} else {
$trangvip = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");  // TAGS MOD
    $trangvip1 = mysql_fetch_assoc($trangvip);  // waptok tags
        $req = mysql_query("SELECT `text` FROM `forum` WHERE `id`= '" . $id . "'");
    $res = mysql_fetch_assoc($req);
    $hdr = strtr($res['text'], array(
        '&quot;' => '',
        '&amp;' => '',
        '&lt;' => '',
        '&gt;' => '',
        '&#039;' => ''
    ));
    $hdr = mb_substr($hdr, 0, 30);
    $hdr = functions::checkout($hdr);
    $textl = mb_strlen($res['text']) > 30 ? $hdr . '...' : $hdr;
    //$textl = ''.bbcode::notags($res['text']).'...'.$trangvip1['tags'].'';
}

/*
-----------------------------------------------------------------
?????????????? ???????? ????????
-----------------------------------------------------------------
*/
$mods = array(
    'addfile',
    'addvote',
   'auto',
    'close',
   'minim1',
    'minim2',
    'minim3',
    'minim4',
    'minim5',
    'deltema',
    'delvote',
    'editpost',
    'editvote',
    'file',
    'files',
    'filter',
    'loadtem',
   'import',
    'massdel',
    'moders',
    'new',
    'nt',
    'per',
    'post',
    'ren',
    'restore',
    'say',
    'tema',
    'pema',
    'users',
    'vip',
    'vote',
   'xoafile',
    'who',
    'curators'
);
if ($act && ($key = array_search($act, $mods)) !== false && file_exists('includes/' . $mods[$key] . '.php')) {
    require('includes/' . $mods[$key] . '.php');
} else {
    require('../incfiles/head.php');

    /*
    -----------------------------------------------------------------
    ??????? ?????? ???????, ???? ???? ?????????? ???????? ????????????
    -----------------------------------------------------------------
    */
    if (!$set['mod_forum']) echo '</div></div><div class="rmenu">' . $lng_forum['forum_closed'] . '</div>';
    elseif ($set['mod_forum'] == 3) echo '<div class="rmenu">' . $lng['read_only'] . '</div>';
    if (!$user_id) {
        if (isset($_GET['newup']))
            $_SESSION['uppost'] = 1;
        if (isset($_GET['newdown']))
            $_SESSION['uppost'] = 0;
    }
    if ($id) {
        /*
        -----------------------------------------------------------------
        ????????????? ????? ???????? (????????, ???? ??????)
        -----------------------------------------------------------------
        */
        $type = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");
        if (!mysql_num_rows($type)) {
            // ??????? ?????? ??? ???????????, ???????????? ???????
            echo functions::display_error($lng_forum['error_topic_deleted'], '<a href="index.php">' . $lng['to_forum'] . '</a>');
            require('../incfiles/end.php');
            exit;
        }
        $type1 = mysql_fetch_assoc($type);

        /*
        -----------------------------------------------------------------
        ?????????? ?????? ??????????? ????????
        -----------------------------------------------------------------
        */
        if ($user_id && $type1['type'] == 't') {
            $req_r = mysql_query("SELECT * FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            if (mysql_num_rows($req_r)) {
                $res_r = mysql_fetch_assoc($req_r);
                if ($type1['time'] > $res_r['time'])
                    mysql_query("UPDATE `cms_forum_rdm` SET `time` = '" . time() . "' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            } else {
                mysql_query("INSERT INTO `cms_forum_rdm` SET `topic_id` = '$id', `user_id` = '$user_id', `time` = '" . time() . "'");
            }
        }

        /*
        -----------------------------------------------------------------
        ??????????? ??????????? ???????
        -----------------------------------------------------------------
        */
        $res = true;
        $parent = $type1['refid'];
        while ($parent != '0' && $res != false) {
            $req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$parent' LIMIT 1");
            $res = mysql_fetch_assoc($req);
            if ($res['type'] == 'f' || $res['type'] == 'r')
                $tree[] = '<a href="' . ___($res['text']) . '_' . $parent . '.html">' . $res['text'] . '</a>';
            $parent = $res['refid'];
        }
        $tree[] = '<a href="index.php">' . $lng['forum'] . '</a>';
        krsort($tree);
        if ($type1['type'] != 't' && $type1['type'] != 'm')
            $tree[] = '<b>' . $type1['text'] . '</b>';

        /*
        -----------------------------------------------------------------
        ?????????? ??????? ?? ???????? ??? ????
        -----------------------------------------------------------------
        */
$sql = ($rights == 9) ? "" : " AND `del` != '1'";
if ($type1['type'] == 'f') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `cat` = '$id'" . $sql), 0);
if (empty($user_id) || ($count > 0) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3)
$filelink = '<a href="index.php?act=files&amp;c=' . $id . '">' . $lng_forum['files_category'] . '</a>';
} elseif ($type1['type'] == 'r') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `subcat` = '$id'" . $sql), 0);
if (empty($user_id) || ($count > 0) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3)
$filelink = '<a href="index.php?act=files&amp;s=' . $id . '">' . $lng_forum['files_section'] . '</a>';
} elseif ($type1['type'] == 't') {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `topic` = '$id'" . $sql), 0);
if (empty($user_id) || ($count > 0) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3)
$filelink = '<a href="index.php?act=files&amp;t=' . $id . '">' . $lng_forum['files_topic'] . '</a>';
}
$filelink = isset($filelink) ? $filelink . '&#160;<span class="red">(' . $count . ')</span>' : false;
        /*
        -----------------------------------------------------------------
        ?????????? "?????? ?? ???????"
        -----------------------------------------------------------------
        */
        $wholink = false;
        if ($user_id && $type1['type'] == 't') {
            $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $wholink = '<a href="index.php?act=who&amp;id=' . $id . '">' . $lng_forum['who_here'] . '?</a>&#160;<span class="red">(' . $online_u . '&#160;/&#160;' . $online_g . ')</span><br/>';
        }

        /*
        -----------------------------------------------------------------
        ????????? ????????? ???????? ???????????
        -----------------------------------------------------------------
        */
        echo '<p>' . counters::forum_new(1) . '</p>' .
             '</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter">' . functions::display_menu($tree) . '</div>' .
             '<div class="topmenu"><a href="search.php?id=' . $id . '">' . $lng['search'] . '</a>' . ($filelink ? ' | ' . $filelink : '') . ($wholink ? ' | ' . $wholink : '') . '</div>';
        /*
        -----------------------------------------------------------------
        S-SzSaS"SzS'SaSl N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
        // bookmark
                                                  
      if ($type1['type'] == 't' && $user_id) {
           if(!$res_r['bookmark'] && isset($_GET['addBookmark'])) {
              mysql_query("UPDATE `cms_forum_rdm` SET `bookmark` = '1' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
               $res_r['bookmark'] = 1;
         } elseif($res_r['bookmark'] && isset($_GET['delBookmark'])) {
              mysql_query("UPDATE `cms_forum_rdm` SET `bookmark` = '0' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            $res_r['bookmark'] = 0;
           }
         echo '<div class="omenu">';
         echo $res_r['bookmark'] ? '<a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;delBookmark">Delete Bookmark</a>' :
           '<a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;addBookmark">Add Bookmark</a>';
      echo ' | <a href="bookmark.php">Bookmark Panel</a>';  
        

      $usersBookmark = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `bookmark` = '1'"), 0);
        if($usersBookmark && !isset($_GET['usersBookmark']))
           echo '<br /><a href="index.php?id=' . $id . '&amp;usersBookmark">' . $usersBookmark . ' Users Bookmark this thread.</a>';
                    
       echo '</div>';
     }
      if(isset($_GET['usersBookmark']) && $usersBookmark) {
         echo '<div class="mainblok"><div class="nfooter"><a href="index.php?id=' . $id . '">' . $type1['text'] . '</a> | Footage</div>';
            $req = mysql_query("SELECT `cms_forum_rdm`.*, `users`.`rights`, `users`.`lastdate`, `users`.`name`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
          FROM `cms_forum_rdm` LEFT JOIN `users` ON `cms_forum_rdm`.`user_id` = `users`.`id`
          WHERE `cms_forum_rdm`.`topic_id`='$id' AND `cms_forum_rdm`.`bookmark` = '1' ORDER BY `id` DESC LIMIT $start,$kmess");
            $i = 0;
          while ($res = mysql_fetch_array($req)) {
              echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
              echo functions::display_user($res, array ('iphide' => 1));
              echo '</div>';
              ++$i;
          }
            echo '<div class="nfooter">Total: ' . $usersBookmark . '</div>';
         if ($usersBookmark > $kmess) {
              echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;usersBookmark&amp;', $start, $usersBookmark, $kmess) . '</div>' .
               '<p><form action="index.php?id=' . $id . '&amp;usersBookmark" method="post">' .
               '<input type="text" name="page" size="2"/>' .
               '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
          }
            echo '</div></div>';
            echo '<p><a href="index.php?id=' . $id . '">To Thread</a></p>';
         require_once('../incfiles/end.php');
            exit;
         }

        /*
        -----------------------------------------------------------------
        SzN,NES+NESzS?SzSuSL N?SlS'SuNES?SlSLSlSu N"SlNEN?SLSz
        -----------------------------------------------------------------
        */
        switch ($type1['type']) {
            case 'f':
                /*
                -----------------------------------------------------------------
                ????????? ????????? ???????
                -----------------------------------------------------------------
                */
                $req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='r' AND `refid`='$id' ORDER BY `realid`");
                $total = mysql_num_rows($req);
                if ($total) {
                    $i = 0;
                    while (($res = mysql_fetch_assoc($req)) !== false) {
                        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                        $coltem = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '" . $res['id'] . "'"), 0);
                        echo '<a href="' . ___($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a>';
                        if ($coltem)
                            echo " [$coltem]";
                        if (!empty($res['soft']))
                            echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
                        echo '</div>';
                        ++$i;
                    }
                    unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                } else {
                    echo '<div class="menu"><p>' . $lng_forum['section_list_empty'] . '</p></div>';
                }
                echo '<div class="nfooter">' . $lng['total'] . ': ' . $total . '</div></div></div></div></div></div></div>';
                break;

            case 'r':
                /*
                -----------------------------------------------------------------
                ????????? ????????
                -----------------------------------------------------------------
                */
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close`!='1'")), 0);
                if (($user_id && !isset($ban['1']) && !isset($ban['11']) && $set['mod_forum'] != 3) || core::$user_rights) {
                    // ???????? ????????? ?????? ??????
                    echo '<div class="gmenu"><form action="index.php?act=nt&amp;id=' . $id . '" method="post"><input type="submit" value="' . $lng_forum['new_topic'] . '" /></form></div>';
                }
                if ($total) {
                    $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t'" . ($rights >= 7 ? '' : " AND `close`!='1'") . " AND `refid`='$id' ORDER BY `vip` DESC, `time` DESC LIMIT $start, $kmess");
                    $i = 0;
                    while (($res = mysql_fetch_assoc($req)) !== false) {
                        if ($res['close'])
                            echo '<div class="rmenu">';
                        else
                            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                        $nikuser = mysql_query("SELECT `from` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $res['id'] . "' ORDER BY `time` DESC LIMIT 1");
                        $nam = mysql_fetch_assoc($nikuser);
                        $colmes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m' AND `refid`='" . $res['id'] . "'" . ($rights >= 7 ? '' : " AND `close` != '1'"));
                        $colmes1 = mysql_result($colmes, 0);
                        $cpg = ceil($colmes1 / $kmess);
                        $np = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `time` >= '" . $res['time'] . "' AND `topic_id` = '" . $res['id'] . "' AND `user_id`='$user_id'"), 0);
                        // ?????????
                        $icons = array(
                            ($np ? (!$res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/op.gif" alt=""/>' : '') : '<img src="../theme/' . $set_user['skin'] . '/images/np.gif" alt=""/>'),
                            ($res['vip'] ? '<img src="../theme/' . $set_user['skin'] . '/images/pt.gif" alt=""/>' : ''),
                            ($res['realid'] ? '<img src="../theme/' . $set_user['skin'] . '/images/rate.gif" alt=""/>' : ''),
                            ($res['edit'] ? '<img src="../theme/' . $set_user['skin'] . '/images/tz.gif" alt=""/>' : '')
                        );
                  $tieude = $res['text'];
                        echo functions::display_menu($icons, '&#160;', '&#160;');
                        echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html">' .bbcode::tags($tieude). '</a> [' . $colmes1 . ']';
                        if ($cpg > 1) {
                            echo '<a href="index.php?id=' . $res['id'] . '&amp;page=' . $cpg . '">&#160;&gt;&gt;</a>';
                        }
                        echo '<div class="sub">';
                        echo $res['from'];
                        if (!empty($nam['from'])) {
                            echo '&#160;/&#160;' . $nam['from'];
                        }
                        echo ' <span class="gray">(' . functions::display_date($res['time']) . ')</span></div></div>';
                        ++$i;
                    }
                    unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                } else {
                    echo '<div class="menu"><p>' . $lng_forum['topic_list_empty'] . '</p></div></div></div></div></div></div></div>';
                }
                echo '<div class="nfooter">' . $lng['total'] . ': ' . $total . '</div>';
                if ($total > $kmess) {
                    echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div></div></div></div></div></div></div>' .
                         '<div class="mainbox"><p><form action="index.php?id=' . $id . '" method="post">' .
                         '<input type="text" name="page" size="2"/>' .
                         '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
                         '</form></p></div></div></div></div></div>';
                }
                break;

            case 't':
                /*
                -----------------------------------------------------------------
                ????????? ???????
                -----------------------------------------------------------------
                */
                $filter = isset($_SESSION['fsort_id']) && $_SESSION['fsort_id'] == $id ? 1 : 0;
                $sql = '';
                if ($filter && !empty($_SESSION['fsort_users'])) {
                    // ????????????????? ???????? ??? ???????????? ????????
                    $sw = 0;
                    $sql = ' AND (';
                    $fsort_users = unserialize($_SESSION['fsort_users']);
                    foreach ($fsort_users as $val) {
                        if ($sw)
                            $sql .= ' OR ';
                        $sortid = intval($val);
                        $sql .= "`forum`.`user_id` = '$sortid'";
                        $sw = 1;
                    }
                    $sql .= ')';
                }
                if ($user_id && !$filter) {
                    // ?????????? ?????? ??????????? ????????
                }
            // Private topic switch
if ($rights == 7 || $rights >= 9) {
if ($type1['minim1'] == 1)
echo '<a href="index.php?act=minim1&amp;id=' . $id . '">&#160;Switch topic to normal post</a><br/>';
else
echo '<a href="index.php?act=minim1&amp;id=' . $id . '&amp;minimed">&#160;Switch topic for 10 post only</a><br/>';
if ($type1['minim2'] == 1)
echo '<a href="index.php?act=minim2&amp;id=' . $id . '">&#160;Switch topic to normal post</a><br/>';
else
echo '<a href="index.php?act=minim2&amp;id=' . $id . '&amp;minimed">&#160;Switch topic for 20 post only</a><br/>';
if ($type1['minim3'] == 1)
echo '<a href="index.php?act=minim3&amp;id=' . $id . '">&#160;Switch topic to normal post</a><br/>';
else
echo '<a href="index.php?act=minim3&amp;id=' . $id . '&amp;minimed">&#160;Switch topic for 30 post only</a><br/>';
if ($type1['minim4'] == 1)
echo '<a href="index.php?act=minim4&amp;id=' . $id . '">&#160;Switch topic to normal post</a><br/>';
else
echo '<a href="index.php?act=minim4&amp;id=' . $id . '&amp;minimed">&#160;Switch topic for 40 post only</a><br/>';
if ($type1['minim5'] == 1)
echo '<a href="index.php?act=minim5&amp;id=' . $id . '">&#160;Switch topic to normal post</a><br/>';
else
echo '<a href="index.php?act=minim5&amp;id=' . $id . '&amp;minimed">&#160;Switch topic for 50 post only</a>';
echo '</div></div>';
}
// Private topic block
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 10 && $type1['minim1'] == 1) {
echo '<div class="menua"><div class="rmenu">Topic that you entered required atleast 10 post in forum and your post doesnt enough to see this topic you may post in another section first but please dont spam or you will get banned..!! </a></div></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 20 && $type1['minim2'] == 1) {
echo '<div class="menua"><div class="rmenu">Topic that you entered required atleast 20 post in forum and your post doesnt enough to see this topic you may post in another section first but please dont spam or you will get banned..!! </a></div></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 30 && $type1['minim3'] == 1) {
echo '<div class="menua"><div class="rmenu">STopic that you entered required atleast 30 post in forum and your post doesnt enough to see this topic you may post in another section first but please dont spam or you will get banned..!! </a></div></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 40 && $type1['minim4'] == 1) {
echo '<div class="menua"><div class="rmenu">Topic that you entered required atleast 40 post in forum and your post doesnt enough to see this topic you may post in another section first but please dont spam or you will get banned..!! </a></div></div></div>';
require_once("../incfiles/end.php");
exit;
}
if ($ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 50 && $type1['minim5'] == 1) {
echo '<div class="menua"><div class="rmenu">Topic that you entered required atleast 50 post in forum and your post doesnt enough to see this topic you may post in another section first but please dont spam or you will get banned..!! </a></div></div></div>';
require_once("../incfiles/end.php");
exit;
}
                if ($rights < 7 && $type1['close'] == 1) {
                    echo '<div class="rmenu"><p>' . $lng_forum['topic_deleted'] . '<br/><a href="?id=' . $type1['refid'] . '">' . $lng_forum['to_section'] . '</a></p></div>';
                    require('../incfiles/end.php');
                    exit;
                }
                // ?????????? ???????? ??????
                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'$sql AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
                if ($start > $colmes) $start = $colmes - $kmess;
                // ????????? ????????? ????????


            $tieude = $type1['text'];
            echo '</div></div><div class="mainbox"><div class="mainblok">';

                echo '<div class="nfooter"><a name="up" id="up"></a><a href="#down"><img src="../theme/' . $set_user['skin'] . '/images/down.png" alt="down" width="20" height="10" border="0"/></a>';
                                    if ($type1['tiento'] ==1) {
echo'<b><font color="purple">Discusion:</font></b>';
} elseif ($type1['tiento'] ==2) {
echo'<b><font color="red">Hot:</font></b>';
} elseif ($type1['tiento'] ==3) {
echo'<b><font color="green">Notice:</font></b>';
} elseif ($type1['tiento'] ==4) {
echo'<b><font color="red">Share:</font></b>';
} elseif ($type1['tiento'] ==5) {
echo'<b><font color="green">Script:</font></b>';
} elseif ($type1['tiento'] ==6) {
echo'<b><font color="blue">Help:</font></b>';
}
            echo '<b>' .bbcode::tags($tieude). '</b></div>';
                if ($colmes > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;', $start, $colmes, $kmess) . '</div>';
// Tags forum
      echo '<div class="topmenu"><b>Tags:</b> ';
      echo $type1['tags'];
      echo '</div>';
            echo '</div></div></div>';

                // ???????? ?????????? ??????
                if ($type1['close'])
                    echo '<div class="rmenu">' . $lng_forum['topic_delete_who'] . ': <b>' . $type1['close_who'] . '</b></div>';
                elseif (!empty($type1['close_who']) && $rights >= 7)
                    echo '<div class="gmenu"><small>' . $lng_forum['topic_delete_whocancel'] . ': <b>' . $type1['close_who'] . '</b></small></div>';
                // ???????? ?????????? ??????
                if ($type1['edit'])
                    echo '<div class="rmenu">' . $lng_forum['topic_closed'] . '</div>';
                //like_dislike
                include 'prus_mod/like_dislike.php';
                /*
                -----------------------------------------------------------------
                &#1041;&#1083;&#1086;&#1082; &#1075;&#1086;&#1083;&#1086;&#1089;&#1086;&#1074;&#1072;&#1085;&#1080;&#1081;
                -----------------------------------------------------------------
                */
                if ($type1['realid']) {
                    $clip_forum = isset($_GET['clip']) ? '&amp;clip' : '';
                    $vote_user = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote_users` WHERE `user`='$user_id' AND `topic`='$id'"), 0);
                    $topic_vote = mysql_fetch_assoc(mysql_query("SELECT `name`, `time`, `count` FROM `cms_forum_vote` WHERE `type`='1' AND `topic`='$id' LIMIT 1"));
                    echo '<div  class="mainbox"><div  class="forumb"><b>' . functions::checkout($topic_vote['name']) . '</b><br />';
                    $vote_result = mysql_query("SELECT `id`, `name`, `count` FROM `cms_forum_vote` WHERE `type`='2' AND `topic`='" . $id . "' ORDER BY `id` ASC");
                    if (!$type1['edit'] && !isset($_GET['vote_result']) && $user_id && $vote_user == 0) {
                        // ????????? ??????? ?? ??????????
                        echo '<form action="index.php?act=vote&amp;id=' . $id . '" method="post">';
                        while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
                            echo '<input type="radio" value="' . $vote['id'] . '" name="vote"/> ' . functions::checkout($vote['name'], 0, 1) . '<br />';
                        }
                        echo '<p><input type="submit" name="submit" value="' . $lng['vote'] . '"/><br /><a href="index.php?id=' . $id . '&amp;start=' . $start . '&amp;vote_result' . $clip_forum .
                             '">' . $lng_forum['results'] . '</a></p></form></div></div></div></div>';
                    } else {
                        // ????????? ???????????? ????????????
                        echo '<small>';
                        while (($vote = mysql_fetch_assoc($vote_result)) !== false) {
                            $count_vote = $topic_vote['count'] ? round(100 / $topic_vote['count'] * $vote['count']) : 0;
                            echo functions::checkout($vote['name'], 0, 1) . ' [' . $vote['count'] . ']<br />';
                            echo '<img src="vote_img.php?img=' . $count_vote . '" alt="' . $lng_forum['rating'] . ': ' . $count_vote . '%" /><br />';
                        }
                        echo '</small></div><div class="nfooter">' . $lng_forum['total_votes'] . ': ';
                        if ($datauser['rights'] > 6)
                            echo '<a href="index.php?act=users&amp;id=' . $id . '">' . $topic_vote['count'] . '</a>';
                        else
                            echo $topic_vote['count'];
                        echo '</div>';
                        if ($user_id && $vote_user == 0)
                            echo '<div class="nfooter"><a href="index.php?id=' . $id . '&amp;start=' . $start . $clip_forum . '">' . $lng['vote'] . '</a></div></div></div></div></div></div></div></div></div>';
                    }
                }
                $curators = !empty($type1['curators']) ? unserialize($type1['curators']) : array();
                $curator = false;
                if ($rights < 6 && $rights != 3 && $user_id) {
                    if (array_key_exists($user_id, $curators)) $curator = true;
                }
                /*
                -----------------------------------------------------------------
                ?????????? ????????? ?????? ?? ??????
                -----------------------------------------------------------------
                */
                if (($set_forum['postclip'] == 2 && ($set_forum['upfp'] ? $start < (ceil($colmes - $kmess)) : $start > 0)) || isset($_GET['clip'])) {
                    $postreq = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
                    FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                    WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
                    ORDER BY `forum`.`id` LIMIT 1");
                    $postres = mysql_fetch_assoc($postreq);
                    echo '<div class="mainbox"><div class="topmenu"><p>';
                    if ($postres['sex'])
                        echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($postres['sex'] == 'm' ? 'm' : 'w') . ($postres['datereg'] > time() - 86400 ? '_new.png" width="14"' : '.png" width="10"') . ' height="10"/>&#160;';
                    else
                        echo '<img src="../images/del.png" width="10" height="10" alt=""/>&#160;';
                    if ($user_id && $user_id != $postres['user_id']) {
                        echo '<a href="../users/profile.php?user=' . $postres['user_id'] . '&amp;fid=' . $postres['id'] . '"><b>' . $postres['from'] . '</b></a> ' .
                             '<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '"> ' . $lng_forum['reply_btn'] . '</a> ' .
                             '<a href="index.php?act=say&amp;id=' . $postres['id'] . '&amp;start=' . $start . '&amp;cyt"> ' . $lng_forum['cytate_btn'] . '</a> ';
                    } else {
                        echo '<b>' . $postres['from'] . '</b> ';
                    }
                    $user_rights = array(
                        1 => 'Kil',
                        3 => 'Mod',
                        6 => 'Smd',
                        7 => 'Adm',
                        8 => 'SV'
                    );
                    echo @$user_rights[$postres['rights']];
                    //echo (time() > $postres['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');
                    //echo ' <span class="gray">(' . functions::display_date($postres['time']) . ')</span><br/>';
                    //echo ' <span class="gray">(' . functions::display_date($postres['time']) . ')</span><br/>';
                    if ($postres['close']) {
                        echo '<span class="red">' . $lng_forum['post_deleted'] . '</span><br/>';
                    }
                    echo functions::checkout(mb_substr($postres['text'], 0, 500), 0, 2);
                    if (mb_strlen($postres['text']) > 500)
                        echo '...<a href="index.php?act=post&amp;id=' . $postres['id'] . '">' . $lng_forum['read_all'] . '</a>';
                    echo '</p></div></div>';
                }
                if ($filter)
                    echo '<div class="rmenu">' . $lng_forum['filter_on'] . '</div>';
                // ???????? ???????? ??????????? (?????? ?????? / ???????)
                if ($user_id)
                    $order = $set_forum['upfp'] ? 'ASC' : 'ASC';
                else
                    $order = ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) ? 'ASC' : 'ASC';
                // ????????? ?? ?????
                $req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`,`users`.`postforum`, `users`.`datereg`, `users`.`podpis`
                FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'"
                                   . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "$sql ORDER BY `forum`.`id` $order LIMIT $start, $kmess");
                // ????????? ????? "???????????"

               if ($rights == 3 || $rights >= 6)
echo '<form action="index.php?act=massdel" method="post">';
$i = 1;
while (($res = mysql_fetch_assoc($req)) !== false) {
echo '</div></div><div class="mainbox"><div class="mainblok"><div class="nfooter" align="right">'; //iki
echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
echo '' . functions::display_date($res['time']) . '</div> ';
echo '</td><td width="auto" align="right">';
echo '#<font color="#FFFFFF"><a href="index.php?act=post&amp;id=' . $res['id']. '?#' .( $start + $i ). '">' .( $start + $i ). '</a></font>';
//echo '<a href="'.$home.'/forum/'.functions::converturl($type1['text']).'_p' . $res['id'] . '.html">#Single Post</a>';
echo '</td></tr></table></div>'; //iki
//echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="../images/file.png" /> ' . functions::display_date($res['time']) . '</div>';
if ($res['close'])
echo '<div class="forum_adm">';
else
echo '<div>';
if ($set_user['avatar']) {
echo '<div
class="avamenu"><table
width="100%" cellpadding="0"
cellspacing="0"><tbody><tr><td
width="36" align="left"
valign="top">';
if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
echo '<span class="avatar"><img src="../files/users/avatar/' . $res['user_id'] . '.png" width="30" height="auto" alt="' . $res['from'] . '" /></span>&#160;';
else
echo '<span class="avatar"><img src="../images/empty.png" width="30" height="auto" alt="' . $res['from'] . '" /></span>&#160;';
echo '</td><td
width="auto" align="left"
valign="top">';
}
echo '&nbsp;<a href="'.$home.'/users/' . $res['from'] . '"><b>' . $res['from'] . '</b></a>&nbsp;';
echo (time() > $res['lastdate'] + 300 ? '<span class="red">&nbsp;[OFF]</span>':'<span class="green">&nbsp;[ON]</span>');
// ??u?,?? ?'???"?????????,?
// ??u?,?? ?.???"??1?? / ?.?"?"??1??
//echo (time() > $postres['lastdate'] + 300 ? '<span class="red"> Off</span>' : '<span class="green"> ON</span>');
//echo ' <span class="gray">(' . functions::display_date($postres['time']) . ')</span><br/>';
// ????<?"?? ??? ???,?2?u?, ? ????,??E???2?????u
//if ($user_id && $user_id != $res['user_id']) {
//echo '<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '">' . $lng_forum['reply_btn'] . '</a>&#160;' .
//'<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '&amp;cyt">' . $lng_forum['cytate_btn'] . '</a> ';
//}
// ?'?E?u???Z ?c?????,?
//echo ' <span class="gray">(' . functions::display_date($res['time']) . ')</span><br />';
// Pangkat
$user_rights = array(
1 => '<font color="orange">&nbsp;Member</font>', 
3 => '<font color="green">&nbsp;Modarator</font>',
6 => '<font color="purple">&nbsp;Moderator</font>',
7 => '<font color="red">&nbsp;Pro Admin</font>',
9 => '<font color="#0066ff"><b>H</b></font><font color="#0000ff"><b>E</b></font><font color="#3300ff"><b>A</b></font><font color="#9900ff"><b>D</b></font>    <font color="#ff0000"><b>A</b></font><font color="#ff3300"><b>D</b></font><font color="#ff6600"><b>M</b></font><font color="#ff9900"><b>IN</b></font>'
);
if (!empty($res['rights']))
echo '<br>'. @$user_rights[$res['rights']];
//echo '<br>Join Date: ' . date("M Y", $res['datereg']) . '';
echo '<br/>';
include 'rankrate.php';
// ??,??,???? ?Z?.?u?E?
echo '</td><td
width="auto" align="right"
valign="top">';
echo '<a href="/mail/index.php?act=write&amp;id=' . $res['user_id'] . '"><b>PM</b> <img src="../images/pm.png" width="auto" heght="12" align="middle" alt=""></a>';
//if (!empty($res['pangkat']))
//echo '<br/>' . bbcode::tags($res['pangkat']) . '';
echo '<br>Post: ' . $res['postforum'] . '';
if (!empty($res['status']))
echo '<br>' . $res['status'] . '';
if ($set_user['avatar'])
echo '</td></tr></table>'; 
echo '</div><div class="forumtxt">';
$text = $res['text'];
if ($set_forum['postcut']) {
// ?????"? ?,?u????, ?'?"??????<?1, ???+?E?u?.??u?? ? ?'??u?? ?????<?"??? ??? ?c???"???<?1 ?2??E?????,
switch ($set_forum['postcut']) {
case 2:
$cut = 5000;
break;

case 3:
$cut = 6000;
break;
default :
$cut = 7000;
}
}
if ($set_forum['postcut'] && mb_strlen($text) > $cut) {
                        $text = mb_substr($text, 0, $cut);
                        $text = functions::checkout($text, 1, 1);
                        $text = preg_replace('#\[c\](.*?)\[/c\]#si', '', $text);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 : 0);
                        echo bbcode::notags($text) . '...<br /><a href="index.php?act=post&amp;id=' . $res['id'] . '">' . $lng_forum['read_all'] . ' &gt;&gt;</a>';
   //echo '<div class="menu"><a href="komm.php?id=' . $res['id'] . '">Comments</a> ['.mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_komm` WHERE `ref`='" . $res['id'] ."';"),0).']</div>';
                    } else {
                        // ???, ???????????? ???? ? ??????? ???? ?????
                        $text = functions::checkout($text, 1, 1);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 : 0);
                                          $checkthank = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $res['id'] . '" and `user` = "' . $res['user_id'] . '"');
$thankcheck = mysql_result($checkthank, 0);
if($thankcheck < 1 && $user_id != $res['user_id']) {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '<div class="rmenu"><p align="center"><b>POST LOCKED</b><br>click thanks to Unlock content</p></div>', $text);
} else {
$text = preg_replace('#\[thank\](.*?)\[/thank\]#si', '\1', $text);
}
if (($start + $i) == 1){
echo $text . '<br/>';
include_once ('buzzcity.php');
//echo '<a href="'.$adscontent['link'].'">'.$adscontent['banner'].'</a>';
} else {
echo $text;
}
}


// ?????"? ?u???,?S ?c?E???E?u?c?"?u?????<?1 ?"??1?", ?2?<?2???'??? ?u?E?? ???c????????u
$freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] . "'");
if (mysql_num_rows($freq) > 0) {
$fres = mysql_fetch_assoc($freq);
$fls = round(@filesize('../files/forum/attach/' . $fres['filename']) / 1024, 2);
echo '<br/>';
//include('buzzcity.php');
echo '<div class="list1"><span class="gray">';

                                          $file_id = $fres['id'];
                                
                     if ($rights >= 1)
                        echo'<a href="index.php?act=xoafile&amp;id=' . $fres['id'] . '"><img src="'.$home.'/images/del.png">&nbsp;</a>';
                     if ($fls == 0) {
echo'<br/><span class="red">File has been deleted</span><br />';}
// ?o?E?u?'?c?E?????????,?E ??.???+?E????u????1
$att_ext = strtolower(functions::format('./files/forum/attach/' . $fres['filename']));
$pic_ext = array(
'gif',
'jpg',
'jpeg',
'png'
);
$req43=mysql_query("SELECT `postforum`, `id` FROM `users` WHERE (id='$user_id') ");
$arr56=mysql_fetch_array($req43);
$total_spent = 2;

                        if (in_array($att_ext, $pic_ext)) {
                            echo '<div><a href="index.php?act=file&amp;id=' . $fres['id'] . '">';
                            echo '<img src="thumbinal.php?file=' . (urlencode($fres['filename'])) . '" alt="' . $lng_forum['click_to_view'] . '" /></a></div>';
                        } else if (empty($user_id)){
                            echo '<a href="' . $homeurl .'/login.php">file.zip</a>';
                        }else if($total_spent < $arr56['postforum']){
                     echo '<a href="index.php?act=file&amp;id=' . $fres['id'] . '">' . ($fres['originalfilename'] ? $fres['originalfilename'] : $fres['filename']) . '</a>';
                  }
else echo "<span class='red'>Minimum 3 Post To Download this file</span>";
                        echo '&nbsp;' . $fls . ' Kb.';
                        echo '&nbsp;Download:' . $fres['dlcount'] . '</span></div>';}

  if ($res['kedit']) {
// ?????"? ?c?????, ?E?u?'???,??E???2??"???Z, ?c?????.?<?2??u?? ??u?? ? ????E?'?
echo '<br /><span class="gray" align="right"><small>' . $lng_forum['edited'] . ' <b>' . $res['edit'] . '</b> (' . functions::display_date($res['tedit']) . ') <b>[' . $res['kedit'] . ']</b></small></span>';
}
   
echo '</div>';
//Mod. Signature
if(!empty($res['podpis']))
echo '<div class="sub" align="right">&nbsp;' . functions::smileys(bbcode::tags($res['podpis'])) . '</div>'; 
$thongkethank = mysql_query("SELECT COUNT(*) from `forum_thank` where `topic`='" . $res["id"] . "'");
$thongkethanks = mysql_result($thongkethank, 0);
//$thongkethanks = mysql_result(mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `topic` = "' . $res['id'] . '"')), 0);
$thongkea = @mysql_query("select * from `forum_thank` where `topic` = '" . $res['id'] . "'");
$thongke = mysql_fetch_array($thongkea);
$idthongke = trim($_GET['idthongke']);
if($thongkethanks > 0 && empty($_GET['idthongke'])) {

echo'<div id="'.$idthongke.'" class="list2" style="font-size:x-small"><b>Thanks:</b> ';
$thongkeaa = @mysql_query("select * from `forum_thank` where `topic` = '" . $res['id'] . "'");
while($thongkea = mysql_fetch_array($thongkeaa)) {
{
/*
if ($dentv['rights'] == 0 ) {
$colornick['colornick'] = '000000';
}
if ($dentv['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
}
if ($dentv['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
}
if ($dentv['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
}
if ($dentv['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
}
if ($dentv['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
}
if ($dentv['rights'] == 6 ) {
$colornick['colornick'] = '228622';
}
if ($dentv['rights'] == 7 ) {
$colornick['colornick'] = '860086';
}
if ($dentv['rights'] == 8 ) {
$colornick['colornick'] = 'FF0000';
}
if ($dentv['rights'] == 9 ) {
$colornick['colornick'] = 'FF0000';
}
if ($dentv['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
}*/
$dentv = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$thongkea['userthank'].'"'));
echo '<a href="/users/'.$dentv['name'].'">'.functions::nickcolor($dentv['id']).'</a>, ';
}
++$f;
}
echo'</div>';
}
echo '<div class="forumb" align="right">'; //iki
echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
$checkthank = mysql_query('SELECT COUNT(*) FROM `forum_thank` WHERE `userthank` = "' . $user_id . '" and `topic` = "' . $res['id'] . '" and `user` = "' . $res['user_id'] . '"');
if ($user_id && $user_id != $res['user_id'] && (mysql_result($checkthank, 0) < 1)) {
echo '<a href="index.php?id=' . $id . '&amp;thanks=' . $res['id'] . '&amp;user=' . $res['user_id'] . '&amp;start=' . $start . '&amp;thank#thankyou"><img src="thanks.gif" width="55" height="16" alt="thanx"/></a>';
}
echo '</td><td width="auto" align="right">';
if ($user_id && $user_id != $res['user_id']) { echo '<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '"><img src="b.png" align="middle" style="border: none"/></a>';
echo '&nbsp<a href="index.php?act=say&amp;id=' . $res['id'] . '&amp;start=' . $start . '&amp;cyt"><img src="c.png" align="middle" style="border: none"/></a>';
}

echo '</td></tr></table></div></div>'; //iki
if ($res['user_id'] == $user_id || $rights >= 7){
// ????<?"?? ??? ?E?u?'???,??E???2?????u / ???'??"?u????u ?c?????,???2
$menu = array(

'<a href="index.php?act=addfile&amp;id=' . $res['id'] . '">Upload</a>',
'<a href="index.php?act=import&amp;id=' . $res['id'] . '">Import</a>',
'<a href="index.php?act=editpost&amp;id=' . $res['id'] . '">' . $lng['edit'] . '</a>',
($rights >= 7 && $res['close'] == 1 ? '<a href="index.php?act=editpost&amp;do=restore&amp;id=' . $res['id'] . '">' . $lng_forum['restore'] . '</a>' : ''),
($res['close'] == 1 ? '' : '<a href="index.php?act=editpost&amp;do=del&amp;id=' . $res['id'] . '">' . $lng['delete'] . '</a>')
);
echo '<div class="forumb" align="right">';
if ($rights == 3 || $rights >= 6)
echo '<input type="checkbox" name="delch[]" value="' . $res['id'] . '"/>&#160;';
echo functions::display_menu($menu);
if ($res['close']) {
echo '<div class="red">' . $lng_forum['who_delete_post'] . ': <b>' . $res['close_who'] . '</b></div>';
} elseif (!empty($res['close_who'])) {
echo '<div class="green">' . $lng_forum['who_restore_post'] . ': <b>' . $res['close_who'] . '</b></div>';
}
echo '</div>';
}
echo '</div></div>';
++$i;
}
if ($rights == 3 || $rights >= 6) {
echo '<div class="mainbox"><input type="submit" value=" ' . $lng['delete'] . ' "/></div>';
echo '</form></div>';
}
// ?2??????u?u ?c???"?u "?2??c?????,?S"
if (($type1['edit'] == 1 || $type1['close'] == 1) && $rights < 7) {
echo '<div class="mainbox"><div class="mainblok"><div class="rmenu">Topic has been closed.You cant add more post here.</div>';}else{
if ($user_id) {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter">Quick reply</div>';
echo '<div class="forumb"><form name="form2" action="index.php?act=say&amp;id=' . $id . '" method="post">';

echo '';
if (!$is_mobile)
echo bbcode::auto_bb('form2', 'msg');
echo '<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/>' .
'<p><input type="checkbox" name="addfiles" value="1" /> ' . $lng_forum['add_file'];
if ($set_user['translit'])
echo '<br /><input type="checkbox" name="msgtrans" value="1" /> ' . $lng['translit'];
echo '</p><p><input type="submit" name="submit" value="' . $lng['write'] . '" style="width: 100px; cursor: pointer;"/> ' .
($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 100px; cursor: pointer;"/>' : '') .
'</p></form></div>';
}}
echo '</div></div></div>';
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Share This Topic</b></div>';
echo '<div class="menu">';
echo '<b>BB Code:</b><br/><input type="text" size="18" value="[url='.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html]'.$type1["text"].'[/url]"/><br/><b>Link:</b><br/><input type="text" size="18" value="'.$home.'/forum/'.functions::gantiurl($type1["text"]).'_'.$id.'.html"/>';
include('share.php');
echo '</div></div></div>';
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a name="down" id="down"></a><a href="#up">' .
'<img src="../theme/' . $set_user['skin'] . '/images/up.png" alt="' . $lng['up'] . '" width="20" height="10" border="0"/></a>' .
'&#160;&#160;' . $lng['total'] . ': ' . $colmes . '</div>';
if ($colmes > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;', $start, $colmes, $kmess) . '</div>' .
'</div></div><div class="mainbox">' .
'<p><form action="index.php?id=' . $id . '" method="post">' .
'<input type="text" name="page" size="2"/>' .
'<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/>' .
'</form></p></div>';
} else {
echo '</div></div></div></div></div></div></div></div></div>';
}
/*
                -----------------------------------------------------------------
                i'?i'?i'?i'?i'?YOUOi'? i'?~Oi'? i'?^Oi'?OOOOi'?NOi'?i'?i'?i'?UOUOi'? i'?i'?i'?~OUOi'?UOi'?
                -----------------------------------------------------------------
                */
                if ($curators) {
                    $array = array();
                    foreach ($curators as $key => $value)
                        $array[] = '<a href="../users/profile.php?user=' . $key . '">' . $value . '</a>';
                    echo '<p><div class="func">' . $lng_forum['curators'] . ': ' . implode(', ', $array) . '</div></p>';
                }
                if ($rights == 3 || $rights >= 6) {
                    echo '<p><div class="mainbox"><div class="func">';
                    if ($rights >= 7)
                        echo '<a href="index.php?act=curators&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['curators_of_the_topic'] . '</a><br />';
                    echo isset($topic_vote) && $topic_vote > 0
                            ? '<a href="index.php?act=editvote&amp;id=' . $id . '">' . $lng_forum['edit_vote'] . '</a><br/><a href="index.php?act=delvote&amp;id=' . $id . '">' . $lng_forum['delete_vote'] . '</a><br/>'
                            : '<a href="index.php?act=addvote&amp;id=' . $id . '">' . $lng_forum['add_vote'] . '</a><br/>';
                    echo '<a href="index.php?act=ren&amp;id=' . $id . '">' . $lng_forum['topic_rename'] . '</a><br/>';
                    // i'?i'?i'?NOUOi'?i'?i'?i'? - i'?i'?i'?UOi'?i'?i'?i'? i'?i'?OO^Oi'?
                    if ($type1['edit'] == 1)
                        echo '<a href="index.php?act=close&amp;id=' . $id . '">' . $lng_forum['topic_open'] . '</a><br/>';
                    else
                        echo '<a href="index.php?act=close&amp;id=' . $id . '&amp;closed">' . $lng_forum['topic_close'] . '</a><br/>';
                    // i'?i'?i'?OONOYOUOi'?i'? - i'?OOi'?i'?i'?i'?NO~Oi'?OOUOi'?i'? i'?i'?OO^Oi'?
                    if ($type1['close'] == 1)
                        echo '<a href="index.php?act=restore&amp;id=' . $id . '">' . $lng_forum['topic_restore'] . '</a><br/>';
                    echo '<a href="index.php?act=deltema&amp;id=' . $id . '">' . $lng_forum['topic_delete'] . '</a><br/>';
                    if ($type1['vip'] == 1)
                        echo '<a href="index.php?act=vip&amp;id=' . $id . '">' . $lng_forum['topic_unfix'] . '</a>';
                    else
                        echo '<a href="index.php?act=vip&amp;id=' . $id . '&amp;vip">' . $lng_forum['topic_fix'] . '</a>';
                    echo '<br/><a href="index.php?act=per&amp;id=' . $id . '">' . $lng_forum['topic_move'] . '</a></div></p>';
                }
            echo '</div></div></div></div></div></div></div></div>';
         
/** Similar topic **/

$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `refid`='$type1[refid]' AND `id`!='$id' ORDER BY `vip` DESC, `time` DESC LIMIT 5");
$total = mysql_num_rows($req);
if($total!=0){
echo '<div class="mainbox"><div class="mainblok">';
echo '<div class="nfooter"><b>Similar topics</b></div><div>';
while ($res = mysql_fetch_assoc($req)) {
$tieude = $res['text'];
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';

if ($is_mobile){
echo '<img src="../images/1.gif" alt=""/>&nbsp;';}
if (!$is_mobile){
echo '<img src="../images/tick.gif" alt=""/>&nbsp;';}

if ($res['tiento'] ==1) {
echo'<b><font color="purple">Discusion:</font></b>';
} elseif ($res['tiento'] ==2) {
echo'<b><font color="red">Hot:</font></b>';
} elseif ($res['tiento'] ==3) {
echo'<b><font color="green">Notice:</font></b>';
} elseif ($res['tiento'] ==4) {
echo'<b><font color="red">Share:</font></b>';
} elseif ($res['tiento'] ==5) {
echo'<b><font color="green">Script:</font></b>';
} elseif ($res['tiento'] ==6) {
echo'<b><font color="blue">Help:</font></b>';
}
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html">' .bbcode::tags($tieude). '</a>';
echo '</div>';
++$i;}
echo'</div></div></div>';
}

if ($filter)
echo '</div></div></div><a href="index.php?act=filter&amp;id=' . $id . '&amp;do=unset">' . $lng_forum['filter_cancel'] . '</a></div>';
else
echo '</div></div></div></div><div class="mainbox"><div class="nfooter"><a href="index.php?act=filter&amp;id=' . $id . '&amp;start=' . $start . '">' . $lng_forum['filter_on_author'] . '&nbsp;l&nbsp;<a href="index.php?act=tema&amp;id=' . $id . '">' . $lng_forum['download_topic'] . '</a></div></div>';

break;

default:
                /*
                -----------------------------------------------------------------
                ??????? ????????? ????????, ???????????? ???????
                -----------------------------------------------------------------
                */
                echo functions::display_error($lng['error_wrong_data']);
                break;
        }
    } else {
        /*
        -----------------------------------------------------------------
        ????????? ???????????? ???????
        -----------------------------------------------------------------
        */
        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
        echo '<p>' . counters::forum_new(1) . '</p>' .
             '</div></div></div><div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $lng['forum'] . '</b></div>' .
             '<div class="topmenu"><a href="search.php">' . $lng['search'] . '</a> | <a href="index.php?act=files">' . $lng_forum['files_forum'] . '</a> <span class="red">(' . $count . ')</span></div>';
        $req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        while (($res = mysql_fetch_array($req)) !== false) {
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
            echo '<a href="' . ___($res['text']) . '_' . $res['id'] . '.html">' . $res['text'] . '</a> [' . $count . ']';
            if (!empty($res['soft']))
                echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';
            echo '</div>';
            ++$i;
        }
        $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        echo '<div class="nfooter">' . ($user_id ? '<a href="index.php?act=who">' . $lng_forum['who_in_forum'] . '</a>' : $lng_forum['who_in_forum']) . '&#160;(' . $online_u . '&#160;/&#160;' . $online_g . ')</div>';
        unset($_SESSION['fsort_id']);
        unset($_SESSION['fsort_users']);
    }

    // ???????????? ?????? ?????????
   // echo '<p>' . ($id ? '<a href="index.php">' . $lng['to_forum'] . '</a><br />' : '');
    if (!$id) {
        echo '</div></div></div><a href="../pages/faq.php?act=forum">' . $lng_forum['forum_rules'] . '</a><br/>';
        echo '<a href="index.php?act=moders">' . $lng['moders'] . '</a>';
    }
    echo '</p>';
    if (!$user_id) {
        if ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0)) {
            echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newup">' . $lng_forum['new_on_top'] . '</a>';
        } else {
            echo '<a href="index.php?id=' . $id . '&amp;page=' . $page . '&amp;newdown">' . $lng_forum['new_on_bottom'] . '</a>';
        }
    }
}
echo '</div>';
require_once('../incfiles/end.php');

?>
