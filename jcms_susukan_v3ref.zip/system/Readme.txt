Modul G-Manager
Author: [url=http://wapinet.ru/gmanager]Gemoroj[/url]
Translate: [url=http://kashur.tk]ton[/url]

[green]Deskripsi[/green]
[*] Memudahkan anda untuk akses ke File Manager tanpa harus ke CPanel
[*] Backup file mudah
[*] Backup MySQL
[*] Support CHMOD file/folder
[*] Upload/Import file
[*] Membuat arsip saat backup

[green]Instalasi[/green]
[*] Upload semua file ke direktori root situs anda [red](rename folder dengan nama rahasia anda)[/red]
[*] Edit file lib/Config.php edit bagian ini:

Set password saat akses folder
[code]public static $auth = array (
        'on'   => true,
        'pass' => 'password',
        'user' => 'username'
    );
[/code]
Koneksi ke File Manager:
[code]public static $ftp = array (
        'user' => 'root',
        'pass' => 'password',
        'host' => 'localhost',
        'port' => 21
    );
[/code]
Selesai,

//////////////////////////////////////
http://kashur.cz.cc
thanks for visit my site
/////////////////////////////////////