<?php

#-----------------------------------------------------------------
# Author by : RealDon
# Mod By : RealDon www.mtuner.tk
# Translate By : RealDon
#-----------------------------------------------------------------

define('_IN_JOHNCMS', 1);
define('_IN_JOHNADM', 1);
$textl = 'Page Editor';
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');
//------------------ete?e?ece?eze?ese~-----------------------//
$pass = 1; // 0- Off
$password = '223366'; //use [^a-z0-9_-]
$md5password = md5(md5($password));
$user_pass = trim($_GET['pass']);
//-----------------------------------------------//
if ($rights == 9)
{
    if ($pass == "NoPass")
    {


        if (isset($_POST['submit']))
        {
            $pass_form = trim($_POST['user_pass']);
            if (empty($pass_form) || eregi("[^a-z0-9_-]", $pass_form))
            {
                header("Location: realdon.php");
                exit;
            } else
            {
                $pass_form = md5(md5($pass_form));
                if ($pass_form == $md5password)
                {
                    header("Location: realdon.php?pass=" . $pass_form . "");
                    exit;
                } else
                {
                    header("Location: realdon.php");
                    exit;
                }
            }
        } else
        {
            echo '<div class="mainbox"><div class="mainblok"><div class="nfooter">Page Editor</div>';
            echo '<div class="menu"><form method="post" action="realdon.php?">';
            echo 'Only [^a-z0-9_-]<br/>';
            echo '<input type="password" name="user_pass"/><br />';

            echo '<input value="Login" name="submit" type="submit" /></form></div></div>';

        }

        require_once ("../incfiles/end.php");
        exit;

    }

    switch ($act)
    {
        case "add":
            //N?e?e.e'eze?e?eu N?N,NEeze?e?N?N<
            if (isset($_POST['submit']))
            {
                $file = trim($_POST['name']);
                $type = ($_POST['type'] == 'php' ? 'php' : 'txt');
                $error = array();
                if (empty($file))
                    $error[] = 'Dont insert';
                if (eregi("[^a-z0-9_-]", $file))
                    $error[] .= 'Name not filed';
                if (!$error)
                {
                    $file = $file . '.' . $type;

                    if (file_exists("../files/$file"))
                        $error[] = 'Name already created';
                }
                if (!$error)
                {
                    $allfile = fopen("../files/$file", "a+");
                    fclose($allfile);
                    chmod($allfile, 0666);
                    chmod("../files/$file", 0666);
                    header("location: realdon.php?act=edit&file=" . $_POST['name'] . "&type=" . $type . "&pass=" . $user_pass . "");
                    exit;

                } else
                {
                    echo functions::display_error($error, '<a href="realdon.php">' . $lng['back'] . '</a>');
                    echo '<div class="b"><a href="realdon.php?act=add&amp;pass='.$user_pass.'">Repeat</a></div>';
                }
            } else
            {
                $CHMOD = decoct(fileperms("../files")) % 1000;
                echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><strong>New file</strong></div>';
                echo '<div class="menu">To dir <strong><span style="color:#FF0000">' . $CHMOD . '</span></strong></div>';
                if (is_writeable("../files"))

                {
                    echo '<div class="gmenu"><strong>Dir its to create file</strong></div>';
                    echo '<div class="menu"><form method="post" action="realdon.php?act=add&amp;pass='.$user_pass.'">';
                    echo 'Alowed [A-z-_0-9]:<br />';
                    echo '<input type="text" name="name" maxlength="30" /><br />File Type';
                    echo ' <select name="type"><option value="txt">TXT</option><option value="php">PHP</option></select><br/>';
                    echo '<input value="Submit" name="submit" type="submit" /></form></div>';


                } else
                {
                    echo '<div class="gmenu"><strong>Not found directory<br />please chmod files to (777)</strong></div></div>';
                }
                echo '<div class="nfooter"><a href="realdon.php?pass=' . $user_pass . '">Back</a></div><div class="list1">RealDon 2013</div></div>';


            }


            break;
        case "edit":
            // e?eue'ezezN,e?NEe?e2eze?e?eu N"eze1e"ez
            $file = trim($_GET['file']);
            $type = ($_GET['type'] == 'php' ? 'php' : 'txt');
            $error = array();
            if (empty($file))
                $error[] = 'No file selected';
            if (eregi("[^a-z0-9_-]", $file))
                $error[] .= 'char not alowed';
            if (!$error)
            {
                $file = $file . '.' . $type;

                if (!file_exists("../files/$file"))
                    $error[] = 'File not found';
            }
            if (!$error)
            {
                echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>File ' . $file . '</b></div>';
                if (isset($_GET['yes']))
                    echo '<div class="rmenu">File its saved</div>';
                $CHMOD = decoct(fileperms("../files/$file")) % 1000;
                echo '<div class="gmenu"><strong>Permission ' . $CHMOD . '</strong></div>';
                if (is_writeable("../files/$file"))
                {

                    if (isset($_POST['submit']))
                    {
                        $text = trim($_POST['text']);
                        $edit_file = fopen("../files/$file", "a+");
                        flock($edit_file, LOCK_EX);
                        ftruncate($edit_file, 0);
                        fputs($edit_file, $text);
                        fflush($edit_file);
                        flock($edit_file, LOCK_UN);
                        fclose($edit_file);
                        header("location: realdon.php?act=edit&file=" . trim($_GET['file']) . "&type=" . $type . "&pass=" . $user_pass . "&yes");
                        exit;

                    } else
                    {
                        echo '<div class="rmenu"><strong>File created</strong></div>';
                        $open_file = file_get_contents("../files/$file");
                        header("Content-type:text/html; charset=utf-8");

                        echo '<div class="menu"><form action="realdon.php?act=edit&amp;file=' . trim($_GET['file']) . '&type=' . $type .  '&amp;pass='.$user_pass.'" name="form" method="POST">';
                        if (empty($open_file) && $type == 'php')
                            $open_file = "<? \r\n defined('_IN_JOHNCMS') or die('Error:restricted access');\r\n\r\n\r\n###Mod By Aan Gabriel\r\n?>";
                        echo '<textarea style="width:70%;height: 200px;" name="text">' . htmlentities($open_file, ENT_QUOTES, 'UTF-8');
                        echo '</textarea><br />';
                        echo "<script language=\"JavaScript\" type=\"text/javascript\">
              function tag(text1, text2) {
     if ((document.selection)) {
       document.form.text.focus();
       document.form.document.selection.createRange().text = text1+document.form.document.selection.createRange().text+text2;
     } else if(document.forms['form'].elements['text'].selectionStart != undefined) {
         var element    = document.forms['form'].elements['text'];
         var str     = element.value;
         var start    = element.selectionStart;
         var length    = element.selectionEnd - element.selectionStart;
         element.value = str.substr(0, start) + text1 + str.substr(start, length) + text2 + str.substr(start + length);
     } else document.form.text.value += text1+text2;
  }
</script>";
                        echo '</div><div class="b">';
                        echo '<a href="#" onClick="javascript:tag(\'<a href=&quot;&quot;>\', \'</a>\');"><img src="../images/editor/a.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<img src=&quot;\', \'&quot; alt=&quot;&quot;\/>\');"><img src="../images/editor/img.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'&lt;br \/&gt;\', \'\');"><img src="../images/editor/br.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'&lt;hr \/&gt;\', \'\');"><img src="../images/editor/hr.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<b>\', \'</b>\');"><img src="../images/editor/b.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<big>\', \'</big>\');"><img src="../images/editor/big.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<small>\', \'</small>\');"><img src="../images/editor/small.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<i>\', \'</i>\');"><img src="../images/editor/i.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<u>\', \'</u>\');"><img src="../images/editor/u.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<div align=&quot;right&quot;>\', \'</div>\');"><img src="../images/editor/right.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<div align=&quot;center&quot;>\', \'</div>\');"><img src="../images/editor/center.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<div align=&quot;left&quot;>\', \'</div>\');"><img src="../images/editor/left.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<span style=&quot;color:blue&quot;>\', \'</span>\');"><img src="../images/editor/blue.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<span style=&quot;color:red&quot;>\', \'</span>\');"><img src="../images/editor/red.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<span style=&quot;color:yellow&quot;>\', \'</span>\');"><img src="../images/editor/yellow.gif" alt=""/></a>';
                        echo '<a href="#" onClick="javascript:tag(\'<span style=&quot;color:green&quot;>\', \'</span>\');"><img src="../images/editor/green.gif" alt=""/></a>';
                        echo '</div><div class="menu"><input value="Create" name="submit" type="submit" /></div></form>';
                    }

                } else
                {
                    echo '<div class="gmenu"><strong>File not created<br />Please set to (666)</strong></div>';
                }
                echo '<div class="b"><a href="realdon.php?pass=' . $user_pass . '">Back</a></div><div class="list1">RealDon 2013</div></div>';
            } else
            {
                    echo functions::display_error($error, '<a href="realdon.php">' . $lng['back'] . '</a>');
                echo '<div class="b"><a href="realdon.php?pass=' . $user_pass . '">Back</a></div></div>';
            }


            break;
        case "code":
            //e'NEe?N?e?e?N,NE eze?e'ez
            $file = trim($_GET['file']);
            $type = ($_GET['type'] == 'php' ? 'php' : 'txt');
            $error = array();
            if (empty($file))
                $error[] = 'No File selected!';
            if (eregi("[^a-z0-9_-]", $file))
                $error[] .= 'Char not alowed';
            if (!$error)
            {
                $file = $file . '.' . $type;

                if (!file_exists("../files/$file"))
                    $error[] = 'File not found';
            }
            if (!$error)
            {
                $open_file = file_get_contents("../files/$file");
                $count = count($open_file);
                echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>File ' . $file . '</b></div>';
                echo '<div class="gmenu">Lines ' . abs(intval($count)) . '</div><div class="menu">';
                $php = trim($open_file);
                if ($type == 'php' && empty($php))
                    $php = "<? \r\n defined('_IN_JOHNCMS') or die('Error:restricted access');\r\n\r\n\r\n##Mod RealDon\r\n?>";
                elseif ($type == 'txt')
                    $php = "<?\necho'" . $php . "';\n?>";
                $php = str_replace('\\', 'slash_O5WERU_slash', $php);
                $php = highlight_string(stripslashes($php), true);
                $php = strtr($php, array('slash_O5WERU_slash' => '&#92;', '&nbsp;' => ' '));
                echo $php;
                echo '</div><div class="b"><a href="realdon.php?type=' . $type . '&amp;pass=' . $user_pass . '">Back</a></div><div class="list1">RealDon 2013</div>';
            } else
            {
                    echo functions::display_error($error, '<a href="realdon.php">' . $lng['back'] . '</a>');
                echo '<div class="b"><a href="realdon.php?pass=' . $user_pass . '">Back</a></div>';
            }


            break;
        case "del":
            //N?e'eze"eue?e?eu N"eze1e"ez
            $file = trim($_GET['file']);
            $type = ($_GET['type'] == 'php' ? 'php' : 'txt');
            $error = array();
            if (empty($file) || $file == 'menu')
                $error[] = 'No File Selected!';
            if (eregi("[^a-z0-9_-]", $file))
                $error[] .= 'Chart not alowed!';
            if (!$error)
            {
                $file = $file . '.' . $type;

                if (!file_exists("../files/$file"))
                    $error[] = 'File not found!';
            }
            if (!$error)
            {
                if (isset($_GET['yes']))
                {
                    unlink("../files/$file");

                    header("location: realdon.php?type=" . $type . "&pass=" . $user_pass . "");
                } else
                {
                    echo 'Are you sure you want to delete <strong>' . $file . '</strong><br/><a href="realdon.php?act=del&amp;file=' . trim($_GET['file']) . '&amp;type=' . $type . '&amp;pass=' . $user_pass . '&amp;yes">Yes</a> &raquo; <a href="realdon.php?type=' . $type . '&amp;pass=' . $user_pass . '">No and back</a>';
                }


            } else
            {
                    echo functions::display_error($error, '<a href="realdon.php">' . $lng['back'] . '</a>');
                echo '<div class="b"><a href="realdon.php?">Back</a></div>';
            }


            break;

        default:
            //N?e'e?N?e?ez N"eze1e"e?e2
            $type = ($_GET['type'] == 'php' ? 'php' : 'txt');
            echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Page Editing</b></div>';
            echo '<div class="gmenu">List page</div>';
            echo '<div class="rmenu">Type: ' . ($type == 'php' ? '<strong>PHP</strong> &raquo; <a href="realdon.php?type=txt&amp;pass='.$user_pass.'">TXT</a>' : '<a href="realdon.php?type=php&amp;pass='.$user_pass.'">PHP</a> &raquo; <strong>TXT</strong>') . '</div>';
            $array = glob($rootpath . 'files/*.' . $type);
            $total = count($array);
            $total = count($array);
            if ($total > 0)
            {
                $end = $start + $kmess;
                if ($end > $total)
                    $end = $total;
                for ($i = $start; $i < $end; $i++)
                {
                    $file = preg_replace('#^' . $rootpath . 'files/(.*?).' . $type . '$#isU', '$1', $array[$i], 1);
                    echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
                    echo $file == 'menu' ? '<strong>' . $file . '</strong>' : '<a href="../pages/pages.php?page=' . $file . '&amp;type=' . $type . '"><strong>' . $file . '</strong></a>';
                    //echo '<br /><small>Mod: ' . date("d.m.y e2 H:s", filemtime("../files/$file.txt")) . '<br />';
                    echo '<br/><a href="realdon.php?act=edit&amp;file=' . $file . '&amp;type=' . $type .  '&amp;pass='.$user_pass.'">Edit</a> &raquo; <a href="realdon.php?act=code&amp;file=' . $file . '&amp;pass='.$user_pass.'&amp;type=' . $type . '">Code</a>';
                    if ($file != 'menu')
                        echo ' &raquo; <a href="realdon.php?act=del&amp;file=' . $file . '&amp;type=' . $typ . '&amp;pass='.$user_pass.'">Delete</a>';
                    echo '</small></div>';
                }
            } else
            {
                echo 'File empty<br/>';
            }
            echo '<div class="nfooter">Total: ' . $total . '</div></div>';

            if ($total > $kmess)
            {
                echo '<p>' . pagenav('realdon.php?type=' . $type . '&amp;pass='.$user_pass.'&amp;', $start, $total, $kmess) . '</p>';
                echo '<p><form action="realdon.php" method="get"><input type="hidden" name="type" value="' . $type . '"/><input type="hidden" name="pass" value="' . $user_pass . '"/><input type="text" name="page" size="2"/><input type="submit" value="go &gt;&gt;"/></form></p>';
            }
            echo '<a href="realdon.php?act=add&amp;pass='.$user_pass.'">Create page</a><br />';
            echo '<a href="../panel/">admin</a>';


    }
} else
{
    header("Location: ../index.php?err");
}

require_once ("../incfiles/end.php");

?>