<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Blogs - Edit Blog';
require('../incfiles/head.php');
$empty = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs` WHERE id='$id'"), 0);
if ($empty == 0) {
echo functions::display_error('None of the selected blog
!');
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array(mysql_query("SELECT * FROM `blogs` WHERE id='$id'"));
if ($rights <= 6) {
if ($blog['user'] != $user_id) {
echo functions::display_error('Ты никто и звать тебя никаг, гггг!');
require('../incfiles/end.php');
exit;
}
}
if (isset($_GET['del'])) {
mysql_query("DELETE FROM `blogs` WHERE id='$id'");
mysql_query("DELETE FROM `blogs_komm` WHERE refid='$id'");
mysql_query("DELETE FROM `zakl` WHERE id_place='$id' AND type='b'");
header ('Location: user.php?id='.$blog['user'].'');
}
echo '<div class="phdr">'.$textl.'</div>';
if (isset($_POST['submit'])) {
if ($rights <= 6) {
if ($blog['user'] != $user_id) {
echo functions::display_error('repeat!<br />Youre no one to call you nikag, yyyy!');
require('../incfiles/end.php');
exit;
}
}
$name = isset($_POST['name_blog']) ? trim($_POST['name_blog']) : '';
$text = isset($_POST['text_blog']) ? trim($_POST['text_blog']) : '';
$close = isset($_POST['close']) ? trim($_POST['close']) : '';
if (empty($text) || empty($name))
$error .= 'You have not inserted the title or text';
if (mb_strlen($name) >= 101)
$error .= '' . (empty($text) || empty($name) >= 101 ? '<br/>' : '') . 'The name of the blog should not be greater than 100 characters, you '.mb_strlen($name).'!';
if (mb_strlen($text) >= 100000)
$error .= '' . (mb_strlen($name) >= 100001 ? '<br/>' : '') . 'The text of the blog should not be more than 100000 characters '.mb_strlen($text).'!';
echo '<div class="rmenu">'.$error.'</div>';
if (empty($error)) {
mysql_query("UPDATE `blogs` SET name='$name', text='" . mysql_real_escape_string($text) . "', close='$close' WHERE id='$id'");
header('Location: view.php?id='.$id.'');
}
}
echo '<form action="edit.php?id='.$id.'" name="form1" method="POST"><div class="gmenu"><h3>Title:</h3><input name="name_blog" value="'.$blog['name'].'" /><br /><br /><h3>Text:</h3><textarea cols="'.$set_user['field_w'].'" rows="'.$set_user['field_h'].'" name="text_blog">' . htmlentities($blog['text'], ENT_QUOTES, 'UTF-8') . '</textarea><br /><input type="checkbox" name="close" value="1" '.($blog['close'] == 1 ? 'checked="ckecked"' : '').' /> disable comments<br /><input type="submit" name="submit" value="Edit"/></div></form>';
echo '<div class="rmenu"><a href="edit.php?id='.$id.'&amp;del">Delete Blog</a></div>';
echo '<div class="menu"><a href="view.php?id='.$id.'">Back</a></div>';
require('../incfiles/end.php');
?>
