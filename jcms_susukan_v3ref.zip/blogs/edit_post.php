<?php
/*
Blog johnCMS 4.x.x, Test Ok for johnCMS 430
Modified by wsid.co.de
Email: wsid.co.de@gmail.com
*/
define('_IN_JOHNCMS', 1);
$headmod = 'blogs';
require('../incfiles/core.php');
$textl = 'Blogs - Edit Komentar';
require('../incfiles/head.php');
$empty = mysql_result(mysql_query("SELECT COUNT(*) FROM `blogs_komm` WHERE id='$id'"), 0);
if ($empty == 0) {
echo functions::display_error('Тidak ada komentar yang dipilih!');
require('../incfiles/end.php');
exit;
}
$komm = mysql_fetch_array(mysql_query("SELECT * FROM `blogs_komm` WHERE id='$id'"));
$blog = mysql_fetch_array(mysql_query("SELECT * FROM `blogs` WHERE id='$komm[refid]'"));
if ($rights <= 6) {
if ($komm['user'] != $user_id) {
echo functions::display_error('Ты никто и звать тебя никаг, гггг!');
require('../incfiles/end.php');
exit;
}
}
if ($rights <= 6) {
if ($komm['time'] < $realtime - 300) {
echo functions::display_error('Время отведённое на редактирование поста вышло!');
require('../incfiles/end.php');
exit;
}
}
if (isset($_GET['del'])) {
mysql_query("DELETE FROM `blogs_komm` WHERE `id` = '$id'");
header ('Location: view.php?id='.$komm['refid'].'');
}
else {
echo '<div class="phdr">'.$textl.'</div>';
if (isset($_POST['submit'])) {
if ($rights <= 6) {
if ($blog['user'] != $user_id) {
echo functions::display_error('Ты никто и звать тебя никаг, гггг!');
require('../incfiles/end.php');
exit;
}
}
if ($empty == 0) {
echo functions::display_error('Такого комментария не существует!');
require('../incfiles/end.php');
exit;
}
$text = isset($_POST['text']) ? trim($_POST['text']) : '';
if (empty($text))
$error .= 'All fields are required!';
if (mb_strlen($text) >= 2000)
$error .= '' . (mb_strlen($name) >= 2001 ? '<br/>' : '') . 'The text of the blog should not be greater than 2000 characters '.mb_strlen($text).'!';
echo '<div class="rmenu">'.$error.'</div>';
if (empty($error)) {
mysql_query("UPDATE `blogs_komm` SET text='" . mysql_real_escape_string($text) . "' WHERE id='$id'");
header('Location: view.php?id='.$komm['refid'].'');
}
}
echo '<form action="edit_post.php?id='.$komm['id'].'" name="form1" method="POST"><div class="gmenu"><h3>Teks:</h3>'.(!$is_mobile ? functions::auto_bb('form1', 'text_blog') : '').'<textarea cols="'.$set_user['field_w'].'" rows="'.$set_user['field_h'].'" name="text">' . htmlentities($komm['text'], ENT_QUOTES, 'UTF-8') . '</textarea><br /><input type="submit" name="submit" value="Edit Komentar"/></div></form>';
echo '<div class="menu"><a href="user.php">Blog Saya</a></div>';
}
require('../incfiles/end.php');
?>
