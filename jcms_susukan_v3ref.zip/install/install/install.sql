-- 
-- Table structure for table `apply_staff`
-- 

CREATE TABLE `apply_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `apply_staff`
-- 

INSERT INTO `apply_staff` VALUES ('3','Apply as Administrator','anu ya mbah','2','0','1','1387887732');
INSERT INTO `apply_staff` VALUES ('4','Apply as Forum Moderator','bro','4','0','1','1388412359');

-- --------------------------------------------------------
-- 
-- Table structure for table `blogs`
-- 

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` text NOT NULL,
  `text` text NOT NULL,
  `time` int(11) NOT NULL,
  `count` int(10) NOT NULL,
  `close` int(3) NOT NULL,
  `file` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`user`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `blogs`
-- 

INSERT INTO `blogs` VALUES ('7','1','PerfCMS Perf-Engine.net','Cara installasi\r\nAtur pada folder2 di bawah ini ke (CHMOD) 777 semuanya yak: \r\n../cache\r\n../cache/downloads_images\r\n../cache/downloads_jad\r\n../cache/albums/thumbs\r\n../files\r\n../files/albums\r\n../files/avatars\r\n../files/forum\r\n../files/downloads\r\n../files/downloads_screens\r\n../system/ini\r\n../tmp','1388451666','0','0','');

-- --------------------------------------------------------
-- 
-- Table structure for table `blogs_komm`
-- 

CREATE TABLE `blogs_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` text NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`user`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `bot`
-- 

CREATE TABLE `bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `key` varchar(100) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `txt1` varchar(500) NOT NULL,
  `txt2` varchar(500) NOT NULL,
  `txt3` varchar(500) NOT NULL,
  `txt4` varchar(500) NOT NULL,
  `txt5` varchar(500) NOT NULL,
  `time` int(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_bot`
-- 

CREATE TABLE `chat_bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tip` int(3) NOT NULL,
  `mass_bot` text NOT NULL,
  `mass_author` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_bot`
-- 

INSERT INTO `chat_bot` VALUES ('1','Chodot','4','a:18:{s:6:"status";s:18:"Waper banjarnegara";s:3:"sex";s:1:"m";s:2:"av";s:6:"Chodot";s:8:"time_off";i:5;s:6:"vopros";s:6:"Chodot";s:7:"time_on";i:0;s:6:"time_1";i:60;s:6:"time_2";i:0;s:7:"nev_vop";s:36:"Selamat datang dan selamat bergabung";s:6:"pods_1";s:36:"Selamat datang dan selamat bergabung";s:6:"pods_2";s:0:"";s:6:"no_otv";s:36:"Selamat datang dan selamat bergabung";s:5:"otv_0";s:0:"";s:5:"otv_1";s:0:"";s:5:"otv_2";s:0:"";s:8:"pods_0_n";i:0;s:8:"pods_1_n";i:0;s:8:"pods_2_n";i:0;}','a:6:{s:6:"author";s:5:"admin";s:12:"author_email";s:16:"admin@susukan.us";s:10:"author_url";s:23:"http://test.indoboox.us";s:11:"description";s:26:"Hanya seorang waper newbie";s:7:"version";s:1:"1";s:3:"iso";s:2:"en";}');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_room_1`
-- 

CREATE TABLE `chat_room_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_u` int(11) NOT NULL,
  `id_s` int(11) NOT NULL,
  `id_bot` int(11) NOT NULL,
  `time` int(15) NOT NULL,
  `text` text NOT NULL,
  `author` text NOT NULL,
  `tip` int(1) NOT NULL,
  `pas` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_room_1`
-- 

INSERT INTO `chat_room_1` VALUES ('8','1','0','1','1388414790','Selamat datang dan selamat bergabung','a:10:{s:2:"av";s:6:"Chodot";s:3:"sex";s:1:"m";s:6:"status";s:18:"Waper banjarnegara";s:4:"name";s:6:"Chodot";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','8','');
INSERT INTO `chat_room_1` VALUES ('9','1','0','1','1388465590','Selamat datang dan selamat bergabung','a:10:{s:2:"av";s:6:"Chodot";s:3:"sex";s:1:"m";s:6:"status";s:18:"Waper banjarnegara";s:4:"name";s:6:"Chodot";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','9','');
INSERT INTO `chat_room_1` VALUES ('10','0','0','2','1388465588','Mobile wap forum Susukan.Us - [ID]','a:10:{s:2:"av";s:0:"";s:3:"sex";s:1:"m";s:6:"status";s:0:"";s:4:"name";s:8:"Informer";s:11:"name_delete";s:0:"";s:4:"cvet";s:0:"";s:6:"cvet_n";s:0:"";s:2:"ip";s:10:"2130706433";s:4:"soft";s:7:"k_2_bot";s:6:"rights";i:0;}','2','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_rooms`
-- 

CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `op` varchar(500) NOT NULL,
  `tip` varchar(3) NOT NULL,
  `bot` text NOT NULL,
  `nev` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_rooms`
-- 

INSERT INTO `chat_rooms` VALUES ('1','Susukan.Us - [ID]','Mobile wap forum','','a:1:{i:0;i:1;}','Mobile wap forum Susukan.Us - [ID]');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_settings`
-- 

CREATE TABLE `chat_settings` (
  `key` tinytext NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`key`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_settings`
-- 

INSERT INTO `chat_settings` VALUES ('access','1');
INSERT INTO `chat_settings` VALUES ('balls','0');
INSERT INTO `chat_settings` VALUES ('color_nik','0');
INSERT INTO `chat_settings` VALUES ('color_nik_text','0');
INSERT INTO `chat_settings` VALUES ('color_text','0');
INSERT INTO `chat_settings` VALUES ('auto_delete','0');
INSERT INTO `chat_settings` VALUES ('faq','1');
INSERT INTO `chat_settings` VALUES ('time','0');
INSERT INTO `chat_settings` VALUES ('leave_post','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_users`
-- 

CREATE TABLE `chat_users` (
  `id_u` int(11) NOT NULL,
  `ban_naz_time` int(11) NOT NULL,
  `ban_time` int(11) NOT NULL,
  `ban_text` text NOT NULL,
  `postchat` int(10) NOT NULL DEFAULT '0',
  `otvetov` int(11) NOT NULL DEFAULT '0',
  `rights` tinyint(1) NOT NULL DEFAULT '0',
  `balans` int(11) NOT NULL DEFAULT '0',
  `set_chat` text NOT NULL,
  PRIMARY KEY (`id_u`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `chat_users`
-- 

INSERT INTO `chat_users` VALUES ('3','0','0','','0','0','0','0','');
INSERT INTO `chat_users` VALUES ('4','0','0','','2','0','0','0','');
INSERT INTO `chat_users` VALUES ('1','0','0','','0','0','0','0','');

-- --------------------------------------------------------
-- 
-- Table structure for table `chat_vop`
-- 

CREATE TABLE `chat_vop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `vopros` text NOT NULL,
  `otvet` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bot` (`id_bot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ads`
-- 

CREATE TABLE `cms_ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(2) NOT NULL,
  `view` int(2) NOT NULL,
  `layout` int(2) NOT NULL,
  `count` int(11) NOT NULL,
  `count_link` int(11) NOT NULL,
  `name` text NOT NULL,
  `link` text NOT NULL,
  `to` int(10) NOT NULL DEFAULT '0',
  `color` varchar(10) NOT NULL,
  `time` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `mesto` int(2) NOT NULL,
  `bold` tinyint(1) NOT NULL DEFAULT '0',
  `italic` tinyint(1) NOT NULL DEFAULT '0',
  `underline` tinyint(1) NOT NULL DEFAULT '0',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_cat`
-- 

CREATE TABLE `cms_album_cat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `name` varchar(40) NOT NULL,
  `description` text NOT NULL,
  `password` varchar(20) NOT NULL,
  `access` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `access` (`access`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_comments`
-- 

CREATE TABLE `cms_album_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  `attributes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_downloads`
-- 

CREATE TABLE `cms_album_downloads` (
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_files`
-- 

CREATE TABLE `cms_album_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `album_id` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `img_name` varchar(100) NOT NULL,
  `tmb_name` varchar(100) NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `comments` tinyint(1) NOT NULL DEFAULT '1',
  `comm_count` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vote_plus` int(11) NOT NULL,
  `vote_minus` int(11) NOT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `unread_comments` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `album_id` (`album_id`),
  KEY `access` (`access`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_views`
-- 

CREATE TABLE `cms_album_views` (
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_album_votes`
-- 

CREATE TABLE `cms_album_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `vote` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `file_id` (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ban_ip`
-- 

CREATE TABLE `cms_ban_ip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip1` bigint(11) NOT NULL DEFAULT '0',
  `ip2` bigint(11) NOT NULL DEFAULT '0',
  `ban_type` tinyint(4) NOT NULL DEFAULT '0',
  `link` varchar(100) NOT NULL,
  `who` varchar(25) NOT NULL,
  `reason` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip1` (`ip1`),
  UNIQUE KEY `ip2` (`ip2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_ban_users`
-- 

CREATE TABLE `cms_ban_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `ban_time` int(11) NOT NULL DEFAULT '0',
  `ban_while` int(11) NOT NULL DEFAULT '0',
  `ban_type` tinyint(4) NOT NULL DEFAULT '1',
  `ban_who` varchar(30) NOT NULL DEFAULT '',
  `ban_ref` int(11) NOT NULL DEFAULT '0',
  `ban_reason` text NOT NULL,
  `ban_raz` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ban_time` (`ban_time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_contact`
-- 

CREATE TABLE `cms_contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `from_id` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `friends` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ban` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `man` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`user_id`,`from_id`),
  KEY `time` (`time`),
  KEY `ban` (`ban`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_contact`
-- 

INSERT INTO `cms_contact` VALUES ('24','2','1','1388465372','1','0','0','1');
INSERT INTO `cms_contact` VALUES ('23','1','2','1387883792','1','0','0','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_counters`
-- 

CREATE TABLE `cms_counters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) NOT NULL DEFAULT '1',
  `name` varchar(30) NOT NULL,
  `link1` text NOT NULL,
  `link2` text NOT NULL,
  `mode` tinyint(4) NOT NULL DEFAULT '1',
  `switch` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_files`
-- 

CREATE TABLE `cms_forum_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat` int(10) NOT NULL,
  `subcat` int(10) NOT NULL,
  `topic` int(10) NOT NULL,
  `post` int(10) NOT NULL,
  `time` int(11) NOT NULL,
  `filename` text NOT NULL,
  `filetype` tinyint(4) NOT NULL,
  `dlcount` int(10) NOT NULL,
  `del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `subcat` (`subcat`),
  KEY `topic` (`topic`),
  KEY `post` (`post`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_rdm`
-- 

CREATE TABLE `cms_forum_rdm` (
  `topic_id` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`,`user_id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_forum_rdm`
-- 

INSERT INTO `cms_forum_rdm` VALUES ('134','2','1387974788');
INSERT INTO `cms_forum_rdm` VALUES ('136','2','1387975103');
INSERT INTO `cms_forum_rdm` VALUES ('136','1','1388450289');
INSERT INTO `cms_forum_rdm` VALUES ('134','1','1387974900');
INSERT INTO `cms_forum_rdm` VALUES ('136','3','1388413344');
INSERT INTO `cms_forum_rdm` VALUES ('163','1','1388451407');
INSERT INTO `cms_forum_rdm` VALUES ('163','2','1388453910');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_vote`
-- 

CREATE TABLE `cms_forum_vote` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(2) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_forum_vote_users`
-- 

CREATE TABLE `cms_forum_vote_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_mail`
-- 

CREATE TABLE `cms_mail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `from_id` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `delete` int(10) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(100) NOT NULL DEFAULT '',
  `count` int(10) NOT NULL DEFAULT '0',
  `size` int(10) NOT NULL DEFAULT '0',
  `them` varchar(100) NOT NULL DEFAULT '',
  `spam` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `from_id` (`from_id`),
  KEY `time` (`time`),
  KEY `read` (`read`),
  KEY `sys` (`sys`),
  KEY `delete` (`delete`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_online`
-- 

CREATE TABLE `cms_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_online`
-- 

INSERT INTO `cms_online` VALUES ('1','user','2','admin, BOT','1362973309');
INSERT INTO `cms_online` VALUES ('2','guest','0','@','1362973309');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_sessions`
-- 

CREATE TABLE `cms_sessions` (
  `session_id` char(32) NOT NULL DEFAULT '',
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sestime` int(10) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `movings` smallint(5) unsigned NOT NULL DEFAULT '0',
  `place` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `lastdate` (`lastdate`),
  KEY `place` (`place`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_sessions`
-- 

INSERT INTO `cms_sessions` VALUES ('4df77af0fb2565b07cbcfe7be384bd61','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10','1388387121','1388387121','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('fc83b9cd913178ab5ba32ecc9d64205c','1123633996','0','SAMSUNG-SGH-E250/1.0 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Browser/6.2.3.3.c.1.101 (GUI) MMP/2.0 (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)','1388388157','1388388157','0','0','forum,5');
INSERT INTO `cms_sessions` VALUES ('7e71622956e3989d0f2e158892ca4f47','2499479589','0','Mozilla/5.0 (compatible; MJ12bot/v1.4.4; http://www.majestic12.co.uk/bot.php?+)','1388390039','1388389814','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('59f58dea41b3f45a853e81a2fe1d96bb','2918992247','0','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','1388402415','1388402415','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('438d8e3a820eb0728b8d87b56bae276f','1893154661','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10','1388402722','1388402432','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('d18a22b8104af5097a2aa7601fe53e3f','3081481767','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/34.818; U; id) Presto/2.8.119 Version/11.10','1388402481','1388402481','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('43b998f0a614ed294eab6f41da35d302','3054407561','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.5.33867/34.818; U; id) Presto/2.8.119 Version/11.10','1388402593','1388402593','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('785890cf0a307834c1d627628066e8a6','1893149733','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.1.11355/34.818; U; en) Presto/2.8.119 Version/11.10','1388402936','1388402936','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('616c5cbfc8442800865a20b9682c33a6','1123634092','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1388405665','1388405665','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('9d89a762f8105f87ec4436472e82cb10','1893154682','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10','1388406153','1388405912','0','1','');
INSERT INTO `cms_sessions` VALUES ('cf1c260634557c31f02d7f21f2535bb6','1123634105','0','SAMSUNG-SGH-E250/1.0 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Browser/6.2.3.3.c.1.101 (GUI) MMP/2.0 (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)','1388413174','1388412893','0','31','admlist');
INSERT INTO `cms_sessions` VALUES ('6aa7a4852fa64da2b5e0759b7dc1a091','3000686675','0','Mozilla/4.0 (compatible; MSIE 7.0b; Win32)','1388412906','1388412906','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('0e441bc3b6a408bd29a27a21e9b9db77','1123634150','0','SAMSUNG-SGH-E250/1.0 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Browser/6.2.3.3.c.1.101 (GUI) MMP/2.0 (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)','1388413331','1388413331','0','0','error404');
INSERT INTO `cms_sessions` VALUES ('0ce783fcf29b6c4d584e7bcfbd75a92a','1123634150','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1388413479','1388413479','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('63fb28716104883d68fe2f146647e880','1123634105','0','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','1388414562','1388414562','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('35bf401b30b3bd2235433dd6fa5c4884','1123634105','0','DoCoMo/2.0 N905i(c100;TB;W24H16) (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)','1388414909','1388414909','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('bf64dca3efe88fe4f32b2f042d0aa751','1123634150','0','DoCoMo/2.0 N905i(c100;TB;W24H16) (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)','1388415529','1388415520','0','2','forum,134');
INSERT INTO `cms_sessions` VALUES ('4bca6178bc4e8118dca658b42cd9a32c','1893154838','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10','1388420708','1388420708','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('2e000444eef7426e3d95a9646c6ef25b','1893154838','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/34.818; U; en) Presto/2.8.119 Version/11.10','1388421576','1388421576','0','0','mainpage');
INSERT INTO `cms_sessions` VALUES ('312e07624f1df74458945f599887622f','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/34.818; U; en) Presto/2.8.119 Version/11.10','1388452074','1388451775','0','0','mainpage');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_settings`
-- 

CREATE TABLE `cms_settings` (
  `key` tinytext NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`key`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_settings`
-- 

INSERT INTO `cms_settings` VALUES ('active','1');
INSERT INTO `cms_settings` VALUES ('admp','panel');
INSERT INTO `cms_settings` VALUES ('antiflood','a:5:{s:4:"mode";i:2;s:3:"day";i:10;s:5:"night";i:30;s:7:"dayfrom";i:10;s:5:"dayto";i:22;}');
INSERT INTO `cms_settings` VALUES ('clean_time','1388464216');
INSERT INTO `cms_settings` VALUES ('copyright','Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('email','susukan.net@gmail.com');
INSERT INTO `cms_settings` VALUES ('flsz','10000');
INSERT INTO `cms_settings` VALUES ('gzip','1');
INSERT INTO `cms_settings` VALUES ('homeurl','http://www.wapscrip.tk');
INSERT INTO `cms_settings` VALUES ('karma','a:6:{s:12:"karma_points";i:5;s:10:"karma_time";i:86400;s:5:"forum";i:20;s:4:"time";i:0;s:2:"on";i:1;s:3:"adm";i:0;}');
INSERT INTO `cms_settings` VALUES ('lng','en');
INSERT INTO `cms_settings` VALUES ('mod_reg','2');
INSERT INTO `cms_settings` VALUES ('mod_forum','2');
INSERT INTO `cms_settings` VALUES ('mod_guest','2');
INSERT INTO `cms_settings` VALUES ('mod_lib','2');
INSERT INTO `cms_settings` VALUES ('mod_gal','2');
INSERT INTO `cms_settings` VALUES ('mod_down_comm','1');
INSERT INTO `cms_settings` VALUES ('mod_down','2');
INSERT INTO `cms_settings` VALUES ('mod_lib_comm','1');
INSERT INTO `cms_settings` VALUES ('mod_gal_comm','1');
INSERT INTO `cms_settings` VALUES ('meta_desc','Susukan wap forum, mod Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('meta_key','Susukan.Us - [ID]');
INSERT INTO `cms_settings` VALUES ('news','a:8:{s:4:"view";i:1;s:4:"size";i:200;s:8:"quantity";i:5;s:4:"days";i:3;s:6:"breaks";i:1;s:7:"smileys";i:1;s:4:"tags";i:1;s:3:"kom";i:1;}');
INSERT INTO `cms_settings` VALUES ('reg_message','Hi, {LOGIN}\r\nWe are glad to see you on our site.\r\nCome more often and here it will be pleasant to you.\r\nYours faithfully, Administrator.');
INSERT INTO `cms_settings` VALUES ('setting_mail','a:2:{s:11:"cat_friends";i:1;s:15:"message_include";i:1;}');
INSERT INTO `cms_settings` VALUES ('skindef','Blue');
INSERT INTO `cms_settings` VALUES ('them_message','Welcome!');
INSERT INTO `cms_settings` VALUES ('timeshift','7');
INSERT INTO `cms_settings` VALUES ('site_access','2');
INSERT INTO `cms_settings` VALUES ('lng_list','a:1:{s:2:"en";s:7:"English";}');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_data`
-- 

CREATE TABLE `cms_users_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `key` varchar(30) NOT NULL DEFAULT '',
  `val` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_guestbook`
-- 

CREATE TABLE `cms_users_guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  `attributes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_users_guestbook`
-- 

INSERT INTO `cms_users_guestbook` VALUES ('1','2','1388422956','1','Bot bot','','a:4:{s:11:"author_name";s:5:"admin";s:9:"author_ip";i:2344760023;s:19:"author_ip_via_proxy";b:0;s:14:"author_browser";s:81:"Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10";}');

-- --------------------------------------------------------
-- 
-- Table structure for table `cms_users_iphistory`
-- 

CREATE TABLE `cms_users_iphistory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=190 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cms_users_iphistory`
-- 

INSERT INTO `cms_users_iphistory` VALUES ('168','1','1893154577','0','1387707866');
INSERT INTO `cms_users_iphistory` VALUES ('171','1','3053932350','0','1387883834');
INSERT INTO `cms_users_iphistory` VALUES ('172','2','3053932350','0','1387886184');
INSERT INTO `cms_users_iphistory` VALUES ('177','1','3053569694','0','1387969045');
INSERT INTO `cms_users_iphistory` VALUES ('182','2','667962772','0','1388155014');
INSERT INTO `cms_users_iphistory` VALUES ('175','1','668416207','0','1387966876');
INSERT INTO `cms_users_iphistory` VALUES ('176','2','668416207','0','1387967894');
INSERT INTO `cms_users_iphistory` VALUES ('181','1','667962772','0','1387975149');
INSERT INTO `cms_users_iphistory` VALUES ('179','1','3053796324','0','1387972682');
INSERT INTO `cms_users_iphistory` VALUES ('180','2','3053569694','0','1387974631');
INSERT INTO `cms_users_iphistory` VALUES ('187','1','1893154682','0','1388405907');
INSERT INTO `cms_users_iphistory` VALUES ('184','1','1893154572','0','1388329548');
INSERT INTO `cms_users_iphistory` VALUES ('185','1','1893154661','0','1388402426');
INSERT INTO `cms_users_iphistory` VALUES ('186','1','1893154703','0','1388404307');
INSERT INTO `cms_users_iphistory` VALUES ('189','1','1893154838','0','1388421604');

-- --------------------------------------------------------
-- 
-- Table structure for table `cons`
-- 

CREATE TABLE `cons` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `number` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  `up` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cons`
-- 

INSERT INTO `cons` VALUES ('1','2','tulung tulung','tulung tulung mbaeh ki njajal','1387032592','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `cons_komm`
-- 

CREATE TABLE `cons_komm` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  `author` int(8) NOT NULL,
  `folder` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `cons_komm`
-- 

INSERT INTO `cons_komm` VALUES ('1','tulung pentung hahaha','1387032617','4','1');

-- --------------------------------------------------------
-- 
-- Table structure for table `counter_ip_base`
-- 

CREATE TABLE `counter_ip_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` bigint(11) NOT NULL,
  `stop` bigint(11) NOT NULL,
  `operator` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=268 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------
-- 
-- Dumping data for table `counter_ip_base`
-- 

INSERT INTO `counter_ip_base` VALUES ('1','-646561792','-646560769','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('2','1494507776','1494508031','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('3','1601019392','1601019647','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('4','1578729472','1578745855','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('5','1360162816','1360164350','BWC','Russia');
INSERT INTO `counter_ip_base` VALUES ('6','-1016011816','-1016011781','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('7','1588723712','1588854783','Utel','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('8','1427813376','1427814399','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('9','-1041268736','-1041268225','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('10','1427809280','1427810303','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('11','1427812352','1427813375','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('12','1402278912','1402279935','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('13','1536099328','1536099839','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('14','1295298720','1295298751','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('15','1333559296','1333575679','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('16','1402275840','1402276863','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('17','-730603520','-730603009','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('18','-1037271040','-1037270785','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('19','-649949184','-649948161','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('20','-649398016','-649397761','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('21','1588920320','1588932607','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('22','1295269888','1295286271','MTS','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('23','1602486272','1602551807','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('24','1536278528','1536286719','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('25','1333575680','1333592063','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('26','1486487552','1486553087','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('27','-1139802112','-1139539969','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('28','1310210048','1310211071','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('29','-730071040','-730066945','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('30','-734353408','-734351361','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('31','1402279936','1402280959','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('32','1519796224','1519800319','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('33','-646557696','-646556673','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('34','1596293120','1596325887','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('35','1347538944','1347543039','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('36','1518993408','1519058943','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('37','1519321088','1519386623','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('38','-730284440','-730284433','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('39','-715698176','-715694081','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('40','1402273792','1402275839','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('41','1410269184','1410334719','BITE','Lithuania');
INSERT INTO `counter_ip_base` VALUES ('42','1441411072','1441415167','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('43','1572081664','1572083711','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('44','-653729792','-653726721','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('45','1536286720','1536294911','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('46','1336176640','1336180735','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('47','-649397504','-649397249','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('48','1505595392','1505599487','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('49','1402284032','1402285055','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('50','1579745280','1579778047','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('51','1294467072','1294499839','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('52','1550958592','1550974975','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('53','1467375616','1467383807','Computer','Germany');
INSERT INTO `counter_ip_base` VALUES ('54','1402277888','1402278911','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('55','1402281984','1402283007','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('56','1402286080','1402287103','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('57','1402287104','1402288127','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('58','-1043733504','-1043732481','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('59','-712935520','-712935489','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('60','1346621440','1346622463','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('61','1433657344','1433657599','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('62','-646560768','-646559745','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('63','-646558720','-646557697','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('64','-646556672','-646555649','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('65','-646555648','-646554625','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('66','-646554624','-646553601','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('67','1047070464','1047072255','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('68','1401450496','1401450751','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('69','1401451520','1401451647','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('70','1425981440','1425981695','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('71','1441366016','1441371903','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('72','-1022602752','-1022602497','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('73','-730292224','-730291713','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('74','-730290464','-730290433','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('75','-723779584','-723775489','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('76','-653151232','-653150977','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('77','-653150720','-653150465','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('78','1519779840','1519783935','Utel','Russia');
INSERT INTO `counter_ip_base` VALUES ('79','1347592192','1347600383','BWC','Russia');
INSERT INTO `counter_ip_base` VALUES ('80','-706447360','-706446337','BWC','Russia');
INSERT INTO `counter_ip_base` VALUES ('81','-1020368128','-1020367873','BWC','Russia');
INSERT INTO `counter_ip_base` VALUES ('82','1042394624','1042394879','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('83','1346950400','1346950655','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('84','1347674112','1347674623','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('85','1360933376','1360933887','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('86','1372794624','1372794879','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('87','1410457600','1410459647','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('88','-1036610560','-1036609537','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('89','-1017778688','-1017778433','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('90','-1018539008','-1018538753','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('91','-1013514240','-1013513985','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('92','-1007707904','-1007707649','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('93','-735278080','-735277825','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('94','-732132608','-732132417','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('95','-732132416','-732132353','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('96','-716135424','-716135169','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('97','-715707904','-715701761','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('98','-715700224','-715699361','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('99','-649400320','-649398273','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('100','-646488576','-646488065','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('101','1535627776','1535628031','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('102','-715699200','-715698689','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('103','1404862464','1404870655','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('104','1404846080','1404854271','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('105','1404854272','1404862463','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('106','1404837888','1404846079','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('107','1404829696','1404837887','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('108','1518927872','1518944255','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('109','-2097938432','-2097872897','TELE2','Sweden');
INSERT INTO `counter_ip_base` VALUES ('110','-644598784','-644598529','Motive','Russia');
INSERT INTO `counter_ip_base` VALUES ('111','-644599808','-644599553','Motive','Russia');
INSERT INTO `counter_ip_base` VALUES ('112','-1016011008','-1016010753','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('113','-1016007168','-1016006913','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('114','1389383040','1389383167','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('115','1432330240','1432334335','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('116','-1012795392','-1012793345','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('117','-709795840','-709793025','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('118','-1027958784','-1027958529','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('119','-1016974848','-1016974337','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('120','1441609984','1441610239','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('121','1346736128','1346737151','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('122','-1034680960','-1034680833','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('123','-649236224','-649236217','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('124','-707747840','-707747585','P','Russia');
INSERT INTO `counter_ip_base` VALUES ('125','-646672384','-646671361','STEK GSM','Russia');
INSERT INTO `counter_ip_base` VALUES ('126','1481787392','1481787647','Tatinkom-Pc','Russia');
INSERT INTO `counter_ip_base` VALUES ('127','-642969600','-642965505','Tatinkom-Pc','Russia');
INSERT INTO `counter_ip_base` VALUES ('128','1506762752','1506763007','Tatinkom-Pc','Russia');
INSERT INTO `counter_ip_base` VALUES ('129','1052193280','1052193535','MTT','Russia');
INSERT INTO `counter_ip_base` VALUES ('130','1347125248','1347125759','MTT','Russia');
INSERT INTO `counter_ip_base` VALUES ('131','1347125248','1347129343','MTT','Russia');
INSERT INTO `counter_ip_base` VALUES ('132','1358118912','1358119423','PtPcPs','Russia');
INSERT INTO `counter_ip_base` VALUES ('133','1358119424','1358120703','PtPcPs','Russia');
INSERT INTO `counter_ip_base` VALUES ('134','1406740480','1406746623','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('135','-730374144','-730373377','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('136','-730371328','-730370561','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('137','-730367488','-730365953','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('138','-729718784','-729717249','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('139','-729717248','-729716737','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('140','-729716736','-729712641','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('141','-716144640','-716111873','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('142','-646754304','-646754049','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('143','1509752832','1509756927','Sky Link','Russia');
INSERT INTO `counter_ip_base` VALUES ('144','1386348544','1386349567','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('145','-1054262272','-1054261249','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('146','-734354944','-734354433','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('147','-734354432','-734353409','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('148','1360467968','1360470015','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('149','1360465920','1360467967','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('150','-734351360','-734347265','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('151','-734355456','-734355201','life:)','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('152','1295253504','1295269887','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('153','1358905344','1358905471','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('154','1358907392','1358907519','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('155','1358907648','1358907775','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('156','1358907904','1358908031','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('157','1358908160','1358908239','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('158','1358908416','1358908431','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('159','1358908928','1358909439','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('160','1490436096','1490444287','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('161','1490444288','1490452479','UMC','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('162','-1010987520','-1010987009','Opera-Mini','Norway');
INSERT INTO `counter_ip_base` VALUES ('163','1403965440','1403967487','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('164','-649397760','-649397505','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('165','-1036908288','-1036908033','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('166','1593212416','1593212927','Opera-Mini','Norway');
INSERT INTO `counter_ip_base` VALUES ('167','1317601280','1317609471','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('168','1570762752','1570763775','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('169','1360164352','1360166910','BWC','Russia');
INSERT INTO `counter_ip_base` VALUES ('170','1536521728','1536521983','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('171','1347677184','1347678207','MTS','Russia');
INSERT INTO `counter_ip_base` VALUES ('172','-733229056','-733224961','Good Line','Russia');
INSERT INTO `counter_ip_base` VALUES ('173','-733233152','-733229057','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('174','-712548352','-712545901','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('175','-1019551744','-1019543553','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('176','1602486272','1602748415','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('177','1572192256','1572200447','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('178','1572087808','1572089855','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('179','1467285504','1467286527','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('180','1568178176','1568194559','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('181','1466826752','1466859519','TELE2','Latvia');
INSERT INTO `counter_ip_base` VALUES ('182','1365222400','1365223423','GE-MAGTICOM','Georgia');
INSERT INTO `counter_ip_base` VALUES ('183','1540055040','1540056063','Opera-Mini','Norway');
INSERT INTO `counter_ip_base` VALUES ('184','1587085312','1587150847','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('185','1595408384','1595932671','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('186','1592803328','1592811519','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('187','1475812368','1475812371','Computer','Kazakhstan');
INSERT INTO `counter_ip_base` VALUES ('188','1592811520','1592815615','PtP','Russia');
INSERT INTO `counter_ip_base` VALUES ('189','1519058944','1519124479','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('190','1346623232','1346625535','PtPcPs','Russia');
INSERT INTO `counter_ip_base` VALUES ('191','-1016005120','-1016004865','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('192','1437532160','1437597695','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('193','1550867968','1550868223','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('194','-1020264704','-1020264449','KCELL','Kazakhstan');
INSERT INTO `counter_ip_base` VALUES ('195','1297055744','1297063935','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('196','1360941312','1360941567','Computer','Belarusia');
INSERT INTO `counter_ip_base` VALUES ('197','1550942208','1550958591','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('198','1042368000','1042368127','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('199','1307182080','1307185151','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('200','1334149120','1334153215','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('201','1357411584','1357411839','Computer','Norway');
INSERT INTO `counter_ip_base` VALUES ('202','1298948736','1298948799','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('203','1578948608','1578950655','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('204','1495015424','1495017471','Computer','Moldavia');
INSERT INTO `counter_ip_base` VALUES ('205','1053675520','1053679615','Computer','Latvia');
INSERT INTO `counter_ip_base` VALUES ('206','1406855168','1406856191','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('207','-644471296','-644471041','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('208','1505605632','1505607679','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('209','1539824896','1539825151','Computer','Uzbekistan');
INSERT INTO `counter_ip_base` VALUES ('210','1306433280','1306433535','Computer','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('211','2130706433','2130706433','Localhost','Server lokal');
INSERT INTO `counter_ip_base` VALUES ('212','3648409600','3648410623','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('213','3239825408','3239825919','Not defined','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('214','3253698560','3253699071','BeeLine','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('215','3273026560','3273027583','PsPcP','Russia');
INSERT INTO `counter_ip_base` VALUES ('216','1582137344','1582139391','DTN Online','Russia');
INSERT INTO `counter_ip_base` VALUES ('217','3645018112','3645019135','PsPcP','Russia');
INSERT INTO `counter_ip_base` VALUES ('218','1519124480','1519190015','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('219','1404870656','1404872703','TELE2','Latvia');
INSERT INTO `counter_ip_base` VALUES ('220','3261777408','3261777919','KCELL','Kazakhstan');
INSERT INTO `counter_ip_base` VALUES ('221','1603907584','1603911679','PsPcP','Russia');
INSERT INTO `counter_ip_base` VALUES ('222','1402275840','1402276863','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('223','1599307776','1599315967','SPARK','Russia');
INSERT INTO `counter_ip_base` VALUES ('224','1601011712','1601036287','PsPcP','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('225','3648411648','3648412671','BeeLine','Russia');
INSERT INTO `counter_ip_base` VALUES ('226','1402285056','1402286079','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('227','1402280960','1402281983','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('228','-1033189888','-1033189377','KCELL','Kazakhstan');
INSERT INTO `counter_ip_base` VALUES ('229','1839349760','1839366143','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('230','1407035392','1407036415','Sharq Telekom','Uzbekistan');
INSERT INTO `counter_ip_base` VALUES ('231','1357902336','1357902847','Opera-Mini','Unspecified');
INSERT INTO `counter_ip_base` VALUES ('232','-1299906560','-1299890177','PsPcP','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('233','-1299857408','-1299849217','PsPcP','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('234','-1299881984','-1299873793','PsPcP','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('235','-1299873792','-1299857409','PsPcP','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('236','-1055797248','-1055796993','Norma-Plus','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('237','1427814400','1427815423','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('238','1603903488','1603907583','PsPcP','Russia');
INSERT INTO `counter_ip_base` VALUES ('239','1306001408','1306132479','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('240','1402283008','1402284031','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('241','1123631104','1123639295','Google Bot','BotLand');
INSERT INTO `counter_ip_base` VALUES ('242','1311641561','1311641561','SymbOS Monitoring','BotLand');
INSERT INTO `counter_ip_base` VALUES ('243','-1297580032','-1297563649','MTS','Belorussia');
INSERT INTO `counter_ip_base` VALUES ('244','1518665728','1518698495','TELE2','Russia');
INSERT INTO `counter_ip_base` VALUES ('245','1600975872','1600976127','Yandex Bot','BotLand');
INSERT INTO `counter_ip_base` VALUES ('246','1427826688','1427828735','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('247','38273024','38535167','KCELL','Kazakhstan');
INSERT INTO `counter_ip_base` VALUES ('248','1600952064','1600952319','YandexBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('249','1600977152','1600977407','YandexBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('250','1297619968','1297620223','YandexBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('251','1373519872','1373520383','RamblerBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('252','-1299644416','-1299611649','Kyivstar','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('253','1427823616','1427824639','Megaphone','Kyrgyzstan');
INSERT INTO `counter_ip_base` VALUES ('254','1441570816','1441571327','Computer','Russia');
INSERT INTO `counter_ip_base` VALUES ('255','1296704512','1296705535','Velcom','Belorussia');
INSERT INTO `counter_ip_base` VALUES ('256','-1303584768','-1303582721','Spark','Russia');
INSERT INTO `counter_ip_base` VALUES ('257','3582611456','3582615551','Spark','Russia');
INSERT INTO `counter_ip_base` VALUES ('258','-1303969792','-1303904257','North-West Telecom','Russia');
INSERT INTO `counter_ip_base` VALUES ('259','1136852992','1136918527','YahooBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('260','1427806208','1427807231','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('261','-1302593536','-1302528001','Ukrtelecom','Ukraine');
INSERT INTO `counter_ip_base` VALUES ('262','-1305526272','-1305518081','Uralsvyazinform','Russia');
INSERT INTO `counter_ip_base` VALUES ('263','-819068928','-819003393','BingBOT','BotLand');
INSERT INTO `counter_ip_base` VALUES ('264','1427826688','1427828735','Megaphone','Russia');
INSERT INTO `counter_ip_base` VALUES ('265','1920988782','3758088197','Telkomsel','Indonesia');
INSERT INTO `counter_ip_base` VALUES ('266','169348966','3758088456','3 Three','Indonesia');
INSERT INTO `counter_ip_base` VALUES ('267','3355443200','3372220415','LACNIC','Mexico');

-- --------------------------------------------------------
-- 
-- Table structure for table `countersall`
-- 

CREATE TABLE `countersall` (
  `date` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `host` int(11) NOT NULL,
  `yandex` int(11) NOT NULL,
  `rambler` int(11) NOT NULL,
  `google` int(11) NOT NULL,
  `mail` int(11) NOT NULL,
  `gogo` int(11) NOT NULL,
  `yahoo` int(11) NOT NULL,
  `bing` int(11) NOT NULL,
  `nigma` int(11) NOT NULL,
  `qip` int(11) NOT NULL,
  `aport` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `countersall`
-- 

INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `countersall` VALUES ('0','0','0','0','0','0','0','0','0','0','0','0','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `download`
-- 

CREATE TABLE `download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `adres` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `ip` text NOT NULL,
  `soft` text NOT NULL,
  `text` text NOT NULL,
  `screen` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `refid` (`refid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `forum`
-- 

CREATE TABLE `forum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `type` char(1) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `from` varchar(25) NOT NULL DEFAULT '',
  `realid` int(3) NOT NULL DEFAULT '0',
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `soft` text NOT NULL,
  `text` text NOT NULL,
  `close` tinyint(1) NOT NULL DEFAULT '0',
  `close_who` varchar(25) NOT NULL,
  `vip` tinyint(1) NOT NULL DEFAULT '0',
  `edit` text NOT NULL,
  `tedit` int(11) NOT NULL DEFAULT '0',
  `kedit` int(2) NOT NULL DEFAULT '0',
  `curators` text NOT NULL,
  `min_post` int(11) NOT NULL DEFAULT '0',
  `tiento` varchar(50) NOT NULL,
  `minim` tinyint(1) NOT NULL,
  `kiemduyet_who` varchar(40) NOT NULL,
  `closed_who` varchar(40) NOT NULL,
  `kiemduyet` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refid` (`refid`),
  KEY `type` (`type`),
  KEY `time` (`time`),
  KEY `close` (`close`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `forum`
-- 

INSERT INTO `forum` VALUES ('132','0','f','0','0','','1','0','0','','WAPMASTER - [ID]','0','','0','0','0','0','','0','','0','BOT','','1');
INSERT INTO `forum` VALUES ('133','132','r','0','0','','1','0','0','','Susukan - [ID]','0','','0','0','0','0','','0','','0','BOT','','1');
INSERT INTO `forum` VALUES ('163','133','t','1388453909','1','admin','0','0','0','','Menampilkan subforum di hompage','0','','0','','0','0','','0','3','0','','','0');
INSERT INTO `forum` VALUES ('164','163','m','1388451407','1','admin','0','2344760023','0','Opera/9.80 (J2ME/MIDP; Opera Mini/4.2/34.818; U; en) Presto/2.8.119 Version/11.10','Pasang kode ini di /papes\r\n[php]<?php\r\necho \'<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>\'.$textl.\'</b></div>\';\r\n$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? \'\' : " WHERE `del` != \'1\'")), 0);\r\nif ($user_id) {\r\necho \'<div class="topmenu"><a href="../forum/index.php?act=new">Unread</a><font color="red">&nbsp;(<b>\' . counters::forum_new() . \'</b>)</font> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(\' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . \')</span></div></div></div>\'; }\r\nif (!$user_id) {\r\necho \'<div class="topmenu"><a href="../forum/index.php?act=new">Last Activity</a> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(\' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . \')</span></div></div></div>\'; }\r\n$bonguyen = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`=\'f\' ORDER BY `realid`");\r\nwhile (($dd = mysql_fetch_array($bonguyen)) !== false) {\r\necho \'<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>\'.$dd[\'text\'].\'</b></div>\';\r\n$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`=\'" . $dd[\'id\'] . "\' ORDER BY `realid`");\r\n$i = 0;\r\nwhile (($res = mysql_fetch_array($req)) !== false) {\r\n$chude = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`=\'t\' and `refid`=\'" . $res[\'id\'] . "\'"), 0);\r\necho \'<div class="\'.(++$j%2==0 ? "list2" : "list2").\'"><div class="susukan" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><img src="images/forum_32.png" width="20" height="20" alt="Susukan" /> <a href="/forum/index.php?id=\' . $res[\'id\'] . \'">\' . $res[\'text\'] . \'</a></td><td width="auto" align="right">        [\'.$chude.\']</td></tr></table></div></div>\';\r\n}\r\necho \'</div></div></div>\';\r\n++$j;\r\n}\r\n?>\r\n[/php]','0','','0','','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('165','163','m','1388453909','2','bot','0','2344760023','0','Opera/9.80','[c]:quote_icon Originally Posted by [b]admin[/b]  [url=http://test.indoboox.us/forum/index.php?act=post&id=164]:viewpost[/url]\r\n[/c]mantap min lanjutkan','0','','0','','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('155','0','f','0','0','','2','0','0','','PHP SCRIP - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('156','0','f','0','0','','3','0','0','','SCRIP UPDATE - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('157','0','f','0','0','','4','0','0','','HOSTING MANAGEMENT - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('158','0','f','0','0','','5','0','0','','PREAKING SELULAR - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('159','155','r','0','0','','1','0','0','','JohnCMS Susukan - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('160','156','r','0','0','','1','0','0','','JohnCMS Susukan - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('161','157','r','0','0','','1','0','0','','Indomob.Net - [ID]','0','','0','0','0','0','','0','','0','','','0');
INSERT INTO `forum` VALUES ('162','158','r','0','0','','1','0','0','','Telkomsel - [ID]','0','','0','0','0','0','','0','','0','','','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `forum_thank`
-- 

CREATE TABLE `forum_thank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL,
  `userthank` int(11) NOT NULL,
  `chude` int(11) NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2261 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `forum_thank`
-- 

INSERT INTO `forum_thank` VALUES ('2258','1','137','2','136','');
INSERT INTO `forum_thank` VALUES ('2259','1','135','2','134','');
INSERT INTO `forum_thank` VALUES ('2260','1','147','2','134','');

-- --------------------------------------------------------
-- 
-- Table structure for table `friendssite`
-- 

CREATE TABLE `friendssite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` text NOT NULL,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `friendssite`
-- 

INSERT INTO `friendssite` VALUES ('11','http://www.susukan.us','Susukan.Us - [ID]','Susukan wap forum','1','13','1','1387678074');

-- --------------------------------------------------------
-- 
-- Table structure for table `gallery`
-- 

CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `type` varchar(2) NOT NULL DEFAULT '',
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `name` text NOT NULL,
  `user` binary(1) NOT NULL DEFAULT '\0',
  `ip` text NOT NULL,
  `soft` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refid` (`refid`),
  KEY `type` (`type`),
  KEY `time` (`time`),
  KEY `avtor` (`avtor`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `guest`
-- 

CREATE TABLE `guest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adm` tinyint(1) NOT NULL DEFAULT '0',
  `time` int(15) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `browser` tinytext NOT NULL,
  `admin` varchar(25) NOT NULL DEFAULT '',
  `otvet` text NOT NULL,
  `otime` int(15) NOT NULL DEFAULT '0',
  `edit_who` varchar(20) NOT NULL DEFAULT '',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `edit_count` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `ip` (`ip`),
  KEY `adm` (`adm`)
) ENGINE=MyISAM AUTO_INCREMENT=176 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `guest`
-- 

INSERT INTO `guest` VALUES ('173','0','1388451407','2','Satpam','@admin just created a new topic: Menampilkan subforum di hompage','1778585865','Susukan.Us','','','0','','0','0');
INSERT INTO `guest` VALUES ('174','0','1388451666','2','Satpam','@admin just created a new blog: Cara installasi\r\nAtur pada folder2 di bawah ini ke (CHMOD) 777 semuanya yak: \r\n../cache\r\n../cache/downloads_images\r\n../cache/downloads_jad\r\n../cache/albums/thumbs\r\n../files\r\n../files/albums\r\n../files/avatars\r\n../files/forum\r\n../files/downloads\r\n../files/downloads_screens\r\n../system/ini\r\n../tmp','1737235248','Susukan.Us','','','0','','0','0');
INSERT INTO `guest` VALUES ('175','0','1388464900','2','Satpam','Hi @bot, welc0me to [b]Susukan.Us - [ID][/b]','0','Susukan.Us','','','0','','0','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `karma_users`
-- 

CREATE TABLE `karma_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `karma_user` int(11) NOT NULL,
  `points` int(2) NOT NULL,
  `type` int(1) NOT NULL,
  `time` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `karma_user` (`karma_user`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `lib`
-- 

CREATE TABLE `lib` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `type` varchar(4) NOT NULL DEFAULT '',
  `name` tinytext NOT NULL,
  `announce` text NOT NULL,
  `avtor` varchar(25) NOT NULL DEFAULT '',
  `text` mediumtext NOT NULL,
  `ip` int(11) NOT NULL DEFAULT '0',
  `soft` text NOT NULL,
  `moder` tinyint(1) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `moder` (`moder`),
  KEY `time` (`time`),
  KEY `refid` (`refid`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `look`
-- 

CREATE TABLE `look` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user` int(20) NOT NULL,
  `place_id` int(20) NOT NULL,
  `type` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `news`
-- 

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL DEFAULT '0',
  `avt` varchar(25) NOT NULL DEFAULT '',
  `name` text NOT NULL,
  `text` text NOT NULL,
  `kom` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `privat`
-- 

CREATE TABLE `privat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(25) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `time` varchar(25) NOT NULL DEFAULT '',
  `author` varchar(25) NOT NULL DEFAULT '',
  `type` char(3) NOT NULL DEFAULT '',
  `chit` char(3) NOT NULL DEFAULT '',
  `temka` text NOT NULL,
  `otvet` binary(1) NOT NULL DEFAULT '\0',
  `me` varchar(25) NOT NULL DEFAULT '',
  `cont` varchar(25) NOT NULL DEFAULT '',
  `ignor` varchar(25) NOT NULL DEFAULT '',
  `attach` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `me` (`me`),
  KEY `ignor` (`ignor`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `privat`
-- 

INSERT INTO `privat` VALUES ('16','bot','Seng mail all member www.situsmu.com/gp.php :D','1388422570','admin','in','no','Notice From mTuner','0','','','','');

-- --------------------------------------------------------
-- 
-- Table structure for table `qchat`
-- 

CREATE TABLE `qchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `staff`
-- 

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` text NOT NULL,
  `name` text NOT NULL,
  `opis` text NOT NULL,
  `iduser` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `vr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `stat_robots`
-- 

CREATE TABLE `stat_robots` (
  `engine` text NOT NULL,
  `date` int(11) NOT NULL,
  `url` text NOT NULL,
  `query` text NOT NULL,
  `ua` text NOT NULL,
  `ip` bigint(11) NOT NULL,
  `count` int(11) NOT NULL,
  `today` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `name_lat` varchar(40) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `rights` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `failed_login` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `imname` varchar(50) NOT NULL,
  `sex` varchar(2) NOT NULL DEFAULT '',
  `komm` int(10) NOT NULL DEFAULT '0',
  `postforum` int(10) NOT NULL DEFAULT '0',
  `postguest` int(11) NOT NULL DEFAULT '0',
  `yearofbirth` int(4) NOT NULL DEFAULT '0',
  `datereg` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(11) NOT NULL DEFAULT '0',
  `mail` varchar(50) NOT NULL DEFAULT '',
  `icq` int(9) NOT NULL DEFAULT '0',
  `skype` varchar(50) NOT NULL,
  `jabber` varchar(50) NOT NULL,
  `www` varchar(50) NOT NULL DEFAULT '',
  `about` text NOT NULL,
  `live` varchar(100) NOT NULL,
  `mibile` varchar(50) NOT NULL DEFAULT '',
  `status` varchar(100) NOT NULL,
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `ip_via_proxy` bigint(11) NOT NULL DEFAULT '0',
  `browser` text NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `preg` tinyint(1) NOT NULL DEFAULT '0',
  `regadm` varchar(25) NOT NULL DEFAULT '',
  `mailvis` tinyint(1) NOT NULL DEFAULT '0',
  `dayb` int(2) NOT NULL DEFAULT '0',
  `monthb` int(2) NOT NULL DEFAULT '0',
  `sestime` int(10) unsigned NOT NULL DEFAULT '0',
  `total_on_site` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL,
  `rest_code` varchar(32) NOT NULL,
  `rest_time` int(11) NOT NULL,
  `movings` int(11) NOT NULL DEFAULT '0',
  `place` varchar(30) NOT NULL,
  `set_user` text NOT NULL,
  `set_forum` text NOT NULL,
  `karma_plus` int(11) NOT NULL DEFAULT '0',
  `karma_minus` int(11) NOT NULL DEFAULT '0',
  `karma_time` int(11) NOT NULL DEFAULT '0',
  `karma_off` tinyint(1) unsigned NOT NULL,
  `comm_count` int(10) unsigned NOT NULL,
  `comm_old` int(10) unsigned NOT NULL DEFAULT '0',
  `smileys` text NOT NULL,
  `podpis` varchar(100) NOT NULL,
  `pangkat` text NOT NULL,
  `journal_forum` int(11) NOT NULL DEFAULT '0',
  `twitter` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `set_mail` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name_lat` (`name_lat`),
  KEY `lastdate` (`lastdate`),
  KEY `place` (`place`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
