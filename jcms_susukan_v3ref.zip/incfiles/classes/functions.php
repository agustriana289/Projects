<?php
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/
defined('_IN_JOHNCMS') or die('Restricted access');
class functions extends core
{
/*
-----------------------------------------------------------------
Ganti URL by kashur.cz.cc
-----------------------------------------------------------------
*/
public static function gantiurl($text)
{
$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
$text=str_replace(" ","-", $text);$text=str_replace("--","-", $text);
$text=str_replace("@","-",$text);$text=str_replace("/","-",$text);
$text=str_replace("\\","-",$text);$text=str_replace(":","",$text);
$text=str_replace("\"","",$text);$text=str_replace("'","",$text);
$text=str_replace("<","",$text);$text=str_replace(">","",$text);
$text=str_replace(",","",$text);$text=str_replace("?","",$text);
$text=str_replace(";","",$text);$text=str_replace(".","",$text);
$text=str_replace("[","",$text);$text=str_replace("]","",$text);
$text=str_replace("red","",$text);$text=str_replace("blue","",$text);
$text=str_replace("orange","",$text);$text=str_replace("orange","",$text);
$text=str_replace("green","",$text);$text=str_replace("lime","",$text);
$text=str_replace("pink","",$text);$text=str_replace("gray","",$text);
$text=str_replace("purple","",$text);$text=str_replace("black","",$text);
$text=str_replace("b","",$text);$text=str_replace("","",$text);
$text=str_replace("","",$text);$text=str_replace("","",$text);
$text=str_replace("(","",$text);$text=str_replace(")","",$text);
$text=str_replace("*","",$text);$text=str_replace("!","",$text);
$text=str_replace("$","-",$text);$text=str_replace("&","-and-",$text);
$text=str_replace("%","",$text);$text=str_replace("#","",$text);
$text=str_replace("^","",$text);$text=str_replace("=","",$text);
$text=str_replace("+","",$text);$text=str_replace("~","",$text);
$text=str_replace("`","",$text);$text=str_replace("--","-",$text);
$text = preg_replace("/(� |á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);$text = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);
$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);
$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);
$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);
$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);
$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);$text = preg_replace("/(đ)/", 'd', $text);
$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);$text = preg_replace("/(đ)/", 'd', $text);
$text = preg_replace("/(À|Á|� |Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);$text = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);
$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);
$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);
$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|� |Ờ|Ớ|Ợ|Ở|� )/", 'O', $text);$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|� |� ̀|� ́|� ̣|� ̉|� ̃)/", 'O', $text);
$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);
$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);$text = preg_replace("/(Đ)/", 'D', $text);
$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);$text = preg_replace("/(Đ)/", 'D', $text);
$text=strtolower($text);
return $text;
}
public static function display_pagination2($base_url, $start, $max_value, $num_per_page)
{
$neighbors = 2;
if ($start >= $max_value)
$start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
else
$start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
$base_link = '<a class="pagenav" href="' . strtr($base_url, array('%' => '%%')) . '_p%d.html' . '">%s</a>';
$out[] = $start == 0 ? '' : sprintf($base_link, $start / $num_per_page, '&lt;&lt;');
if ($start > $num_per_page * $neighbors)
$out[] = sprintf($base_link, 1, '1');
if ($start > $num_per_page * ($neighbors + 1))
$out[] = '<span style="font-weight: bold;">...</span>';
for ($nCont = $neighbors; $nCont >= 1; $nCont--)
if ($start >= $num_per_page * $nCont) {
$tmpStart = $start - $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
$out[] = '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span>';
$tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;
for ($nCont = 1; $nCont <= $neighbors; $nCont++)
if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
$tmpStart = $start + $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
if ($start + $num_per_page * ($neighbors + 1) < $tmpMaxPages)
$out[] = '<span style="font-weight: bold;">...</span>';
if ($start + $num_per_page * $neighbors < $tmpMaxPages)
$out[] = sprintf($base_link, $tmpMaxPages / $num_per_page + 1, $tmpMaxPages / $num_per_page + 1);
if ($start + $num_per_page < $max_value) {
$display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start / $num_per_page + 2);
$out[] = sprintf($base_link, $display_page, '&gt;&gt;');
}
return implode(' ', $out);
}
/**
* Является ли выбранный юзер другом?
*
* @param int $id   Идентификатор пользователя, которого проверяем
*
* @return bool
*/
public static function is_friend($id = 0)
{
static $user_id = NULL;
static $return = FALSE;
if (!self::$user_id && !$id) {
return FALSE;
}
if (is_null($user_id) || $id != $user_id) {
$query = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type` = '2' AND ((`from_id` = '$id' AND `user_id` = '" . self::$user_id . "') OR (`from_id` = '" . self::$user_id . "' AND `user_id` = '$id'))"), 0);
$return = $query == 2 ? TRUE : FALSE;
}
return $return;
}
/**
* Находится ли выбранный пользователь в контактах и игноре?
*
* @param int $id Идентификатор пользователя, которого проверяем
*
* @return int Результат запроса:
*             0 - не в контактах
*             1 - в контактах
*             2 - в игноре у меня
*/
public static function is_contact($id = 0)
{
static $user_id = NULL;
static $return = 0;
if (!self::$user_id && !$id) {
return 0;
}
if (is_null($user_id) || $id != $user_id) {
$user_id = $id;
$req_1 = mysql_query("SELECT * FROM `cms_contact` WHERE `user_id` = '" . self::$user_id . "' AND `from_id` = '$id'");
if (mysql_num_rows($req_1)) {
$res_1 = mysql_fetch_assoc($req_1);
if ($res_1['ban'] == 1) {
$return = 2;
} else {
$return = 1;
}
} else {
$return = 0;
}
}
return $return;
}
/**
* Проверка на игнор у получателя
*
* @param $id
*
* @return bool
*/
public static function is_ignor($id)
{
static $user_id = NULL;
static $return = FALSE;
if (!self::$user_id && !$id) {
return FALSE;
}
if (is_null($user_id) || $id != $user_id) {
$user_id = $id;
$req_2 = mysql_query("SELECT * FROM `cms_contact` WHERE `user_id` = '$id' AND `from_id` = '" . self::$user_id . "'");
if (mysql_num_rows($req_2)) {
$res_2 = mysql_fetch_assoc($req_2);
if ($res_2['ban'] == 1) {
$return = TRUE;
}
}
}
return $return;
}
/*
-----------------------------------------------------------------
Антифлуд
-----------------------------------------------------------------
� ежимы работы:
1 - Адаптивный
2 - День / Ночь
3 - День
4 - Ночь
-----------------------------------------------------------------
*/
public static function antiflood()
{
$default = array(
'mode' => 2,
'day' => 10,
'night' => 30,
'dayfrom' => 10,
'dayto' => 22
);
$af = isset(self::$system_set['antiflood']) ? unserialize(self::$system_set['antiflood']) : $default;
switch ($af['mode']) {
case 1:
// Адаптивный режим
$adm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` > 0 AND `lastdate` > " . (time() - 300)), 0);
$limit = $adm > 0 ? $af['day'] : $af['night'];
break;
case 3:
// День
$limit = $af['day'];
break;
case 4:
// Ночь
$limit = $af['night'];
break;
default:
// По умолчанию день / ночь
$c_time = date('G', time());
$limit = $c_time > $af['day'] && $c_time < $af['night'] ? $af['day'] : $af['night'];
}
if (self::$user_rights > 0)
$limit = 4; // Для Администрации задаем лимит в 4 секунды
$flood = self::$user_data['lastpost'] + $limit - time();
if ($flood > 0)
return $flood;
else
return false;
}
/*
-----------------------------------------------------------------
Маскировка ссылок в тексте
-----------------------------------------------------------------
*/
public static function antilink($var)
{
$var = preg_replace('~\\[url=(https?://.+?)\\](.+?)\\[/url\\]|(https?://(www.)?[0-9a-z\.-]+\.[0-9a-z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', '###', $var);
$replace = array(
'.ru' => '***',
'.com' => '***',
'.biz' => '***',
'.cn' => '***',
'.in' => '***',
'.net' => '***',
'.org' => '***',
'.info' => '***',
'.mobi' => '***',
'.wen' => '***',
'.kmx' => '***',
'.h2m' => '***'
);
return strtr($var, $replace);
}
/*
-----------------------------------------------------------------
Проверка переменных
-----------------------------------------------------------------
*/
public static function check($str)
{
$str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
$str = nl2br($str);
$str = strtr($str, array(
chr(0) => '',
chr(1) => '',
chr(2) => '',
chr(3) => '',
chr(4) => '',
chr(5) => '',
chr(6) => '',
chr(7) => '',
chr(8) => '',
chr(9) => '',
chr(10) => '',
chr(11) => '',
chr(12) => '',
chr(13) => '',
chr(14) => '',
chr(15) => '',
chr(16) => '',
chr(17) => '',
chr(18) => '',
chr(19) => '',
chr(20) => '',
chr(21) => '',
chr(22) => '',
chr(23) => '',
chr(24) => '',
chr(25) => '',
chr(26) => '',
chr(27) => '',
chr(28) => '',
chr(29) => '',
chr(30) => '',
chr(31) => ''
));
$str = str_replace("'", "&#39;", $str);
$str = str_replace('\\', "&#92;", $str);
$str = str_replace("|", "I", $str);
$str = str_replace("||", "I", $str);
$str = str_replace("/\\\$/", "&#36;", $str);
$str = mysql_real_escape_string($str);
return $str;
}
/*
-----------------------------------------------------------------
Обработка текстов перед выводом на экран
-----------------------------------------------------------------
$br=1           обработка переносов строк
$br=2           подстановка пробела, вместо переноса
$tags=1         обработка тэгов
$tags=2         вырезание тэгов
-----------------------------------------------------------------
*/
public static function checkout($str, $br = 0, $tags = 0)
{
$str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
if ($br == 1)
$str = nl2br($str);
elseif ($br == 2)
$str = str_replace("\r\n", ' ', $str);
if ($tags == 1)
$str = bbcode::tags($str);
elseif ($tags == 2)
$str = bbcode::notags($str);
$replace = array(
chr(0) => '',
chr(1) => '',
chr(2) => '',
chr(3) => '',
chr(4) => '',
chr(5) => '',
chr(6) => '',
chr(7) => '',
chr(8) => '',
chr(9) => '',
chr(11) => '',
chr(12) => '',
chr(13) => '',
chr(14) => '',
chr(15) => '',
chr(16) => '',
chr(17) => '',
chr(18) => '',
chr(19) => '',
chr(20) => '',
chr(21) => '',
chr(22) => '',
chr(23) => '',
chr(24) => '',
chr(25) => '',
chr(26) => '',
chr(27) => '',
chr(28) => '',
chr(29) => '',
chr(30) => '',
chr(31) => ''
);
return strtr($str, $replace);
}
/*
-----------------------------------------------------------------
Показ различных счетчиков внизу страницы
-----------------------------------------------------------------
*/
public static function display_counters()
{
global $headmod;
$req = mysql_query("SELECT * FROM `cms_counters` WHERE `switch` = '1' ORDER BY `sort` ASC");
if (mysql_num_rows($req) > 0) {
while (($res = mysql_fetch_array($req)) !== false) {
$link1 = ($res['mode'] == 1 || $res['mode'] == 2) ? $res['link1'] : $res['link2'];
$link2 = $res['mode'] == 2 ? $res['link1'] : $res['link2'];
$count = ($headmod == 'mainpage') ? $link1 : $link2;
if (!empty($count))
echo $count;
}
}
}
/*
-----------------------------------------------------------------
Показываем дату с учетом сдвига времени
-----------------------------------------------------------------
*/
public static function display_date($var)
{
$shift = (self::$system_set['timeshift'] + self::$user_set['timeshift']) * 3600;
if (date('Y', $var) == date('Y', time())) {
if (date('z', $var + $shift) == date('z', time() + $shift))
return self::$lng['today'] . ', ' . date("h:ia", $var + $shift);
if (date('z', $var + $shift) == date('z', time() + $shift) - 1)
return self::$lng['yesterday'] . ', ' . date("h:ia", $var + $shift);
}
return date("d F h:ia", $var + $shift);
}
/*
-----------------------------------------------------------------
Сообщения об ошибках
-----------------------------------------------------------------
*/
public static function display_error($error = NULL, $link = NULL)
{
if (!empty($error)) {
return '<div class="rmenu"><p><b>' . self::$lng['error'] . '!</b><br />' .
(is_array($error) ? implode('<br />', $error) : $error) . '</p>' .
(!empty($link) ? '<p>' . $link . '</p>' : '') . '</div>';
} else {
return false;
}
}
/*
-----------------------------------------------------------------
Отображение различных меню
-----------------------------------------------------------------
$delimiter - разделитель между пунктами
$end_space - выводится в конце
-----------------------------------------------------------------
*/
public static function display_menu($val = array(), $delimiter = ' | ', $end_space = '')
{
return implode($delimiter, array_diff($val, array(''))) . $end_space;
}
/*
-----------------------------------------------------------------
Постраничная навигация
За основу взята аналогичная функция от форума SMF2.0
-----------------------------------------------------------------
*/
public static function display_pagination($base_url, $start, $max_value, $num_per_page)
{
$neighbors = 2;
if ($start >= $max_value)
$start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
else
$start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
$base_link = '<a class="pagenav" href="' . strtr($base_url, array('%' => '%%')) . 'page=%d' . '">%s</a>';
$out[] = $start == 0 ? '' : sprintf($base_link, $start / $num_per_page, 'Prev');
if ($start > $num_per_page * $neighbors)
$out[] = sprintf($base_link, 1, '1');
if ($start > $num_per_page * ($neighbors + 1))
$out[] = '<span style="font-weight: bold;">...</span>';
for ($nCont = $neighbors; $nCont >= 1; $nCont--)
if ($start >= $num_per_page * $nCont) {
$tmpStart = $start - $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
$out[] = '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span>';
$tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;
for ($nCont = 1; $nCont <= $neighbors; $nCont++)
if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
$tmpStart = $start + $num_per_page * $nCont;
$out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
}
if ($start + $num_per_page * ($neighbors + 1) < $tmpMaxPages)
$out[] = '<span style="font-weight: bold;">...</span>';
if ($start + $num_per_page * $neighbors < $tmpMaxPages)
$out[] = sprintf($base_link, $tmpMaxPages / $num_per_page + 1, $tmpMaxPages / $num_per_page + 1);
if ($start + $num_per_page < $max_value) {
$display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start / $num_per_page + 2);
$out[] = sprintf($base_link, $display_page, 'Next');
}
return implode(' ', $out);
}
/*
-----------------------------------------------------------------
Показываем местоположение пользователя
-----------------------------------------------------------------
*/
public static function display_place($user_id = '', $place = '')
{
global $headmod;
$place = explode(",", $place);
$placelist = parent::load_lng('places');
if (array_key_exists($place[0], $placelist)) {
if ($place[0] == 'profile') {
if ($place[1] == $user_id) {
return '<a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $place[1] . '">' . $placelist['profile_personal'] . '</a>';
} else {
$user = self::get_user($place[1]);
return $placelist['profile'] . ': <a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $user['id'] . '">' . $user['name'] . '</a>';
}
}
elseif ($place[0] == 'online' && isset($headmod) && $headmod == 'online') return $placelist['here'];
else return str_replace('#home#', self::$system_set['homeurl'], $placelist[$place[0]]);
}
else return '<a href="' . self::$system_set['homeurl'] . '/index.php">' . $placelist['homepage'] . '</a>';
}
/*
-----------------------------------------------------------------
Отображения личных данных пользователя
-----------------------------------------------------------------
$user          (array)     массив запроса в таблицу `users`
$arg           (array)     Массив параметров отображения
[lastvisit] (boolean)   Дата и время последнего визита
[stshide]   (boolean)   Скрыть статус (если есть)
[iphide]    (boolean)   Скрыть (не показывать) IP и UserAgent
[iphist]    (boolean)   Показывать ссылку на историю IP
[header]    (string)    Текст в строке после Ника пользователя
[body]      (string)    Основной текст, под ником пользователя
[sub]       (string)    Строка выводится вверху области "sub"
[footer]    (string)    Строка выводится внизу области "sub"
-----------------------------------------------------------------
*/
public static function display_user($user = false, $arg = false)
{
global $rootpath, $mod;
$out = false;
if (!$user['id']) {
$out = '<b>' . self::$lng['guest'] . '</b>';
if (!empty($user['name']))
$out .= ': ' . $user['name'];
if (!empty($arg['header']))
$out .= ' ' . $arg['header'];
} else {
if (self::$user_set['avatar']) {
$out .= '<table cellpadding="0" cellspacing="0"><tr><td>';
if (file_exists(($rootpath . 'files/users/avatar/' . $user['id'] . '.png')))
$out .= '<span class="avatar"><img src="' . self::$system_set['homeurl'] . '/files/users/avatar/' . $user['id'] . '.png" width="32" height="32" alt="" /></span>&#160;';
else
$out .= '<span class="avatar"><img src="' . self::$system_set['homeurl'] . '/images/empty.png" width="32" height="32" alt="" /></span>&#160;';
$out .= '</td><td>';
}
if ($user['sex'])
$out .= '<img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/' . ($user['sex'] == 'm' ? 'm' : 'w') . ($user['datereg'] > time() - 86400 ? '_new' : '')
. '.png" width="16" height="16" align="middle" alt="' . ($user['sex'] == 'm' ? 'М' : 'Ж') . '" />&#160;';
else
$out .= '<img src="' . self::$system_set['homeurl'] . '/images/del.png" width="12" height="12" align="middle" />&#160;';
if ($user['rights'] == 0 ) {
$colornick['colornick'] = '000000';
$colornickk['colornick'] = '000000';
}
if ($user['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
$colornickk['colornick'] = 'FFD700';
}
if ($user['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
$colornickk['colornick'] = '7192a8';
}
if ($user['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
$colornickk['colornick'] = '0000FF';
}
if ($user['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
$colornickk['colornick'] = '40E000';
}
if ($user['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
$colornickk['colornick'] = '40E000';
}
if ($user['rights'] == 6 ) {
$colornick['colornick'] = '228622';
$colornickk['colornick'] = '228622';
}
if ($user['rights'] == 7 ) {
$colornick['colornick'] = '860086';
$colornickk['colornick'] = '860086';
}
if ($user['rights'] == 8 ) {
$colornick['colornick'] = 'ff0000';
$colornickk['colornick'] = 'ff0000';
}
if ($user['rights'] == 9 ) {
$colornick['colornick'] = 'ff0000';
$colornickk['colornick'] = 'ff0000';
}
if ($user['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
$colornickk['colornick'] = '7192a8';
}
if ($user['rights'] == 9 ) {
$out .= !$user_id || $user_id == $user['id'] ? '<a
href="../users/' . $user['name'] . '"><span style="color:
rgb(255, 0, 0); background: url(/images/6.gif) repeat scroll 0% 0%
transparent;" border="0"><b>' . $user['name'] . '
</b></span></a>' : '<a href="../users/' . $user['name'] . '"><span style="color: rgb(255, 0, 0); background:
url(/images/6.gif) repeat scroll 0% 0% transparent;"
border="0"><b>' . $user['name'] . ' </b></span></a>';
}else {
$out .= !$user_id || $user_id == $user['id'] ? '<a
href="../users/' . $user['name'] . '"><span
style="color:#' . $colornick['colornick'] . '"><b>' . $user['name'] . '
</b></span></a>' : '<a href="../users/' . $user['name'] . '"><span style="color:#' . $colornickk['colornick'] .
'"><b>' . $user['name'] . ' </b></span></a>';
}
$out .= ' ' . $rank[$user['rights']];
/*$rank = array(
0 => '',
1 => '(GMod)',
2 => '(CMod)',
3 => '(FMod)',
4 => '(DMod)',
5 => '(LMod)',
6 => '(Smd)',
7 => '(Adm)',
9 => '(SV!)'
);*/
$out .= ' ' . $rank[$user['rights']];
//$out .= (time() > $user['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');
if (!empty($arg['header']))
$out .= ' ' . $arg['header'];
if (!isset($arg['stshide']) && !empty($user['status']))
$out .= '<div class="status"><img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/label.png" alt="" align="middle" />&#160;' . $user['status'] . '</div>';
if (self::$user_set['avatar'])
$out .= '</td></tr></table>';
}
if (isset($arg['body']))
$out .= '<div>' . $arg['body'] . '</div>';
$ipinf = !isset($arg['iphide']) && (self::$user_rights || ($user['id'] && $user['id'] == self::$user_id)) ? 1 : 0;
$lastvisit = time() > $user['lastdate'] + 300 && isset($arg['lastvisit']) ? self::display_date($user['lastdate']) : false;
if ($ipinf || $lastvisit || isset($arg['sub']) && !empty($arg['sub']) || isset($arg['footer'])) {
$out .= '<div class="sub">';
if (isset($arg['sub']))
$out .= '<div>' . $arg['sub'] . '</div>';
if ($lastvisit)
$out .= '<div><span class="gray">' . self::$lng['last_visit'] . ':</span> ' . $lastvisit . '</div>';
$iphist = '';
if ($ipinf) {
$out .= '<div><span class="gray">' . self::$lng['browser'] . ':</span> ' . $user['browser'] . '</div>' .
'<div><span class="gray">' . self::$lng['ip_address'] . ':</span> ';
$hist = $mod == 'history' ? '&amp;mod=history' : '';
$ip = long2ip($user['ip']);
if (self::$user_rights && isset($user['ip_via_proxy']) && $user['ip_via_proxy']) {
$out .= '<b class="red"><a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a></b> / ';
$out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($user['ip_via_proxy']) . $hist . '">' . long2ip($user['ip_via_proxy']) . '</a>';
} elseif (self::$user_rights) {
$out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a>';
} else {
$out .= $ip . $iphist;
}
if (isset($arg['iphist'])) {
$iptotal = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_users_iphistory` WHERE `user_id` = '" . $user['id'] . "'"), 0);
$out .= '<div><span class="gray">' . self::$lng['ip_history'] . ':</span> <a href="' . self::$system_set['homeurl'] . '/users/profile.php?act=ip&amp;user=' . $user['id'] . '">[' . $iptotal . ']</a></div>';
}
$out .= '</div>';
}
if (isset($arg['footer']))
$out .= $arg['footer'];
$out .= '</div>';
}
return $out;
}
/*
-----------------------------------------------------------------
Форматирование имени файла
-----------------------------------------------------------------
*/
public static function format($name)
{
$f1 = strrpos($name, ".");
$f2 = substr($name, $f1 + 1, 999);
$fname = strtolower($f2);
return $fname;
}
/*
-----------------------------------------------------------------
Получаем данные пользователя
-----------------------------------------------------------------
*/
public static function get_user($id = false)
{
if ($id && $id != self::$user_id) {
$req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id'");
if (mysql_num_rows($req)) {
return mysql_fetch_assoc($req);
} else {
return false;
}
} else {
return self::$user_data;
}
}
/*
-----------------------------------------------------------------
Транслитерация с � усского в латиницу
-----------------------------------------------------------------
*/
public static function rus_lat($str)
{
$replace = array(
'а' => 'a',
'б' => 'b',
'в' => 'v',
'г' => 'g',
'д' => 'd',
'е' => 'e',
'ё' => 'e',
'ж' => 'j',
'з' => 'z',
'и' => 'i',
'й' => 'i',
'к' => 'k',
'л' => 'l',
'м' => 'm',
'н' => 'n',
'о' => 'o',
'п' => 'p',
'р' => 'r',
'с' => 's',
'т' => 't',
'у' => 'u',
'ф' => 'f',
'х' => 'h',
'ц' => 'c',
'ч' => 'ch',
'ш' => 'sh',
'щ' => 'sch',
'ъ' => "",
'ы' => 'y',
'ь' => "",
'э' => 'ye',
'ю' => 'yu',
'я' => 'ya'
);
return strtr($str, $replace);
}
/*
-----------------------------------------------------------------
Обработка смайлов
-----------------------------------------------------------------
*/
private static $smileys_cache = array();
public static function smileys($str, $adm = false)
{
global $rootpath;
if (empty(self::$smileys_cache)) {
$file = $rootpath . 'files/cache/smileys.dat';
if (file_exists($file) && ($smileys = file_get_contents($file)) !== false) {
self::$smileys_cache = unserialize($smileys);
return strtr($str, ($adm ? array_merge(self::$smileys_cache['usr'], self::$smileys_cache['adm']) : self::$smileys_cache['usr']));
} else {
return $str;
}
} else {
return strtr($str, ($adm ? array_merge(self::$smileys_cache['usr'], self::$smileys_cache['adm']) : self::$smileys_cache['usr']));
}
}
/*
-----------------------------------------------------------------
Функция пересчета на дни, или часы
-----------------------------------------------------------------
*/
public static function timecount($var)
{
global $lng;
if ($var < 0) $var = 0;
$day = ceil($var / 86400);
if ($var > 345600) return $day . ' ' . $lng['timecount_days'];
if ($var >= 172800) return $day . ' ' . $lng['timecount_days_r'];
if ($var >= 86400) return '1 ' . $lng['timecount_day'];
return date("G:i:s", mktime(0, 0, $var));
}
/*
-----------------------------------------------------------------
?????????????? ??????
-----------------------------------------------------------------
*/
public static function nhanhnao($text)
{
$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
$text=str_replace(" ","-", $text);$text=str_replace("--","-", $text);
$text=str_replace("@","-",$text);$text=str_replace("/","-",$text);
$text=str_replace("\\","-",$text);$text=str_replace(":","",$text);
$text=str_replace("\"","",$text);$text=str_replace("'","",$text);
$text=str_replace("<","",$text);$text=str_replace(">","",$text);
$text=str_replace(",","",$text);$text=str_replace("?","",$text);
$text=str_replace(";","",$text);$text=str_replace(".","",$text);
$text=str_replace("[","",$text);$text=str_replace("]","",$text);
$text=str_replace("(","",$text);$text=str_replace(")","",$text);
$text=str_replace("�","", $text);
$text=str_replace("`","", $text);
$text=str_replace("~","", $text);
$text=str_replace("?","", $text);
$text=str_replace("?","", $text);
$text=str_replace("*","",$text);$text=str_replace("!","",$text);
$text=str_replace("$","-",$text);$text=str_replace("&","-and-",$text);
$text=str_replace("%","",$text);$text=str_replace("#","",$text);
$text=str_replace("^","",$text);$text=str_replace("=","",$text);
$text=str_replace("+","",$text);$text=str_replace("~","",$text);
$text=str_replace("`","",$text);$text=str_replace("--","-",$text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|a|?|?|?|?|?)/", 'a', $text);
$text = preg_replace("/(a`|a�|a?|a?|a~|�|�`|�|�?|�?|�~|a|a`|a�|a?|a?|a~)/", 'a', $text);
$text = preg_replace("/(�|�|?|?|?|�|?|?|?|?|?)/", 'e', $text);
$text = preg_replace("/(e`|e�|e?|e?|e~|�|�`|�|�?|�?|�~)/", 'e', $text);
$text = preg_replace("/(�|�|?|?|i)/", 'i', $text);
$text = preg_replace("/(i`|i�|i?|i?|i~)/", 'i', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|o|?|?|?|?|?)/", 'o', $text);
$text = preg_replace("/(o`|o�|o?|o?|o~|�|�`|��|�?|�?|�~|o|o`|o�|o?|o?|o~)/", 'o', $text);
$text = preg_replace("/(�|�|?|?|u|u|?|?|?|?|?)/", 'u', $text);
$text = preg_replace("/(u`|u�|u?|u?|u~|u|u`|u�|u?|u?|u~)/", 'u', $text);
$text = preg_replace("/(?|�|?|?|?)/", 'y', $text);
$text = preg_replace("/(d)/", 'd', $text);
$text = preg_replace("/(y`|y�|y?|y?|y~)/", 'y', $text);
$text = preg_replace("/(d)/", 'd', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|A|?|?|?|?|?)/", 'A', $text);
$text = preg_replace("/(A`|A�|A?|A?|A~|�|�`|´|�?|�?|�~|A|A`|A�|A?|A?|A~)/", 'A', $text);
$text = preg_replace("/(�|�|?|?|?|�|?|?|?|?|?)/", 'E', $text);
$text = preg_replace("/(E`|E�|E?|E?|E~|�|�`|ʴ|�?|�?|�~)/", 'E', $text);
$text = preg_replace("/(�|�|?|?|I)/", 'I', $text);
$text = preg_replace("/(I`|I�|I?|I?|I~)/", 'I', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|O|?|?|?|?|?)/", 'O', $text);
$text = preg_replace("/(O`|O�|O?|O?|O~|�|�`|Դ|�?|�?|�~|O|O`|O�|O?|O?|O~)/", 'O', $text);
$text = preg_replace("/(�|�|?|?|U|U|?|?|?|?|?)/", 'U', $text);
$text = preg_replace("/(U`|U�|U?|U?|U~|U|U`|U�|U?|U?|U~)/", 'U', $text);
$text = preg_replace("/(?|�|?|?|?)/", 'Y', $text);
$text = preg_replace("/(�)/", 'D', $text);
$text = preg_replace("/(Y`|Y�|Y?|Y?|Y~)/", 'Y', $text);
$text = preg_replace("/(�)/", 'D', $text);
$text=strtolower($text);
return $text;
}
function rwurl($text){
$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
$text=str_replace(" ","-", $text);
$text=str_replace("@","-",$text);
$text=str_replace("/","-",$text);
$text=str_replace("{","",$text);
$text=str_replace("}","",$text);
$text=str_replace("\\","-",$text);
$text=str_replace(":","",$text);
$text=str_replace("\"","",$text);
$text=str_replace("'","",$text);
$text=str_replace("<","",$text);
$text=str_replace(">","",$text);
$text=str_replace(",","",$text);
$text=str_replace("?","",$text);
$text=str_replace(";","",$text);
$text=str_replace(".","",$text);
$text=str_replace("[","",$text);
$text=str_replace("]","",$text);
$text=str_replace("(","",$text);
$text=str_replace(")","",$text);
$text=str_replace("*","",$text);
$text=str_replace("!","",$text);
$text=str_replace("$","-",$text);
$text=str_replace("&","-and-",$text);
$text=str_replace("%","",$text);
$text=str_replace("#","",$text);
$text=str_replace("^","",$text);
$text=str_replace("=","",$text);
$text=str_replace("+","",$text);
$text=str_replace("~","",$text);
$text=str_replace("`","",$text);
$text=str_replace("--","-",$text);
$text=str_replace("--","-",$text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|a|?|?|?|?|?)/", 'a', $text);
$text = preg_replace("/(a`|a�|a?|a?|a~|�|�`|�|�?|�?|�~|a|a`|a�|a?|a?|a~)/", 'a', $text);
$text = preg_replace("/(�|�|?|?|?|�|?|?|?|?|?)/", 'e', $text);
$text = preg_replace("/(e`|e�|e?|e?|e~|�|�`|�|�?|�?|�~)/", 'e', $text);
$text = preg_replace("/(�|�|?|?|i)/", 'i', $text);
$text = preg_replace("/(i`|i�|i?|i?|i~)/", 'i', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|o|?|?|?|?|?)/", 'o', $text);
$text = preg_replace("/(o`|o�|o?|o?|o~|�|�`|��|�?|�?|�~|o|o`|o�|o?|o?|o~)/", 'o', $text);
$text = preg_replace("/(�|�|?|?|u|u|?|?|?|?|?)/", 'u', $text);
$text = preg_replace("/(u`|u�|u?|u?|u~|u|u`|u�|u?|u?|u~)/", 'u', $text);
$text = preg_replace("/(?|�|?|?|?)/", 'y', $text);
$text = preg_replace("/(d)/", 'd', $text);
$text = preg_replace("/(y`|y�|y?|y?|y~)/", 'y', $text);
$text = preg_replace("/(d)/", 'd', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|A|?|?|?|?|?)/", 'A', $text);
$text = preg_replace("/(A`|A�|A?|A?|A~|�|�`|´|�?|�?|�~|A|A`|A�|A?|A?|A~)/", 'A', $text);
$text = preg_replace("/(�|�|?|?|?|�|?|?|?|?|?)/", 'E', $text);
$text = preg_replace("/(E`|E�|E?|E?|E~|�|�`|ʴ|�?|�?|�~)/", 'E', $text);
$text = preg_replace("/(�|�|?|?|I)/", 'I', $text);
$text = preg_replace("/(I`|I�|I?|I?|I~)/", 'I', $text);
$text = preg_replace("/(�|�|?|?|�|�|?|?|?|?|?|O|?|?|?|?|?)/", 'O', $text);
$text = preg_replace("/(O`|O�|O?|O?|O~|�|�`|Դ|�?|�?|�~|O|O`|O�|O?|O?|O~)/", 'O', $text);
$text = preg_replace("/(�|�|?|?|U|U|?|?|?|?|?)/", 'U', $text);
$text = preg_replace("/(U`|U�|U?|U?|U~|U|U`|U�|U?|U?|U~)/", 'U', $text);
$text = preg_replace("/(?|�|?|?|?)/", 'Y', $text);
$text = preg_replace("/(�)/", 'D', $text);
$text = preg_replace("/(Y`|Y�|Y?|Y?|Y~)/", 'Y', $text);
$text = preg_replace("/(�)/", 'D', $text);
$text=strtolower($text);
return $text;
}
function untags($var = '') {
$var = preg_replace('#\[b\](.*?)\[/b\]#si', '\1', $var);
$var = preg_replace('#\[i\](.*?)\[/i\]#si', '\1', $var);
$var = preg_replace('#\[u\](.*?)\[/u\]#si', '\1', $var);
$var = preg_replace('#\[s\](.*?)\[/s\]#si', '\1', $var);
$var = preg_replace('#\[red\](.*?)\[/red\]#si', '\1', $var);
$var = preg_replace('#\[green\](.*?)\[/green\]#si', '\1', $var);
$var = preg_replace('#\[blue\](.*?)\[/blue\]#si', '\1', $var);
$var = preg_replace('#\[c\](.*?)\[/c\]#si', '\1', $var);
$var = preg_replace('#\[img=(.+?)\]#is', '', $var);
$var = preg_replace('#\[img](.+?)\[/img]#is', '', $var);
$var = preg_replace('#\[img=(.+?)\][/img]#is', '', $var);
$var = preg_replace("#\[url=(.+?)\](.+?)\[/url\]#is", "", $var );
$var = preg_replace("#\[URL=(.+?)\](.+?)\[/URL\]#is", "", $var );
$var = preg_replace('#\[COLOR=(.+?)\](.+?)\[/COLOR\]#is', '\2', $var );
$var = preg_replace('#\[color=(.+?)\](.+?)\[/color\]#is', '\2', $var );
$var = preg_replace('#\[SIZE=(.+?)\](.+?)\[/SIZE\]#is', '\2', $var );
$var = preg_replace('#\[size=(.+?)\](.+?)\[/size\]#is', '\2', $var );
$var = preg_replace('#\[FONT=(.+?)\](.+?)\[/FONT\]#is', '\2', $var );
$var = preg_replace('#\[font=(.+?)\](.+?)\[/font\]#is', '\2', $var );
$var = preg_replace("#\[url\](.+?)\[/url\]#is", "", $var );
$var = preg_replace('#\[phai\](.+?)\[/phai\]#is', '\1', $var );
$var = preg_replace('#\[center\](.+?)\[/center\]#is', '\1', $var );
$var = preg_replace('#\[CENTER\](.+?)\[/CENTER\]#is', '\1', $var );
$var = preg_replace('#\[LEFT\](.+?)\[/LEFT\]#is', '\1', $var );
$var = preg_replace('#\[left\](.+?)\[/left\]#is', '\1', $var );
$var = preg_replace('#\[right\](.+?)\[/right\]#is', '\1', $var );
$var = preg_replace('#\[RIGHT\](.+?)\[/RIGHT\]#is', '\1', $var );
$var = preg_replace('#\[trai\](.+?)\[/trai\]#is', '\1', $var );
$var = preg_replace('#\[giua\](.+?)\[/giua\]#is', '\1', $var );
return $var;
}
function tags($var = '') {
$var = preg_replace('#\[b\](.*?)\[/b\]#si', '\1', $var);
$var = preg_replace('#\[i\](.*?)\[/i\]#si', '\1', $var);
$var = preg_replace('#\[u\](.*?)\[/u\]#si', '\1', $var);
$var = preg_replace('#\[s\](.*?)\[/s\]#si', '\1', $var);
$var = preg_replace('#\[red\](.*?)\[/red\]#si', '\1', $var);
$var = preg_replace('#\[orange\](.*?)\[/orange\]#si', '\1', $var);
$var = preg_replace('#\[black\](.*?)\[/black\]#si', '\1', $var);
$var = preg_replace('#\[green\](.*?)\[/green\]#si', '\1', $var);
$var = preg_replace('#\[blue\](.*?)\[/blue\]#si', '\1', $var);
$var = preg_replace('#\[olive\](.*?)\[/olive\]#si', '\1', $var);
$var = preg_replace('#\[pink\](.*?)\[/pink\]#si', '\1', $var);
$var = preg_replace('#\[lime\](.*?)\[/lime\]#si', '\1', $var);
$var = preg_replace('#\[yellow\](.*?)\[/yellow\]#si', '\1', $var);
$var = preg_replace('#\[purple\](.*?)\[/purple\]#si', '\1', $var);
$var = preg_replace('#\[navy\](.*?)\[/navy\]#si', '\1', $var);
$var = preg_replace('#\[gray\](.*?)\[/gray\]#si', '\1', $var);
$var = preg_replace('#\[c\](.*?)\[/c\]#si', '<b>[\1]</b><br/>', $var);
$var = preg_replace('#\[COLOR=(.+?)\](.+?)\[/COLOR\]#is', '\2', $var );
$var = preg_replace('#\[color=(.+?)\](.+?)\[/color\]#is', '\2', $var );
$var = preg_replace('#\[SIZE=(.+?)\](.+?)\[/SIZE\]#is', '\2', $var );
$var = preg_replace('#\[size=(.+?)\](.+?)\[/size\]#is', '\2', $var );
$var = preg_replace('#\[FONT=(.+?)\](.+?)\[/FONT\]#is', '\2', $var );
$var = preg_replace('#\[font=(.+?)\](.+?)\[/font\]#is', '\2', $var );
$var = preg_replace('#\[phai\](.+?)\[/phai\]#is', '\1', $var );
$var = preg_replace('#\[center\](.+?)\[/center\]#is', '\1', $var );
$var = preg_replace('#\[CENTER\](.+?)\[/CENTER\]#is', '\1', $var );
$var = preg_replace('#\[LEFT\](.+?)\[/LEFT\]#is', '\1', $var );
$var = preg_replace('#\[left\](.+?)\[/left\]#is', '\1', $var );
$var = preg_replace('#\[right\](.+?)\[/right\]#is', '\1', $var );
$var = preg_replace('#\[RIGHT\](.+?)\[/RIGHT\]#is', '\1', $var );
$var = preg_replace('#\[trai\](.+?)\[/trai\]#is', '\1', $var );
$var = preg_replace('#\[giua\](.+?)\[/giua\]#is', '\1', $var );
$var = preg_replace('#\[php\](.*?)\[\/php\]#se',  '\1', $var);
$var = preg_replace('#\[sub\](.*?)\[/sub\]#si', '\1', $var);
$var = preg_replace('#\[sup\](.*?)\[/sup\]#si', '\1', $var);
$var = preg_replace('#\[offtop\](.*?)\[/offtop\]#si', '\1', $var);
$var = preg_replace('#\[\*\]#si', '', $var);
$var = preg_replace('#\[hr\]#si', '', $var);
$var = preg_replace('#\[img=(.+?)\]#is', '\1', $var);
$var = preg_replace('#\[img](.+?)\[/img]#is', '\1', $var);
$var = preg_replace('#\[img=(.+?)\][/img]#is', '\1', $var);
$var = preg_replace("#\[url=(.+?)\](.+?)\[/url\]#is", "<a href=\"\\1\">\\2</a>", $var );
$var = preg_replace("#\[URL=(.+?)\](.+?)\[/URL\]#is", "<a href=\"\\1\">\\2</a>", $var );
$var = preg_replace("#\[url\](.+?)\[/url\]#is", "<a href=\"\\1\">\\1</a>", $var );
$var = preg_replace('#\[black\](.*?)\[/black\]#si', '\1', $var);
$var = preg_replace('#\[violet\](.*?)\[/violet\]#si', '\1', $var);
$var = preg_replace('#\[pink\](.*?)\[/pink\]#si', '\1', $var);
$var = preg_replace('#\[yellow\](.*?)\[/yellow\]#si', '\1', $var);
$var = preg_replace('#\[brown\](.*?)\[/brown\]#si', '\1', $var);
$var = preg_replace('#\[khaki\](.*?)\[/khaki\]#si', '\1', $var);
$var = preg_replace('#\[orange\](.*?)\[/orange\]#si', '\1', $var);
$var = preg_replace('#\[gold\](.*?)\[/gold\]#si', '\1', $var);
$var = preg_replace('#\[olive\](.*?)\[/olive\]#si', '\1', $var);
$var = preg_replace('#\[skyblue\](.*?)\[/skyblue\]#si', '\1', $var);
$var = preg_replace('#\[indigo\](.*?)\[/indigo\]#si', '\1', $var);
$var = preg_replace('#\[sienna\](.*?)\[/sienna\]#si', '\1', $var);
$var = preg_replace('#\[peru\](.*?)\[/peru\]#si', '\1', $var);
$var = preg_replace('#\[do\](.*?)\[/do\]#si', '\1', $var);
return $var;
}
/*
-----------------------------------------------------------------
Функция пересчета на дни, или часы
-----------------------------------------------------------------
*/
function update_time($jam) {
global $realtime, $lng, $set_user;
$waktu = $jam + ($set_user['sdvig'] * 3600);
$lama=round((time()-$waktu)/60);
if($lama==0){
$lama= $lng['few_second_ago'];
}
if($lama >0 && $lama < 60){
$lama= $lama . ' ' . $lng['minutes_ago'];
}
if($lama>=60 && $lama<120){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=120 && $lama<180){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];}
if($lama>=180 && $lama<240){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=240 && $lama<300){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=300 && $lama<360){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=360 && $lama<420){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=420 && $lama<480){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=480 && $lama<540){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=540 && $lama<600){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=600 && $lama<660){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=660 && $lama<720){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=720 && $lama<780){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=780 && $lama<820){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=820 && $lama<880){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=880 && $lama<920){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=920 && $lama<980){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=980 && $lama<1020){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1020 && $lama<1080){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1080 && $lama<1140){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1140 && $lama<1200){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1200 && $lama<1260){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1260 && $lama<1320){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1320 && $lama<1380){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
if($lama>=1380 && $lama<1440){
$lama=round($lama/60);
$lama=$lama . ' ' . $lng['hours_ago'];
}
// Jika lebih dari 24 jam
if($lama>=1440 && $lama<2880){
$lama=round($lama/60/24); $lama=$lng['yesterday'];
}
// Jika lebih dari 48 jam
if($lama>=2880){
$lama = date("F d h:ia", $waktu);
}
return $lama;
}
/*
-----------------------------------------------------------------
Транслитерация текста
-----------------------------------------------------------------
*/
public static function trans($str)
{
$replace = array(
'a' => 'а',
'b' => 'б',
'v' => 'в',
'g' => 'г',
'd' => 'д',
'e' => 'е',
'yo' => 'ё',
'zh' => 'ж',
'z' => 'з',
'i' => 'и',
'j' => 'й',
'k' => 'к',
'l' => 'л',
'm' => 'м',
'n' => 'н',
'o' => 'о',
'p' => 'п',
'r' => 'р',
's' => 'с',
't' => 'т',
'u' => 'у',
'f' => 'ф',
'h' => 'х',
'c' => 'ц',
'ch' => 'ч',
'w' => 'ш',
'sh' => 'щ',
'q' => 'ъ',
'y' => 'ы',
'x' => 'э',
'yu' => 'ю',
'ya' => 'я',
'A' => 'А',
'B' => 'Б',
'V' => 'В',
'G' => 'Г',
'D' => 'Д',
'E' => 'Е',
'YO' => 'Ё',
'ZH' => 'Ж',
'Z' => 'З',
'I' => 'И',
'J' => 'Й',
'K' => 'К',
'L' => 'Л',
'M' => 'М',
'N' => 'Н',
'O' => 'О',
'P' => 'П',
'R' => '� ',
'S' => 'С',
'T' => 'Т',
'U' => 'У',
'F' => 'Ф',
'H' => 'Х',
'C' => 'Ц',
'CH' => 'Ч',
'W' => 'Ш',
'SH' => 'Щ',
'Q' => 'Ъ',
'Y' => 'Ы',
'X' => 'Э',
'YU' => 'Ю',
'YA' => 'Я'
);
return strtr($str, $replace);
}
function nickcolor($id, $mod = false) {
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'"));
if($ban > 0) {
$out .= '<font color="black">'.($mod == 1 ? '<small>' : '<b>').'<s>' . $user['name'] . '</s>'.($mod == 1 ? '</small>' : '</b>').'</font>';
} else {
if($user['rights'] > 1) {
if($user['rights'] == 2) {$font = '<font color="#7192a8">';}
if($user['rights'] == 3) {$font = '<font color="#0000FF">';}
if($user['rights'] > 4) {$font = '<font color="#40E000">';}
if($user['rights'] == 5) {$font = '<font color="#40E000">';}
if($user['rights'] == 6) {$font = '<font color="#228622">';}
if($user['rights'] == 7) {$font = '<font color="#860086">';}
if($user['rights'] == 8) {$font = '<font color="#FF0000">';}
if($user['rights'] == 9) {$font = '<font color="#FF0000">';}
if($user['rights'] == 10) {$font = '<font color="#7192a8">';}
$out .= ''.$font.'' . $user['name'] . '</font>';
} else {
$out .= '<font color="black">' . $user['name'] . '</font>';
}
}
return $out;
}
}
?>
