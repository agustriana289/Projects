<?php
echo '<td class="prus-left">';
require($rootpath . 'incfiles/menu.php');
echo '</td><td class="prus-center">';

?>