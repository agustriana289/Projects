<?php



defined('_IN_JOHNCMS') or die('Error: restricted access');

//web
if(!$is_mobile)

{
echo '</td>';
require($rootpath . 'incfiles/right.php');

echo '</tr></table>';
}
if (!empty($cms_ads[2]))
echo '<div class="gmenu">' . $cms_ads[2] . '</div>';

echo '</div><div>';
echo '<div style="text-align:center">';
require($rootpath . 'incfiles/seo.php');

functions::display_counters();
if (!empty($cms_ads[3]))
echo '<br />' . $cms_ads[3];

echo '</div></div></div></div></div><div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
$time = microtime();
$time = explode(' ', $time);
$time = $time[0] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 3);
echo 'Page: '.$total_time.' sec';
echo '</td><td width="auto" align="right">';
$Contents = ob_get_contents();
$gzib_file = strlen($Contents);
$gzib_file_out = strlen(gzcompress($Contents, 9));
$gzib_pro = round(100 - (100 / ($gzib_file / $gzib_file_out)), 1);
echo 'Gzip: ' . $gzib_pro . '%';
echo '</a></td></tr></table></div>';
//////////////////////////////////////////////////////////////www.susukan.us
//////////////////////////////////////////////////////////////functions::display_counters();
//////////////////////////////////////////////////////////////www.chapink.com
//////////////////////////////////////////////////////////////if (!empty($cms_ads[3]))
echo '<div style="text-align:center">' . $cms_ads[3];

/*
-----------------------------------------------------------------
www.indoboox.us

ATTENTION!!!
The copyright could not be removed within 60 days of installation scripts
-----------------------------------------------------------------
*/

echo '<div style="text-align:center"><div class="header">';
if($user_id){
echo '<b><a href="/constitution">TOS</a> | <a name="down" id="down"></a><a href="#up"><img src="../theme/' . $set_user['skin'] . '/images/up.png"/></a> | <a href="pages/faq.php">FAQ</a></b>';
}
echo '<div><a href="http://www.indowaptop.tk/go.php?id=2"><img src="http://www.indowaptop.tk/image.php?id=2" alt="Indowaptop - [ID]"/></a><br><small>&copy; ' . date('Y') . ' ' . $set['copyright'] . '</small><div>';
echo '<div><small>Powered by <a href="http://www.susukan.us">Susukan.Us - [ID]</a></small></div>';
echo '</div></body></html>';
