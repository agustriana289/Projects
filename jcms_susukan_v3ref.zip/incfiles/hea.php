<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
define('PHP_FIREWALL_REQUEST_URI', strip_tags($_SERVER['REQUEST_URI']));
define('PHP_FIREWALL_ACTIVATION', false);
if (file_exists('../php-firewall/firewall.php'))
include_once('../php-firewall/firewall.php');
include'source.php';
include 'ksantiddos.php';
$ksa = new ksantiddos();
$ksa->doit(15,10);
$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];
$statistic = new statistic($textl);
/*
-----------------------------------------------------------------
??????? HTML ????????? ????????, ?????????? CSS ????
-----------------------------------------------------------------
*/
if(stristr(core::$user_agent, "msie") && stristr(core::$user_agent, "windows")){
// ?????? ????????? ??? Internet Explorer
//header("Cache-Control: no-store, no-cache, must-revalidate");
//header('Content-type: text/html; charset=UTF-8');
} else {
// ?????? ????????? ??? ????????? ?????????
//header("Cache-Control: public");
//header('Content-type: application/xhtml+xml; charset=UTF-8');
}
echo '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
"\n" . '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' .
"\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">' .
"\n" . '<head>' .
"\n" . '<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>' .
"\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
"\n" . '<meta name="msvalidate.01" content="78D04B66C886783CCDD5171
345ADBE21" />' . // ????????!!! ?????? ???????? ??????? ??????
(!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
(!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
"\n" . '<link rel="stylesheet" href="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/style.css" type="text/css" />' .
"\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico" />' .
"\n" . '<title>' . bbcode::notags($textl) . '</title>' .
"\n" . '</head><body>' . core::display_core_errors();
if(!$is_mobile)
{
echo '<style TYPE="text/css">
<!--.social{background-color:#696969;}.social{background-color:#696969;}-->
</style>';}
/*
-----------------------------------------------------------------
????????? ??????
-----------------------------------------------------------------
*/
$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
$view = $user_id ? 2 : 1;
$layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
$req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
if (mysql_num_rows($req)) {
while (($res = mysql_fetch_assoc($req)) !== false) {
$name = explode("|", $res['name']);
$name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
// ???? ???? ?????? ?????????? ??????, ?? ?????????
$font = $res['bold'] ? 'font-weight: bold;' : false;
$font .= $res['italic'] ? ' font-style:italic;' : false;
$font .= $res['underline'] ? ' text-decoration:underline;' : false;
if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
@$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
}
}
}
/*
-----------------------------------------------------------------
????????? ???? ?????
-----------------------------------------------------------------
*/
if (isset($cms_ads[0])) echo $cms_ads[0];
/*
-----------------------------------------------------------------
??????? ??????? ? ????????????? ??????
-----------------------------------------------------------------
*/
if (!$is_mobile){ include 'sirah.php';}
if($is_mobile)
{
if ($headmod == 'mainpage') {
echo '<style>
<!--
.social{background-color:#696969;}.social{background-color:#696969;}-->
</style>
</head>
<body>
<div align="center">
<div class="social">
<a href="http://www.facebook.com/sharer.php?u=http://mtuner.tk" style="color: #fe9b00; text-decoration: none">
<img src="/images/bfacebook.png" alt="fb" style="max-width: 100%; vertical-align: middle; border-style: none" width="32" height="16"></a>
<a style="color: #fe9b00; text-decoration: none" href="http://twitter.com/share?via=real80don&text=www.mtuner.tk ::: BD- Best Wapmaster Forum::: http://mtuner.tk">
<img src="/images/btwitter.png" alt="twtr" style="max-width: 100%; vertical-align: middle; border-style: none" width="32" height="16"></a> </div>
</div>';}
echo '<table width="100%" valign="top" class="nfooter">';
echo'<td width="90%" valign="top" align="left"><a href="' . $set['homeurl'] . '"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/logo.png" width="90" hieght="4" alt="mtuner" /></a></td>';}
/*
-----------------------------------------------------------------
??????? ??????? ???? ? ????????????
-----------------------------------------------------------------
*/
if($is_mobile)
{
echo '<td width="10%" align="right">' . ($user_id ? '<b><a href=/users/profile.php>' . $login . '</b>!</a>' : $lng['guest'] . '!') . '' .
($headmod == 'mainpage' && count(core::$lng_list) > 1 ? ' &#183;
<a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</a>' : '') .
'';
//////////////
echo '</td></table>';
}
if(!$is_mobile)
{
echo '<div class="header"> ' . $lng['hi'] . ', ' . ($user_id ? '<b>' . $login . '</b>!' : $lng['guest'] . '!') . '' .
($headmod == 'mainpage' && count(core::$lng_list) > 1 ? ' &#183;
<a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</a>' : '') .
'';
//////////////
echo '</div></div></div>';
}
if($is_mobile)
{
if ($user_id) {
echo '<div class="menu">' .
(isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act) ? '<a href=\'' . $set['homeurl'] . '\'>' . $lng['homepage'] . '</a> | ' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/users/profile.php?act=office">' . $lng['personal'] . '</a> | ' : '') .
($rights >= 1 ? '<span class="red"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php">CPanel</a></span> | ' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/exit.php">' . $lng['exit'] . '</a>' : '') .
'</a>';
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if ($new_mail) {
echo '&nbsp;|&nbsp;<a href="'.$home.'/mail/index.php?act=new"><font color="#ff0000"><b>Messages (' . $new_mail . ')</b></font></a>';
} else {
echo ' | <a href="'.$home.'/mail/index.php?act=input">Messages</a>'; }
$total_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `type`='2' AND `friends`='1'"), 0);
$new_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `from_id`='$user_id' AND `type`='2' AND `friends`='0';"), 0);
$online_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id` WHERE `cms_contact`.`user_id`='$user_id' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `lastdate` > " . (time() - 300) . ""), 0);
if ($new_friends) {
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends&do=offers"><font color="#ff0000"><b>Friends&#160;('.$new_friends .')</b></font></a> (' . $total_friends . ($new_friends ? '/<span class="red">+' . $new_friends . '</span>' : '') . ')';
} else {
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends">Friends</a>'; }
echo '&#160;|&#160;<a href="'.$home.'/users/profile.php?act=friends&amp;do=online">Chat</a> (' . $online_friends . ')';
$list = array();
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
if ($new_sys_mail) $list[] = '<a href="'.$home.'/mail/index.php?act=systems"><font color="#ff0000"><b>Mail (' . $new_sys_mail . ')</b></font></a>';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '"><font color="#ff0000"><b>' . $lng['guestbook'] . ' (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')</b></font></a>';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if ($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm"><font color="#ff0000"><b>' . $lng['albums_comments'] . ' (' . $new_album_comm . ')</b></font></a>';
if ($datauser['journal_forum']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/journal.php"><font color="#ff0000"><b>Forum&#160;(' . $datauser['journal_forum'] . ')</b></font></a>';
if (!empty($list)) echo '&#160;|&#160;' . functions::display_menu($list, '&#160;|&#160;') . '';
echo '</div></div></div></div></div></div>';
}
else echo '<div class="forumtime"><b>Welcome to mTuner</b></div>';
}
if($is_mobile)
{
if ($user_id) {
} else {
if ($headmod == 'mainpage') {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Login</b></div><div class="currentpage"><form action="'.$home.'/login.php" method="post"><input type="text" name="n" value="" maxlength="28" size="7" class="name"> <input type="password" name="p" maxlength="25" size="7" class="pass"><input type="hidden" name="mem" value="1" checked="checked"> <input type="submit" value="Login"></form></div><p>&bull; <a href="'.$home.'/users/skl.php">Forgot password?</a></p><p>&bull; <a href="'.$home.'/login.php">Trouble logging in?</a></p><p>&bull; <a href="'.$home.'/pages/faq.php?act=forum">Forum Rules</a></p>
<div class="omenu">Need a <b>mTuner</b> Account?<br/><center><div class="_4u9b aclb"><div class="button_area aclb apl"><form action="registration.php"><input value="Create New Account" type="submit" name="signup" class="btn btnS largeBtn" size="0" /></form></div></div></center></div></div></div></div>';}}}
/*
-----------------------------------------------------------------
??????? ???? ????????????
-----------------------------------------------------------------
*/
//web
if(!$is_mobile)
{
echo '<table align="center" class="prus-body"><tr>';
include ("left.php");
}
/*
//ads
echo '<div class="menu">Ads:';
require($rootpath . 'incfiles/adshub.php');
require ($rootpath.'incfiles/admob.php');
echo '</div>';
//
*/
/*
-----------------------------------------------------------------
????????? ???? ?????
-----------------------------------------------------------------
*/
if (!empty($cms_ads[1])) echo '<div class="gmenu">' . $cms_ads[1] . '</div>';
/*
-----------------------------------------------------------------
???????? ?????????????? ???????????
-----------------------------------------------------------------
*/
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
// ????????? ?????????????? ??????????????
if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
$sql = "`karma_time` = '" . time() . "', ";
}
$movings = $datauser['movings'];
if ($datauser['lastdate'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "',";
}
if ($datauser['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
if ($datauser['browser'] != $agn)
$sql .= "`browser` = '" . mysql_real_escape_string($agn) . "',";
$totalonsite = $datauser['total_on_site'];
if ($datauser['lastdate'] > (time() - 300))
$totalonsite = $totalonsite + time() - $datauser['lastdate'];
mysql_query("UPDATE `users` SET $sql
`movings` = '$movings',
`total_on_site` = '$totalonsite',
`lastdate` = '" . time() . "'
WHERE `id` = '$user_id'
");
} else {
// ????????? ?????????????? ??????
$movings = 0;
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
$req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req)) {
// ???? ???? ? ????, ?? ????????? ??????
$res = mysql_fetch_assoc($req);
$movings = $res['movings'];
if ($res['sestime'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "', `movings` = '0'";
}
if ($res['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
mysql_query("UPDATE `cms_sessions` SET $sql
`movings` = '$movings',
`lastdate` = '" .time()  . "'
WHERE `session_id` = '$session'
");
} else {
// ???? ??? ?????? ? ????, ?? ????????? ??????
mysql_query("INSERT INTO `cms_sessions` SET
`session_id` = '" . $session . "',
`ip` = '" . core::$ip . "',
`ip_via_proxy` = '" . core::$ip_via_proxy . "',
`browser` = '" . mysql_real_escape_string($agn) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',
`place` = '$headmod'
");
}
}
if ($user_id) {
$list = array();
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `privat` WHERE `user` = '$login' AND `type` = 'in' AND `chit` = 'no'"), 0);
if ($nw_mail) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/pradd.php?act=in&amp;new">' . $lng['mail'] . '</a>&#160;(' . $new_mail . ')';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '">' . $lng['guestbook'] . '</a> (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';
if ($datauser['journal_forum']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/journal.php">Forum</a>&#160;(' . $datauser['journal_forum'] . ')';
if (!empty($list)) echo '<div class="mainbox"><div class="omenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div></div>';
if(!file_exists(($rootpath.'files/users/avatar/'.$user_id.
'.png')))
echo'<div class="mainbox"><div class="rmenu">You Need to upload your profile picture. Click<a href="../users/profile.php?act=images&amp;mod=avatar&amp;user='.$user_id.'"> Here</a> to Upload!!</div></div>';
}
/*
-----------------------------------------------------------------
??????? ????????? ? ????
-----------------------------------------------------------------
*/
if (!empty($ban)) echo '<div class="mainbox"><div class="omenu">' . $lng['ban'] . '&#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=ban">' . $lng['in_detail'] . '</a></div></div>';
/*
/*
-----------------------------------------------------------------
Qchat
-----------------------------------------------------------------
*/
if ($is_mobile)
{if($user_id && $ban !='1' && $ban !='12') {
if ($headmod != "guestbook" && $headmod != "pradd" && $headmod != "load") {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/ficon/shout.png" noselect="true"/>&nbsp;<a href="/guestbook"><b>Shoutbox</b></a></div>';
$refer = base64_encode($_SERVER['REQUEST_URI']);
echo '<div class="currentpage"><form name="form" action="/guestbook/index.php?act=say" method="post">';
echo '<textarea cols="30" rows="2" name="msg"></textarea>';
echo '<input type="hidden" name="ref" value="'.$refer.'">';
echo '<input type="submit" name="submit" value="Shout"><br/></form></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
if ($total) {
$req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`lastdate`, `users`.`id`, `users`.`rights`, `users`.`name`
FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT 4");
echo '<div class="">';
while ($gres = mysql_fetch_assoc($req)) {
$post = $gres['text'];
if(strlen($post) > 260) {
$post = substr($post, 0, 260).'....';
}
$post = functions::checkout($gres['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $gres['rights'] ? 1 : 0);
if($user_id) {
$post = str_replace ( '[  ]' , 'Good NooN' , $post ) ;
$post = str_replace ( "[   ]" , "Good After NooN" , $post ) ;
$post = str_replace ( "[    ]" , "Good Night" , $post ) ;
$post = str_replace ( "[     ]" , "MiD Night Bro!" , $post ) ;
$post = str_replace('[+]','Good Morning', $post);
$post = str_replace('[++]','Good NooN', $post);
$post = str_replace('[+++]','Good After NooN', $post);
$post = str_replace('[++++]','Good Night', $post);
$post = str_replace('[you]', $login, $post);
} else {
$post = str_replace('[you]', 'Guest', $post);
}
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">' : '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">';
echo (time() > $gres['lastdate'] + 600 ? '<font color="red">&#x2022;</font> ' : '<font color="green">&#x2022;</font> ');
if (!empty($user_id) && ($user_id != $gres['user_id'])) {
echo '<a href="'.$home.'/users/'.$gres['name'].'"><b>'.functions::nickcolor($gres['user_id']).'</b></span></a> :&nbsp;';}
else{echo'<b>'.functions::nickcolor($gres['user_id']).'</b></span> :&nbsp;';}
// text
if (mb_strlen($post) >= 500)
{
$post = mb_substr($post, 0, 500);
echo $post.' ';
echo '...<a href="../guestbook/index.php">more</a>';
}
else
{
echo $post;
}
echo '</div>';
$i;
}
}else {
echo '<div class="textshout">' . $lng['guestbook_empty'] . '</div>';
}
echo '<div class="forumb"><center><a href="/pages/faq.php">F.A.Q.</a> &bull; <a href="/pages/img.php">BBimg</a> &bull; <a href="/guestbook/index.php">Shoutbox</a></center></div></div></div>';
echo'</div></div></div>';
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '2'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '7'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '283'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '3'");
}}
}
?>
