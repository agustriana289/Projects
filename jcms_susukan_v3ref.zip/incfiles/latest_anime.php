<?php
// last myblog mod whiznoe http://www.waptok.asia
// last myblog with preview image
// jika ingin memakai last myblog dengan preview image ini rename menjadi last_myblog.php

echo '<div class="mainbox"><div class="mainblok">';
if ($user_id) {
echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">
<font size=2><b>Last Blogs</b></font></td><td width="auto" align="right"><a href="myblog/index.php"><img src="./images/add.jpg" alt="Add" width="12" height="12"/></a></td></tr></table></div>';}
if (!$user_id) {
echo '<div class="nfooter"><b>Last Blog</b></div>';}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog`"), 0);
      if($total) {
         $req = mysql_query("SELECT `id`,`user_id`, `name`, `count`, `text`, `time` FROM `myblog` ORDER BY `id` DESC LIMIT 5");
         $i = 1;
         while (($row = mysql_fetch_assoc($req)) !== false) {
            echo $i % 2 ? '<div class="list">' : '<div class="list2">';
            if(file_exists('files/myblog/small_news_' . $row['id'] . '.jpg') !== false) {
               echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="50">';
               echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../files/myblog/small_news_' . $row['id'] . '.jpg" alt="" width="50" height="50"/>&#160;';
               echo '</td><td>';
               echo '<a href="../myblog/index.php?act=view&amp;id=' . $row['id'] . '">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '</a><br/>(' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/>';
               echo '</td></tr></table>';
            } else {
               echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="50">';
               echo '<img style="margin: 0 0 -3px 0;border: 0px;" src="../myblog/default.png" alt="" title="no images" width="50" height="50"/>&#160;';
               echo '</td><td>';
               echo '<a href="../myblog/index.php?act=view&amp;id=' . $row['id'] . '">' . htmlentities($row['name'], ENT_QUOTES, 'UTF-8') . '</a><br/> (' . date('d.m.o / H:i', $row['time'] + $sdvigclock * 3600) . ')<br/>';
               echo '</td></tr></table>';
            }
            echo '<div class="sub"></div>';
            $text = $row['text'];
            if(mb_strlen($text) > 100) {
               $str = mb_substr($text, 0, 100);
               $text = mb_substr($str, 0, mb_strrpos($str, ' ')) . '...';
            }
            echo functions::checkout($text, 2, 1);
            
            $us = mysql_query("SELECT `id`, `name` FROM `users` WHERE `id` = '".$row['user_id']."'");         
              if (mysql_num_rows($us)) {
         $rowuse = mysql_fetch_assoc($us);
         $name_use = $user_id ? '<a href="../users/profile.php?id=' . $rowuse['id'] . '">' . $rowuse['name'] . '</a>' : $rowuse['name'];
      } else {
         $name_use = $lng['guest'];
      }
             
               echo '</div>';
            
             
           echo '<div class="topmenu" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><a href="../myblog/comments.php?id=' . $row['id'] . '">Komentar:</a> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `myblog_comments` WHERE `refid`= '".$row['id']."' "), 0) . ')';
              echo '</td><td width="auto" align="right">Dilihat: '.$row['count'].' kali ';
echo '</td></tr></table></div></div>';
            
            ++$i;
         }
}
if ($total == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}

              echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">' . $lng['total'] . ': ' . $total . '';

              echo '</td><td width="auto" align="right"><a href="/myblog">' . $lng['more'] . '...</a>';
echo '</td></tr></table></div>';
   
         
echo '</div>';
         

?>
