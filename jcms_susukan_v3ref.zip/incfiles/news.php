<?php
$XMLFILE = "http://feeds.bbci.co.uk/news/technology/rss.xml";
$TEMPLATE = "http://susukan.us/pages/sample-template.html";
$MAXITEMS = "5";
include("../pages/rss2html.php");
?>