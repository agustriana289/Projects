<?php

// change to "live" to disable demo mode and show realtime ads
define("ADSHUB_ADSERVE_MODE", "live");


function adshub_ad($adshub_params = array())
{
    $ua = $_SERVER['HTTP_USER_AGENT'];
    $ip = (stristr($ua,"opera mini") && array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER))
        ? trim(end(split(",", $_SERVER['HTTP_X_FORWARDED_FOR'])))
        : $_SERVER['REMOTE_ADDR'];

    // build parameters for ad request
    $params  = 'uid='.urlencode('22842');
    $params .= '&REMOTE_ADDR='.urlencode($ip);
    $params .= '&HTTP_USER_AGENT='.urlencode($ua);
    $params .= '&CODE_TYPE='.urlencode('curl-version-1.0');
    $params .= '&URI='.urlencode(sprintf("http%s://%s%s", (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == TRUE ? "s": ""), $_SERVER["HTTP_HOST"], $_SERVER["REQUEST_URI"]));


    if(ADSHUB_ADSERVE_MODE == "test")  { $params .= '&mode=test';  }
    else { $params .= '&mode=live';  }
    $ab_headers = array();
    foreach ($_SERVER as $name => $value) {
        $ab_headers[] = "AB_$name: $value";
    }

    // send ad request
    $adurl="http://ads.adshub.net/index.php?".$params;
    $timeout=3; //timeout in seconds
    $ch  = curl_init($adurl);
    curl_setopt($ch, CURLOPT_URL, $adurl);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    @curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $ab_headers);
    $html=@curl_exec($ch);
    @curl_close($ch);
    if($html!==false) return $html;
    else return "";

}

?>
<?php

// copy this snippet elsewhere on your page for display more of ads
echo adshub_ad();

?>