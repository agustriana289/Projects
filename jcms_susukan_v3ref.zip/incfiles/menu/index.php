<?php
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html dir="ltr">

<head>
   <meta http-equiv="content-type" content="text/html; charset=utf-8" />

   <!-- Start css3menu.com HEAD section -->
   <link rel="stylesheet" href="CSS3 Menu_files/css3menu1/style.css" type="text/css" /><style>._css3m{display:none}</style>
   <!-- End css3menu.com HEAD section -->
   
</head>
<body style="background-color:#EBEBEB">

<!-- Start css3menu.com BODY section -->
<ul id="css3menu1" class="topmenu">
   <li class="topfirst"><a class="pressed" href="#" style="height:19px;line-height:19px;"><img src="CSS3 Menu_files/css3menu1/home3.png" alt=""/>Inbox</a></li>
   <li class="topmenu"><a href="#" style="height:19px;line-height:19px;"><span><img src="CSS3 Menu_files/css3menu1/service.png" alt=""/>Personal</span></a>
   <ul>
      <li class="subfirst"><a href="http://susukan.us/users/profile.php?act=settings" target="_parent" title="Account Setting"><img src="CSS3 Menu_files/css3menu1/samples.png" alt=""/>Setting</a></li>
      <li><a href="http://susukan.us/users/profile.php" target="_parent"><img src="CSS3 Menu_files/css3menu1/service1.png" alt=""/>Profile</a></li>
      <li><a href="http://susukan.us/users/album.php?act=list" target="_parent"><img src="CSS3 Menu_files/css3menu1/favour.png" alt=""/>Photo</a></li>
   </ul></li>
   <li class="topmenu"><a href="#" style="height:19px;line-height:19px;"><span><img src="CSS3 Menu_files/css3menu1/contact.png" alt=""/>Message</span></a>
   <ul>
      <li class="subfirst"><a href="http://susukan.us/mail/index.php?act=input" target="_parent"><img src="CSS3 Menu_files/css3menu1/contact2.png" alt=""/>Inbox</a></li>
      <li><a href="http://susukan.us/mail/index.php?act=output" target="_parent"><img src="CSS3 Menu_files/css3menu1/contact1.png" alt=""/>Outbox</a></li>
   </ul></li>
   <li class="topmenu"><a href="http://susukan.us/download" target="_parent" style="height:19px;line-height:19px;"><img src="CSS3 Menu_files/css3menu1/news.png" alt=""/>Download</a></li>
   <li class="topmenu"><a href="http://susukan.us/news" target="_parent" style="height:19px;line-height:19px;"><img src="CSS3 Menu_files/css3menu1/info.png" alt=""/>News</a></li>
   <li class="toplast"><a href="http://susukan.us/exit.php" target="_parent" title="Logout" style="height:19px;line-height:19px;"><img src="CSS3 Menu_files/css3menu1/register.png" alt=""/>Logout</a></li>
</ul><p class="_css3m"><a href="http://css3menu.com/">Dropdown Menu Using CSS Css3Menu.com</a></p>
<!-- End css3menu.com BODY section -->

</body>
</html>
?>