<?
$set[pasword]="12345";
$set[buku]="1000";
$set[shout]="200";
$set[css]="/tema/style.css";
$set[waktu]="6";
$set[visitor]="MBAHH..?!";
$set[judul]="Facebook Kreasi Wapsite";

$set[description]="Naradan wapsite,free download,game,aplikasi,php script";
$set[rss]="http://my.opera.com/operamini/xml/rss/blog";
$app_id= '497589123608615';

$app_secret= '9840ff3e7fa590a7046b3ed7bb0053db';

$baseUrl= 'www.demo.xtweb.org/';

?>