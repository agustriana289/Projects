<?php

if($user_id && $headmod != 'guest') {
echo'<div class="mainblok">'; echo '<div class="phdr"><a href="/guestbook/index.php"><b>Luu bu?t</b></a>'.($rights >= 3 ? ' <b>| <a href="/guestbook/botpanel.php">Bot Panel</a></b>' : '').'</div>';
$refer = base64_encode($_SERVER['REQUEST_URI']);
echo '<div class="gmenu"><form name="form" action="/guestbook/index.php?act=say" method="post">';
echo '<input type="text" name="msg" size="10">';
echo '<input type="hidden" name="ref" value="'.$refer.'">';
echo '<input type="submit" name="submit" value="' . $lng['sent'] . '"><br/>[<a href="/pages/faq.php?act=tags">bbcode</a>] [<a href="/pages/faq.php?act=smileys">Smileys</a>]</form></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
if ($total) {
$req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`lastdate`, `users`.`id`, `users`.`rights`, `users`.`name`
FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT 7");
echo '<div class="textx">';
while ($gres = mysql_fetch_assoc($req)) {
$post = $gres['text'];
if(strlen($post) > 160) {
$post = substr($post, 0, 160).'....';
}
$post = functions::checkout($gres['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $gres['rights'] ? 1 : 0);
if($user_id) {
$post = str_replace('[you]', $login, $post);
} else {
$post = str_replace('[you]', 'Kha?ch', $post);
}
echo (time() > $gres['lastdate'] + 600 ? '<font color="red"><b>&#x2022;</b></font> ' : '<font color="green"><b>&#x2022;</b></font> ');
if ($gres['rights'] == 0 ) {
$colornick['colornick'] = '000000';
}
if ($gres['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
}
if ($gres['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
}
if ($gres['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
}
if ($gres['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
}
if ($gres['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
}
if ($gres['rights'] == 6 ) {
$colornick['colornick'] = '228622';
}
if ($gres['rights'] == 7 ) {
$colornick['colornick'] = '860086';
}
if ($gres['rights'] == 8 ) {
$colornick['colornick'] = 'FF0000';
}
if ($gres['rights'] == 9 ) {
$colornick['colornick'] = 'FF0000';
}
if ($gres['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
}
if ($user_id && $user_id != $gres['id']) {
echo '<a href="/users/profile.php?user='.$gres['id'].'"><span style="color:#' . $colornick['colornick'] . '"><b>'.$gres['name'].'</b></span></a>';}
else{echo'<span style="color:#' . $colornick['colornick'] . '"><b>'.$gres['name'].'</b></span>';}echo': '.$post.'
<br/>';
++$i;
}
echo '</div>';
}
else {
echo '<div class="menu"><p>' . $lng['guestbook_empty'] . '</p></div>';
}
echo'</div>';
}


?>
