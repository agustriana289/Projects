<?
{
global $realtime;
global $user_id;
$req = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");
while ($res = mysql_fetch_array($req)) {
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">' : '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">';
global $set_user, $realtime, $user_id, $admp, $home;
$ontime = $res['lastdate'] + 300;
if (time() > $ontime) {
echo '<font color="red">&bull;</font>&nbsp;';
} else {
echo '<font color="green">&bull;</font>&nbsp;';
}
if ($res['rights'] == 0 ) {
$colornick['colornick'] = '000000';
}
if ($res['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
}
if ($res['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
}
if ($res['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
}
if ($res['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 6 ) {
$colornick['colornick'] = '228622';
}
if ($res['rights'] == 7 ) {
$colornick['colornick'] = '860086';
}
if ($res['rights'] == 8 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 9 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
}
if ($user_id && $user_id != $res['id']) {
echo '<a href="../users/profile.php?user=' . $res['user_id'] . '"><span style="color:#' . $colornick['colornick'] . '"><b>'.$res['name'] .'</b></span></a>';
} else {
echo '<span style="color:#' . $colornick['colornick'] . '"><b>' . $res['name'] . '</b></span> ';
}
$ontime = $res['lastdate'] + 300;
if (time() > $ontime) {
echo ': ';
} else {
echo ': ';
}
if (!empty($res['status']))
$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = bbcode::tags($text);
$text = str_replace("\r\n", "<br />", $text);
if ($res['user_id']) {
$text = functions::checkout(mb_substr($res['text'], 0, 100), 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] >= 1 ? 1 : 0);
}
echo $text;
if (mb_strlen($res['text']) > 100)
echo '...<a href="../users/qchat.php">more</a>';
echo '</div>';
++$i;
}
}

?>
