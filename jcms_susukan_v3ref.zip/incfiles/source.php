<?php

$huz = array();
$huz[] = '';
$huz[] = '';
foreach($huz as $huz) {
$jangan = strtolower($_SERVER['HTTP_USER_AGENT']);
if($jangan == $huz){
echo"No URL inserted, please insert url Exp: http://google.com";
exit();
}
}
?>
