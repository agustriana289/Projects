<?

global $realtime, $user_id, $home;
$u_on = array();
$ontime = time() - 300;
$guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
$qon = mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate`>='" . $ontime . "';");
$qon2 = mysql_result($qon, 0);
if($qon2>=1){
	echo 'User On: ';
}else{
	echo 'No User On';
}
$onltime = time() - 300;
$q = @mysql_query("select * from `users` where lastdate>='" . intval($onltime) . "';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
	$where = explode(",", $arr['place']);
	switch ($where[0]){
		case 'forumfiles' :
		$place = '<a href="../forum/index.php?act=files">Files Forum</a>';
		break;
		
		case 'forumwho' :
		$place = '<a href="../forum/index.php?act=who">Who in forum</a>';
		break;
		
		case 'profile' :
		$place = '<a href="../users/profile.php">Profil</a>';
		break;
		
		case 'userset' :
		$place = '<a href="../users/profile.php?act=settings">Pengaturan</a>';
		break;
		
		case 'scan' :
		$place = '<a href="../scan/index.php">scaner</a>';
		break;
		
		case 'online' :
		$place = '<a href="../users/index.php?act=online">List online</a>';
		break;
		
		case 'privat' :
		$place = '<a href="../index.php?act=cab">mainmenu</a>';
		break;
		
		case 'birth' :
		$place = '<a href="../users/birth.php">Birthday List</a>';
		break;
		
		case 'read' :
		$place = '<a href="../faq.php">FAQ</a>';
		break;
		
		case 'load' :
		$place = '<a href="../download/index.php">Download</a>';
		break;
		
		case 'gallery' :
		$place = '<a href="../gallery/index.php">Gallery</a>';
		break;
		
		case 'quickchat' :
		$place = '<a href="../users/qchat.php">Shout</a>';
		break;
		
		case 'teman' :
		$place = '<a href="../users/count.php?user=' . $arr['id'] . '">Dftr.Teman</a>';
		break;
		
		case 'forum' :
		$place = '<a href="../forum/index.php">Forum</a>';
		break;
		
		case 'chat' :
		$place = '<a href="../chat/index.php">Chat</a>';
		break;
		
		case 'guest' :
		$place = '<a href="../guestbook/index.php">Bukutamu</a>';
		break;
		
		case 'dinding' :
		$place = '<a href="../users/profile.php?user=write' . $arr['id'] . '">Dinding</a>';
		break;
		
		case 'lib' :
		$place = '<a href="../library/index.php">Library</a>';
		break;
		
		case 'mainpage' :
		default :
		$place = '<a href="../index.php">Home</a>';
		break;
	}
	$u_on[]='<b><a href="../users/profile.php?user=' . $arr['id'] . '">' . $arr['name'] . '</a></b>';
}
if (($qon2>=1) && ($qon2<=5)){
	echo implode(',',$u_on).'.';
}elseif ($qon2>=6){
	$ton = $qon2-5;
	echo implode(', ',$u_on).'.';
	echo ' <a href="' . $home . '/users/index.php?act=online">' . $ton . ' more</a>';
}
echo '<br/>Guest: ';
if ($guests>=1){
	echo '<a href="' . $home . '/users/index.php?act=online&amp;mod=guest">' . $guests . '</a><br/>';
}else
	echo 'No Guest<br/>';
/*
------------------
New Member
------------------
*/
echo 'New Member:&nbsp;';
$req = mysql_query("SELECT `id`, `name`, `datereg` FROM `users` WHERE (preg='1') ORDER BY `datereg` DESC LIMIT 1; ");
$arr = mysql_fetch_array($req);
echo '<a href="../users/profile.php?user=' . $arr['id'] . '"><b>'.$arr['name'] .'</b></a>';
?>