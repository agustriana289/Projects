<?php

/**
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Pe?a?? @o?ca?a
if (!empty($cms_ads[2]))
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
    // C??? ?ce????o?a?
//if ($is_mobile){  
echo '<a href="'.$adscontent['link'].'">'.$adscontent['banner'].'</a>';  
echo '</div></div>';
if ($headmod != "mainpage" || ($headmod == 'mainpage' && $act))
    echo '<img src="../images/home.png" /> <a href="' . $set['homeurl'] . '">' . $lng['homepage'] . '</a><br/>';
//}

list($msec,$sec)=explode(chr(3),microtime());
echo '<div class="footer" align="right">'; //iki
echo '<table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">';
echo '<blink>mTuner.Tk</blink>';
echo '</td><td width="auto" align="right">';
echo '<blink>Page: '.round(($sec + $msec) - $conf['headtime'], 3).' sec</blink>';
echo '</td></tr></table></div>'; //iki
//if (!$is_mobile)include_once 'ads/clicksor.php';
echo '<div style="text-align:center">';
//echo 'Hits: '.$hity.' | Host: '.$hosty.'<br/>';
// C???????A?
functions::display_counters();

// Pe?a?? @o?ca?a
if (!empty($cms_ads[3]))
    echo '<br />' . $cms_ads[3];
echo '<small><div>&copy; <a href="http://mtuner.tk" target="_blank">2012</a> - <a href="' . core::$system_set['homeurl'] . '">' . date("Y") . '</a> | ' . $lng['language'] . ':<a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b></a></div></small>';
echo '<div></div></body>';
if (!$is_mobile){?>
<link rel="stylesheet" href="/facebox.css" media="screen" type="text/css" />
<script type="text/javascript" src="/js/green.js"></script>
<script src="/lib/jquery.js" type="text/javascript"></script>
<script src="/src/facebox.js" type="text/javascript"></script>
<? }
echo '</html>';?>