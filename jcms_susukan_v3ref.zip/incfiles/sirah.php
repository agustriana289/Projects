<?
/////////////////////////////////////////////
///DO NOT REMOVE THIS COPYRIGHT//////////////
///ORIGINALY CREATED BY S@M A.K.A NGADIMIN///
///SITE = HTTP://NGUPRUS.COM/////////////////
///PLEASE RESPECT MY HARD WORK///////////////
/////////////////////////////////////////////
echo '<style>
<!--
.social{background-color:#696969;}.social{background-color:#696969;}-->
</style>
</head>
<body>
<div align="center">
<div class="social">
<a href="http://www.facebook.com/sharer.php?u=http://susukan.us" style="color: #fe9b00; text-decoration: none">
<img src="/images/bfacebook.png" alt="fb" style="max-width: 100%; vertical-align: middle; border-style: none" width="40" height="20"></a>
<a style="color: #fe9b00; text-decoration: none" href="http://twitter.com/share?via=mantraJAYBEE&text=www.susukan.us ::: Best Wapmaster Forum::: http://susukan.us">
<img src="/images/btwitter.png" alt="twtr" style="max-width: 100%; vertical-align: middle; border-style: none" width="40" height="20"></a> </div>
</div>';
echo '<div class="menu"><table class="hlogo" width="100%"><tr height="45px"><td width="20%">';
echo '<a href="' . $set['homeurl'] . '"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/logo.jpg" width="150" hieght="42" alt="Susukan.Us" /></a>';
echo '</td><td class="menu" width="40%">';
echo '' . (isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act) ? '<a href=\'' . $set['homeurl'] . '\'><span class="btn">' . $lng['homepage'] . '</a></span>' : '') .'';
echo '' . ($user_id ? '<a href="' . $set['homeurl'] . '/users/profile.php?act=office"><span class="btn">' . $lng['personal'] . '</a></span>' : '') . '';
echo '<a href="/forum"><span class="btn">Forum</span></a><a href="/download"><span class="btn">Downloads</span></a><a href="/news"><span class="btn">News</span></a>';
echo '' . ($user_id ? '<a href="' . $set['homeurl'] . '/logout.php"><span class="btn">' . $lng['exit'] . '</span></a>' : '<a href="' . $set['homeurl'] . '/signin.html"><span class="btn">' . $lng['login'] . '</span></a><a href="' . $set['homeurl'] . '/signup.html"><span class="btn">' . $lng['registration'] . '</span></a>') .
'';
echo '</td><td class="menu" width="40%">';
if (!$user_id){
/*
echo '<form action="' . $set['homeurl'] . '/login.php" method="post">' . $lng['login_name'] . ': ' .
'<input class="log" type="text" name="n" value="' . htmlentities($user_login, ENT_QUOTES, 'UTF-8') . '" maxlength="20"/>' .
' ' . $lng['password'] . ': ' .
'<input class="log" type="password" name="p" maxlength="20"/>' .
' <input type="checkbox" name="mem" value="1" checked="checked"/>' . $lng['remember'] . '' .
' <input class="btn" type="submit" value="' . $lng['login'] . '"/>' .
'</form>' . '<a href="users/skl.php?continue">' . $lng['forgotten_password'] . '?</a>';
*/
?>
<form action="/login.php" method="post">
<input class="log" value="username" name="n" maxlength="20" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" type="text" class="inputusername" />
<input class="log" maxlength="20" name="p" value="password" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" type="password" />
<input value="Login" class="btn" type="submit" />
<br />
<input class="log" name="mem" value="1" type="checkbox" /><small> Remember me | <a href="users/skl.php?continue">Forgot password?</a></small>
</form>
<?
}else{
echo '<form action="' . $set['homeurl'] . '/forum/search.php" method="post">';
echo '<input name="t" type="checkbox" value="1"  />Forum Topic<br/>';
echo '<input type="text" value="' . ($search ? functions::checkout($search) : '') . '" name="search" />';
echo '<input class="btn" type="submit" value="' . $lng['search'] . '" name="submit" /></small>';
echo '</form>';
}
echo '</td></tr></table></div></div>';
?>
