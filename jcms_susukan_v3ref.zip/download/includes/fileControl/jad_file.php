<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || functions::format($res_down['name']) != 'jar' || ($res_down['type'] == 3 && $rights < 6 && $rights != 4)) {
    require('../incfiles/head.php');
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if (isset($_GET['more'])) {
    $more = abs(intval($_GET['more']));
    $req_more = mysql_query("SELECT * FROM `down_more` WHERE `id` = '$more' LIMIT 1");
    $res_more = mysql_fetch_assoc($req_more);
    if (!mysql_num_rows($req_more) || !is_file($res_down['dir'] . '/' . $res_more['name']) || functions::format($res_more['name']) != 'jar') {
        require('../incfiles/head.php');
        echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
        require('../incfiles/end.php');
        exit;
    }
    $down_file = $res_down['dir'] . '/' . $res_more['name'];
    $jar_file = $res_more['name'];
} else {
    $down_file = $res_down['dir'] . '/' . $res_down['name'];
    $jar_file = $res_down['name'];
}
if (!$_SESSION['down_' . $id]) {
    mysql_query("UPDATE `down_files` SET `field`=`field`+1 WHERE `id`='$id'");
    $_SESSION['down_' . $id] = 1;
}

$size = filesize($down_file);
require('../incfiles/lib/pclzip.lib.php');
$zip = new PclZip($down_file);
$content = $zip->extract(PCLZIP_OPT_BY_NAME, 'META-INF/MANIFEST.MF', PCLZIP_OPT_EXTRACT_AS_STRING);
header('Content-type: text/vnd.sun.j2me.app-descriptor');
header('Content-Disposition: attachment; filename="' . basename($down_file) . '.jad";');
echo $content[0]['content'] . "\n" . 'MIDlet-Jar-Size: ' . $size . "\n" . 'MIDlet-Jar-URL: ' . $set['homeurl'] . '/' . str_replace($filesroot, $dir_load, $res_down['dir']) . '/' . $jar_file;
exit;
?>