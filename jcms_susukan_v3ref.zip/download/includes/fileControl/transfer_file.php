<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
$title .= ': Transfer the file';
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name'])) {
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if ($rights > 6 ) {
	$catId = isset($_GET['catId']) ? abs(intval($_GET['catId'])) : 0;
	if($catId) {
		$queryDir = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$catId' AND `type` = 1 AND `id` != " . $res_down['refid'] . " LIMIT 1");
		if(!mysql_num_rows($queryDir)) $catId = 0;
	}
	switch($do) {
    	case 'transfer':
        	if($catId) {
            	if(isset($_GET['yes'])) {
					$resDir = mysql_fetch_assoc($queryDir);
					$req_file_more = mysql_query("SELECT * FROM `down_more` WHERE `refid` = '$id'");
                	if (mysql_num_rows($req_file_more)) {
                		while ($res_file_more = mysql_fetch_assoc($req_file_more)) {
							copy($res_down['dir'] . '/' . $res_file_more['name'], $resDir['dir'] . '/' . $resDir['name'] . '/' . $res_file_more['name']);
                       		unlink($res_down['dir'] . '/' . $res_file_more['name']);
						}
                	}
					$name = $res_down['name'];
					$newFile =  $resDir['dir'] . '/' . $resDir['name'] . '/' . $res_down['name'];
                    if(is_file($newFile)) {
                    	$name = time() . '_' .$res_down['name'];
                    	$newFile =  $resDir['dir'] . '/' . $resDir['name'] . '/' . $name;

                    }
					copy($res_down['dir'] . '/' . $res_down['name'], $newFile);
                    unlink($res_down['dir'] . '/' . $res_down['name']);
					mysql_query("UPDATE `down_files` SET `name`='$name', `dir`='" . $resDir['dir'] . "/" . $resDir['name'] . "', `refid`='$catId'  WHERE `id`='$id'");
                    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">File</a> | <b>Transfer file</b></div>' .
                    '<div class="gmenu">Done<br />
                    <small>After the last transferred file, do not forget <a href="index.php?act=recount">Reset counters</a></small></div>' .
                    '<div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">File</a></div>';
               	} else {
                	echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="index.php?act=transfer_file&amp;id=' . $id . '">Back</a> | <b>Transfer file</b></div>' .
                    '<div class="menu">Transfer file? - <a href="index.php?act=transfer_file&amp;id=' . $id . '&amp;catId=' . $catId . '&amp;do=transfer&amp;yes">Yes</a></div>' .
                    '<div class="nfooter"><a href="index.php?act=transfer_file&amp;id=' . $id . '">Back</a></div>';
				}
			}
			break;
		default:
			$queryCat = mysql_query("SELECT * FROM `down_files` WHERE `refid` = '$catId' AND `type` = 1 AND `id` != " . $res_down['refid']);
			$totalCat = mysql_num_rows($queryCat);
    		echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a> | <b>Transfer file</b></div>';
    		if($totalCat > 0) {
        		while ($resCat = mysql_fetch_assoc($queryCat)) {
                	echo ($i++ % 2) ? '<div class="list2">' : '<div class="list1">';
                	echo '<img src="' . $set['homeurl'] . '/images/download/file.gif" alt="" />&#160;' .
                	'<a href="index.php?act=transfer_file&amp;id=' . $id . '&amp;catId=' . $resCat['id'] . '">' . functions::checkout($resCat['rus_name']) . '</a><br />' .
                	'<small><a href="index.php?act=transfer_file&amp;id=' . $id . '&amp;catId=' . $resCat['id'] . '&amp;do=transfer">Move this folder</a></small></div>';
				}
			} else
				echo '<div class="rmenu"><p>The list is empty</p></div>';
			echo '<div class="nfooter">Total: ' . $totalCat .'</div>';
            if($catId)
            	echo '<p><div class="func"><a href="index.php?act=transfer_file&amp;id=' . $id . '&amp;catId=' . $catId . '&amp;do=transfer">Move this folder</a></div></p>';
			echo '<p><a href="index.php?act=view&amp;id=' . $id . '">Back</a></p>';
	}
} else {
    header('Location: ../?err');
}
?>