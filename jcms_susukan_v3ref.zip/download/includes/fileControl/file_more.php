<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || ($rights < 6 && $rights != 4)) {
    echo functions::display_error('<a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
$del = isset($_GET['del']) ? abs(intval($_GET['del'])) : false;
$edit = isset($_GET['edit']) ? abs(intval($_GET['edit'])) : false;
if ($edit) {
    $name_link = isset($_POST['name_link']) ? functions::check(mb_substr($_POST['name_link'], 0, 200)) : null;
    $req_file_more = mysql_query("SELECT `rus_name` FROM `down_more` WHERE `id` = '$edit' LIMIT 1");
    if ($name_link && mysql_num_rows($req_file_more) && isset($_POST['submit'])) {
        mysql_query("UPDATE `down_more` SET `rus_name`='$name_link' WHERE `id` = '$edit' LIMIT 1");
        header('Location: index.php?act=file_more&id=' . $id);
    } else {
        $res_file_more = mysql_fetch_assoc($req_file_more);
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . functions::checkout($res_down['rus_name']) . '</b></div><div class="gmenu"><b>Editing ext. file</b></div>';
        echo '<div class="list1"><form action="index.php?act=file_more&amp;id=' . $id . '&amp;edit=' . $edit . '"  method="post">
        Name for the link (max. 200)<span class="red">*</span>:<br /><input type="text" name="name_link" value="' . $res_file_more['rus_name'] . '"/><br /><input type="submit" name="submit" value="Save"/>';
        echo '</form></div><div class="bmenu"><a href="index.php?act=file_more&amp;id=' . $id . '">Back</a></div>';
    }
} else if ($del) {
    $req_file_more = mysql_query("SELECT `name` FROM `down_more` WHERE `id` = '$del' LIMIT 1");
    if (mysql_num_rows($req_file_more) && isset($_GET['yes'])) {
        $res_file_more = mysql_fetch_assoc($req_file_more);
        if (is_file($res_down['dir'] . '/' . $res_file_more['name']))
            unlink($res_down['dir'] . '/' . $res_file_more['name']);
        mysql_query("DELETE FROM `down_more` WHERE `id` = '$del' LIMIT 1");
        header('Location: index.php?act=file_more&id=' . $id);
    } else {
        echo '<div class="rmenu">Are you sure you want to delete the file?<br /> <a href="index.php?act=file_more&amp;id=' . $id . '&amp;del=' . $del . '&amp;yes">Remove</a> | <a href="index.php?act=file_more&amp;id=' . $id . '">Back</a></div>';
    }
} else if (isset($_POST['submit'])) {
    $error = array ();
    $link_file = isset($_POST['link_file']) ? str_replace('./', '_', trim($_POST['link_file'])) : null;
    if ($link_file) {
        if (mb_substr($link_file, 0, 7) !== 'http://')
            $error[] = 'Invalid Link';
        else {
            $link_file = str_replace('http://', '', $link_file);
            if ($link_file) {
                $do_file = true;
                $fname = basename($link_file);
                $fsize = 0;
            } else {
                $error[] = 'Invalid Link';
            }
        }
        if ($error) {
            echo functions::display_error($error);
            require('../incfiles/end.php');
            exit;
        }
    } elseif ($_FILES['fail']['size'] > 0) {
        $do_file = true;
        $fname = strtolower($_FILES['fail']['name']);
        $fsize = $_FILES['fail']['size'];
    }
    if ($do_file) {
        $new_file = isset($_POST['new_file']) ? trim($_POST['new_file']) : null;
        $name_link = isset($_POST['name_link']) ? functions::check(mb_substr($_POST['name_link'], 0, 200)) : null;
        $ext = explode(".", $fname);
        if (!empty($new_file)) {
            $fname = strtolower($new_file . '.' . $ext[1]);
            $ext = explode(".", $fname);
        }
        if (empty($name_link))
            $error[] = 'Please enter name.';
        if ($fsize > 1024 * $set['flsz'] && !$link_file)
            $error[] = 'Max size ' . $set['flsz'] . ' Kb.';
        if (count($ext) != 2)
            $error[] = 'Incorrect file name! By sending only allowed with a file name and 1 extension (<b>name.ext</b>)';
        if (!in_array($ext[1], $defaultExt))
            $error[] = 'Prohibited file type! By sending only allowed files have the following extension: ' . implode(', ', $defaultExt);
        if (strlen($fname) > 30)
            $error[] = 'The length of the file name to save should not exceed 30 characters';
        if (eregi("[^a-z0-9.()+_-]", $fname))
            $error[] = 'File name contains invalid characters. Allowed only Latin characters, numbers and some characters ( .()+_- ). forbidden white space.';
        if ($error) {
            $error[] = '<a href="index.php?act=file_more&amp;id=' . $id . '">Back</a>';
            echo functions::display_error($error);
        } else {
        	$newFile = 'file' . $id . '_' . $fname;
            if(file_exists($res_down['dir'] . '/' . $newFile)) $fname = 'file' . $id . '_' . $realtime . $fname;
            else $fname = $newFile;
            if ($link_file) {
                $up_file = copy('http://' . $link_file, "$res_down[dir]/$fname");
                $fsize = filesize("$res_down[dir]/$fname");
            } else {
                $up_file = move_uploaded_file($_FILES["fail"]["tmp_name"], "$res_down[dir]/$fname");
            }
            if ($up_file == true) {
                @chmod("$fname", 0777);
                @chmod("$res_down[dir]/$fname", 0777);
                echo '<div class="gmenu">File is attached<br /><a href="index.php?act=file_more&amp;id=' . $id . '">Continue</a><br /><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></div>';
                $fname = mysql_real_escape_string($fname);
                mysql_query("INSERT INTO `down_more` SET `refid`='$id', `time`='$realtime',`name`='$fname', `rus_name` = '$name_link',`size`='" . intval($fsize) . "'");
            } else
                echo '<div class="rmenu">Error attaching.<br /><br /><a href="index.php?act=file_more&amp;id=' . $id . '">Repeat</a><br /><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></div>';
		}
    } else
        echo '<div class="rmenu">Error attaching.<br /><a href="index.php?act=file_more&amp;id=' . $id . '">Repeat</a><br /><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></div>';
} else {
    echo '<div class="nfooter"><b>Additional files:</b> ' . functions::checkout($res_down['rus_name']) . '</div>';
    echo '<div class="menu"><form action="index.php?act=file_more&amp;id=' . $id
        . '"  method="post" enctype="multipart/form-data">File<span class="red">*</span>::<br /><input type="file" name="fail"/><br />
            Or Import:<br /><input type="post" name="link_file" value=""/><br />
            Save as (max. 30, with no extension):<br /><input type="text" name="new_file"/><br />
            Name link (max. 200)<span class="red">*</span>:<br /><input type="text" name="name_link" value="Upload additional file file"/><br /><input type="submit" name="submit" value="Upload"/>';
    echo '</form></div><div class="nfooter"><small>Max size: ' . $set['flsz'] . ' Kb, Extension: ' . implode(', ', $defaultExt) . '</small></div>';
    $req_file_more = mysql_query("SELECT * FROM `down_more` WHERE `refid` = '$id'");
    $total_file = mysql_num_rows($req_file_more);
    if ($total_file) {
        while ($res_file_more = mysql_fetch_assoc($req_file_more)) {
            echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
            $format = explode('.', $res_file_more['name']);
            $format_file = strtolower($format[count($format) - 1]);
            echo '<table  width="100%"><tr><td width="16" valign="top">';
            if ($format_file == 'jar' && $set_down['icon_java'])
                echo java_icon($res_down['dir'] . '/' . $res_file_more['name'], 'more_' . $res_file_more['id']);
            else
                echo '<img src="' . $filesroot . '/images/download/' . (file_exists($filesroot . '/images/download/' . $format_file . '.png') ? $format_file . '.png' : 'file.gif') . '" alt="file" />';
            echo '</td><td> ' . $res_file_more['rus_name'] . ' <a href="index.php?act=file_more&amp;id=' . $id . '&amp;edit=' . $res_file_more['id'] . '">Change</a> <span class="red"><a href="index.php?act=file_more&amp;id=' . $id . '&amp;del=' . $res_file_more['id'] .
                '">[X]</a></span><div class="sub">' . $res_file_more['name'] . ' (' .  formatsize($res_file_more['size']) . '), ' . date("d.m.y в H:i", $res_file_more['time'] + $set_user['timeshift'] * 3600) . '</div></td></tr></table></div>';
            ++$i;
        }
        echo '<div class="nfooter">Total: ' . $total_file . '</div>';
    }
    echo '<p><a href="index.php?act=view&amp;id=' . $id . '">Back</a></p>';
}
?>