<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || ($rights < 6 && $rights != 4)) {
    echo functions::display_error('<a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
if (isset($_POST['submit'])) {
    $text = isset($_POST['opis']) ? mysql_real_escape_string(trim($_POST['opis'])) : '';
    mysql_query("UPDATE `down_files` SET `about` = '$text' WHERE `id` = '$id' LIMIT 1");
    header('Location: index.php?act=view&id=' . $id);
} else {
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Description:</b> ' . functions::checkout($res_down['rus_name']) . '</div>';
    echo '<div class="list1"><form action="index.php?act=edit_about&amp;id=' . $id . '" method="post">
   <small>Maximum 500 characters</small><br /><textarea name="opis">' . htmlentities($res_down['about'], ENT_QUOTES, 'UTF-8') . '</textarea>';
    echo '<br /><input type="submit" name="submit" value="Save"/></form></div>';
    echo '<div class="nfooter"><a href="index.php?act=view&amp;id=' . $id . '">Back</a></div>';
}
?>