<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Search';
require('../incfiles/head.php');
$search_post = isset($_POST['search']) ? trim($_POST['search']) : false;
$search_get = isset($_GET['search']) ? rawurldecode(trim($_GET['search'])) : '';
$search = $search_post ? $search_post : $search_get;
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="index.php"><b>Download</b></a> | Search</div>';
echo '<form action="index.php?act=search" method="post"><div class="gmenu"><p>';
echo 'Search:<br /><input type="text" name="search" value="' . functions::checkout($search) . '" />';
echo '<br /><input name="id" type="checkbox" value="1" ' . ($id ? 'checked="checked"' : '') . '/> Search in description<br />';
echo '<input type="submit" value="Search" name="submit" /><br />';
echo '</p></div></form>';
$error = false;
if (!empty($search) && mb_strlen($search) < 2 || mb_strlen($search) > 64)
    $error = 'Invalid length. Allowed minimum 3 and maximum 64 characters';
if ($search && !$error) {
    $search = preg_replace("/[^\w\x7F-\xFF\s]/", " ", $search);
    $search_db = strtr($search, array (
        '_' => '\\_',
        '%' => '\\%',
        '*' => '%'
    ));
    $search_db = '%' . $search_db . '%';
    $sql = ($id ? '`about`' : '`rus_name`') . ' LIKE \'' . mysql_real_escape_string($search_db) . '\'';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2'  AND $sql"), 0);
    if ($total) {
        $req_down = mysql_query("SELECT * FROM `down_files` WHERE `type` = '2'  AND $sql ORDER BY `rus_name` ASC LIMIT $start, $kmess");
        while ($res_down = mysql_fetch_assoc($req_down)) {
            echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
            echo display_file($res_down);
            echo '</div>';
            ++$i;
        }
    } else {
        echo '<div class="menu"><p>Your search did not found</p></div>';
    }
    echo '<div class="nfooter">Total:  ' . $total . '</div>';
    if ($total > $kmess) {
        $check_search = functions::checkout(rawurlencode($search));
        echo '<p>' . functions::display_pagination('index.php?act=search&amp;search=' . $check_search . '&amp;id=' . $id . '&amp;', $start, $total, $kmess) . '</p>';
        echo '<p><form action="index.php" method="get"><input type="hidden" value="search" name="act" /><input type="hidden" value="' . $id . '" name="id" /><input type="hidden" value="' . $check_search . '" name="search" /><input type="hidden" name="id" value="' . $id
            . '"/><input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form></p>';
    }
    echo '<p><a href="index.php?act=search">Search again</a></p>';
} else {
    if ($error)
        echo '<div class="rmenu"><p>ERROR!<br />' . $error . '</p></div>';
    echo '<div class="omenu"><small>Search goes on the file name and not case-sensitive letters. that is, <b>FiLe</b> or <b>file</b> to find equivalent. <br />Length of query: min 3, max 64.</small></div>';
}
echo '<p><a href="index.php?">Back</a></p>';
?>
