<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'New files';
$sql_down = '';
if ($id) {
    $cat = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$id' LIMIT 1");
    $res_down_cat = mysql_fetch_assoc($cat);
    if (mysql_num_rows($cat) == 0 || !is_dir($res_down_cat['dir'] . '/' . $res_down_cat['name'])) {
        require('../incfiles/head.php');
        echo functions::display_error('Directory does not exist<br /><a href="index.php">Back</a>');
        require('../incfiles/end.php');
        exit;
    }
    $title_pages = functions::checkout(mb_substr($res_down_cat['rus_name'], 0, 30));
    $textl = 'New files: ' . (mb_strlen($res_down_cat['rus_name']) > 30 ? $title_pages . '...' : $title_pages);
    $sql_down = ' AND `dir` LIKE \'' . ($res_down_cat['dir'] . '/' . $res_down_cat['name']) . '%\' ';
}
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $textl . '</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2'  AND `time` > $old $sql_down"), 0);
if ($total) {
    $req_down = mysql_query("SELECT * FROM `down_files` WHERE `type` = '2'  AND `time` > $old $sql_down ORDER BY `time` DESC LIMIT $start, $kmess");
    while ($res_down = mysql_fetch_assoc($req_down)) {
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        echo display_file($res_down);
        echo '</div>';
        ++$i;
    }
} else {
    echo '<div class="menu">No new files!</div>';
}
echo '<div class=nfooter">Total: ' . $total . '</div>';
if ($total > $kmess) {
    echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;act=new_files&amp;', $start, $total, $kmess) . '</div>';
    echo '<form action="index.php" method="get"><input type="hidden" value="new_files" name="act" /><input type="hidden" name="id" value="' . $id . '"/><input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form><br />';
}
echo '<a href="index.php">Back</a>';
?>