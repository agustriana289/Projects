<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Files in moderation';
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $textl . '</b></div>';
    if ($id) {
        mysql_query("UPDATE `down_files` SET `type` = 2 WHERE `id` = '$id' LIMIT 1");
        echo '<div class="gmenu">File accepted</div>';
    } else if (isset($_POST['all_mod'])) {
        mysql_query("UPDATE `down_files` SET `type` = 2 WHERE `type` = '3'");
        echo '<div class="gmenu">All files are accepted</div>';
    }
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '3'"), 0);
    if ($total) {
        $req_down = mysql_query("SELECT * FROM `down_files` WHERE `type` = '3' ORDER BY `time` DESC LIMIT $start, $kmess");
        while ($res_down = mysql_fetch_assoc($req_down)) {
            echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
            echo display_file($res_down);
            echo '<div class="sub"><a href="index.php?act=mod_files&amp;id=' . $res_down['id'] . '">Accept</a> | <span class="red"><a href="index.php?act=del_file&amp;id=' . $res_down['id'] . '">Delete</a></span></div></div>';
            ++$i;
        }
        echo '<div class="rmenu"><form name="" action="index.php?id=' . $id . '&amp;act=mod_files" method="post"><input type="submit" name="all_mod" value="Accept all"/></form></div>';
    } else {
        echo '<div class="menu">The list is empty!</div>';
    }
    echo '<div class="nfooter">Total: ' . $total . '</div>';
    if ($sum_total > $kmess) {
        echo '<p>' . functions::display_pagination('index.php?id=' . $id . '&amp;act=mod_files&amp;', $start, $total, $kmess) . '</p>';
        echo '<p><form action="index.php" method="get"><input type="hidden" value="mod_files" name="act" /><input type="hidden" name="id" value="' . $id . '"/><input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form></p>';
    }
    echo '<p><a href="index.php">Back</a></p>';
} else {
    header('Location: ' . $set['homeurl'] . '/?err');
}
?>