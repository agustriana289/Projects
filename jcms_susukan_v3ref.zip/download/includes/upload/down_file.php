<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
$req = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND `type` = 1 LIMIT 1");
$res = mysql_fetch_assoc($req);
if (mysql_num_rows($req) && is_dir($res['dir'] . '/' . $res['name'])) {
    if (($res['field'] && $user_id) || ($rights == 4 || $rights >= 6)) {
        $al_ext = $res['field'] ? explode(', ', $res['text']) :  $defaultExt;
        if (isset($_POST['submit'])) {
            $load_cat = $res['dir'] . '/' . $res['name'];
            $do_file = false;
            if ($_FILES['fail']['size'] > 0) {
                $do_file = true;
                $fname = strtolower($_FILES['fail']['name']);
                $fsize = $_FILES['fail']['size'];
            }
            if ($do_file) {
                $error = array ();
                $new_file = isset($_POST['new_file']) ? trim($_POST['new_file']) : null;
                $name = isset($_POST['text']) ? trim($_POST['text']) : null;
                $name_link = isset($_POST['name_link']) ? functions::check(mb_substr($_POST['name_link'], 0, 200)) : null;
                $text = isset($_POST['opis']) ? mysql_real_escape_string(trim($_POST['opis'])) : null;
                $ext = explode(".", $fname);
                if (!empty($new_file)) {
                    $fname = strtolower($new_file . '.' . $ext[1]);
                    $ext = explode(".", $fname);
                }
                if (empty($name))
                    $name = $fname;
                if (empty($name_link))
                    $error[] = 'Please enter name.';
                if ($fsize > 1024 * $set['flsz'])
                    $error[] = 'File exceeds the weight ' . $set['flsz'] . ' Kb.';
                if (count($ext) != 2)
                    $error[] = 'Incorrect file name! By sending only allowed with a file name and 1 extension (<b>name.ext</b>)';
                if (!in_array($ext[1], $al_ext))
                    $error[] = 'Prohibited file type! By sending only allowed files with the following extension: ' . implode(', ', $al_ext);
                if (strlen($fname) > 30)
                    $error[] = 'The length of the file name to save should not exceed 30 characters';
                if (preg_match("/[^\da-z_\-.]+/", $fname))
                    $error[] = 'File name contains invalid characters. Allowed only Latin characters, numbers and some characters ( .()+_- ). forbidden white space.';
                if ($error) {
                    $error[] = '<a href="index.php?act=down_file&amp;id=' . $id . '">Back</a>';
                    echo functions::display_error($error);
                } else {
                    if (file_exists("$load_cat/$fname"))
                        $fname = $realtime . $fname;
                    if ((move_uploaded_file($_FILES["fail"]["tmp_name"], "$load_cat/$fname")) == true) {
                        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Uploading a file</b></div>';
                        @chmod("$fname", 0777);
                        @chmod("$load_cat/$fname", 0777);
                        echo '<div class="gmenu">File is attached';
                        if ($set_down['mod'] && ($rights < 6 && $rights != 4)) {
                            echo ' After accept by staff, this file will be added to download menu.';
                            $type = 3;
                        } else
                            $type = 2;
                        echo '</div>';
                        $fname = mysql_real_escape_string($fname);
                        $name = mysql_real_escape_string(mb_substr($name, 0, 200));
                        mysql_query("INSERT INTO `down_files` SET `refid`='$id', `dir`='$load_cat', `time`='$realtime',`name`='$fname', `text` = '$name_link',`rus_name`='$name', `type` = '$type',`user_id`='$user_id', `about` = '$text'");
                        $file_id = mysql_insert_id();
                        require('../incfiles/lib/class.upload.php');
                        $handle = new upload($_FILES['screen']);
                        if ($handle->uploaded) {
                            if (mkdir($screens_path . '/' . $file_id, 0777) == true)
                                @chmod($screens_path . '/' . $file_id, 0777);
                            $handle->file_new_name_body = $file_id;
                            $handle->allowed = array (
                                'image/jpeg',
                                'image/gif',
                                'image/png'
                            );
                            $handle->file_max_size = 1024 * $set['flsz'];
                            $handle->file_overwrite = true;
                            if ($set_down['screen_resize']) {
                                $handle->image_resize = true;
                                $handle->image_x = 240;
                                $handle->image_ratio_y = true;
                            }
                            $handle->process($screens_path . '/' . $file_id . '/');
                            if ($handle->processed) {
                                echo '<div class="rmenu">Screenshot is attached</div>';
                            } else
                                echo '<div class="rmenu">Screenshot not attached: ' . $handle->error . '</div>';
                        } else
                            echo '<div class="rmenu">Screenshot not attached</div>';
                        if (!$set_down['mod'] || $rights > 6 || $rights == 4) {
                            echo '<div class="menu"><a href="index.php?act=view&amp;id=' . $file_id . '">Back to file</a></div>';
                            $dirid = $id;
                            $sql = '';
                            while ($dirid != '0' && $dirid != "") {
                                $res_down = mysql_fetch_assoc(mysql_query("SELECT `refid` FROM `down_files` WHERE `type` = 1 AND `id` = '$dirid' LIMIT 1"));
                                if ($i)
                                    $sql .= ' OR ';
                                $sql .= '`id` = \'' . $dirid . '\'';
                                $dirid = $res_down['refid'];
                                ++$i;
                            }
                            mysql_query("UPDATE `down_files` SET `total` = (`total`+1) WHERE $sql");
                            mysql_query("OPTIMIZE TABLE `down_files`");
                        }
                        echo '<div class="phdr"><a href="index.php?act=down_file&amp;id=' . $id . '">Upload</a> | <a href="index.php?id=' . $id . '">Back</a></div>';
                    } else
                        echo '<div class="rmenu">Error attaching.<br /><a href="index.php?act=down_file&amp;id=' . $id . '">Repeat</a></div>';
                }
            } else
                echo '<div class="rmenu">No file selected.<br /><a href="index.php?act=down_file&amp;id=' . $id . '">Repeat</a></div>';
        } else {
            echo '<div class="phdr"><b>Uploading a file: ' . functions::checkout($res['rus_name']) . '</b></div>';
            echo '<div class="list1"><form action="index.php?act=down_file&amp;id=' . $id
                . '" method="post" enctype="multipart/form-data">
            File<span class="red">*</span>:<br /><input type="file" name="fail"/><br />
            Save as (max. 30, with no extension):<br /><input type="text" name="new_file"/><br />
            Screenshot:<br /><input type="file" name="screen"/><br />
            File Name (max. 200):<br /><input type="text" name="text"/><br />
            Link to download the file (max. 200)<span class="red">*</span>:<br /><input type="text" name="name_link" value="Upload"/><br />
            Description (max. 500)<br /><textarea name="opis"></textarea>';
            echo '<br /><input type="submit" name="submit" value="Upload"/></form>';
            echo '</div><div class="omenu"><small>Max size: ' . $set['flsz'] . ' Kb, Extension: ' . implode(', ', $al_ext) . ($set_down['screen_resize'] ? '<br />Screenshot will be automatically preobrozavan in the picture, of a width not exceeding 240px (height will be automatically resize)' : '') . '</small></div>';
            echo '<p><a href="index.php?id=' . $id . '">Back</a></p>';
        }
    } else
        echo functions::display_error('Access denied<br /><a href="index.php?id=' . $id . '">Back</a>');
} else
    echo functions::display_error('Directory does not exist<br /><a href="index.php">Back</a>');
?>