<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Top Uploader';
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $textl . '</b></div>';
$req = mysql_query("SELECT * FROM `down_files` WHERE `user_id` > 0 GROUP BY `user_id` ORDER BY COUNT(`user_id`)");
$total = mysql_num_rows($req);
if ($total) {
	$req_down = mysql_query("SELECT *, COUNT(`user_id`) AS `count` FROM `down_files` WHERE `user_id` > 0 GROUP BY `user_id` ORDER BY `count` DESC LIMIT $start, $kmess");

	while ($res_down = mysql_fetch_assoc($req_down)) {
        echo ($i++ % 2) ? '<div class="list2">' : '<div class="list1">';
        $user = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id`=". $res_down['user_id']));
		echo functions::display_user($user, array('iphide' => 0, 'sub' => '<a href="index.php?act=user_files&amp;id=' . $user['id'] . '">Files user:</a> ' . $res_down['count'])) . '</div>';
	}
} else {
    echo '<div class="menu">The list is empty!</div>';
}
echo '<div class="nfooter">Total: ' . $total . '</div>';
if ($total > $kmess) {
    echo '<div class="topmenu">' . functions::display_pagination('index.php?act=top_users&amp;', $start, $total, $kmess) . '</div>';
    echo '<form action="index.php" method="get">
    <input type="hidden" value="top_users" name="act" />
    <input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form><br />';
}
echo '<p><a href="index.php">Back</a></p>';
?>