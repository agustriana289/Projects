<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    $req = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$id' LIMIT 1");
    $res = mysql_fetch_assoc($req);
    if (!mysql_num_rows($req) || !is_dir($res['dir'] . '/' . $res['name'])) {
        echo functions::display_error('Directory does not exist<br /><a href="index.php">Back</a>');
        require('../incfiles/end.php');
        exit;
    }
    if (isset($_GET['up']) || isset($_GET['down'])) {
        if (isset($_GET['up'])) {
            $order = 'DESC';
            $val = '<';
        } else {
            $order = 'ASC';
            $val = '>';
        }
        $req_two = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `refid` = '" . $res['refid'] . "' AND `sort` $val '" . $res['sort'] . "' ORDER BY `sort` $order LIMIT 1");
        if (mysql_num_rows($req_two)) {
            $res_two = mysql_fetch_assoc($req_two);
            mysql_query("UPDATE `down_files` SET `sort` = '" . $res_two['sort'] . "' WHERE `id` = '$id' LIMIT 1");
            mysql_query("UPDATE `down_files` SET `sort` = '" . $res['sort'] . "' WHERE `id` = '" . $res_two['id'] . "' LIMIT 1");
        }
        header('location: index.php?id=' . $res['refid']);
        exit;
    }
    if (isset($_POST['submit'])) {
        $rus_name = trim($_POST['rus_name']);
        if (empty($rus_name))
            $error[] = 'Please enter name';
        $error_format = false;
        if ($rights == 9 && isset($_POST['user_down'])) {
            $format = trim($_POST['format']);
            $format_array = explode(', ', $format);
            foreach ($format_array as $value) {
                if (!in_array($value, $defaultExt))
                    $error_format .= 1;
            }
            $user_down = 1;
            $format_files = functions::check($_POST['format']);
        } else {
            $user_down = 0;
            $format_files = '';
        }
        if ($error_format)
            $error[] = 'You can only write the following extension: ' . implode(', ', $defaultExt);
        if ($error) {
            $error[] = '<a href="index.php?act=edit_cat&amp;id=' . $id . '">Back</a>';
            echo functions::display_error($error);
            require('../incfiles/end.php');
            exit;
        }
        $rus_name = mysql_real_escape_string($rus_name);
        $desc = isset($_POST['desc']) ? functions::check($_POST['desc']) : '';
        mysql_query("UPDATE `down_files` SET `field`='$user_down', `text` = '$format_files', `desc`='$desc', `rus_name`='$rus_name' WHERE `id` = '$id' LIMIT 1");
        header('location: index.php?id=' . $id);
    } else {
        $name = functions::checkout($res['rus_name']);
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Edit Category:</b> ' . $name . '</div>' .
        '<div class="menu"><form action="index.php?act=edit_cat&amp;id=' . $id . '" method="post">
        Name to display:<br/><input type="text" name="rus_name" value="' . $name . '"/><br/>' .
        'Description (max. 500):<br/><textarea name="desc" cols="24" rows="4">' . functions::checkout($res['desc']) . '</textarea><br/>';
       if ($rights == 9) {
            echo '<div class="sub"><input type="checkbox" name="user_down" value="1"' . ($res['field'] ? ' checked="checked"' : '') . '/> Ð�Ñ�Ð³Ñ�Ñ�Ð·ÐºÐ° Ñ�Ð°Ð¹Ð»Ð¾Ð² Ñ�Ð·ÐµÑ�Ð°Ð¼Ð¸<br/>
                 Allowed extension (zip, jar etc.):<br/><input type="text" name="format" value="' . $res['text'] . '"/></div>
                 <div class="sub">You can only write the following extension:<br /> ' . implode(', ', $defaultExt) . '<br />Other extensions to the safety of upload will not be permitted</div>';
        }
        echo ' <input type="submit" name="submit" value="Save"/><br/></form></div>';
    }
    echo '<div class="nfooter">';
    if ($id)
        echo '<a href="index.php?id=' . $id . '">Back</a> | ';
    echo '<a href="index.php">Category</a></div>';
} else {
    header('Location: ' . $set['homeurl'] . '/?err');
}
?>