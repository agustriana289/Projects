<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

//TODO: Ð�Ð¾Ð±Ð°Ð²Ð¸Ñ�Ñ� Ð¿Ñ�Ð¾Ð²ÐµÑ�ÐºÑ�, Ð¿Ñ�Ñ�Ñ�Ð¾Ð¹ Ð»Ð¸ ÐºÐ°Ñ�Ð°Ð»Ð¾Ð³, Ð¿ÐµÑ�ÐµÐ´ Ñ�Ð´Ð°Ð»ÐµÐ½Ð¸ÐµÐ¼
defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    $req = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$id' LIMIT 1");
    $del_cat = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = 1 AND`refid` = '$id'"), 0);
    if (!mysql_num_rows($req) || $del_cat) {
        echo functions::display_error('System error<br /><a href="index.php">Back</a>');
        require('../incfiles/end.php');
        exit;
    }
    $res = mysql_fetch_assoc($req);
    if (isset($_GET['yes'])) {
        $req_down = mysql_query("SELECT * FROM `down_files` WHERE `refid` = '$id'");
        while ($res_down = mysql_fetch_assoc($req_down)) {
            if (is_dir($screens_path . '/' . $res_down['id'])) {
                $dir_clean = opendir($screens_path . '/' . $res_down['id']);
                while ($file = readdir($dir_clean)) {
                    if ($file != '.' && $file != '..') {
                        @unlink($screens_path . '/' . $res_down['id'] . '/' . $file);
                    }
                }
                closedir($dir_clean);
                rmdir($screens_path . '/' . $res_down['id']);
            }
            @unlink('../files/download/java_icons/' . $res_down['id'] . '.png');
            $req_file_more = mysql_query("SELECT * FROM `down_more` WHERE `refid` = '" . $res_down['id'] . "'");
            while ($res_file_more = mysql_fetch_assoc($req_file_more)) {
                @unlink($res_down['dir'] . '/' . $res_file_more['name']);
            }
            @unlink($res_down['dir'] . '/' . $res_down['name']);
            mysql_query("DELETE FROM `down_more` WHERE `refid`='" . $res_down['id'] . "'");
            mysql_query("DELETE FROM `down_comms` WHERE `refid`='" . $res_down['id'] . "'");
        }
        mysql_query("DELETE FROM `down_files` WHERE `refid` = '$id' OR `id` = '$id'");
        rmdir($res['dir'] . '/' . $res['name']);
        header('location: index.php?id=' . $res['refid']);
    } else {
        echo '<div class="phdr"><b>Delete a category</b></div><div class="rmenu">Are you sure you want to delete a directory?<br /> <a href="index.php?act=del_cat&amp;id=' . $id . '&amp;yes">Remove</a></div><div class="nfooter"><a href="index.php?id=' . $id . '">Cancel</a></div>';
    }
} else {
    header('Location: ' . $set['homeurl'] . '/?err');
}
?>