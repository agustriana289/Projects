<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
if ($rights == 4 || $rights >= 6) {
    if (!$id)
        $load_cat = $files_path;
    else {
        $req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND `type` = 1 LIMIT 1");
        $res_down = mysql_fetch_assoc($req_down);
        if (mysql_num_rows($req_down) == 0 || !is_dir($res_down['dir'] . '/' . $res_down['name'])) {
            echo functions::display_error('Directory does not exist');
            echo '<div class="rmenu"><a href="index.php">Back</a></div>';
            require('../incfiles/end.php');
            exit;
        }
        $load_cat = $res_down['dir'] . '/' . $res_down['name'];
    }
    if (isset($_POST['submit'])) {
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        $rus_name = isset($_POST['rus_name']) ? trim($_POST['rus_name']) : '';
        $desc = isset($_POST['desc']) ? trim($_POST['desc']) : '';
        $user_down = isset($_POST['user_down']);
        $format = $user_down && isset($_POST['format']) ? trim($_POST['format']) : false;
        if (empty($name))
            $error[] = 'Please enter the name';
        if (preg_match("/[^0-9a-zA-Z]+/", $name))
            $error[] = 'Invalid characters in the name of the folder<br/>';
        if ($rights == 9 && $user_down) {
            foreach (explode(',', $format) as $value) {
                if (!in_array(trim($value), $defaultExt)){
                    $error[] = 'You can only write the following extension: ' . implode(', ', $defaultExt);
                    break;
                }
            }
        }
        if ($error) {
            echo functions::display_error($error, '<a href="index.php?act=add_cat&amp;id=' . $id . '">Back</a>');
            require('../incfiles/end.php');
            exit;
        }
        if (empty($rus_name))
            $rus_name = $name;
        $dir = false;
        if (!is_dir("$load_cat/$name"))
            $dir = mkdir("$load_cat/$name", 0777);
        if ($dir == true) {
            chmod("$load_cat/$name", 0777);
            mysql_query("INSERT INTO `down_files` SET
                `refid`='$id',
                `dir`='$load_cat',
                `time`='$realtime',
                `sort`='$realtime',
                `name`='" . mysql_real_escape_string($name) . "',
                `desc`='" . mysql_real_escape_string($desc) . "',
                `type` = '1',
                `field`='$user_down',
                `text` = '" . mysql_real_escape_string($format) . "',
                `rus_name`='" . mysql_real_escape_string($rus_name) . "'
            ");
            $cat_id = mysql_insert_id();
            echo '<div class="phdr"><b>Create a category</b></div><div class="list1">Folder is created</div>';
            echo '<div class="list2"><a href="index.php?id=' . $cat_id . '">Ð� Ð¿Ð°Ð¿ÐºÑ�</a></div>';
        } else {
            echo functions::display_error('Error while creating categories<br /><a href="index.php?act=add_cat&amp;id=' . $id . '">Back</a>');
            require('../incfiles/end.php');
            exit;
        }
    } else {
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Create a category</b></div><div class="menu">' .
            '<form action="index.php?act=add_cat&amp;id=' . $id . '" method="post">
        Name [A-Za-z0-9]:<br/><input type="text" name="name"/><br/>' .
            'Name to display:<br/><input type="text" name="rus_name"/><br/>' .
            'Description (max. 500):<br/><textarea name="desc" cols="24" rows="4"></textarea><br/>';
        if ($rights == 9) {
            echo '<div class="sub"><input type="checkbox" name="user_down" value="1" /> Allow user to upload file<br/>
                 Allowed extension (zip, jar etc.):<br/><input type="text" name="format"/></div>
                 <div class="sub">You can only write the following extension:<br /> ' . implode(', ', $defaultExt)
                . '<br />Other extensions for safety of upload will not be permitted</div>';
        }
        echo ' <input type="submit" name="submit" value="Create"/><br/></form></div>';
    }
    echo '<div class="nfooter">';
    if ($id)
        echo '<a href="index.php?id=' . $id . '">Back</a> | ';
    echo '<a href="index.php">Category</a></div>';
} else {
    header('Location: ' . $set['homeurl'] . '/?err');
}
?>