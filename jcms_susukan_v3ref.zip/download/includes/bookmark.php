<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Files user';
require('../incfiles/head.php');

if (!$user_id) {
    echo functions::display_error('Only authorized');
    require('../incfiles/end.php');
    exit;
}
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>My favorites</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_bookmark` WHERE `user_id` = $user_id"), 0);
if ($total) {
    $req_down = mysql_query("SELECT `down_files`.*, `down_bookmark`.`id` AS `bid`
    FROM `down_files` LEFT JOIN `down_bookmark` ON `down_files`.`id` = `down_bookmark`.`file_id`
    WHERE `down_bookmark`.`user_id`=$user_id ORDER BY `down_files`.`time` DESC LIMIT $start, $kmess");
	while ($res_down = mysql_fetch_assoc($req_down)) {
        echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
        echo display_file($res_down);
        echo '</div>';
        ++$i;
    }
} else {
    echo '<div class="menu">The list is empty!</div>';
}
echo '<div class="nfooter">Total: ' . $total . '</div>';
if ($total > $kmess) {
    echo '<div class="topmenu">' . functions::display_pagination('index.php?act=bookmark&amp;', $start, $total, $kmess) . '</div>';
    echo '<form action="index.php" method="get">
    <input type="hidden" value="bookmark" name="act" />
    <input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form><br />';
}
echo '<p><a href="index.php">Back to category</a></p>';
?>