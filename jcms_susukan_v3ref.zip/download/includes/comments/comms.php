<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$req_down = mysql_query("SELECT * FROM `down_files` WHERE `id` = '$id' AND (`type` = 2 OR `type` = 3)  LIMIT 1");
$res_down = mysql_fetch_assoc($req_down);
if (mysql_num_rows($req_down) == 0 || !is_file($res_down['dir'] . '/' . $res_down['name']) || ($res_down['type'] == 3 && $rights < 6 && $rights != 4)) {
    require('../incfiles/head.php');
    echo functions::display_error('File not found<br /><a href="index.php">Back</a>');
    require('../incfiles/end.php');
    exit;
}
$title_pages = functions::checkout(mb_substr($res_down['rus_name'], 0, 30));
$textl = 'Comment: ' . (mb_strlen($res_down['rus_name']) > 30 ? $title_pages . '...' : $title_pages);
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>' . $textl . '</b></div>';
switch ($do) {
    case "delpost":
        $comm = isset($_GET['comm']) ? abs(intval($_GET['comm'])) : false;
        if ($rights >= 6 && $comm) {
            if (isset($_GET['yes'])) {
                mysql_query("DELETE FROM `down_comms` WHERE `id`='$comm' LIMIT 1");
                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_comms` WHERE `refid`='$id'"), 0);
                mysql_query("UPDATE `down_files` SET `total` = '$colmes' WHERE `id` = '$id' LIMIT 1");
                header('Location: index.php?act=comms&id=' . $id);
            } else {
                echo '<div class="rmenu"><p>Are you sure you want to remove a comment?<br/>';
                echo '<a href="index.php?act=comms&amp;id=' . $id . '&amp;do=delpost&amp;comm=' . $comm . '&amp;yes">Delete</a></p></div><div class="nfooter"><a href="index.php?act=comms&amp;id=' . $id . '">Back</a></div>';
            }
        }
        break;

    case 'say':
        if ($user_id && !$ban['1'] && !$ban['10']) {
            $error = array ();
            $flood = false;
            $flood = functions::antiflood();
            if ($flood)
                $error[] = 'Antiflood, Please wait ' . $flood . ' sec.';
            $msg = trim($_POST['msg']);
            if (empty($msg))
                $error[] = 'Please enter name.';
            if ($error) {
                $error[] = '<a href="index.php?act=comms&amp;id=' . $id . '">Back</a>';
                echo functions::display_error($error);
            } else {
                $msg = mb_substr($msg, 0, 500);
                if (isset($_POST['msgtrans'])) {
                    $msg = functions::trans($msg);
                }
                $msg = mysql_real_escape_string($msg);
                $agn = mysql_real_escape_string($agn);
                mysql_query("INSERT INTO `down_comms` SET `time`='$realtime', `user_id`='$user_id', `refid`='$id', `text`='$msg', `ip`='$ip', `browser`='$agn'");
                mysql_query("UPDATE `users` SET `lastpost` = '$realtime', `komm` = (`komm`+1) WHERE `id` = '$user_id' LIMIT 1");
                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_comms` WHERE `refid`='$id'"), 0);
                mysql_query("UPDATE `down_files` SET `total` = '$colmes' WHERE `id` = '$id' LIMIT 1");
                header('Location: index.php?act=comms&id=' . $id);
            }
        } elseif (!$user_id) {
            echo '<div class="rmenu">Please <a href="../login.php">Login</a> to post a comment</div>';
        }
        break;

    default:
        if ($user_id && !$ban['1'] && !$ban['10']) {
            echo '<div class="gmenu"><form name="form" action="index.php?act=comms&amp;id=' . $id . '&amp;do=say" method="post">';
            echo '<b>Message</b> <small>(max. 500)</small><br/>';
            if (!$is_mobile) echo bbcode::auto_bb('form', 'msg');
            echo '<textarea rows="5" name="msg"></textarea><br/>';
            if ($set_user['translit'])
                echo '<input type="checkbox" name="msgtrans" value="1" /> Translate posts<br/>';
            echo '<input type="submit" title="Click to send" name="submit" value="Post"/></form></div>';
        } elseif (!$user_id) {
            echo '<div class="rmenu">Please <a href="../login.php">Login</a> to post a comment</div>';
        }
        $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_comms` WHERE `refid`='$id'"), 0);
        if ($colmes) {
            $req = mysql_query("SELECT `down_comms`.*, `down_comms`.`id` AS `cid`, `users`.`rights`, `users`.`name`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
            FROM `down_comms` LEFT JOIN `users` ON `down_comms`.`user_id` = `users`.`id` WHERE `down_comms`.`refid`='$id' ORDER BY `down_comms`.`time` DESC LIMIT $start, $kmess");
            while ($res = mysql_fetch_assoc($req)) {
                $text = '';
                echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
                $text = ' <span class="gray">(' . date("d.m.y / H:i", $res['time'] + $set_user['timeshift'] * 3600) . ')</span>';
                $post = functions::checkout($res['text'], 1, 1);
                if ($set_user['smileys'])
                    $post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
                $subtext = '<span class="red"><a href="index.php?act=comms&amp;id=' . $id . '&amp;do=delpost&amp;comm=' . $res['cid'] . '">Remove</a></span>';
                $arg = array (
                    'header' => $text,
                    'body' => $post,
                    'sub' => $subtext
                );
                echo functions::display_user($res, $arg) . '</div>';
                ++$i;
            }
        } else {
            echo '<div class="menu">This file has no comment!</div>';
        }
        echo '<div class="nfooter">Total: ' . $colmes . '</div>';
        if ($colmes > $kmess) {
            echo '<p>' . functions::display_pagination('index.php?act=comms&amp;id=' . $id . '&amp;', $start, $colmes, $kmess) . '</p>';
            echo '<p><form action="index.php" method="get"><input type="text" name="page" size="2"/><input type="hidden" name="act" value="comms"/><input type="hidden" name="id" value="' . $id . '"/><input type="submit" value="Jump &gt;&gt;"/></form></p>';
        }
        echo '<p><a href="index.php?act=view&amp;id=' . $id . '">Back to file</a></p>';
}
?>