<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'load';
$textl = 'Download';
require('../incfiles/core.php');
require('includes/functions.php');
$down_path = $rootpath . 'files/download';
$screens_path = $rootpath . 'files/download/screen';
$files_path = $rootpath . 'files/download/files';
/*
-----------------------------------------------------------------
Настройки
-----------------------------------------------------------------
*/
$set_down = !empty($set['download']) ? unserialize($set['download']) : array (
    'mod' => 1,
    'theme_screen' => 1,
    'top' => 25,
    'icon_java' => 1,
    'video_screen' => 1,
    'screen_resize' => 1
);
if ($set_down['video_screen'] && !extension_loaded('ffmpeg'))
    $set_down['video_screen'] = 0;

/*
-----------------------------------------------------------------
Ограничиваем доступ к Загрузкам
-----------------------------------------------------------------
*/
$error = '';
if (!$set['mod_down'] && $rights < 7)
    $error = 'Downloads are closed';
elseif ($set['mod_down'] == 1 && !$user_id)
    $error = 'Access to downloads is only open for user, please <a href="../login.php">Login</a> first';
if ($error) {
    require('../incfiles/head.php');
    echo functions::display_error($error);
    require('../incfiles/end.php');
    exit;
}
$old = time() - 259200;
$realtime = time() + $system_set['timeshift']*3600;
/*
-----------------------------------------------------------------
Список разрешений для выгрузки
-----------------------------------------------------------------
*/
$defaultExt = array('rar', 'zip', 'pdf', 'nth', 'txt', 'tar', 'gz', 'jpg', 'jpeg', 'gif', 'png', 'bmp',
'3gp', 'mp3', 'mpg', 'sis', 'thm', 'jad', 'jar', 'cab', 'sis', 'sisx', 'exe', 'msi', 'apk', 'djvu', 'fb2');
/*
-----------------------------------------------------------------
Переключаем режимы работы
-----------------------------------------------------------------
*/
$array = array (
    'add_cat' => 'includes/category',
    'edit_cat' => 'includes/category',
    'del_cat' => 'includes/category',
	'mod_files' => 'includes/outputFiles',
    'new_files' => 'includes/outputFiles',
    'top_files' => 'includes/outputFiles',
    'user_files' => 'includes/outputFiles',
	'comms' => 'includes/comments',
    'comms_all' => 'includes/comments',
	'edit_file' => 'includes/fileControl',
    'del_file' => 'includes/fileControl',
    'edit_about' => 'includes/fileControl',
    'edit_screen' => 'includes/fileControl',
    'file_more' => 'includes/fileControl',
    'jad_file' => 'includes/fileControl',
    'mp3tags' => 'includes/fileControl',
    'load_file' => 'includes/fileControl',
    'open_zip' => 'includes/fileControl',
    'txt_in_jar' => 'includes/fileControl',
    'txt_in_zip' => 'includes/fileControl',
    'view' => 'includes/fileControl',
    'transfer_file' => 'includes/fileControl',
	'down_file' => 'includes/upload',
    'import' => 'includes/upload',
	'scan_about' => 'includes',
    'scan_dir' => 'includes',
    'search' => 'includes',
	'top_users' => 'includes',
    'recount' => 'includes',
	'bookmark' => 'includes'
);
$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php')) {
    require($path . $act . '.php');
} else {
    require('../incfiles/head.php');
    if (!$set['mod_down'])
        echo '<div class="rmenu"><b>Downloads are closed!</b></div>';
    /*
    -----------------------------------------------------------------
    Выводим список папок и файлов
    -----------------------------------------------------------------
    */
    if ($id) {
        $cat = mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$id' LIMIT 1");
        $res_down_cat = mysql_fetch_assoc($cat);
        if (mysql_num_rows($cat) == 0 || !is_dir($res_down_cat['dir'] . '/' . $res_down_cat['name'])) {
            // Если неправильно выбран каталог, выводим ошибку
            echo functions::display_error('Directory does not exist<br /><a href="index.php">Back</a>');
            require('../incfiles/end.php');
            exit;
        }
        $title_pages = functions::checkout(mb_substr($res_down_cat['rus_name'], 0, 30));
        $textl = mb_strlen($res_down_cat['rus_name']) > 30 ? $title_pages . '...' : $title_pages;
        // Ð�Ð¾Ð»Ñ�Ñ�Ð°ÐµÐ¼ Ñ�Ñ�Ñ�Ñ�ÐºÑ�Ñ�Ñ�Ñ� ÐºÐ°Ñ�Ð°Ð»Ð¾Ð³Ð¾Ð²
        $tree = array ();
        $dirid = $id;
        $i = 0;
        while ($dirid != '0' && $dirid != "") {
            $res_down = mysql_fetch_assoc(mysql_query("SELECT * FROM `down_files` WHERE `type` = 1 AND `id` = '$dirid' LIMIT 1"));
            $tree[] = $i ? '<a href="index.php?id=' . $dirid . '">' . functions::checkout($res_down['rus_name']) . '</a>' : functions::checkout($res_down['rus_name']);
            $dirid = $res_down['refid'];
            ++$i;
        }
        $tree[] = '<a href="index.php"><b>Download</b></a>';
        krsort($tree);
        echo '<div class="phdr">' . functions::display_menu($tree) . '</div>';
        $total_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2'  AND `time` > $old AND `dir` LIKE '" . ($res_down_cat['dir'] . '/' . $res_down_cat['name']) . "%'"), 0);
        if ($total_new)
            echo '<div class="rmenu"><a href="index.php?act=new_files&amp;id=' . $id . '">New files</a> (' . $total_new . ')</div>';
    } else {
        //TODO: Ð�Ð°Ð¿Ð¸Ñ�Ð°Ñ�Ñ� Ð¼Ð¾Ð´Ñ�Ð»Ñ� "Ð¿Ð¾Ñ�Ð»ÐµÐ´Ð½Ð¸Ðµ Ñ�Ð°Ð¹Ð»Ñ�". Ð�Ñ�Ð»Ð¸ Ð½ÐµÑ� Ð½Ð¾Ð²Ñ�Ñ� Ñ�Ð°Ð¹Ð»Ð¾Ð², Ñ�Ð¾ Ð±Ñ�Ð´Ñ�Ñ� Ð¿Ð¾ÐºÐ°Ð·Ñ�Ð²Ð°Ñ�Ñ�Ñ�Ñ� 10, Ð¸Ð»Ð¸ Ð±Ð¾Ð»ÐµÐµ Ð¿Ð¾Ñ�Ð»ÐµÐ´Ð½Ð¸Ñ� (Ð¿Ð¾ Ð´Ð°Ñ�Ðµ Ð²Ñ�Ð³Ñ�Ñ�Ð·ÐºÐ¸)
        echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Download</b></div>' .
            '<div class="topmenu"><a href="index.php?act=search">Search</a> | <a href="index.php?act=top_files&amp;id=0">Top Download</a> | <a href="index.php?act=top_users">Top Uploader</a></div>';
        $total_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2'  AND `time` > $old"), 0);
        if ($total_new)
            echo '<div class="rmenu"><a href="index.php?act=new_files&amp;id=' . $id . '">New files</a> (' . $total_new . ')</div>';
    }
    // Ð�Ð¾Ð´Ñ�Ñ�Ð¸Ñ�Ñ�Ð²Ð°ÐµÐ¼ Ñ�Ð¸Ñ�Ð»Ð¾ Ð¿Ð°Ð¿Ð¾Ðº Ð¸ Ñ�Ð°Ð¹Ð»Ð¾Ð²
    $total_cat = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `refid` = '$id' AND `type` = 1"), 0);
    $total_files = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `refid` = '$id' AND `type` = 2"), 0);
    $sum_total = $total_files + $total_cat;
    if ($sum_total) {
        if ($total_files > 1) {
            // Ð¡Ð¾Ñ�Ñ�Ð¸Ñ�Ð¾Ð²ÐºÐ° Ñ�Ð°Ð¹Ð»Ð¾Ð²
            if (isset($_POST['sort_down']))
                $_SESSION['sort_down'] = $_POST['sort_down'] ? 1 : 0;
            if (isset($_POST['sort_down2']))
                $_SESSION['sort_down2'] = $_POST['sort_down2'] ? 1 : 0;
            $sql_sort = isset($_SESSION['sort_down']) && $_SESSION['sort_down'] ? ', `name`' : ', `time`';
            $sql_sort .= isset($_SESSION['sort_down2']) && $_SESSION['sort_down2'] ? ' ASC' : ' DESC';
            echo '<form action="index.php?id=' . $id . '" method="post"><div class="topmenu"><b>Sort: </b>' .
                '<select name="sort_down" style="font-size:x-small"><option value="0"' . (!$_SESSION['sort_down'] ? ' selected="selected"' : '') . '>By Time</option>' .
                '<option value="1"' . ($_SESSION['sort_down'] ? ' selected="selected"' : '') . '>By Name</option>' .
                '</select> &amp; <select name="sort_down2" style="font-size:x-small">' .
                '<option value="0"' . (!$_SESSION['sort_down2'] ? ' selected="selected"' : '') . '>Descending</option>' .
                '<option value="1"' . ($_SESSION['sort_down2'] ? ' selected="selected"' : '') . '>Ascending</option>' .
                '</select><input type="submit" value="&gt;&gt;" style="font-size:x-small"/></div></form>';
        } else
            $sql_sort = '';
        $req_down = mysql_query("SELECT * FROM `down_files` WHERE `refid` = '$id' AND `type` < 3 ORDER BY `type` ASC, `sort` ASC $sql_sort LIMIT $start, $kmess");
        //Выводим список папок и файлов
        $i = 0;
        while ($res_down = mysql_fetch_assoc($req_down)) {
            echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
            if ($res_down['type'] == 1) {
$total_fls = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = '2' AND `dir` LIKE '" . ($res_down['dir']) . "%'"), 0);

echo '<img src="' . $set['homeurl'] . '/images/download/file.gif" alt="" />&#160;' .
                    '<a href="index.php?id=' . $res_down['id'] . '">' . functions::checkout($res_down['rus_name']) . '</a> (' . $total_fls . ')';
                if ($res_down['field'])
                    echo '<div><small>Folder: <span class="green"><b>' . $res_down['text'] . '</b></span></small></div>';
                if ($rights == 4 || $rights >= 6 || !empty($res_down['desc'])) {
                    $menu = array (
                        '<a href="index.php?act=edit_cat&amp;id=' . $res_down['id'] . '&amp;up">Up</a>',
                        '<a href="index.php?act=edit_cat&amp;id=' . $res_down['id'] . '&amp;down">Down</a>',
                        '<a href="index.php?act=edit_cat&amp;id=' . $res_down['id'] . '">Edit</a>',
                        '<a href="index.php?act=del_cat&amp;id=' . $res_down['id'] . '">Delete</a>'
                    );
                    echo '<div class="sub">' .
                        (!empty($res_down['desc']) ? '<div class="gray">' . functions::checkout($res_down['desc'], 1, 1) . '</div>' : '') .
                        ($rights == 4 || $rights >= 6 ? functions::display_menu($menu) : '') .
                        '</div>';
                }
            } else {
                echo display_file($res_down);
            }
            echo '</div>';
            ++$i;
        }
    } else {
        echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
    }
    echo '<div class="nfooter">';
    if ($total_cat > 0)
        echo 'Folders: ' . $total_cat;
    echo '&nbsp;&nbsp;';
    if ($total_files > 0)
        echo 'Files: ' . $total_files;
    echo '</div>';
    // Ð�Ð¾Ñ�Ñ�Ñ�Ð°Ð½Ð¸Ñ�Ð½Ð°Ñ� Ð½Ð°Ð²Ð¸Ð³Ð°Ñ�Ð¸Ñ�
    if ($sum_total > $kmess) {
        echo '<div class="topmenu">' . functions::display_pagination('index.php?id=' . $id . '&amp;', $start, $sum_total, $kmess);
        echo '<br /><form action="index.php" method="get"><input type="hidden" name="id" value="' . $id . '"/>' .
        '<input type="text" name="page" size="2"/><input type="submit" value="Jump &gt;&gt;"/></form></div>';
    }
    if ($rights == 4 || $rights >= 6) {
        /*
        -----------------------------------------------------------------
        Выводим ссылки на модерские функции
        -----------------------------------------------------------------
        */
        echo '<p><div class="func"><form action="redirect.php" method="post"><select name="act">' .
            '<option value="add_cat">Create a folder</option>';
        if ($id) {
            $del_cat = mysql_result(mysql_query("SELECT COUNT(*) FROM `down_files` WHERE `type` = 1 AND`refid` = '$id'"), 0);
            if (!$del_cat) {
                echo '<option value="del_cat">Delete a folder</option>';
            }
            echo '<option value="edit_cat">Edit file</option>' .
                '<option value="import">Import a file</option>' .
                '<option value="down_file">Upload file</option>';
        }
        echo '<option value="scan_dir">Update files</option>' .
            '<option value="clean">Remove innactive files</option>' .
            '<option value="scan_about">Update description</option>' .
            '<option value="recount">Update counters</option>' .
            '<input type="hidden" name="id" value="' . $id . '"/>' .
            '</select><input type="submit" value="Go"/></form></div></p>';
    }
    else if (isset($res_down_cat['field']) && $res_down_cat['field'] && $user_id && $id)
        echo '<p><div class="func"><a href="index.php?act=down_file&amp;id=' . $id . '">Upload file</a></div></p>';
    echo '<p>';
    echo ($id ? '<a href="index.php">Back to category</a>' :
    '<a href="index.php?act=bookmark">Overview of comments</a><br /><a href="index.php?act=bookmark">Bookmark</a>') . '</p>';
}
require('../incfiles/end.php');
?>