<?php
header('location: ../index.php?err');
die();