<?php
/*
////////////////////////////////////////////////////////////////////////////////
// GocMaster Community
// Home: http://gocmaster.com
// Developer: Ari(Tuan)
// Development Team: GMT
////////////////////////////////////////////////////////////////////////////////
*/
define('_IN_JOHNCMS', 1);
@ini_set('default_charset', 'utf-8');
require('../incfiles/core.php');
$sql1 = "ALTER TABLE bot ADD txt1 varchar(500) not null;";
$sql2 = "ALTER TABLE bot ADD txt2 varchar(500) not null;";
$sql3 = "ALTER TABLE bot ADD txt3 varchar(500) not null;";
$sql4 = "ALTER TABLE bot ADD txt4 varchar(500) not null;";
$sql5 = "ALTER TABLE bot ADD txt5 varchar(500) not null;";
mysql_query($sql1) or die('lỗi1: colums đã tồn tại');
mysql_query($sql2) or die('lỗi2: colums đã tồn tại');
mysql_query($sql3) or die('lỗi3: colums đã tồn tại');
mysql_query($sql4) or die('lỗi4: colums đã tồn tại');
mysql_query($sql5) or die('lỗi5: colums đã tồn tại');
echo 'Bạn đã cài đặt thành công mod BOT Panel v2 by GocMaster.com => <a href="botpanel.php">Quản lý BOT</a>';
?>