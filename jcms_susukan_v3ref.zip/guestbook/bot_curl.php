<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Mod BOT kể truyện cười ngẫu nhiên và BOT đọc KQXS for JohnCMS by thiendaik //
//            Liên hệ khi cần hỗ trợ: http://teamsmile.net                     //
////////////////////////////////////////////////////////////////////////////////
*/

define('_IN_JOHNCMS', 1);

if(preg_match('|kqxs|',$msg) ||preg_match('|Kqxs|',$msg) ||preg_match('|KQXS|',$msg)) {

function laynoidung ($noidung, $start, $stop) {
$bd = strpos ($noidung, $start);
$kt = strpos(substr($noidung,$bd),$stop) + $bd;
$content = substr($noidung, $bd, $kt - $bd);
return $content;
}

$u = 'http://xoso.wap.vn/ket-qua-xo-so/XSTD/xo-so-Mien-Bac.html';
$link=$u;
$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, $header);   //trace header response
curl_setopt($ch, CURLOPT_NOBODY, $header);  //return body
curl_setopt($ch, CURLOPT_URL, $u);   //curl Targeted URL
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $ref);   //fake referer
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

$kq = curl_exec($ch);
curl_close($ch);
$ketqua = laynoidung ($kq, '<div class="menu">', '</table><a href="');
$giaidb = explode('<td class="bold">ĐB:&nbsp;</td><td class="bold">',$ketqua);
$giaidb = explode('</td>',$giaidb[1]);
$giaidb = $giaidb[0];
$ketqua1 = explode('<td class="bold">G1:&nbsp;</td><td>',$ketqua);
$ketqua1 = explode('</td>',$ketqua1[1]);
$ketqua1 = $ketqua1[0];
$ketqua2 = explode('<td class="bold">G2:&nbsp;</td><td>',$ketqua);
$ketqua2 = explode('</td>',$ketqua2[1]);
$ketqua2 = $ketqua2[0];
$ketqua3 = explode('<td class="bold">G3:&nbsp;</td><td>',$ketqua);
$ketqua3 = explode('</td>',$ketqua3[1]);
$ketqua3 = $ketqua3[0];
$ketqua4 = explode('<td class="bold">G4:&nbsp;</td><td>',$ketqua);
$ketqua4 = explode('</td>',$ketqua4[1]);
$ketqua4 = $ketqua4[0];
$ketqua5 = explode('<td class="bold">G5:&nbsp;</td><td>',$ketqua);
$ketqua5 = explode('</td>',$ketqua5[1]);
$ketqua5 = $ketqua5[0];
$ketqua6 = explode('<td class="bold">G6:&nbsp;</td><td>',$ketqua);
$ketqua6 = explode('</td>',$ketqua6[1]);
$ketqua6 = $ketqua6[0];
$ketqua7 = explode('<td class="bold">G7:&nbsp;</td><td>',$ketqua);
$ketqua7 = explode('</td>',$ketqua7[1]);
$ketqua7 = $ketqua7[0];
$ngaymo = explode('<div class="menu">',$ketqua);
$ngaymo = explode('<br/>',$ngaymo[1]);
$ngaymo = $ngaymo[0];
$kqxs = '[b]KQXS '.$ngaymo.'[/b]
[b]Giải ĐB:[/b] '.$giaidb.'
[b]Giải Nhất:[/b] '.$ketqua1.'
[b]Giải Nhì:[/b] '.$ketqua2.'
[b]Giải Ba:[/b] '.$ketqua3.'
[b]Giải Tư:[/b] '.$ketqua4.'
[b]Giải Năm:[/b] '.$ketqua5.'
[b]Giải Sáu:[/b] '.$ketqua6.'
[b]Giải Bảy:[/b] '.$ketqua7.'';
$kqxs = str_replace('-',' - ',$kqxs);
$bot = $kqxs;

} else {

if(preg_match('|cuoi|',$msg) ||preg_match('|Cuoi|',$msg) ||preg_match('|CUOI|',$msg)) {

$maso = rand(100,999);
$u = 'http://image.thegioitrochoi.vn/wap/truyencuoi/viewdetail.aspx?tcid='.$maso;
$link=$u;
$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, $header);   //trace header response
curl_setopt($ch, CURLOPT_NOBODY, $header);  //return body
curl_setopt($ch, CURLOPT_URL, $u);   //curl Targeted URL
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $ref);   //fake referer
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

$ketqua = curl_exec($ch);
curl_close($ch);
$cuoi = explode('0912345678',$ketqua);
$cuoi = explode('<u>Truyen khac</u>',$cuoi[1]);
$cuoi = $cuoi[0];
$cuoi = preg_replace('|</b(.*)b>|is','',$cuoi);
$cuoi = str_replace('<br/>','
',$cuoi);

$bot = $cuoi;

}
}

?>
