<?php

/*
////////////////////////////////////////////////////////////////////////////////
// GocMaster Community
// Home: http://gocmaster.com
// Developer: Ari(Tuan)
// Development Team: GMT
////////////////////////////////////////////////////////////////////////////////
*/
define('_IN_JOHNCMS', 1);
@ini_set('default_charset', 'utf-8');
require('../incfiles/core.php');
$sql1 = "CREATE TABLE `bot` (`id` int(11) NOT NULL AUTO_INCREMENT, `user` varchar(50) NOT NULL, `key` varchar(100) NOT NULL DEFAULT '', `text` text NOT NULL, txt1 varchar(500) not null, txt2 varchar(500) not null, txt3 varchar(500) not null, txt4 varchar(500) not null, txt5 varchar(500) not null, `time` int(15) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
mysql_query($sql1) or die('lỗi1: table đã tồn tại. Lưu ý file này chỉ có thể chạy 1 lần duy nhất. Vui lòng chạy file <a href="bot_update.php">bot_update.php</a>');
echo 'Bạn đã cài đặt thành công. <a href="botpanel.php">Quản lý BOT</a>';
?>