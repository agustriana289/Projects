<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
require('../incfiles/core.php');
$sql = "CREATE TABLE IF NOT EXISTS `bot` (
  `id` int(11) NOT NULL auto_increment,
  `time` int(11) NOT NULL,
  `edit_count` int(11) NOT NULL,
  `edit_who` int(11) NOT NULL,
  `key` text NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";


mysql_query($sql) or die('lỗi');
echo 'Thành công';
?>