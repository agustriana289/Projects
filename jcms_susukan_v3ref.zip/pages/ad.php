<?
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Friend site</b></div>';
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 6))
echo '<div class="gmenu"><a href="friendssite.php?act=add_site">Add site</a></div>';
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="friendssite.php?act=mod_site">sites for moderation</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if($total) {    		$req = mysql_query("SELECT `friendssite`.*, `users`.`name` AS `nick` FROM `friendssite` LEFT JOIN `users` ON `friendssite`.`iduser` = `users`.`id` WHERE `friendssite`.`type`='1' ORDER BY `friendssite`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 6)
echo '<form action="friendssite.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a> (' . $res['count'] . ')<br />' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Added by <a href="../users/profile.php?user=' . $res['iduser'] . '">' . $res['nick'] . '</a>, ' . functions::display_date($res['vr']) . '</small>';?>