<?php

#config#
$bot['like'] = true; // false untuk non aktifkan autolike
$bot['ck_k'] = true; // false untuk non aktifkan fungsi jika status mengandung kata maka di comen dengan kata
$bot['ck_u'] = true; // true jika pengkondisian di non aktifkan akan beralih ke koment umum jika kondisi aktif komen umum juga aktif (tidak akan dobel komen jika keduanya aktif)
$bot['time'] = true; // false untuk menonaktifkan fungsi waktu di komentar
$bot['aces'] = ""; // ganti dengan access token yang kamu dapat tadi
################com_like($cl,$ck,$cu,$tm,$access_token)

####By Me####
#    BOT Facebook v 1.0cr 20/januari/2011
#
#    Created by casper_kae
#    Edited by Ade Andriana
#    simple bot komment & like
#    thanks to balikita team
#
#    mohon untuk tidak merubah tulisan ini untuk saling menghargai.
#    tunggu Versi bot berikutnya. :D salam
###############

com_like($bot['like'],$bot['ck_k'],$bot['ck_u'],$bot['time'],$bot['aces']);

#komentar#
function cmn($text,$ck,$cu){
##########umum
$cmn_umum = array("hadir menyukai untuk status <name> !!!",
                  "Mampir di statusmu boleh kan <name>.?",
                  "Maaf saya robot koment. hadir hanya untuk koment di status <name>.. :D",
                  "Bos Ajis lagi offlen jadi bot ditugaskan untuk koment di statusmu <name> :D",
                  "Orang cakep lewat distatusmu <name> minggirrrrrrrr.. :P",
                  "Bingung mo koment apa <name> :D",
                  "Nulis status gak perlu mikir yang penting koment hadir. stuju kan <name>..?",
                  "absen koment aja deh <name>",
                  "Ampek jempol kriting tetep stia ane coment di status <name> :D",
                  "Numpang ngisi koment distatusmu <name>..:D",
                  "ga kan necewain deh, like this dan komen hadir selalu <name>",
                  "<name> statusmu sip banget. pokoknya JEMPOL trus dah..:D",
                  "apapun statusnya? jempol Aji slalu mampir di status <name>",
                  "status <name> emang tempat nongkrong komentarku. hihi",
                  "mau komen apa ya?? bingung?? nambah like this, biar tambah eksis. hihihihihi.... :D",
                  "Di tungguin dari tadi,, akhirnya <name> update status juga,, oklah tanpa basa-basi lagi ane kasi jempol dah,, Like This d[*_*]]b",
                  "dikasih tempat komen ama <name>. gak mungkin gak koment gue.. :D",
                  "lupa? bru koment. biar koment paling akhir, yg penting hadir!!",
                  "Pokoknya Gw jadi penggemar setia postingan <name>. Jadi slalu setia hadir. :D",
                  "<name> update status. ane slalu setia dateng n koment. hihi",
);
##########kondisi
$comment = array(
array(
      array("sepi",
            "pada kemana",
            "pada kmn",
           ),
      array("Nih Udah aQ ramein <name>. hhe",
            "Meski sepi JEMPOL Ade masih setia di status <name>.hhe",
            "He'eh ni penghuni FB pada tidur kali. tapi JEMPOL Ade slalu hadir buat status <name>",
           )
     ),
array(
      array("semoga",
            "moga",
            "amin",
           ),
      array("Amin <name>.. Skalian like this juga ah. biar tambah exsis. hhe",
            "Mang knape <name>.?",
            "He'eh ni penghuni FB pada tidur kali. tapi JEMPOL Ade slalu hadir buat status <name>",
           )
     ),
array(
      array("jancok",
            " asu ",
            " raimu ",
            " matamu ",
            " bangsat ",
           ),
      array("Wew. <name> lagi marah tetep Q kasi LIKE dah. hhe",
            "ada apa dengan mu <name> kok marah amat..? wkwkwkwk",
            "Robot versi gaul buat ademin kamu <name>. wkwkwkwk",
            "Meski marah. tetep hadir aja dah n like this. :D",
           )
     ),
array(
      array("lapar",
            " ewul ",
            " luwe ",
            "laper",
            " krucuk",
           ),
      array("Ni makanan buanyak disini. mau a <name>..? hhe",
            "sama <name> klaparan nih. kunjungannya http://naxsmk.pun.bz ",
           )
     ),
array(
      array("askum",
            "asalam",
            "assalam",
            "mekum",
            "laikum",
           ),
      array("Waalaikumsalam warahmatullahi wabarakatuh. <name> hihi",
            "Waskum",
           )
     ),
array(
      array("pamid",
            "off dulu",
            "ngantuk",
            "bobok",
            "tidur",
           ),
      array("lho aq ditinggal <name> wkwkwkwk",
            "wew. masi jam sgini <name> mo kmana.?",
            "Walah kmana <name>..?",
            "Ditinggal dah ane. hhe.",
           )
     ),
);
$komentar = '';
$cr_kondisi=false;
foreach($comment as $cx){
    foreach($cx[0] as $ct){
        if(ereg($ct,$text)){
            $cr_kondisi=true;
            $komentar = $cx[1][rand(0,count($cx[1]) - 1)];
        }
    }
}
if($cr_kondisi==true && $ck==true){
    return $komentar;
}else{
    if($cu==true){ return $cmn_umum[rand(0,count($cmn_umum) - 1)]; }
}
}
###############
function com_like($cl,$ck,$cu,$tm,$access_token){
    $beranda = json_decode(httphit("https://graph.facebook.com/me/home?fields=id,from,type,message&limit=100&access_token=".$access_token))->data;
    $saya_cr = json_decode(httphit("https://graph.facebook.com/me?access_token=".$access_token));
    if($beranda){
        foreach($beranda as $cr_post){
            if(!ereg($saya_cr->id,$cr_post->id)){
                $log_cr = simlog($cr_post->id);
                if($log_cr==true){
                    if($ck==true){
                        $url_ck = cmn($cr_post->message,$ck,$cu);
                        $url_ck = str_replace("<name>",$cr_post->from->name,$url_ck);
                        if($tm==true){ $url_ck = $url_ck.wkthit(); }
                        $url_ck = urlencode($url_ck);
                        if($ck==true OR $cu==true){
                            httphit("https://api.facebook.com/method/stream.addComment?post_id=".$cr_post->id."&comment=".$url_ck."&access_token=".$access_token);
                        }
                        if($cl==true){
                            httphit("https://api.facebook.com/method/stream.addLike?post_id=".$cr_post->id."&access_token=".$access_token);
                        }
                    }
                }
            }
        }
    }
}
###############
function httphit($url){
    return file_get_contents($url);
}
function wkthit(){
    $ent="
";
    $hari=gmdate("D", time()+60*60*7);
    if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Minggu"; }
    if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Senin"; }
    if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Selasa"; }
    if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Rabu"; }
    if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Kamis"; }
    if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Jum'at"; }
    if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Sabtu"; }
    $jam="Jam : ".gmdate("g:i a", time()+60*60*7);
    return $ent.$ent."[ ".$jam." ][ ".$hari." ][ Tgl : ".gmdate("j/m/Y", time()+60*60*7)." ]";
}
function simlog($cr_id) {
    $fname = "cr_log.txt";
    $lihatiplist=fopen ($fname, "rb");
    $text='';
    if($lihatiplist){
        $spasipol = "";
        do {
            $barislistip = fread($lihatiplist, 512);
            if(strlen($barislistip) == 0){ break; }
            $spasipol .= $barislistip;
        } while(true);
        fclose ($lihatiplist);
        for ($i = 1; $i <= 10; $i++) {$spasipol = str_replace(" ","",$spasipol);}
        $text=$text.$spasipol;
    }else{$text="";}
    if(ereg($cr_id,$text)){
        return false;
    }else{
        $text = $text.$cr_id;
        $w_file=@fopen($fname,"w") or bberr();
        if($w_file) {
            @fputs($w_file,$text);
            @fclose($w_file);
        }
        return true;
    }
}
?>