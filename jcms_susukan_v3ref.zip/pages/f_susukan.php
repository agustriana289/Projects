<?php
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>'.$textl.'</b></div>';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
if ($user_id) {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Unread</a><font color="red">&nbsp;(<b>' . counters::forum_new() . '</b>)</font> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div></div></div>'; }
if (!$user_id) {
echo '<div class="topmenu"><a href="../forum/index.php?act=new">Last Activity</a> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div></div></div>'; }
$bonguyen = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while (($dd = mysql_fetch_array($bonguyen)) !== false) {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>'.$dd['text'].'</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`='" . $dd['id'] . "' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
$chude = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' and `refid`='" . $res['id'] . "'"), 0);
echo '<div class="'.(++$j%2==0 ? "list2" : "list2").'"><div class="susukan" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><img src="images/forum_32.png" width="20" height="20" alt="Susukan" /> <a href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a></td><td width="auto" align="right">        ['.$chude.']</td></tr></table></div></div>';
}
echo '</div></div></div>';
++$j;
}
?>
