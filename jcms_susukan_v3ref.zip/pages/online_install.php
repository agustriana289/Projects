<?php

/*
////////////////////////////////////////////////////////////////////////////////
// GocMaster Community
// Home: http://gocmaster.com
// Developer: Ari(Tuan)
// Development Team: GMT
////////////////////////////////////////////////////////////////////////////////
*/
define('_IN_JOHNCMS', 1);
$headmod = 'pages';
require('../incfiles/core.php');
//script import data by ari
$sql1 = "CREATE TABLE `cms_online` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` varchar(50) NOT NULL, `total` int(11) NOT NULL default '0', `text` text NOT NULL, `time` int(11) NOT NULL default '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
mysql_query($sql1) or die('lỗi1');
mysql_query("INSERT INTO `cms_online` SET
`type`='user',
`total`='2',
`text`='admin, BOT',
`time`='".time()."'
") or die('lỗi1');
mysql_query("INSERT INTO `cms_online` SET
`type`='guest',
`total`='0',
`text`='@',
`time`='".time()."'
") or die('lỗi1');
echo 'Bạn đã cài đặt thành công.';
?>