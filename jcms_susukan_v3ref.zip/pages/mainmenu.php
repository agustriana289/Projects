<?
/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/
defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'mainpage';
$mp = new mainpage();
if ($user_id) {
include 'files/Notice.php';
}
/*
-----------------------------------------------------------------
www.susukan.us
-----------------------------------------------------------------
*/
echo $mp->news;
/*
-----------------------------------------------------------------
Comrade79 Main menu
-----------------------------------------------------------------
*/
if ($user_id) {
if (!$rights >= 6) {
echo '</div></div><div class="mainbox"><div class="omenu"><b>Apply for Staff</b><br/>we are looking for Staff to Moderate Susukan.Us forum Apply Now<a href="pages/apply_staff.php?act=add_staff"><b><red>&nbsp;Here</red></b></a><br/>';
}}
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="mainbox"><div class="omenu"><span class="green"><a href="pages/apply_staff.php?act=mod_staff"><b> ' . $total_mod . ' Moderation For Admin</b></a></span>';
}
echo '</div></div></div></div>';
/*
-----------------------------------------------------------------
www.susukan.us
-----------------------------------------------------------------
*/
include 'welcome.php';
include 'friendsite_susukan.php';
if ($is_mobile)
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Forum Search</b></div><div class="forumb"><form action="' . $set['homeurl'] . '/forum/search.php" method="post"><input name="t" type="checkbox" value="1"  />Forum Topic<br/><form action="' . $set['homeurl'] . '/forum/search.php" method="post"><div> <div style="text-align:left"><input type="text" value="' . ($search ? functions::checkout($search) : '') . '" name="search" /><input class="btn" type="submit" value="' . $lng['search'] . '" name="submit"></small></form>
</div></div></div></div></div></div>';
include 'lastblog_susukan.php';
echo '<div class="mainbox"><div class="mainblok">';
if ($user_id) {
echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">
<font size=2><b>New Post</b></font></td><td width="auto" align="right"><a href="forum/post.html"><img src="./images/add.jpg" alt="Add" width="12" height="12"/></a></td></tr></table></div>';}
if (!$user_id) {
echo '<div class="nfooter"><b>New Post</b></div>';}
switch ($act)
{
default:
echo '<div class="topmenu"><b>New Post</b> | <a href="/index.php?act=top"><b>Top Post</b></a> | <a href="/index.php?act=upl"><b>Forum File</b></a></div>';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1'"), 0);
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `close` != '1' ORDER BY `time` DESC LIMIT $start, $kmess");
$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
if ($res['edit'])
echo '<img src="images/tz.gif" alt=""/>&nbsp;';
elseif ($res['close'])
echo '<img src="images/dl.gif" alt=""/>&nbsp;';
else
echo '<img src="images/np.gif" alt=""/>&nbsp;';
if ($res['realid'] == 1)
echo '&#160;<img src="images/rate.gif" alt=""/>&nbsp;';
if ($arr['realid'] == 1)
echo '&nbsp;<img src="images/rate.gif" alt="vote"/>&nbsp;';
if ($res['tiento'] ==1) {
echo'<b><font color="purple">Discusion:&nbsp;</font></b>';
} elseif ($res['tiento'] ==2) {
echo'<b><font color="red">Hot:&nbsp;</font></b>';
} elseif ($res['tiento'] ==3) {
echo'<b><font color="green">Notice:&nbsp;</font></b>';
} elseif ($res['tiento'] ==4) {
echo'<b><font color="red">Share:&nbsp;</font></b>';
} elseif ($res['tiento'] ==5) {
echo'<b><font color="green">Script:&nbsp;</font></b>';
} elseif ($res['tiento'] ==6) {
echo'<b><font color="blue">Help:&nbsp;</font></b>';
}
if (mb_strlen($res['text']) >= 40)
{
$res['text'] = mb_substr($res['text'], 0, 40);
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html#down">' . bbcode::tags($res['text']) . '</a>';
echo '...';
}
else
{
echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html#down">' . bbcode::tags($res['text']) . '</a>';
}
echo '<small> (' . $colmes1 . ')</small>';
//echo '<a href="'.$home.'/forum/'.functions::gantiurl($res["text"]).'_' . $res['id'] . ($cpg > 1 && $set_forum['upfp'] && $set_forum['postclip'] ? '_clip_' : '') . ($set_forum['upfp'] && $cpg > 1 ? '_p' . $cpg : '.html') . '" title="'.$res["text"].'">' . bbcode::tags($res['text']) . '</a>&nbsp;[' . ($colmes1-1) . '] ';
echo '<br /><div class="sub">';
echo ''.$res['from'].'&nbsp;&raquo;&nbsp;';
if ($colmes1 > 1) {
echo '' . $nick['from'] . ''; } else
echo ''.$res['from'].'';
echo '&nbsp;--<span class="gray">' . functions::display_date($res['time']) . '</span>';
echo '</div></div>';
++$i; }
if ($tong > $kmess){echo '<div class="topmenu">' . functions::display_pagination('index.html?', $start, $tong, $kmess) . '</div>';}
break;
case 'top':
// ad
echo '<div class="topmenu"><a href="http://susukan.us/index.php"><b>New Post</b></a> | <b>Top Post</b> | <a href="/index.php?act=like"><b>Forum File</b></a></div>';
$kmessreq= 5;
$startreq = isset($_REQUEST['page']) ? $page * $kmessreq - $kmessreq : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0); 
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and `kedit`='0' AND `close`!='1' "), 0); 
$req = mysql_query("SELECT *, `id` AS `indozona`, (SELECT COUNT(*) FROM `forum` WHERE `refid` = `indozona` AND `type` = 'm' AND `close` != '1') AS `total_post` FROM `forum` WHERE `type`='t' AND `edit` != '1' AND `close` != '1' ORDER BY `total_post` DESC LIMIT 5");

$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
echo '<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '.html'. ($cpg > 1 && $_SESSION['uppost'] ? '&amp;clip&amp;page=' . $cpg : '') . '">' . $res['text'] . '</a>&#160;[' . $colmes1 . ']';
if ($cpg > 1)
echo '<a href="/forum/' . functions::gantiurl($res['text']) . '_' . $res['id'] . '_p' . $cpg . '.html' . ($_SESSION['uppost']) . '">&rarr;</a>';
echo '<span class="gray">&nbsp;by: '.$res['from'].'</span>';
echo '</div>';
++$i;
}
    if ($startreq > $kmessreq) {

echo '<div class="topmenu">' . functions::display_pagination('index.php' . $id . '?', $startreq, $total, $kmessreq) . '</div>';

}


if ($cpg == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
break;
case 'upl':
echo '<div class="topmenu"><a href="/index.php"><b>New Post</b></a> | <a href="/index.php?act=top"><b>Top Post</b></a> | <b>Forum File</b></div>';
$req = mysql_query("SELECT * FROM `cms_forum_files` ORDER BY `id` DESC LIMIT 5");
$i = 0;
while($file = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$path = $file['filename'];
$fls = round(@filesize('files/forum/attach/' . $path) / 1024, 2);
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 5){
echo '<img class="middle" src="images/locked.png" alt="5 post for download"/> File Locked';
}
else {
echo '<img class="middle" src="images/file.gif" alt="'.$file['id'].'"/>';
echo '<a href="forum/index.php?act=file&id='.$file['id'].'"> '.$file['filename'].'</a> ('.$fls.'KB)';
}
echo '</div>';
++$i;
}
}
echo '</div></div></div></div>';
/*
-----------------------------------------------------------------
??????????? ?????????????????????
-----------------------------------------------------------------
*/
// www.susukan.us

echo '</div></div></div>';
include 'susukan_subforum.php';
echo '<div class="mainbox"><div class="mainblok">';

echo '<div class="nfooter"><b><a href="/forum/fforum.php">Top Forum</a></b></div>';

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" . ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);

if ($user_id) {

echo '<div class="topmenu"><a href="forum/index.php?act=new">Unread</a><font color="red">&nbsp;(<b>' . counters::forum_new() . '</b>)</font> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div>'; }

if (!$user_id) {

echo '<div class="topmenu"><a href="forum/index.php?act=new">Last Activity</a> | <a href="http://susukan.us/susukan.us">Files</a> <span class="red">(' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . ')</span></div>'; }

$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");

$i = 0;

while (($res = mysql_fetch_array($req)) !== false) {

echo $i % 2 ? '<div class="list2">' : '<div class="list2">';

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);

$counts = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='f' and `refid`='" . $res['id'] . "'"), 0);

$chude = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);

echo '<div class="susukan" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left"><img src="images/forum_32.png" width="20" height="20" alt="Susukan" /> <a href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a> </td><td width="auto" align="right">[' . $count . ']</td></tr></table></div></div>';

if (!empty($res['soft']))

echo '<div class="sub"><span class="gray">' . $res['soft'] . '</span></div>';

echo '<div>';

++$i;

}

$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);

$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `place` LIKE 'forum%'"), 0);

echo '<div class="nfooter">' . ($user_id ? '<a href="/forum/index.php?act=who">Who in forum</a>' : $lng_forum['who_in_forum']) . '&#160;(' . $online_u . '&#160;/&#160;' . $online_g . ')</div>';

unset($_SESSION['fsort_id']);

unset($_SESSION['fsort_users']);

// eteze2eze3ezN?ezN? e2e?eze.N? N?N?NOeze?ezN?N?

echo '</div></div></div></div></div></div></div></div></div></div></div></div>';

echo '<div class="mainbox"><div class="mainblok">';

echo '<div class="nfooter"><b>Statistics</b></div>';

echo'<div class="list1">&#x2022;<a href="/email.php">Email: </a><b><small> (Send Attach Via URL)</small></b></div>';



echo'<div class="list1">&#x2022;<a href="/store">Store: </a><b><small> (Unlimated)</small></b></div>';

echo'<div class="list1">&#x2022;<a href="susukan.us">Total Files: </a><b><small>' . mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`"), 0) . '</small></b></div>';

echo'<div class="list2">&#x2022;<a href="forum/">' . $lng['forum'] . '</a><span class="gray"><b><small>&nbsp;(' . counters::forum() . ')</small></b></span></div>';

$thanhvienmoi=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` ORDER BY `datereg` DESC LIMIT 1"));

$all_users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`;"), 0);

echo '<div class="list2">&#x2022;<a href="users/">Members:</a> (' . counters::users() . ')</div>'; echo'<div class="topmenu">';

echo "Welcome <a href='users/".$thanhvienmoi['name']."'><b>".$thanhvienmoi['name']."</b></a> at Susukan.Us.\n";

echo'</div>';

echo '</div></div></div></div>';

if ($user_id){

function show_online($user = array(), $status = 0, $ip = 0, $str = '', $text = '', $sub = '') {    global $set_user,$realtime, $user_id, $admp, $home;    $out = false;  /*if ($user['rights'] == 0 ) {$colornick['colornick'] = '000000';} if ($user['rights'] == 1 ) {$colornick['colornick'] = 'FFD700';}       if ($user['rights'] == 2 ) {$colornick['colornick'] = '7192a8';}      if ($user['rights'] == 3 ) {$colornick['colornick'] = '0000FF';}      if ($user['rights'] == 4 ) {$colornick['colornick'] = '40E000';}      if ($user['rights'] == 5 ) {$colornick['colornick'] = '40E000';}      if ($user['rights'] == 6 ) {$colornick['colornick'] = '228622';}      if ($user['rights'] == 7 ) {$colornick['colornick'] = '860086';}   if ($user['rights'] == 8 ) {$colornick['colornick'] = 'FF0000';}     if ($user['rights'] == 9 ) {$colornick['colornick'] = 'FF0000';}       if ($user['rights'] == 10 ) {$colornick['colornick'] = '7192a8';} */  $out .= !$user_id || $user_id == $user['id'] ? '' .functions::nickcolor($vip['vip']). '' . functions::nickcolor($user['id']) . '' .functions::nickcolor($vip1['vip1']). '' : '<a href="users/' . $user['name'] . '">' .functions::nickcolor($vip['vip']). '' . functions::nickcolor($user['id']) . '' .functions::nickcolor($vip1['vip1']). '</a>';   return $out;

}

function timecount($var) {

if ($var < 0)

$var = 0;

$day = ceil($var / 86400);

if ($var > 345600) {

$str = $day . ' Gi&#417;&#768;';

}  elseif ($var >= 172800) {

$str = $day . 'Phu&#769;t';

}  elseif ($var >= 86400) {

$str = '1 Gi?y';

} else {

$str = gmdate('G:i:s', $var);

}

return $str;

}

global $realtime, $user_id, $home;

$u_on = array();

$ontime = time() - 900;

$guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 900) . "'"), 0);

$qon = mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate`>='" . $ontime . "';");

$qon2 = mysql_result($qon, 0);

$online = $_GET['online'];

echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><b>Information</b></div>';

echo '<div class="topmenu" id="online" name="online">'.($online ? '<a href="index.php#online">online</a>' : '<b>online</b>').' | '.($online == '24h' ? '<b>Last 24h</b>' : '<a href="?online=24h#online">Last 24h</a>').'';

echo '| <b>Guest:</b> ';

if ($guests>=1){

echo '<a href="' . $home . '/users/index.php?act=online&amp;mod=guest">' . $guests . '</a></div>';

}else

echo '<font color="red">0</font></div>';

switch($online) {

default:

$onltime = time() - 900;

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `" . ($act == 'guest' ? 'cms_guests' : 'users') . "` WHERE `lastdate` > '$onltime'"), 0);

$gbot = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';

$yanbot = 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)';

$bing = 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)';

$bd = 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';

$googlebot = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '$onltime' AND `browser`='$gbot'"), 0);

$yandexbot = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '$onltime' AND `browser`='$yanbot'"), 0);

$bingbot = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '$onltime' AND `browser`='$bing'"), 0);

$baidu = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '$onltime' AND `browser`='$bd'"), 0);

$total = $total+$googlebot+$yandexbot+$bingbot+$baidu;

if ($total) {

echo '<div class="list2">'.($googlebot > 0 ? '<font color="#7192a8"><b>Google[bot]</b></font>, ' : '').''.($yandexbot > 0 ? '<font color="#7192a8"><b>Yandex[bot]</b></font>, ' : '').''.($bingbot > 0 ? '<font color="#7192a8"><b>Bing[bot]</b></font>, ' : '').''.($baidu > 0 ? '<font color="#7192a8"><b>Baidu[bot]</b></font>, ' : '').'';

$req = mysql_query("SELECT * FROM `" . ($act == 'guest' ? 'cms_guests' : 'users') . "` WHERE `preg`='1' and `lastdate` > '" . (time() - 900) . "' ORDER BY " . ($act == 'guest' ? "`movings` DESC" : "`name` ASC") . " LIMIT 1000");

while ($res = mysql_fetch_assoc($req)) {

echo show_online($res, 0, ($act == 'guest' || ($rights >= 1 && $rights >= $res['rights']) ? ($rights >= 6 ? 2 : 1) : 0), ' (' . $res['movings'] . ' - ' . timecount($realtime - $res['sestime']) . ') ' . $place);

echo ', ';

++$l;

}

echo'</div>';

}

else {

echo '<div class="maintxt">No Member Online !</div>';

}

break;

case '24h':

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `" . ($act == 'guest' ? 'cms_guests' : 'users') . "` WHERE `lastdate` > '" . (time() - 96000) . "'"), 0);

if ($total > 0) {

echo '<div class="maintxt"><p>';

$req = mysql_query("SELECT * FROM `" . ($act == 'guest' ? 'cms_guests' : 'users') . "` WHERE `preg`='1' and `lastdate` > '" . (time() - 96000) . "' ORDER BY " . ($act == 'guest' ? "`movings` DESC" : "`name` ASC") . " LIMIT 1000");

while ($res = mysql_fetch_assoc($req)) {

echo show_online($res, 0, ($act == 'guest' || ($rights >= 1 && $rights >= $res['rights']) ? ($rights >= 6 ? 2 : 1) : 0), ' (' . $res['movings'] . ' - ' . timecount($realtime - $res['sestime']) . ') ' . $place);

echo ', ';

++$l;

}

echo '</div>';

} else {

echo '<div class="maintxt">No Member Online !</div>';

}

break;

case 'kyluc':

//$res = mysql_fetch_assoc(mysql_query("SELECT * FROM `cms_online` WHERE `id`='1' LIMIT 1"));

//$gres = mysql_fetch_assoc(mysql_query("SELECT * FROM `cms_online` WHERE `id`='2' LIMIT 1"));

echo '<div class="maintxt">';

echo 'Record at online <b>'.date('d F Y', $res['time']).'</b><b>'.($res['total']).'</b>Members and<b>'.$gres['total'].'</b> Guest  Results show the largest number of people online at the same time at Susukan.Us!';

echo '</div>';

break;

}

$day = date('d');

$month = date('m');

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `dayb`='$day' AND `monthb`='$month'"), 0);

if($total) {

echo ' There Is A Birthday Today: ';

$req = mysql_query("SELECT * FROM `users` WHERE `dayb`='$day' AND `monthb`='$month' ORDER BY `name` DESC LIMIT 100");

while($res = mysql_fetch_assoc($req)) {

echo '<a href="users/'.$res['name'].'">'.$res['name'].'</a>, ';

}

}

}

echo'</div></div></div></div></div>';

