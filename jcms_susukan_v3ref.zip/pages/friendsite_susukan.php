<?php
echo '</div><div class="mainbox"><div class="mainblok">';
if ($user_id) {
echo '<div class="nfooter" align="right"><table cellpadding="0" cellspacing="0" width="100%"><tr><td width="auto" align="left">
<font size=2><b>Friendsite</b></font></td><td width="auto" align="right"><a href="/pages/friendssite.php?act=add_site"><img src="./images/add.jpg" alt="Add" width="12" height="12"/></a></td></tr></table></div>';}
if (!$user_id) {
echo '<div class="nfooter"><b>Friendsite</b></div>';}
$total_site = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_site < $userssite || $rights >= 6) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 6))
if ($rights >= 6) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="pages/friendssite.php?act=mod_site">sites for moderation</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `friendssite` WHERE `type`='1'"), 0);
if($total) {          $req = mysql_query("SELECT * FROM `friendssite` WHERE `friendssite`.`type`='1' ORDER BY rand() LIMIT 1;");
if ($rights >= 6)
echo '<form action="pages/friendssite.php?act=mass_del" method="post"></form>';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="pages/friendssite.php?act=redirect&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a> (' . $res['count'] . ')<br />' . functions::checkout($res['opis'], 1, 1);
++$i;
echo '</div></div></div></div></div>';
}
}
echo '</div>';
?>