<?
define('_IN_JOHNCMS', 1);

require_once ("../incfiles/core.php");

require_once ('../incfiles/head.php');

echo '<div class="mainblok"><div class="phdr"><b>Quy Định - Nội Quy</b></div>';

echo '<div class="gmenu">';
echo '<div><b>QUY ĐỊNH TRÊN MẠNG XÃ HỘI ShockVn.MoBi</b> <br/> 
• Tất cả các thành viên của mạng xã hội ShockVn.MoBi, kể cả Admin, kĩ thuật, kiểm sát, SMod, Mod....Thuộc BQT, đều phải tuân thủ những quy định của hệ thống.<br/> 
• Thành viên nào vi phạm quy định, tùy từng trường hợp sẽ xử lý bằng cách áp dụng trực tiếp luật của hệ thống và sẽ được Admin hoặc Mod thông báo qua hộp tin nhắn cá nhân. <br/> 
• Các quy định này sẽ được bổ sung, thay đổi cho phù hợp với sự phát triển của ShockVn.MoBi. Khi quy định được thay đổi thì Admin sẽ thông báo trên hệ thống hoặc gửi e-mail đến tất cả mọi người để thông báo.</div>';
echo '<div><font color="blue"><b>I.Quy định về chủ đề bài viết</b></font></div>';
echo '<div>1.Không gửi các bài viết có tiêu đề không mô tả được nội dung bài viết: "....", "Hay nè", "Giúp tui với", "Admin ơi",... Những bài viết này sẽ được biên tập lại tiêu đề. Tuy nhiên, nếu thành viên gửi bài vẫn vi phạm sau khi được nhắc nhở nhiều lần thì các bài viết về sau sẽ bị xóa.<br/>
2.Không lập những chủ đề đã có từ trước, và lập chủ đề phải đúng box.</div>';
echo '<div><font color="blue"><b>II.Nội dung bài viết</b></font></div>';
echo '<div>1.Không gửi bài viết bằng tiếng Việt không có dấu.<br/>
2.Không gửi bài viết toàn bằng chữ HOA. Những bài viết này sẽ bị xóa ngay lập tức, bất kể nội dung là gì.<br/>
3.Không gửi các bài viết không có nội dung hoặc nội dung không liên quan đến chủ để thảo luận. Những bài viết này sẽ bị xóa không cần gửi tin nhắn thông báo hoặc chuyển sang box có nội dung phù hợp hơn.<br/>
4.Tránh gửi các bài viết cố tình sai chính tả hoặc dùng ngôn ngữ teen kiểu như "hay wé", "chít rùi", " chúc dk..."... Hãy giữ cho tiếng Việt của chúng ta được trong sáng. Nếu thành viên quá lạm dụng kiểu viết này sẽ bị xóa bài ngay lập tức.<br/>
5.Không gửi các bài mang tính đả kích, khích bác, chỉ trích, nói xấu,dùng các từ ngữ không hay. Những bài viết này sẽ được nhắc nhở hoặc xóa tùy theo nội dung.<br/>
6.TUYỆT ĐỐI KHÔNG gửi các bài có nội dung liên quan đến sex, chính trị, tôn giáo, chính sách của Đảng và Nhà nước ( Ở đây phải hiểu là tất cả các tin tức trong lĩnh vực trên không chỉ cả các tin mang nội dung không phù hợp), hoặc có nội dung không phù hợp với thuần phong mỹ tục của nước Việt Nam. Những bài này sẽ bị xóa ngay lập tức.<br/>
7.Bạn được phép gửi các bài viết, tin tức sưu tầm từ các nơi khác nhưng phải ghi rõ xuất xứ, nguồn gốc.<br/>
8.Không gởi những bài viết có liên kết hoặc kèm theo các tập tin chứa virus, keylogger, trojan, rootkit, bom mail ... hoặccung cấp các mail list, công cụ spam email.<br/>
9.Tất cả những bài viết quảng cáo, rao vặt, giới thiệu trang web mới nếu gửi quá 2 bài cùng nội dung hoặc nội dung tương tự trong 1 hoặc nhiều box sẽ bị xóa ngay tất cả các bài.<br/>
10.Không viết các bài giới thiệu có liến kết đến các chương trình quảng cáo dạng truyền tiêu đa cấp như GS0 MEDIA...<br/>
11.Không phát tán các liên kết trang web nhái, trang web Phishing .....<br/>
12.Bạn được phép gửi các bài viết hay có nội dung hoàn toàn bằng tiếng Anh (English). Tuy nhiên, Ban quản trị hệ thống khuyến khích việc phiên dịch của các bạn. hệ thống không chấp nhận bài viết có ngôn ngữ khác ngoài tiếng Anh và tiếng Việt, trừ 1 số trường hợp đặc biệt.<br/>
13.Thành viên phải chịu tránh nhiệm về những nội dung mà mình post lên hệ thống.</div>';
echo '<div><font color="blue"><b>III.Tài khoản thành viên</b></font></div>';
echo '<div>1.Ban quản trị sẽ loại bỏ ngay những user name có nội dụng không lành mạnh, dễ gây hiểu lầm, cố tình bôi nhọ thành viên khác, cố tình giả danh ban quản trị hệ thống như: Admin; Ad_min, web_master...<br/>
2.Các username bằng chữ tượng hình (ví dụ tiếng Hoa), hoặc toàn số hay abcdef... không được chấp nhận.<br/>
3.Thành viên mới đăng ký không được sử dụng username tương tự với username đã có, cố tình gây ra sự nhầm lẫn như thành viên mới "chikaz"với thành viên cũ "chikax". Ban quản trị hệ thống sẽ xóa bỏ (Khóa tàikhoản) nick đặt sau dựa theo ngày tháng đăng ký của thành viên.<br/>
4.Thành viên không được sử dụng biểu tượng (avatar) là các hình ảnh vi phạm thuần phong mỹ tục của người Việt Nam.<br/>
5.Tài khoản trên 6 tháng không còn đăng nhập cũng sẽ bị xóa.</div>';
echo '<div><font color="blue"><b>IV. Hệ thống Blog,Bang hội trong ShockVn.MoBi</b></font></div>';
echo '<div>Vì cũng thuộc cùng một hệ thống của ShockVn.MoBi nên khi viết blog hay tham gia bang hội bạn cần tuân thủ theo các quy định bên trên của hệ thống đồng thời tuân thủ các quy định của bang hội.</div>';
echo '<div><font color="blue"><b>V. Hệ thống Shoutbox ( Chat Box)</b></font></div>';
echo '<div>- Quy định khi tham gia dùng chat box. Ngoài những yêu cầu trên nghiêm cấm quảng cáo link từ website khác , cấm gửi quá 5 icon, spam liên tục gây nghẽn shoutbox, cấm nói tục chửi bậy, cãi cọ, dùng tiếng lóng, từ viết tắt gây dễ hiểu nhầm.<br/>
Lần đầu nhắc nhở đối với thành viên mới. Lần 2 Ban trên shoutbox, tùy theo mức độ vi phạm BQT sẽ quyết định có ban trên toàn hệ thống hay không và thời gian ban bao lâu. </div>';
echo '<div><font color="blue"><b>VI. Hệ thống tin nhắn trong phần cá nhân và Album ảnh + Group</b></font></div>';
echo '<div>- Ngoài các quy định trên nghiêm cấm up ảnh với nội dung không phù hợp...<br/>
Thành viên có thể tùy ý tham gia tạo nhóm riêng cho mình. Yêu cầu không tạo nhóm mang nghĩa không hay, các bài thảo luận trong nhóm vi phạm vào các quy định trên của hệ thống thì nhóm đó sẽ bị xóa và sử lý những thành viên vi phạm.</div>';
echo '<div><font color="blue"><b>VII. Hệ thống E-mail, tin nhắn</b></font></div>';
echo '<div>1. Nội dung các tin nhắn cá nhân (PM) không được kiểm soát, vì vậy các thành viên sẽ tự chịu trách nhiệm với nhau về các tin nhắn trao đổi.<br/>
2. hệ thống sẽ không chịu trách nhiệm về nội dung các e-mail được gửi thông qua hệ thống e-mail của hệ thống.</div>';
echo '<div><font color="blue"><b>VIII. Admin, SMod, Mod</b></font></div>';
echo '<div>1.Những thành viên nào bị nhiều người khiếu nại là có ý đồ gây rối, phá hoại sẽ bị loại ra khỏi hệ thống.<br/>
2.Những Mods nào được nhiều thành viên góp ý mà không chịu sửa đổi,hoặc không làm tròn trách nhiệm của mình thì sẽ sẽ bị tước quyền Mod.</div>';
echo '<div><font color="blue"><b>IX. Đối với Web Submit Directory</b></font></div>';
echo '<div>Khi bạn đăng tải link website lên, cần tuân theo nội quy chung của diễnđàn. Không add link trái thuần phong mỹ tục, link về phản động hay đồitrụy, lừa đảo....<br/>
Bạn tự chịu trách nhiệm thông tin mình đăng tải.</div>';
echo '<div><b>Tất cả các quy định trên khi bạn đồng ý và đăng ký làm thành viên của hệ thống tức là bạn đã chấp nhận theo nội quy chung này. Nếu có bất kỳ vi phạm sẽ bị xử lý tùy theo mức độ. Mong tất cả các bạn hãy vì một cộng đồng trong sạch và lành mạnh.</b></div>';














require_once ("../incfiles/end.php");

?>
