<?

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();
/*
-----------------------------------------------------------------
asu
-----------------------------------------------------------------
*/
echo '<div class="hdr"><img src="images/news.gif" alt="" align="left" /><a href=""><b>' . $lng['information'] . '</b></a></div>';
echo $mp->news;
echo '<div class="link"><a href="news/index.php">' . $lng['news_archive'] . '</a> <a href="pages/faq.php">' . $lng['information'] . '(FAQ)</a> <a href="">More...</a></div>';

// jancok
if ($user_id || $set['active']) {
	echo '<div class="hdrs"><img src="images/community.gif" alt="" align="left" /><a href="users/index.php"><b>' . $lng['community'] . '</b></a></div>' ;
	echo '<div class="link"><a href="users/album.php">' . $lng['photo_albums'] . '</a> ' . functions::count_photo() . ' <a href="users/index.php">More...</a>';
}

// tempik
if ($set['mod_forum'] || $rights >= 7)
if ($set['mod_guest'] || $rights >= 7)
	echo '<div class="hdr"><img src="images/talk.gif" alt="" align="left" /><a href="forum/index.php?act=new"><b>' . $lng['dialogue'] . '</b></a></div>' ;
	echo '<div class="link"><a href="forum/?">' . $lng['forum'] . '</a> ' . functions::stat_forum() . ' <a href="guestbook/index.php">' . $lng['guestbook'] . '</a> <a href="forum/?">More...</a>';
	 
// turuk
if ($set['mod_lib'] || $rights >= 7){
	echo '<div class="hdr"><img src="images/talk.gif" alt="" align="left" />a href="library/">' . $lng['library'] . '</a> <span class="mcount">' . functions::stat_library() . '</span></div>';
	echo '<div class="link"><a href="library/index.php">LINK</a> <a href="library/index.php">LINK</a> <a href="library/index.php">More...</a></div>';
}

// Kontol
if ($set['mod_gal'] || $rights >= 7){
	echo '<div class="hdr"><img src="images/gal.gif" alt="" align="left" /><a href="gallery/index.php">' . $lng['gallery'] . '</a></div>';
	echo '<div class="link"><a href="gallery/index.php?id=3">Fun</a> <a href="gallery/index.php">More...</a></div>';
}

// Kenthu
if ($set['mod_down'] || $rights >= 7){
	echo '<div class="hdr"><img src="images/useful.gif" alt="" align="left" /><a href="download/">' . $lng['downloads'] . '</a> <span class="mcount">' . functions::stat_download() . '</span></div>';
	echo '<div class="link"><a href="http://kashur.cz.cc"><b>Mobile Clubz</b></a> <a href="download/index.php?cat=1">WAP Master</a> <a href="download/">More...</a></div>';
}
?>
