<?php

/**
 * @package     TrinhHuyenTrang
 * @link        http://trinhhuyentrang.org
 * @copyright   Copyright (C) 2008-2011 Huyen Trang
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      Tong Hoai
 */

define('_IN_JOHNCMS', 1);
$headmod = 'pages';
require('../incfiles/core.php');
$user = functions::get_user($user);
    $textl = 'Truy vấn từ GooGle';
    require('../incfiles/head.php');

$sql = " AND `engine` LIKE '%google%'";
$sql = str_replace('AND', 'WHERE', $sql);
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `stat_robots` ".$sql.""), 0);
if($total > 0){
echo '<div class="mainblok"><div class="phdr"><b>Từ khóa Google</b></div><div class="menu">';
$start = $start + 40;
$kmess = $kmess + 40;
$req = mysql_query("SELECT * FROM `stat_robots` ".$sql." ORDER BY `date` DESC LIMIT $start, $kmess");
while ($arr = mysql_fetch_array($req)){
$color = array('IndianRed','LightCoral','Salmon','DarkSalmon','Red','DarkRed','LightPink','DeepPink','MediumVioletRed','LightSalmon','Coral','OrangeRed','Orange','Gold','LightYellow','LightGoldenRodYellow','PeachPuff','DarkKhaki','Violet','Magenta','BlueViolet','DarkOrchid','Purple','DarkSlateBlue','GreenYellow','LimeGreen','MediumSpringGreen','ForestGreen','YellowGreen','OliveDrab','DarkOliveGreen','MediumAquaMarine','DarkCyan','SteelBlue','MediumBlue','RosyBrown','Sienna','Brown','Chocolate','NavajoWhite','DarkGray','DimGray','SlateGray','Black','MistyRose','HoneyDew','SeaShell','OldLace','LavenderBlush','AntiqueWhite');
$rand_color = rand(0, count($color)); 
    echo '<a href="' . $arr['url'] . '"><font color="'.$color[$rand_color].'">'.$arr['query'].'</a></font>, ';
                                       }
echo '</div></div>';
              }
if ($total > $kmess) {
echo '<div class="menu">' . functions::display_pagination('google.php?', $start, $total, $kmess) . '</div>';
}

require_once('../incfiles/end.php');
?>