<?php
define('_IN_JOHNCMS', 1);
$textl = 'apply for staff';
$headmod = 'apply_staff';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$maxapply = 500;
$adddate = 6;
$usersapply = 2;
switch ($act) {
case 'delete':
// COMRADE79
$req = mysql_query("SELECT * FROM `apply_staff` WHERE id='$id' LIMIT 1");
if ($rights >= 9 && mysql_num_rows($req)) {
if (isset($_GET['yes'])) {
mysql_query("DELETE FROM `apply_staff`  WHERE `id`='$id' LIMIT 1");
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
} else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want to delete staff crew from list..??!<br/><a href="apply_staff.php?act=delete&amp;id=' . $id . '&amp;yes">Yes</a> &bull; <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'edit':
// COMRADE79
$req = mysql_query("SELECT * FROM `apply_staff` WHERE id='$id' LIMIT 1");
if ($rights >= 9 && mysql_num_rows($req)) {
if (isset($_POST['submit'])) {
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 300) : '';
$count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;
$soob = functions::check(trim($_POST['message']));
$error = array();
if (empty($name) || empty($opis) || empty($soob))
$error[] = 'Field could not be empty..!!';
if($error) {
echo '<div class="rmenu">'.functions::display_error($error, '<a href="apply_staff.php?act=edit&amp;id=' . $id . '">Try again..!!</a>').'</div>';
require_once("../incfiles/end.php");
exit;
}
mysql_query("UPDATE `apply_staff` SET `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "', `count`='$count' WHERE `id`='$id' LIMIT 1");
$creq = mysql_query("SELECT `apply_staff`.*, `users`.`name` AS `nick` FROM `apply_staff` LEFT JOIN `users` ON `apply_staff`.`iduser` = `users`.`id` WHERE `apply_staff`.`type`='1' ORDER BY `apply_staff`.`count` DESC LIMIT 1");
while ($cres = mysql_fetch_assoc($creq)) {
$usname = $cres['nick'];
$admin = 'Staff Administrator';
if ($usname == $admin) {
continue;
}
mysql_query("INSERT INTO `privat` VALUES(0,'" .$usname. "','" .$soob. "','" .time(). "','" .$admin. "','in','no','Staff recruitment','0','','','','');");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
} else {
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
$res = mysql_fetch_array($req);
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/images/subfldr.png" width="16" height="16" class="left"/>&nbsp;<b>Change applyed status</b></div>' .
'<div class="menu"><form action="apply_staff.php?act=edit&amp;id=' . $id . '" method="post"><font color="#3399ff"><b>' . bbcode::tags($res['name']) . '</b></font><br/>' .
'Reason to become a staff:<br/><textarea cols="17" rows="2" name="opis">' . htmlentities($res['opis'], ENT_QUOTES, 'UTF-8') . '</textarea><br/>' .
'Change the status:<br/><select name="name" size="1"><option value="[red]Rejected[/red]"> Rejected </option>
<option value="[red]Staff position[/red] already exist..!!"> Staff position already exist </option>
<option value="[green]Accepted[/green] as Forum Moderator"> Forum Moderator </option>
<option value="[green]Accepted[/green] as Download Moderator"> Download Moderator </option>
<option value="[green]Accepted[/green] as Library Moderator"> Library Moderator </option>
<option value="[green]Accepted[/green] as Super Moderator"> Super Moderator </option>
<option value="[green]Accepted[/green] as Administrator"> Administrator </option>
</select><br/>' .
'Message to applyed staff:<br/><select name="message" size="1"><option value="We are sorry you are [red][b]Rejected[/b][/red], thanks for your contribution for applyng staff.."> Message for Rejected </option>
<option value="We are sorry [red][b]Staff position[/b][/red], you applyed already exist.. thanks for your contribution for applyng staff.."> Staff position already exist </option>
<option value="You are accepted as [green][b]Forum Moderator[/b][/green], thanks for applyng staff recruitment.. be wise for what your doing on your duty to manage the forum..!!"> Message for Forum Moderator </option>
<option value="You are accepted as [green][b]Download Moderator[/b][/green], thanks for applyng staff recruitment.. be wise for what your doing on your duty to manage the forum..!!"> Message for Download Moderator </option>
<option value="You are accepted as [green][b]Library Moderator[/b][/green], thanks for applyng staff recruitment.. be wise for what your doing on your duty to manage the forum..!!"> Message for Library Moderator </option>
<option value="You are accepted as [green][b]Super Moderator[/b][/green], thanks for applyng staff recruitment.. be wise for what your doing on your duty to manage the forum..!!"> Message for Super Moderator </option>
<option value="You are accepted as [green][b]Administrator[/b][/green], thanks for applyng staff recruitment.. be wise for what your doing on your duty to manage the forum..!!"> Message for Administrator </option>
</select><br/>' .
'<input name="submit" type="submit" title="click to apply" value="Proceed to apply"/></form>' .
'</div><div class="nfooter"><a href="' . $_SESSION['prd'] . '">Back</a></div></div></div>';
}
}
break;

case 'redirect':
// COMRADE79
$req = mysql_query("SELECT `name` FROM `apply_staff` WHERE `id`='$id' AND `type`='1'");
if(mysql_num_rows($req)) {
$res = mysql_fetch_assoc($req);
if (!$_SESSION['fr_staff_' . $id]) {
mysql_query("UPDATE `apply_staff` SET `count` = (`count`+1) WHERE `id` = '$id' LIMIT 1");
$_SESSION['fr_staff_' . $id] = true;
}
header('location:' . $res['name']);
exit;
}
break;

case 'mass_del':
// COMRADE79
if ($rights >= 9) {
if (isset($_GET['yes'])) {
foreach ($_SESSION['dc'] as $delid) {
mysql_query("DELETE FROM `apply_staff`  WHERE `id`='" . intval($delid) . "';");
}
header('location: ' . preg_replace('/(page|start)\=[0-9]+/', '', $_SESSION['prd']));
exit;
} else {
if (empty($_POST['delch'])) {
echo '<div class="rmenu">'.functions::display_error('You not choose for deleting..<br/><a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Try again..!!</a>').'</div>';
require_once ("../incfiles/end.php");
exit;
}
foreach ($_POST['delch'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="rmenu"><p>Are you sure want delete this staff crew..??!<br/><a href="?act=mass_del&amp;yes">Yes</a> &bull; <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></p></div>';
}
}
break;

case 'mod_staff':
// COMRADE79
if ($rights >= 9) {
if (isset($_GET['pr'])) {
mysql_query("UPDATE `apply_staff` SET `type` = '1' WHERE `id` = '$id' LIMIT 1");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='1'"), 0);
if ($total > $maxapply)
mysql_query("DELETE FROM `apply_staff` where `type`='1' ORDER BY `vr` ASC LIMIT 1");
header("location: apply_staff.php?act=mod_staff");
exit;
}
elseif (isset($_GET['vs'])) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='1'"), 0);
if ($total > $maxapply) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='2'"), 0);
mysql_query("DELETE FROM `apply_staff` where `type`='1' ORDER BY `vr` ASC LIMIT $total_mod");
}
mysql_query("UPDATE `apply_staff` SET `type` = '1' WHERE `type` = '2'");
header("location: apply_staff.php?act=mod_staff");
exit;
} else {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/images/subfldr.png" width="16" height="16" class="left"/>&nbsp;<b><a href="apply_staff.php">Staff request pending</a></b></div>';
$req = mysql_query("SELECT `apply_staff`.*, `users`.`name` AS `nick` FROM `apply_staff` LEFT JOIN `users` ON `apply_staff`.`iduser` = `users`.`id` WHERE `apply_staff`.`type`='2'");
if(mysql_num_rows($req)) {
echo '<form action="apply_staff.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<b>' . bbcode::tags($res['name']) . '</b><br/>' . functions::checkout($res['opis'], 1, 1);
echo '<br/><small>Apply by <a href="../users/profile.php?user=' . $res['iduser'] . '"><font color="#3399ff">' . $res['nick'] . '</font></a>, ' . functions::display_date($res['vr']) . '</small>';
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="apply_staff.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> &bull; <a href="apply_staff.php?act=mod_staff&amp;id=' . $res["id"] . '&amp;pr">Confirm to list</a></div></div></div>';
++$i;
}
echo '<div class="rmenu"><input type="submit" value="delete check it"/></div></form>' .
'<div class="list1"><a href="apply_staff.php?act=mod_staff&amp;vs">Confirm all</a></div>';
}
else
echo '<div class="menu"><p>Empty pending request list..!!</p></div>';
echo '<div class="nfooter"><a href="apply_staff.php?act=view_list">Go to view list</a></div></div>';
}
}
break;

case 'add_staff':
// COMRADE79
if ($user_id) {
$total_staff = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `iduser`='$user_id'"), 0);
$error = array();
if ($total_staff >= $usersapply && $rights < 9)
$error[] = 'user only allowed add one ' . $usersapply . ' staff apply..!!';
$flood = functions::antiflood();
if ($flood)
$error[] = 'antiflood..!! Please.. wait ' . $flood . ' second..!!';
if ($error) {
echo '<div class="rmenu">'.functions::display_error($error, '<a href="apply_staff.php?act=add_staff">Please wait a minute..!!</a>').'</div>';
require_once("../incfiles/end.php");
exit;
}
if (isset($_POST['submit'])) {
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$opis = isset($_POST['opis']) ? mb_substr(trim($_POST['opis']), 0, 300) : '';
$type = $rights >= 0 ? 2 : 2;
if (empty($name) || empty($opis))
$error[] = 'Field could not be empty..!!';
if (!$error) {
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `name`='" . mysql_real_escape_string($name) . "' OR  `name`='" . mysql_real_escape_string($name) . "'"), 0);
if ($total >= 1)
$error[] = 'This staff position already exist..!!';
}
if ($error) {
echo '<div class="rmenu">'.functions::display_error($error, '<a href="apply_staff.php?act=add_staff">Try again..!!</a>').'</div>';
require_once("../incfiles/end.php");
exit;
}
mysql_query("INSERT INTO `apply_staff` SET `vr`='" . time() . "', `iduser`='$user_id', `type`='$type', `name`='" . mysql_real_escape_string($name) . "', `opis`='" . mysql_real_escape_string($opis) . "'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/images/subfldr.png" width="16" height="16" class="left"/>&nbsp;<b>Confirmation Message</b></div><div class="list1"><b>Thank you for applying</b><br/>Your Application has been Submited.. ' . ($rights >= 9 ? '' : ' your Application is going to Moderate by Owner') . '<br/>You will shortly notify by pm from admin within 24 hour or you can check your status <a href="apply_staff.php?act=view_list"><b>Here</b></a></div>
<div class="nfooter"><a href="../index.php">Back to Home</a></div></div></div>';
} else {
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/images/subfldr.png" width="16" height="16" class="left"/>&nbsp;<b>Joint to be our staff</b></div><div class="list1">' .
'<p>We are continuously trying to find talented member for our staff and also to expand our community..<br/><b>What do we want..?! We want to make the forum better..</b><br/>
And you are invited to join us.. You dont know if you will fit in here..?! Well its very simple to answer that.. If you like any kind of programming we usually like you.. You must note that a staff member needs to have some level of knowledge about programming in order to help other users..
You also need to note that a staff member needs to be active here daily and usually reply to threads if he can help.. Finally the most important thing a staff member has to do is to HAVE FUN.. Do you think you can manage that..?! And most importantly do you think that by doing this you can help others..?! If the answer is yes then we invite you to become a part of our team..
To ancomplish that all you have to do is to submit the form down below and if the current staff members agree that you can become a staff member you will be promoted in just a few hours.. Its also possible to receive pms from the staff if they want to get to know you better but it is recommended to submit this form after you do some decent number of posts here and by doing that they we already know you..
That being said we wish you good luck and we hope, staff member or not, that you have a good time here..</p> ' .
'<form action="apply_staff.php?act=add_staff" method="post">' .
'<b>Apply to be staff as:</b>' .
'<br/><select name="name" size="1"><option value="Apply as Forum Moderator"> Forum Moderator </option>
<option value="Apply as Download Moderator"> Download Moderator </option>
<option value="Apply as Library Moderator"> Library Moderator </option>
<option value="Apply as Super Moderator"> Super Moderator </option>
<option value="Apply as Administrator"> Administrator </option>
</select><br/> ' .
'<b>Reason to become a staff..??!</b>' .
'<br/><textarea cols="17" rows="2" name="opis"></textarea><br/>' .
'<input name="submit" type="submit" title="click to apply staff" value="Apply for staff"/></form>' .
'</div><div class="omenu">If you applyed you can view your status <a href="apply_staff.php?act=view_list"><span class="red"><b>Here</b></span></a></div>';
echo '<div class="nfooter"><a href="../index.php">Back To Home</a></div></div></div>';
}
} else {
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;
}
break;

default:
// COMRADE79
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><img src="/images/subfldr.png" width="16" height="16" class="left"/>&nbsp;<b>Staff request list</b></div>';
$total_staff = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `iduser`='$user_id'"), 0);
if ($user_id && ($total_staff < $usersapply || $rights >= 0) && ((time()  - $datauser['datereg']) > ($adddate * 86400) || $rights >= 9))
echo '<div class="list1"><a href="apply_staff.php?act=add_staff">Apply for staff</a></div>';
if ($rights >= 9) {
$total_mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='2'"), 0);
if($total_mod)
echo '<div class="rmenu"><a href="apply_staff.php?act=mod_staff">staff for moderation</a> ' . $total_mod . '</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `apply_staff` WHERE `type`='1'"), 0);
if($total) {
$req = mysql_query("SELECT `apply_staff`.*, `users`.`sex`, `users`.`datereg`, `users`.`name` AS `nick` FROM `apply_staff` LEFT JOIN `users` ON `apply_staff`.`iduser` = `users`.`id` WHERE `apply_staff`.`type`='1' ORDER BY `apply_staff`.`count` DESC LIMIT $start, $kmess");
if ($rights >= 9)
echo '<form action="apply_staff.php?act=mass_del" method="post">';
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
if ($res['sex'])
echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($res['sex'] == 'm' ? 'm' : 'w') . ($res['datereg'] > time() - 86400 ? '_new' : '')
. '.png" width="16" height="16" align="left" alt="' . ($res['sex'] == 'm' ? 'es' : 'eu') . '" />&#160;';
else
echo '<img src="../images/del.png" width="12" height="12" alt=""/>&#160;';
echo '<a href="../users/profile.php?user=' . $res['iduser'] . '"><b>' . $res['nick'] . '</b></a><br/>';
echo '<font color="green">Reason to be staff</font>:<br/>';
echo '' . functions::checkout($res['opis'], 1, 1);
echo '<br/><b>' . bbcode::tags($res['name']) . '</b><br/>';
if ($rights >= 9)
echo '<div class="sub"><input type="checkbox" name="delch[]" value="' . $res["id"] . '"/>&nbsp;<a href="apply_staff.php?act=delete&amp;id=' . $res["id"] . '"><span class="red">Delete</span></a> &bull; <a href="apply_staff.php?act=edit&amp;id=' . $res["id"] . '">Change status</a></div>';
echo '</div>';
++$i;
}
if ($rights >= 9)
echo '<div class="rmenu"><input type="submit" value="delete check it list"/></form></div>';
}
else
echo '<div class="menu"><p>Empty list..!!</p></div>';
echo '<div class="nfooter">Total staff:&nbsp;' . $total . '</div>';
if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('apply_staff.php?', $start, $total, $kmess) . '<br/>';
echo '<form action="apply_staff.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="Go to page &gt;&gt;"/></form></div>';
}
echo '</div>';
}
require_once("../incfiles/end.php");
?>