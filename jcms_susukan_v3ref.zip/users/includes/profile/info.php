<?php
/*
Author: Sohel
Site: http://masterloft.tk
*/
defined('_IN_JOHNCMS') or die('Error: restricted access');
/*
-----------------------------------------------------------------
Подробная информация, контактные данные
-----------------------------------------------------------------
*/
$textl = htmlspecialchars($user['name']) . ': ' . $lng['information'];
require('../incfiles/head.php');
echo '<div class="mainbox"><div class="mainblok"><div class="nfooter"><a href="/users/' . $user['name'] . '"><b>' . $lng['profile'] . '</b></a> | ' . $lng['information'] . '</div>';
if ($user['id'] == $user_id || ($rights >= 7 && $rights > $user['rights']))
echo '<div class="topmenu"><a href="profile.php?act=edit&amp;user=' . $user['id'] . '">' . $lng['edit'] . '</a></div>';
echo '<div class="user"><p>' . functions::display_user($user, array ('iphide' => 1,)) . '</p></div>' .
'<div class="topmenu">' .
'<b><img src="../images/contacts.png" width="16" height="16" class="left" />&#160;' . $lng_profile['personal_data'] . '</b>' .
'</div>';
if (file_exists('../files/users/photo/' . $user['id'] . '_small.jpg'))
echo '<div class="list1"><center><a href="../files/users/photo/' . $user['id'] . '.jpg"><img src="../files/users/photo/' . $user['id'] . '_small.jpg" alt="' . $user['name'] . '" border="0" /></a></center></div>';
echo '<div class="none"><b>' . $lng_profile['name'] . ':</b> ' . (empty($user['imname']) ? '' : $user['imname']) . '</div>' .
'<div class="none"><b>Title:</b> ' . (empty($user['pangkat']) ? '' : '' . bbcode::tags($user['pangkat'])) . '</div>' .
'<div class="none"><b>' . $lng_profile['birt'] . ':</b> ' . (empty($user['dayb']) ? '' : sprintf("%02d", $user['dayb']) . '.' . sprintf("%02d", $user['monthb']) . '.' . $user['yearofbirth']) . '</div>' .
'<div class="none"><b>' . $lng_profile['city'] . ':</b> ' . (empty($user['live']) ? '' : $user['live']) . '</div>' .
'<div class="none"><b>' . $lng_profile['about'] . ':</b> ' . (empty($user['about']) ? '' : '<br />' . functions::smileys(bbcode::tags($user['about']))) . '</div>' .
'<div class="none"><b>Signature:</b> ' . (empty($user['podpis']) ? '' : functions::smileys(bbcode::tags($user['podpis']))) . '</div>' .
'<div class="topmenu">' .
'<b><img src="../images/mail.png" width="16" height="16" class="left" />&#160;' . $lng_profile['communication'] . '</b></div>' .
'<div class="none"><b>' . $lng_profile['phone_number'] . ':</b> <a href="tel:' . (empty($user['mibile']) ? '' : $user['mibile']) . '">' . (empty($user['mibile']) ? '' : $user['mibile']) . '</a></div>' .
'<div class="none"><b>E-mail:</b>';
if (!empty($user['mail']) && $user['mailvis'] || $rights >= 7 || $user['id'] == $user_id) {
echo $user['mail'] . ($user['mailvis'] ? '' : '<span class="gray"> [' . $lng_profile['hidden'] . ']</span>');
}
echo '</div>' .
'<div class="none"><b>ICQ:</b> ' . (empty($user['icq']) ? '' : $user['icq']) . '</div>' .
'<div class="none"><b>Skype:</b> ' . (empty($user['skype']) ? '' : $user['skype']) . '</div>' .
'<div class="none"><b>Netbook:</b> <a href="http://netbook.tk/' . (empty($user['jabber']) ? '' : $user['jabber']) . '">' . (empty($user['jabber']) ? '' : $user['jabber']) . '</a></div>' .
'<div class="none"><b>Facebook:</b> <a href="http://m.facebook.com/' . (empty($user['facebook']) ? '' : bbcode::tags($user['facebook'])) . '">' . (empty($user['facebook']) ? '' : bbcode::tags($user['facebook'])) . '</a></div>' .
'<div class="none"><b>Twitter:</b> <a href="http://twitter.com/' . (empty($user['twitter']) ? '' : bbcode::tags($user['twitter'])) . '">' . (empty($user['twitter']) ? '' : bbcode::tags($user['twitter'])) . '</a></div>' .
'<div class="none"><b>' . $lng_profile['site'] . ':</b> ' . (empty($user['www']) ? '' : bbcode::tags($user['www'])) . '</div>' .
'</div>' .
'<div class="nfooter"><a href="/users/' . $user['name'] . '">' . $lng['back'] . '</a></div></div></div>';
?>
