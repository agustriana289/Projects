<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
require('../incfiles/core.php');
$sql1 = "ALTER TABLE `forum` ADD `kiemduyet_who` varchar(40) NOT NULL;";
$sql2 = "ALTER TABLE `forum` ADD `closed_who` varchar(40) NOT NULL;";
$sql3 = "ALTER TABLE forum ADD kiemduyet int(1) not null;";
$sql4 = "UPDATE forum SET kiemduyet='1';";
$sql5 = "UPDATE forum SET kiemduyet_who='BOT';";
mysql_query($sql1) or die('lỗi1');
mysql_query($sql2) or die('lỗi2');
mysql_query($sql3) or die('lỗi3');
mysql_query($sql4) or die('lỗi4');
mysql_query($sql5) or die('lỗi5');
echo 'Bạn đã cài đặt thành công mod kiểm duyệt';
?>