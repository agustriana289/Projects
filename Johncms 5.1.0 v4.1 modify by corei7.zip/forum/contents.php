<?php

/**
 * @Info        Modify by corei7
 * @link        http://wapshare.free96.ru
 * @author      corei7
 */

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = $lng['forum'];
require('../incfiles/head.php');
$map = new sitemap();
echo $map->forum_contents();
require('../incfiles/end.php');
?>