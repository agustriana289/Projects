<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];

// stats
$statistic = new statistic($textl);

mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '2'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '3'");
                 
                      
/*
-----------------------------------------------------
S'N<S2SlS'SlSL HTML S.SzS"SlS"SlS2SaSl N?N,NESzS?SlN?N<, SzSlS'SaS"NZN?SzSuSL CSS N"SzSaS"
-----------------------------------------------------
*/
if(stristr(core::$user_agent, "msie") && stristr(core::$user_agent, "windows")){
// S'N<S'SzSuSL S.SzS"SlS"SlS2SaSl S'S"NZ Internet Explorer
header("Cache-Control: no-store, no-cache, must-revalidate");
header('Content-type: text/html; charset=UTF-8');
} else {
// S'N<S'SzSuSL S.SzS"SlS"SlS2SaSl S'S"NZ SlN?N,SzS"NSS?N<Na S+NESzN?S.SuNESlS2
header("Cache-Control: public");
//header('Content-type: application/xhtml+xml; charset=UTF-8');
}
header("Expires: " . date("r",  time() + 60));
echo '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
"\n" . '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' .
"\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">' .
"\n" . '<head>' .
"\n" . '<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>' .
"\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
"\n" . '<meta name="Generator" content="JohnCMS, http://johncms.com" />' . // S'StS~SsS?StS~SR!!! S"SzS?S?N<Sa SaSlSzSlNESzSaN, N?S'SzS"NZN,NS S?SuS"NSS.NZ
(!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
(!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
"\n" . '<link rel="stylesheet" href="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/style.css" type="text/css" />' .
"\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico" />' .
"\n" . '<link rel="alternate" type="application/rss+xml" title="RSS | ' . $lng['site_news'] . '" href="' . $set['homeurl'] . '/rss/rss.php" />' .
"\n" . '<title>' . $textl . ' | ID Community</title>' .
"\n" . '</head><body>' . core::display_core_errors();
/*
-----------------------------------------------------------------
S?SuSaS"SzSLS?N<Sa SLSlS'N?S"NS
-----------------------------------------------------------------
*/
$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
$view = $user_id ? 2 : 1;
$layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
$req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
if (mysql_num_rows($req)) {
while (($res = mysql_fetch_assoc($req)) !== false) {
$name = explode("|", $res['name']);
$name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
// SRN?S"Sl S+N<S"Sl S.SzS'SzS?Sl S?SzN?SuNEN,SzS?SlSu N^NESlN"N,Sz, N,Sl SzNESlSLSuS?NZSuSL
$font = $res['bold'] ? 'font-weight: bold;' : false;
$font .= $res['italic'] ? ' font-style:italic;' : false;
$font .= $res['underline'] ? ' text-decoration:underline;' : false;
if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
@$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
}
}
}

/*
-----------------------------------------------------------------
S?SuSaS"SzSLS?N<Sa S+S"SlSa N?SzSaN,Sz
-----------------------------------------------------------------
*/
if (isset($cms_ads[0])) echo $cms_ads[0];

/*
-----------------------------------------------------------------
S'N<S2SlS'SlSL S"SlS"SlN,SlSz Sl SzSuNESuSaS"NZN?SzN,SuS"NS NZS.N<SaSlS2
-----------------------------------------------------------------
*/
echo '<div class="logo"><table style="width:100%;"><tr><td valign="bottom"><a href="' . $set['homeurl'] . '"><img src="' . $set['homeurl'] . '/theme/' . $set_user['skin'] . '/images/logo.gif" alt=""/></a><br /><small><font color="#eeeeee">';
include 'date.php';
echo '</font></small></td>' .
($headmod == 'mainpage' && count(core::$lng_list) > 1 ? '<td align="right"><a href="' . $set['homeurl'] . '/go.php?lng"><b>' . strtoupper(core::$lng_iso) . '</b></a>&#160;<img src="' . $set['homeurl'] . '/images/flags/' . core::$lng_iso . '.gif" alt=""/>&#160;</td>' : '') .
'</tr></table></div>';

    
/*
-----------------------------------------------------------------
S'N<S2SlS'SlSL S2SuNENaS?SlSa S+S"SlSa N? SzNESlS2SuN,N?N,S2SlSuSL
-----------------------------------------------------------------
*/

/*
-----------------------------------------------------------------
S"S"SzS2S?SlSu SLSuS?NZ SzSlS"NSS.SlS2SzN,SuS"NZ
-----------------------------------------------------------------
*/
echo '<div class="tmn" align="bottom">' . ($rights >= 1 ? '<span class="red"><a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php">AdminCp</a></span> &bull; ' : '') .
($user_id ? '<span class="silver"><a href="' . $set['homeurl'] . '/users/profile.php?act=office">UserCp</a></span> &bull; ' : '') .
($user_id ? '<a href="' . $set['homeurl'] . '/exit.php">' . $lng['exit'] . '</a>' : '<a href="' . $set['homeurl'] . '/login.php">' . $lng['login'] . '</a> | <a href="' . $set['homeurl'] . '/registration.php">' . $lng['registration'] . '</a>') .'</div>';
                                                                          echo '<div class="maintxt">';                                       
if ($headmod == 'mainpage') {
$mp = new mainpage();
echo $mp->news;
}
if ($user_id) {
}else {
if ($headmod == 'mainpage') {
echo '<div class="mainblok"><div class="phdr"><b>User Login</b></div>';

echo '<div class="sbox sundawap">';
echo '<form action="/login.php" method="post"><input type="text" name="n" value="' . htmlentities($user_login, ENT_QUOTES, 'UTF-8') . '" size="5" class="name">&nbsp;<input type="password" name="p" size="5" class="pass">';
echo '&nbsp;<input type="hidden" name="mem" value="1" checked="checked"><input type="submit" value="Login"></form></div></div></div>';

}
}
/*
-----------------------------------------------------------------
S?SuSaS"SzSLS?N<Sa S+S"SlSa N?SzSaN,Sz
-----------------------------------------------------------------
*/
echo '<div style="text-align:center">';
if (!empty($cms_ads[1])) echo '' . $cms_ads[1] . '';
echo '</div>';


/*
-----------------------------------------------------------------
SRSlSaN?SzN?SlNZ SLSuN?N,SlSzSlS"SlS?SuS?SlSa SzSlN?SuN,SlN,SuS"SuSa
-----------------------------------------------------------------
*/
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
// SRSlSaN?SlNEN?SuSL SLSuN?N,SlSzSlS"SlS?SuS?SlSu SzS2N,SlNESlS.SlS2SzS?S?N<Na
if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
$sql = "`karma_time` = '" . time() . "', ";
}
$movings = $datauser['movings'];
if ($datauser['lastdate'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "',";
}
if ($datauser['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
if ($datauser['browser'] != $agn)
$sql .= "`browser` = '" . mysql_real_escape_string($agn) . "',";
$totalonsite = $datauser['total_on_site'];
if ($datauser['lastdate'] > (time() - 300))
$totalonsite = $totalonsite + time() - $datauser['lastdate'];
mysql_query("UPDATE `users` SET $sql
`movings` = '$movings',
`total_on_site` = '$totalonsite',
`lastdate` = '" . time() . "'
WHERE `id` = '$user_id'
");
} else {
// SRSlSaN?SlNEN?SuSL SLSuN?N,SlSzSlS"SlS?SuS?SlSu S"SlN?N,SuSa
$movings = 0;
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
$req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req)) {
// SRN?S"Sl SuN?N,NS S2 S+SzS.Su, N,Sl SlS+S?SlS2S"NZSuSL S'SzS?S?N<Su
$res = mysql_fetch_assoc($req);
$movings = $res['movings'];
if ($res['sestime'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "', `movings` = '0'";
}
if ($res['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
mysql_query("UPDATE `cms_sessions` SET $sql
`movings` = '$movings',
`lastdate` = '" .time()  . "'
WHERE `session_id` = '$session'
");
} else {
// SRN?S"Sl SuNeSu S?SuS+N<S"Sl S2 S+SzS.Su, N,Sl S'SlS+SzS2S"NZSuSL S.SzSzSlN?NS
mysql_query("INSERT INTO `cms_sessions` SET
`session_id` = '" . $session . "',
`ip` = '" . core::$ip . "',
`ip_via_proxy` = '" . core::$ip_via_proxy . "',
`browser` = '" . mysql_real_escape_string($agn) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',
`place` = '$headmod'
");
}
}
/*
-----------------------------------------------------------------
S'N<S2SlS'SlSL N?SlSlS+NeSuS?SlSu Sl S'SzS?Su
-----------------------------------------------------------------
*/
if (!empty($ban)) echo '<div class="alarm">' . $lng['ban'] . '&#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=ban">' . $lng['in_detail'] . '</a></div>';

/*
-------------------------------------------------------------
S?N?N<S"SaSl S?Sz S?SuSzNESlN?SlN,SzS?S?SlSu
------------------------------------------------------------
*/
if ($user_id) {
$list = array();
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `privat` WHERE `user` = '$login' AND `type` = 'in' AND `chit` = 'no'"), 0);
if ($new_mail) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/pradd.php?act=in&amp;new">' . $lng['mail'] . '</a>&#160;(' . $new_mail . ')';
if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '">' . $lng['guestbook'] . '</a> (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')';
$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';
if ($datauser['journal_forum']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/journal.php">Forum</a>&#160;(' . $datauser['journal_forum'] . ')';

if (!empty($list)) echo '<div class="rmenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div>';
if (!file_exists(($rootpath . 'files/users/avatar/' . $user_id . '.png')))
echo '<div class="rmenu">You have not uploaded an avatar, click<a href="../users/profile.php?act=images&amp;mod=avatar&amp;user=' . $user_id . '"><b>&nbsp;HERE&nbsp;</b></a>to upload.</div>';
}

# MOD GUESTBOOK IN HEAD
if ($user_id) {
if ($user_id &&
$headmod != "pradd" &&
$headmod != "guest" &&
$headmod != "quick chat" &&
$headmod != "load" &&
$headmod != "admin" &&
$headmod != "leave" &&
$headmod != "guestbook" &&
$headmod != "library" &&
$headmod != "gallery"
){
$jshout = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
if ($user_id && !$ban['1'] && !$ban['13']) {
echo '<div class="mainblok"><div class="phdr"><a href="/guestbook/index.php"><b>Shoutbox</b></a>';
if ($rights >= 1) {
echo ' | <a href="'.$home.'/guestbook/botpanel.php"><b>Bot Panel</b></a>';
}
echo '</div><div class="sbox"><form action="' . $rootpath . 'guestbook/index.php?act=say" method="post">';
 
$refer = base64_encode($_SERVER['REQUEST_URI']);
echo '<textarea cols="15" rows="2" name="msg"></textarea>';
echo '<input type="submit" name="submit" value="Shout"/></input></form></div>';
}
if ($jshout) {
$jreq = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT 3");
while ($jres = mysql_fetch_array($jreq)) {
echo ceil(ceil($waptok / 2) - ($waptok / 2)) == 0 ? '<div class="textshout">' : '<div class="textshout">'; 
echo (time() > $jres['lastdate'] + 300 ? '<span class="red">&bull;</span>&#160;' : '<span class="green">&bull;</span>&#160;');               
if (!empty($user_id) && ($user_id != $jres['user_id'])) {
$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$jres['user_id']. "' LIMIT 1;"), 0);
echo '<a href="../' .$name_lat. '"><b>' . $jres['name'] . '</b></a>: ';
} else {
echo '<b>' . $jres['name'] . '</b>: ';
}         
if (!empty($jres['status']))
$text = htmlentities($jres['text'], ENT_QUOTES, 'UTF-8');
$jpost = bbcode::tags($jpost);
$jpost = str_replace("\r\n", "<br />", $jpost);
if ($jres['user_id']) {

# MENAMPILKAN SMILEYS
$jpost = functions::checkout(mb_substr($jres['text'], 0, 150), 1, 1);
if ($set_user['smileys'])
$jpost = functions::smileys($jpost, $jres['rights'] >= 1 ? 1 : 0);
}
if($user_id) {
$jpost = str_replace('[you]', $login, $jpost);
} else {
$jpost = str_replace('[you]', 'Guest', $jpost);
}

# MENAMPILKAN POSTING
if (mb_strlen($jres['text']) > 150)
{
echo $jpost.' ';
echo '...<a href="../guestbook/index.php">more</a>';
} else {
echo $jpost;
}
echo '</div>';
++$waptok;
}
} else {
echo '<div class="textshout">' . $lng['guestbook_empty'] . '</div>';
}
echo '<div class="none" align="center"><a href="' . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'] . '">Refresh</a> | <a href="/pages/faq.php?act=smileys">Smileys</a> | <a href="/pages/img.php">BBimg</a></div>';     
echo '</div>';    
}
}
