<?
{
$roq = mysql_query("SELECT `qchat`.*, `users`.`name`,`users`.`hans_color`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");;
while ($res = mysql_fetch_array($roq))
{
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="list1">' : '<div class="list2">';
// icon seks
global $set_user, $realtime, $user_id, $admp, $home;
if ($set_user['avatar']) {
if (file_exists(($rootpath . 'files/users/avatar/' . $res['user_id'] . '.png')))
echo '<img src="' . $set['homeurl'] . '/files/users/avatar/' . $res['user_id'] . '.png" width="22" height="22" alt="' . $user['name'] . '" /> ';
else
echo '<img src="' . $set['homeurl'] . '/images/empty.png" width="22" height="22" alt="' . $user['name'] . '" /> ';
}
if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="' . $set['homeurl'] . '/users/profile.php?user=' . $res['user_id'] . '"><b><font color="' . $res['hans_color'] .'">' . $res['name'] . '</font></b></a> ';
}
else {
echo '<a href="' . $set['homeurl'] . '/users/profile.php?user=' . $res['user_id'] . '"><b><font color="' . $res['hans_color'] .'">' . $res['name'] . '</font></b></a>';
}
$ontimes = $res['lastdate'] + 300;
if (time() > $ontimes)
{
echo '<span class="red"><img src="../images/off.gif" alt="[OFF]" /"></span>';
}
else
{
echo '<font color="#00AA00"><img src="../images/on.gif" alt="[ON]" /"></font>';
}
echo ' ';
$post = functions::antilink(functions::checkout($res['text'], 0, 2));
$post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
// text
if (mb_strlen($post) >= 100)
{
$post = mb_substr($post, 0, 150);
echo $post.' ';
}
else
{
echo $post;
echo '<br>';
echo '&#8226;
<font color="gray">';
echo functions::update_time($res['time']);
echo '</span>';
}
echo '</div>';
++$i;
}
}
?>
