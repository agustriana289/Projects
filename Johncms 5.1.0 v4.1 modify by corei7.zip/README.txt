﻿/**
 * @Info        Modify by corei7
 * @need help   visit my site bellow
 * @link        http://wapshare.free96.ru
 * @author      corei7
 */

The given description is valid for the system, that was download from the site  http://johncms.com
 For the archives download from the other sites the work is not guaranteed and there is no maintenance. 

Content Management System JohnCMS
is for the construction of the sites that will be looked through from mobiles. It 
completely fits  the specification 
XHTML Mobile Profile and has not a very big size of mechanized pages. 

The main possibilities of the system:
- multilingual, the possibility to install / delete the languages of the interface.
- a high level of safety
- quick in work, built on MySQL
- advanced system of differentiation of rights for administrators/moderators
- forum with the possibility to open / close themes, to create voting, possibility to 
  attach files to the theme and etc.
- private photo albums
- private guest books
- advanced library with unlimited nesting of sections and the possibility for the guests to publish their own articles.
  There is a moderation of the articles, that had been published by guests.
  The automatic compillation of Java books.
- photo gallery
- download centre with unlimited nesting of sections, counter, raiting and comments
- private mail with the possibility to attach files
- easy work with smiles
- change of styles
- and many other things...