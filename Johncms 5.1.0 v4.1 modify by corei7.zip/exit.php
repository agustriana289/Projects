<?php

/**
 * @Info        Modify by corei7
 * @link        http://wapshare.free96.ru
 * @author      corei7
 */

session_name('SESID');
session_start();
setcookie('cuid', '');
setcookie('cups', '');
session_destroy();
header('Location: index.php');

?>