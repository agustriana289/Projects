<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
$key = isset($_GET['key']) ? trim($_GET['key']) : '';

if (!$user_id) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require('../incfiles/end.php');
    exit;
}
$rc = mysql_query("SELECT * FROM `preg_users` WHERE `coupon` = '".mysql_real_escape_string("u".$user_id."-".$key)."'");
if (mysql_num_rows($rc) == 0) {
    require('../incfiles/head.php');
    echo functions::display_error("Kode konfirmasi tidak benar");
    require('../incfiles/end.php');
    exit;
}
$re = mysql_fetch_array($rc);
mysql_query("DELETE FROM `preg_users` WHERE `coupon` = '".mysql_real_escape_string("u".$user_id."-".$key)."'");
mysql_query("UPDATE `users` SET `mail`='".mysql_real_escape_string($re['email'])."' WHERE `id`='".$user_id."'");
    require('../incfiles/head.php');
    echo "Email berhasil dikonfirmasi. Email baru Anda adalah <b>".$re['email']."</b>.";
    require('../incfiles/end.php');
?>