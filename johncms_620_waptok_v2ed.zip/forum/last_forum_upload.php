<?php
/** Last forum upload Jcms v4.4.0
 * http://www.waptok.asia
 */

if($user_id){
echo '<div class="mainblok"><div class="phdr"><b>Last Forum Upload</b></div>';
$req = mysql_query("SELECT * FROM `cms_forum_files` ORDER BY `id` DESC LIMIT 5");
$i = 0;
while($file = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$path = $file['filename'];
$fls = round(@filesize('../files/forum/attach/' . $path) / 1024, 2);
if (empty($user_id) || $ban['1'] || $ban['12'] || $ban['11'] || $datauser['postforum'] < 3){
echo '<img class="middle" src="../images/lock.gif" alt="3 post for download"/> File Locked';
}
else {
echo '&raquo; <a href="index.php?act=file&id='.$file['id'].'"> '.$file['filename'].'</a> ('.$fls.' kB)';
}
echo '</div>';
++$i;
}
if ($fls == 0) {
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
echo '</div>';
}
?>
