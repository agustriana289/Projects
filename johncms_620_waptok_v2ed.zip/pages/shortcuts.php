<?php
/** Shortcuts Jcms
 * http://www.waptok.asia
 */

echo'<div class="mainblok"><div class="phdr"><b>Wapmaster</b></div><div class="menu"><select align="right" onchange="location.href=this.options[this.selectedIndex].value" style="width: 80px">
<option SELECTED  value="/">Service Tool</option><br />
<option value="http://wapftp.com">Wapftp</option><br/>
<option value="/service/intip.php">Source Viewer</option><br/><option value="/service/colorcode.php">Color Code</option><br/><option value="/service/rainbow.php">Rainbow Text</option><br/><option value="/screen">Screenshot Site</option><br/><option value="/service/teshtml.php">Tes HTML</option></select>';
echo'</div></div>';
?>