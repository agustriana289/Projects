<?php
/** Forum Category Jcms
 * Copyright Jcms 6.x.x
 * Author http://johncms.com/about
 * http://www.waptok.asia
 */

switch($act) 
{ 
default: 
echo '<div class="mainblok"><div class="phdr"><a href="'.$home.'/forum"><b>Forum</b></a></div>';
echo '<div class="topmenu"><b>Forum Category</b> | <a href="'.$home.'/index.php?act=top_forum"><b>Top Forum</b></a></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        while (($res = mysql_fetch_array($req)) !== false) {
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
            echo '<a href="'.$home.'/forum/' . functions::gantiurl($res['text']) . '_'.$res['id'].'.html">' . $res['text'] . '</a> [<font color="red">' . $count . '</font>]';
            if (!empty($res['soft']))
                echo '<div class="func"><span class="gray">' . $res['soft'] . '</span></div>';
            echo '</div>';
            ++$i;
        }

           if ($count == 0)
{
echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}

echo '</div>';
// add
break;
case 'top_forum':
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while (($res = mysql_fetch_array($req)) !== false) {
echo '<div class="mainblok"><div class="phdr"><a href="'.$home.'/forum"><b>Forum</b></a></div>';
echo '<div class="topmenu"><a href="'.$home.'/index.php"><b>Forum Category</b></a> | <b>Top Forum</b></div>';
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `refid`='" . $res['id'] . "' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' and `refid`='" . $res['id'] . "'"), 0);
echo '<div class="'.(++$i%2==0 ? "list2" : "list1").'">&bull; <a href="'.$home.'/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a>        Topics : '.$count.'<br/>';
if ($user_id) {
echo '<a class="omenu" href="'.$home.'/forum/index.php?act=nt&id=' . $res['id'] . '">Add Post</a>';
}
echo '</div>';
if ($rights >= 9) 
{ 
echo '<div class="rmenu">[<a href="'.$home.'/panel/index.php?act=forum&mod=edit&id=' . $res['id'] . '">Edit</a>] | [<a href="'.$home.'/panel/index.php?act=forum&mod=del&id=' . $res['id'] . '">Delete</a>]</div>';
}
++$i;
}
echo '</div>';
}

}
?>