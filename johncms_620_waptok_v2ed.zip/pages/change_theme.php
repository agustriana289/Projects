<?php
/**
 * Change Theme JohnCMS v620
 * http://www.waptok.asia
 */

echo'<div class="mainblok"><div class="phdr"><b>' . $lng['change_theme'] . '</b></div>';
echo'<div class="menu">';
if ($user_id || $set['active']) {
echo '<form action="../users/?act=setskin" method="post" ><select name="skin">';
foreach (glob($rootpath . 'theme/*/*.css') as $val) {
$dir = explode('/', dirname($val));
$theme = array_pop($dir);
echo '<option' . (core::$user_set['skin'] == $theme ? ' selected="selected">' : '>') . $theme . '</option>';
}
echo '</select>' .
'<input type="submit" name="submit" value="' . $lng['change'] . '"/></form></div>';
}
echo'</div>';
?>