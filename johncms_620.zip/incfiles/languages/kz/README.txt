Kazakh language pack
============================================================
TRANSLATION AUTHORS:
Nurdaulet (http://kzwap.net, wen.kz@list.ru)