Georgian language pack
============================================================
TRANSLATION AUTHORS:
QOQOSA (http://getwap.in, nz2607@gmail.com), სპეციალურად ქართველი მომხმარებლებისთვის