La langue francaise 
L'auteur de la traduction: Black_Cat 
Profil: http://johncms.com/users/profile.php?user=32684
La date de la traduction: 04.11.2015