Polish language pack
============================================================
TRANSLATION AUTHORS:
Bazyl (xboot@o2.pl)