Chinese language pack
============================================================
TRANSLATION AUTHORS:
旭小东and媛小媛 (http://v-wap.com, QQ: 260775007), 本语言包仅供参考